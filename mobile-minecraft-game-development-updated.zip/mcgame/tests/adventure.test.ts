import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { ALL_ITEMS, B, BLOCKS, I, MINERALS, RECIPES, STATION_BLOCKS, TILES, TIERS, TOOL_TYPES, isPlaceable, maxStack, recipeStation, toolId, type Station } from '../src/game/blocks.ts';
import { craftInventory, makeSlot } from '../src/game/inventory.ts';
import { BOSS_MAX_HP, journeySteps, newAdventure } from '../src/game/adventure.ts';
import { World } from '../src/game/world.ts';
import { CombatSystem } from '../src/game/combat.ts';
import { setSoundEnabled } from '../src/game/sound.ts';
import type { Engine } from '../src/game/engine.ts';
import type { Slot } from '../src/game/settings.ts';

test('catalog IDs, textures, recipes and all seven tool tiers are valid', () => {
  assert.equal(new Set(ALL_ITEMS).size, ALL_ITEMS.length);
  BLOCKS.forEach((item, id) => {
    assert.ok(item.tiles.every((tile) => tile >= 0 && tile < TILES.length), `Missing texture for ${id}`);
    if (isPlaceable(id)) assert.ok(id > 0 && id < 256);
  });
  RECIPES.forEach((recipe) => {
    assert.ok(BLOCKS[recipe.out]);
    assert.ok(recipe.count > 0);
    recipe.input.forEach(([id, count]) => { assert.ok(BLOCKS[id]); assert.ok(count > 0); });
  });
  TIERS.forEach((tier) => TOOL_TYPES.forEach((tool) => {
    const id = toolId(tier.key, tool);
    assert.equal(BLOCKS[id].tool, tool);
    assert.equal(BLOCKS[id].durability, tier.durability);
    assert.equal(maxStack(id), 1);
    assert.ok(RECIPES.some((recipe) => recipe.out === id));
  }));
  assert.equal(MINERALS.length, 11);
});

test('a full backpack never consumes ingredients if the result cannot fit', () => {
  const inventory: (Slot | null)[] = Array.from({ length: 36 }, () => makeSlot(I.STICK, 64));
  inventory[0] = makeSlot(B.LOG, 64);
  const before = JSON.stringify(inventory);
  const recipe = RECIPES.find((r) => r.out === B.PLANKS && r.input[0][0] === B.LOG)!;
  assert.equal(craftInventory(inventory, recipe).ok, false);
  assert.equal(JSON.stringify(inventory), before);
});

test('crafting consumes exactly once and creates separate non-stackable tools', () => {
  const inventory: (Slot | null)[] = Array(36).fill(null);
  inventory[0] = makeSlot(B.PLANKS, 6);
  inventory[1] = makeSlot(I.STICK, 4);
  const id = toolId('wood', 'pickaxe');
  const recipe = RECIPES.find((r) => r.out === id)!;
  const first = craftInventory(inventory, recipe);
  assert.equal(first.ok, true);
  if (!first.ok) return;
  const second = craftInventory(first.inventory, recipe);
  assert.equal(second.ok, true);
  if (!second.ok) return;
  assert.equal(second.inventory.filter((slot) => slot?.id === id).length, 2);
  assert.ok(second.inventory.filter((slot) => slot?.id === id).every((slot) => slot?.count === 1 && slot.durability === 59));
  assert.equal(craftInventory(second.inventory, recipe).ok, false);
});

test('netherite upgrades preserve enchantments and remove their ingredients', () => {
  const inventory: (Slot | null)[] = Array(36).fill(null);
  inventory[0] = { ...makeSlot(toolId('diamond', 'sword')), enchant: 2, durability: 700 };
  inventory[1] = makeSlot(I.NETHERITE);
  inventory[2] = makeSlot(I.UPGRADE);
  const recipe = RECIPES.find((r) => r.out === toolId('netherite', 'sword'))!;
  const result = craftInventory(inventory, recipe);
  assert.equal(result.ok, true);
  if (!result.ok) return;
  const sword = result.inventory.find((slot) => slot?.id === recipe.out);
  assert.equal(sword?.enchant, 2);
  assert.equal(sword?.durability, 2031);
  assert.equal(result.inventory.filter(Boolean).length, 1);
});

test('the crafting and mining dependency graph can reach the final portal and every tool', () => {
  const reachable = new Set<number>([B.LOG, B.BIRCH_LOG, B.DIRT, B.SAND, B.GRAVEL, B.LEAVES, I.APPLE, I.SEEDS, I.WHEAT]);
  const stations = new Set<Station>(['hand']);
  const natural = [B.STONE, B.COAL, B.IRON, B.COPPER, B.GOLD, B.REDSTONE, B.LAPIS, B.DIAMOND, B.EMERALD, B.AMETHYST, B.OBSIDIAN];
  const nether = [B.NETHERRACK, B.NETHER_GOLD, B.QUARTZ_ORE, B.ANCIENT_DEBRIS];
  for (let pass = 0; pass < 30; pass++) {
    let pickTier = 0;
    reachable.forEach((id) => { if (BLOCKS[id].tool === 'pickaxe') pickTier = Math.max(pickTier, BLOCKS[id].tier ?? 0); });
    const canEnterNether = reachable.has(B.OBSIDIAN) && reachable.has(I.FLINT_STEEL);
    for (const id of [...natural, ...(canEnterNether ? nether : [])]) {
      if ((BLOCKS[id].minTier ?? 0) <= pickTier) reachable.add(BLOCKS[id].drop ?? id);
    }
    if (reachable.has(toolId('wood', 'sword'))) [I.STRING, I.LEATHER, I.PEARL, I.STEAK].forEach((id) => reachable.add(id));
    if (canEnterNether) reachable.add(I.BLAZE_ROD);
    for (const [id, station] of Object.entries(STATION_BLOCKS)) if (station && reachable.has(Number(id))) stations.add(station);
    for (const recipe of RECIPES) if (stations.has(recipeStation(recipe)) && recipe.input.every(([id]) => reachable.has(id))) reachable.add(recipe.out);
  }
  assert.ok(reachable.has(B.END_FRAME));
  assert.ok(reachable.has(I.EYE));
  TIERS.forEach((tier) => TOOL_TYPES.forEach((tool) => assert.ok(reachable.has(toolId(tier.key, tool)), `${tier.key}/${tool} is unreachable`)));
  MINERALS.forEach((mineral) => assert.ok(reachable.has(mineral.item)));
});

test('both overworld and Nether generate real obtainable mineral blocks', () => {
  const world = new World(1337, 'plano');
  const found = new Set<number>();
  for (let z = -1; z <= 1; z++) for (let x = -1; x <= 1; x++) world.generate(x, z).data.forEach((id) => found.add(id));
  for (const id of [B.COAL, B.IRON, B.COPPER, B.DIAMOND, B.REDSTONE, B.LAPIS, B.OBSIDIAN]) assert.ok(found.has(id) || [...found].some((block) => BLOCKS[block]?.drop === BLOCKS[id].drop), `Missing ore ${id}`);
  const nether = new World(1337, 'normal', {}, 'nether');
  const netherFound = new Set<number>();
  for (let z = -1; z <= 1; z++) for (let x = -1; x <= 1; x++) nether.generate(x, z).data.forEach((id) => netherFound.add(id));
  for (const id of [B.ANCIENT_DEBRIS, B.QUARTZ_ORE, B.NETHER_GOLD]) assert.ok(netherFound.has(id));
});

test('four crystals gate the dragon; defeating it awards one trophy and completes the journey', () => {
  setSoundEnabled(false);
  const world = new World(1337, 'normal', {}, 'end');
  for (let z = -2; z <= 2; z++) for (let x = -2; x <= 2; x++) world.generate(x, z);
  const rewards: number[] = [];
  const progress = newAdventure();
  const camera = new THREE.PerspectiveCamera();
  const host = {
    world, scene: new THREE.Scene(), camera, adventure: progress, dimension: 'end',
    settings: { preset: 'rapido' }, pos: new THREE.Vector3(8.5, 33, 14.5), health: 20,
    notify: () => {}, damage: () => {}, addItem: (id: number) => rewards.push(id),
    emitHud: () => {}, setPaused: () => {}, dropLoot: () => {}, serialize: () => ({ mods: {} }), cb: { onAutosave: () => {} },
  } as unknown as Engine;
  const combat = new CombatSystem(host);
  combat.update(0);
  const aim = (from: number[], to: number[]) => { camera.position.set(from[0], from[1], from[2]); camera.lookAt(to[0], to[1], to[2]); camera.updateMatrixWorld(true); };
  aim([8.5, 39, 3], [8.5, 39, -4]);
  combat.melee(BOSS_MAX_HP, 8);
  assert.equal(progress.bossHealth, BOSS_MAX_HP);
  for (const [x, y, z] of [[24.5, 36.1, 8.5], [-7.5, 36.1, 8.5], [8.5, 36.1, 24.5], [8.5, 36.1, -7.5]]) {
    aim([x + 3, y, z], [x, y, z]);
    assert.equal(combat.melee(12, 4.5), true);
  }
  assert.equal(progress.crystals.length, 4);
  aim([8.5, 39, 3], [8.5, 39, -4]);
  combat.melee(BOSS_MAX_HP, 8);
  assert.equal(progress.victory, true);
  assert.equal(progress.bossHealth, 0);
  assert.deepEqual(rewards, [I.TROPHY]);
  assert.ok(journeySteps(progress).every((step) => step.done));
  combat.melee(BOSS_MAX_HP, 8);
  assert.equal(rewards.length, 1);
  combat.dispose();
});