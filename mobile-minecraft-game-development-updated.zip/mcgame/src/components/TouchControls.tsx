import { useEffect, useRef, type ReactNode, type CSSProperties } from 'react';
import type { Engine } from '../game/engine';
import type { Settings } from '../game/settings';
import { unlockAudio } from '../game/sound';

interface LookTouch {
  lx: number;
  ly: number;
  sx: number;
  sy: number;
  t: number;
  moved: boolean;
  breaking: boolean;
  timer: number;
}

function HoldButton({ onDown, onUp, children, style, className = '', label }: { onDown: () => void; onUp?: () => void; children: ReactNode; style: CSSProperties; className?: string; label?: string }) {
  const up = () => onUp?.();
  return (
    <button type="button" aria-label={label} data-silent
      className={`touch-action-button absolute z-30 flex items-center justify-center border-2 border-white/40 bg-black/30 text-white/90 active:bg-white/30 select-none ${className}`}
      style={{ touchAction: 'none', opacity: 'var(--touch-opacity, 0.7)', ...style }}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
        unlockAudio();
        onDown();
      }}
      onPointerUp={up}
      onPointerCancel={up}
      onLostPointerCapture={up}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

export default function TouchControls({ engine, settings, creative, flying, hasShield }: { engine: () => Engine | null; settings: Settings; creative: boolean; flying: boolean; hasShield: boolean }) {
  const base = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLDivElement>(null);
  const st = useRef({ joyId: -1, ox: 0, oy: 0, attackHeld: false, looks: new Map<number, LookTouch>() });
  const S = Math.max(0.65, Math.min(settings.buttonSize, (window.innerHeight - 110) / 240, window.innerWidth * 0.36 / 165));
  const R = 52 * S;
  const B = 62 * S;
  const bottom = 72;
  const defaultJoy = { x: 40 + R, y: window.innerHeight - bottom - R - 20 };

  useEffect(() => {
    const state = st.current;
    return () => {
      state.looks.forEach((touch) => clearTimeout(touch.timer));
      state.looks.clear();
      const e = engine();
      if (e) { e.input.moveX = e.input.moveY = 0; e.input.breaking = e.input.blocking = e.input.jump = e.input.down = e.input.sprint = e.input.useHeld = false; }
    };
  }, [engine]);

  const placeJoy = (x: number, y: number, active: boolean) => {
    if (base.current) {
      base.current.style.left = `${x - R}px`;
      base.current.style.top = `${y - R}px`;
      base.current.style.opacity = `${settings.touchOpacity * (active ? 1 : 0.65)}`;
    }
    if (knob.current) knob.current.style.transform = 'translate(0px,0px)';
  };

  const onStart = (e: React.TouchEvent) => {
    unlockAudio();
    const eng = engine();
    if (!eng) return;
    const s = st.current;
    for (const t of Array.from(e.changedTouches)) {
      if (t.clientX < window.innerWidth * 0.42 && s.joyId === -1) {
        s.joyId = t.identifier;
        s.ox = t.clientX;
        s.oy = t.clientY;
        placeJoy(t.clientX, t.clientY, true);
      } else {
        const lt: LookTouch = { lx: t.clientX, ly: t.clientY, sx: t.clientX, sy: t.clientY, t: performance.now(), moved: false, breaking: false, timer: 0 };
        lt.timer = window.setTimeout(() => {
          if (!lt.moved) {
            lt.breaking = true;
            eng.input.breaking = true;
          }
        }, 260);
        s.looks.set(t.identifier, lt);
      }
    }
  };

  const onMove = (e: React.TouchEvent) => {
    const eng = engine();
    if (!eng) return;
    const s = st.current;
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier === s.joyId) {
        let dx = t.clientX - s.ox, dy = t.clientY - s.oy;
        const d = Math.hypot(dx, dy);
        if (d > R) {
          dx = (dx / d) * R;
          dy = (dy / d) * R;
        }
        if (knob.current) knob.current.style.transform = `translate(${dx}px,${dy}px)`;
        const dead = 0.12;
        const nx = dx / R, ny = -dy / R;
        eng.input.moveX = Math.abs(nx) < dead ? 0 : nx;
        eng.input.moveY = Math.abs(ny) < dead ? 0 : ny;
        eng.input.sprint = d >= R * 0.98 && ny > 0.7;
      } else {
        const lt = s.looks.get(t.identifier);
        if (!lt) continue;
        const dx = t.clientX - lt.lx, dy = t.clientY - lt.ly;
        lt.lx = t.clientX;
        lt.ly = t.clientY;
        if (!lt.moved && Math.hypot(t.clientX - lt.sx, t.clientY - lt.sy) > 12) {
          lt.moved = true;
        }
        const k = 0.0052 * settings.sensitivity;
        eng.input.lookX += dx * k;
        eng.input.lookY += dy * k * (settings.invertY ? -1 : 1);
      }
    }
  };

  const onEnd = (e: React.TouchEvent, cancelled = false) => {
    const eng = engine();
    const s = st.current;
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier === s.joyId) {
        s.joyId = -1;
        placeJoy(defaultJoy.x, defaultJoy.y, false);
        if (eng) {
          eng.input.moveX = 0;
          eng.input.moveY = 0;
          eng.input.sprint = false;
        }
      } else {
        const lt = s.looks.get(t.identifier);
        if (!lt) continue;
        clearTimeout(lt.timer);
        s.looks.delete(t.identifier);
        if (!eng) continue;
        if (lt.breaking) {
          eng.input.breaking = s.attackHeld || [...s.looks.values()].some((l) => l.breaking);
        } else if (!cancelled && settings.tapToUse && !lt.moved && performance.now() - lt.t < 260) {
          eng.input.place = true;
        }
      }
    }
  };

  const fs = (n: number) => `${n * S}px`;

  return (
    <div className="contents" style={{ '--touch-opacity': settings.touchOpacity } as CSSProperties}>
      <div className="absolute inset-0 z-10" style={{ touchAction: 'none' }} onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={(e) => onEnd(e)} onTouchCancel={(e) => onEnd(e, true)} />
      {/* joystick */}
      <div
        ref={base}
        className="pointer-events-none absolute z-20 rounded-full border-2 border-white/50 bg-black/25"
        style={{ width: R * 2, height: R * 2, left: defaultJoy.x - R, top: defaultJoy.y - R, opacity: settings.touchOpacity * 0.65 }}
      >
        <div
          ref={knob}
          className="absolute rounded-full border-2 border-white/70 bg-white/40"
          style={{ width: R, height: R, left: R / 2, top: R / 2 }}
        />
      </div>

      {/* action buttons */}
      <HoldButton
        label="Pular"
        style={{ width: B * 1.1, height: B * 1.1, right: 18, bottom, fontSize: fs(30) }}
        onDown={() => {
          const e = engine();
          if (!e) return;
          e.input.jump = true;
          e.jumpPressed();
        }}
        onUp={() => {
          const e = engine();
          if (e) e.input.jump = false;
        }}
      >
        <svg viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><path d="M5 13h5v7h4v-7h5L12 4z" fill="currentColor" /></svg>
      </HoldButton>
      <HoldButton
        label="Usar item ou colocar bloco"
        style={{ width: B, height: B, right: 18 + B * 1.1 + 12, bottom, fontSize: fs(26) }}
        onDown={() => {
          const e = engine();
          if (e) {
            e.input.place = true;
            e.input.useHeld = true;
          }
        }}
        onUp={() => { const e = engine(); if (e) e.input.useHeld = false; }}
      >
        <span className="text-base">USAR</span>
      </HoldButton>
      <HoldButton
        label="Atacar ou minerar"
        style={{ width: B, height: B, right: 18 + B * 1.1 + 12, bottom: bottom + B + 12, fontSize: fs(26) }}
        onDown={() => {
          const e = engine();
          st.current.attackHeld = true;
          if (e) e.input.breaking = true;
        }}
        onUp={() => {
          const e = engine();
          st.current.attackHeld = false;
          if (e) e.input.breaking = [...st.current.looks.values()].some((l) => l.breaking);
        }}
      >
        <span className="text-base leading-none">ATACAR<br /><small className="text-xs opacity-70">MINAR</small></span>
      </HoldButton>
      {!creative && hasShield && <HoldButton label="Defender com escudo" style={{ width: B * 1.1, height: B, right: 18, bottom: bottom + B * 1.1 + 12 }}
        onDown={() => { const e = engine(); if (e) e.input.blocking = true; }}
        onUp={() => { const e = engine(); if (e) e.input.blocking = false; }}>
        <span className="text-base">DEFENDER</span>
      </HoldButton>}
      {!creative && <HoldButton label="Agachar" style={{ width: B * 1.1, height: B * 0.58, right: 18, bottom: hasShield ? bottom + B * 2.1 + 24 : bottom + B * 1.1 + 12 }}
        onDown={() => { const e = engine(); if (e) e.input.down = true; }}
        onUp={() => { const e = engine(); if (e) e.input.down = false; }}><span className="text-sm">AGACHAR</span></HoldButton>}
      {creative && (
        <HoldButton
          className={flying ? 'border-sky-300/80!' : ''}
          style={{ width: B * 1.1, height: B, right: 18, bottom: bottom + B * 1.1 + 12, fontSize: fs(flying ? 28 : 24) }}
          onDown={() => {
            const e = engine();
            if (!e) return;
            if (flying) e.input.down = true;
            else e.toggleFly();
          }}
          onUp={() => {
            const e = engine();
            if (e) e.input.down = false;
          }}
        >
          <span className="text-base">{flying ? 'DESCER' : 'VOAR'}</span>
        </HoldButton>
      )}
      {creative && flying && (
        <HoldButton
          style={{ width: B * 0.8, height: B * 0.6, right: 18, bottom: bottom + B * 2.1 + 24, fontSize: fs(13) }}
          onDown={() => engine()?.toggleFly()}
        >
          <span className="text-base leading-none">POUSAR</span>
        </HoldButton>
      )}
    </div>
  );
}
