import { B, BLOCKS, ingredientMatches, maxStack, type Recipe } from './blocks';
import type { Slot } from './settings';

export function makeSlot(id: number, count = 1): Slot {
  const durability = BLOCKS[id]?.durability;
  return durability ? { id, count: 1, durability } : { id, count };
}

export function cloneInventory(inventory: (Slot | null)[]) {
  return inventory.map((slot) => slot ? { ...slot } : null);
}

export function normalizeSlot(slot: Slot | null | undefined): Slot | null {
  if (!slot || !BLOCKS[slot.id] || slot.id === 0 || !Number.isFinite(slot.count) || Math.floor(slot.count) <= 0) return null;
  if (BLOCKS[slot.id].durability && slot.durability !== undefined && slot.durability <= 0) return null;
  const out = makeSlot(slot.id, Math.min(maxStack(slot.id), Math.floor(slot.count)));
  if (BLOCKS[slot.id].durability) out.durability = Math.max(1, Math.min(BLOCKS[slot.id].durability!, Number.isFinite(slot.durability) ? slot.durability! : BLOCKS[slot.id].durability!));
  if (slot.enchant && Number.isFinite(slot.enchant)) out.enchant = Math.max(0, Math.min(3, Math.floor(slot.enchant)));
  return out;
}

export function insertItem(inventory: (Slot | null)[], id: number, count: number, template?: Slot) {
  if (!BLOCKS[id] || id === 0 || !Number.isInteger(count) || count <= 0) return count;
  const limit = maxStack(id);
  let left = count;
  if (limit > 1) for (const slot of inventory) {
    if (!slot || slot.id !== id || slot.count >= limit || template && !sameStack(slot, template)) continue;
    const amount = Math.min(limit - slot.count, left);
    slot.count += amount;
    left -= amount;
    if (!left) return 0;
  }
  for (let i = 0; i < inventory.length && left > 0; i++) {
    if (inventory[i]) continue;
    const amount = Math.min(limit, left);
    inventory[i] = template ? { ...template, count: amount } : makeSlot(id, amount);
    left -= amount;
  }
  return left;
}

export function itemCount(inventory: (Slot | null)[], id: number) {
  return inventory.reduce((count, slot) => count + (slot?.id === id ? slot.count : 0), 0);
}

export function ingredientCount(inventory: (Slot | null)[], id: number) {
  return inventory.reduce((count, slot) => count + (slot && ingredientMatches(id, slot.id) ? slot.count : 0), 0);
}

export function consume(inventory: (Slot | null)[], ingredients: [number, number][], exact = false) {
  if (ingredients.some(([id, n]) => !BLOCKS[id] || !Number.isInteger(n) || n <= 0)) return false;
  const totals = new Map<number, number>();
  ingredients.forEach(([id, count]) => totals.set(id, (totals.get(id) ?? 0) + count));
  // Reserve specific species before wildcard planks; overlapping ingredients cannot double-count a stack.
  const working = cloneInventory(inventory);
  const order = [...totals].sort(([a], [b]) => (a === B.PLANKS ? 1 : 0) - (b === B.PLANKS ? 1 : 0));
  for (const [id, count] of order) {
    let left = count;
    for (let i = 0; i < working.length && left > 0; i++) {
      const slot = working[i];
      if (!slot || !(exact ? slot.id === id : ingredientMatches(id, slot.id))) continue;
      const amount = Math.min(left, slot.count);
      left -= amount;
      slot.count -= amount;
      if (!slot.count) working[i] = null;
    }
    if (left) return false;
  }
  working.forEach((slot, index) => {
    if (!slot) inventory[index] = null;
    else if (inventory[index]) inventory[index]!.count = slot.count;
  });
  return true;
}

// Crafting is atomic: neither ingredients nor output are lost with a full inventory.
export function craftInventory(inventory: (Slot | null)[], recipe: Recipe, free = false, exact = false) {
  const next = cloneInventory(inventory);
  const donorId = recipe.station === 'smithing' ? recipe.input.find(([id]) => !!BLOCKS[id]?.durability)?.[0] : undefined;
  // Inherit from the actual first item consumed, not another copy elsewhere in the bag.
  const inherited = donorId === undefined ? 0 : inventory.find((slot) => slot?.id === donorId)?.enchant ?? 0;
  if (!free && !consume(next, recipe.input, exact)) return { ok: false as const, reason: 'Faltam materiais.' };
  const output = makeSlot(recipe.out, recipe.count);
  if (inherited && BLOCKS[recipe.out].durability) output.enchant = inherited;
  if (insertItem(next, recipe.out, recipe.count, output) > 0) return { ok: false as const, reason: 'Inventario cheio. Libere um espaco.' };
  return { ok: true as const, inventory: next };
}

export function organizeSlots(slots: (Slot | null)[]) {
  const occupied = slots.filter((slot): slot is Slot => !!slot).map((slot) => ({ ...slot })).sort((a, b) => {
    const kind = (id: number) => BLOCKS[id]?.kind ?? 'block';
    return kind(a.id).localeCompare(kind(b.id)) || a.id - b.id || (b.durability ?? 0) - (a.durability ?? 0);
  });
  const output: (Slot | null)[] = Array(slots.length).fill(null);
  for (const slot of occupied) insertItem(output, slot.id, slot.count, slot);
  return output;
}

export function transferStack(source: (Slot | null)[], destination: (Slot | null)[], index: number, count = Infinity) {
  if (source === destination || !Number.isInteger(index) || index < 0 || index >= source.length) return 0;
  const slot = source[index];
  if (!slot) return 0;
  const amount = Math.min(slot.count, count);
  if (!Number.isInteger(amount) || amount < 1) return 0;
  const left = insertItem(destination, slot.id, amount, slot);
  const moved = amount - left;
  slot.count -= moved;
  if (slot.count === 0) source[index] = null;
  return moved;
}

export function sameStack(a: Slot, b: Slot) {
  return a.id === b.id && a.durability === b.durability && (a.enchant ?? 0) === (b.enchant ?? 0);
}

export function clickStack(target: Slot | null, carried: Slot | null, right = false): { target: Slot | null; carried: Slot | null } {
  let next = target ? { ...target } : null, hand = carried ? { ...carried } : null;
  if (!hand) {
    if (!next) return { target: null, carried: null };
    const count = right ? Math.ceil(next.count / 2) : next.count;
    hand = { ...next, count }; next.count -= count;
    if (!next.count) next = null;
  } else if (!next) {
    const count = Math.min(right ? 1 : hand.count, maxStack(hand.id));
    next = { ...hand, count }; hand.count -= count;
    if (!hand.count) hand = null;
  } else if (sameStack(hand, next) && maxStack(next.id) > 1) {
    const count = Math.min(maxStack(next.id) - next.count, right ? 1 : hand.count);
    next.count += count; hand.count -= count;
    if (!hand.count) hand = null;
  } else if (!right) [next, hand] = [hand, next];
  return { target: next, carried: hand };
}