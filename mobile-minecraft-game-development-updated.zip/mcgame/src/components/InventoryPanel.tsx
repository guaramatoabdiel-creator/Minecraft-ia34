import { useEffect, useMemo, useRef, useState, type MouseEvent } from 'react';
import type { Engine, HudState } from '../game/engine';
import { ALL_ITEMS, ARMOR_SLOTS, BLOCKS, RECIPES, SLOT_NAMES, maxStack, type EquipmentSlot } from '../game/blocks';
import { BlockIcon, DurabilityBar, ItemStats } from './ui';
import { makeSlot, sameStack } from '../game/inventory';
import { allowedRecipe } from '../game/crafting';
import { searchText } from '../utils/search';
import type { Settings, Slot } from '../game/settings';
import { OUTFITS, SKIN_TONES } from '../game/playerModel';
import CharacterPreview from './CharacterPreview';

function EquipmentGlyph({ kind }: { kind: EquipmentSlot | 'book' | 'bag' }) {
  const paths = {
    head: 'M4 4h16v15h-5v-6H9v6H4z', chest: 'M7 3h3v4h4V3h3l5 5-4 3v10H6V11L2 8z',
    legs: 'M5 3h14v18h-6V11h-2v10H5z', feet: 'M5 3h5v18H2v-5h3zm9 0h5v13h3v5h-8z',
    offhand: 'M4 3h16v12l-8 7-8-7z', book: 'M3 4h7l2 2 2-2h7v16h-7l-2 2-2-2H3zm8 3v11h2V7z',
    bag: 'M8 2h8v4h4v16H4V6h4zm2 2v2h4V4zM7 13v6h10v-6z',
  };
  return <svg width="23" height="23" viewBox="0 0 24 24" aria-hidden="true"><path d={paths[kind]} fill="currentColor" fillRule="evenodd" /></svg>;
}

type Hover = { slot: Slot | null; name: string; bagIndex?: number; x: number; y: number };

export default function InventoryPanel({ hud, engine, creative, icons, onClose, settings, onSettings }: {
  hud: HudState; engine: Engine; creative: boolean; icons: string[]; onClose: () => void;
  settings: Settings; onSettings: (settings: Settings) => void;
}) {
  const [page, setPage] = useState<'survival' | 'creative'>(creative ? 'creative' : 'survival');
  const [book, setBook] = useState(false), [appearanceOpen, setAppearanceOpen] = useState(false);
  const [query, setQuery] = useState(''), [category, setCategory] = useState('all');
  const [message, setMessage] = useState('Clique para pegar e colocar. Botão direito divide a pilha.');
  const [hover, setHover] = useState<Hover | null>(null);
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [singlePlace, setSinglePlace] = useState(false);
  const carried = useRef<HTMLDivElement>(null);
  const pointer = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const latest = useRef({ hud, hover }); latest.current = { hud, hover };
  const profile = useMemo(() => ({ style: settings.playerStyle, skin: settings.skinTone }), [settings.playerStyle, settings.skinTone]);
  const recipeIndex = engine.personalRecipeIndex();
  const recipe = recipeIndex >= 0 ? RECIPES[recipeIndex] : null;
  const output = recipe ? makeSlot(recipe.out, recipe.count) : null;
  const canTake = !!output && (!hud.cursor || sameStack(output, hud.cursor) && hud.cursor.count + output.count <= maxStack(output.id));
  const catalog = useMemo(() => ALL_ITEMS.filter((id) => {
    const item = BLOCKS[id];
    return searchText(item.name).includes(searchText(query)) && (category === 'all' || category === 'blocks' && !item.kind || category === item.kind);
  }), [query, category]);
  const recipes = RECIPES.map((r, index) => ({ r, index })).filter(({ r, index }) => allowedRecipe(r, 'hand', 2) && searchText(BLOCKS[r.out].name).includes(searchText(query)) && (!onlyAvailable || engine.canCraft(index)));

  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(target.tagName) || event.repeat) return;
      const { hud: current, hover: focused } = latest.current;
      if (event.code === 'KeyQ') {
        event.preventDefault(); event.stopPropagation();
        if (current.cursor) engine.dropCarried(event.ctrlKey);
        else if (focused?.bagIndex !== undefined) engine.dropSlot(focused.bagIndex, event.ctrlKey);
      }
      if (/^Digit[1-9]$/.test(event.code)) {
        event.preventDefault(); const index = Number(event.code.slice(5)) - 1;
        if (current.cursor) engine.inventoryClick('bag', index);
        else if (focused?.bagIndex !== undefined) engine.swapSlots(focused.bagIndex, index);
      }
    };
    window.addEventListener('keydown', key, true);
    return () => window.removeEventListener('keydown', key, true);
  }, [engine]);

  useEffect(() => {
    if (carried.current) carried.current.style.transform = `translate(${pointer.current.x + 12}px, ${pointer.current.y + 10}px)`;
  }, [hud.cursor]);

  const point = (x: number, y: number) => {
    pointer.current = { x, y };
    if (carried.current) carried.current.style.transform = `translate(${Math.min(window.innerWidth - 54, x + 12)}px, ${Math.min(window.innerHeight - 54, y + 10)}px)`;
  };
  const labelSlot = (slot: Slot | null, name: string, event: MouseEvent<HTMLButtonElement>, bagIndex?: number) => {
    setHover({ slot, name, bagIndex, x: event.clientX, y: event.clientY });
  };
  const slotButton = (slot: Slot | null, area: 'bag' | 'craft', index: number, extra = '') => <button key={`${area}${index}`} type="button"
    className={`classic-slot ${slot?.enchant ? 'enchanted' : ''} ${extra}`} aria-label={slot ? `${BLOCKS[slot.id].name}, ${slot.count}` : 'Espaço vazio'}
    onMouseEnter={(event) => labelSlot(slot, slot ? BLOCKS[slot.id].name : '', event, area === 'bag' ? index : undefined)} onMouseLeave={() => setHover(null)}
    onFocus={(event) => { const rect = event.currentTarget.getBoundingClientRect(); setHover({ slot, name: slot ? BLOCKS[slot.id].name : '', x: rect.right, y: rect.top, bagIndex: area === 'bag' ? index : undefined }); }}
    onClick={(event) => {
      point(event.clientX, event.clientY);
      setHover(null);
      if (area === 'bag' && event.shiftKey && !hud.cursor) { engine.quickMove(index); return; }
      if (area === 'bag' && event.detail === 2 && !event.shiftKey) { engine.collectMatching(index); return; }
      engine.inventoryClick(area, index, singlePlace);
    }}
    onContextMenu={(event) => { event.preventDefault(); engine.inventoryClick(area, index, true); }}
    draggable={!!slot && !hud.cursor && area === 'bag'}
    onDragStart={(event) => { event.dataTransfer.setData('application/x-mineblock-slot', String(index)); setHover(null); }}
    onDragOver={(event) => event.preventDefault()} onDrop={(event) => {
      event.preventDefault(); const raw = event.dataTransfer.getData('application/x-mineblock-slot'); if (!/^\d+$/.test(raw)) return;
      const from = Number(raw); if (from < 0 || from >= 36) return;
      if (area === 'bag') engine.swapSlots(from, index);
      else { if (!engine.cursor) engine.inventoryClick('bag', from); engine.inventoryClick('craft', index, true); }
    }}>
    {slot && <><BlockIcon src={icons[slot.id]} size={48} /><span className="classic-count">{slot.count > 1 ? slot.count : ''}</span><DurabilityBar slot={slot} /></>}
  </button>;

  const equipSlot = (key: EquipmentSlot) => {
    const slot = hud.equipment[key];
    return <button key={key} className={`classic-slot armor-slot ${slot?.enchant ? 'enchanted' : ''}`} aria-label={`${SLOT_NAMES[key]}: ${slot ? BLOCKS[slot.id].name : 'vazio'}`}
      onClick={() => { if (!engine.equipmentClick(key)) setMessage('Selecione uma peça compatível para este espaço.'); }}
      onMouseEnter={(event) => labelSlot(slot, slot ? BLOCKS[slot.id].name : SLOT_NAMES[key], event)} onMouseLeave={() => setHover(null)}
      onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); const raw = event.dataTransfer.getData('application/x-mineblock-slot'); if (!/^\d+$/.test(raw)) return; const index = Number(raw); if (BLOCKS[hud.inventory[index]?.id ?? 0]?.equip === key) engine.equipItem(index); }}>
      {slot ? <><BlockIcon src={icons[slot.id]} size={48} /><DurabilityBar slot={slot} /></> : <EquipmentGlyph kind={key} />}
    </button>;
  };

  const takeResult = (shift: boolean) => { if (!engine.takePersonalCraft(shift, shift)) setMessage(engine.craftError); else setMessage('Item criado. Shift + clique envia a criação para a mochila.'); };
  const close = () => { engine.settleInventory(); onClose(); };

  return <div className="classic-inventory-overlay" onPointerMove={(event) => point(event.clientX, event.clientY)} onContextMenu={(event) => event.preventDefault()}>
    <div className={`classic-inventory-layout panel-enter ${book && page === 'survival' ? 'with-book' : ''}`}>
      {book && page === 'survival' && <aside className="classic-recipe-book">
        <div className="classic-book-title"><EquipmentGlyph kind="book" /><h3>Receitas</h3><button onClick={() => setBook(false)} aria-label="Fechar livro">×</button></div>
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar receita..." aria-label="Buscar receita" />
        <label><input type="checkbox" checked={onlyAvailable} onChange={(event) => setOnlyAvailable(event.target.checked)} /> Somente disponíveis</label>
        <div className="classic-recipe-grid scroll-thin">{recipes.map(({ r, index }) => <button key={index} className={`classic-slot ${engine.canCraft(index) ? 'available' : 'unavailable'}`} title={BLOCKS[r.out].name}
          onClick={() => { setMessage(engine.fillPersonalRecipe(index) ? 'Receita preenchida. Recolha o resultado.' : engine.craftError); }}>
          <BlockIcon src={icons[r.out]} size={44} /><span className="classic-count">{r.count > 1 ? r.count : ''}</span>
        </button>)}</div>
        <p>Criação 2 × 2. Ferramentas e receitas maiores precisam de uma mesa.</p>
      </aside>}

      <section className={`classic-inventory-main ${page === 'creative' ? 'catalog-open' : ''}`} aria-label="Inventário" role="dialog" aria-modal="true">
        <header className="classic-inventory-header"><div><span>MINEBLOCK</span><h2>{page === 'creative' ? 'Inventário criativo' : 'Inventário'}</h2></div><button className="classic-square-button" aria-label="Fechar inventário" onClick={close}>×</button></header>
        {creative && <nav className="classic-creative-tabs"><button className={page === 'creative' ? 'selected' : ''} onClick={() => { engine.settleInventory(); engine.emitHud(); setPage('creative'); }}><EquipmentGlyph kind="book" />Catálogo</button><button className={page === 'survival' ? 'selected' : ''} onClick={() => setPage('survival')}><EquipmentGlyph kind="bag" />Personagem</button></nav>}

        {page === 'survival' ? <>
          <div className="classic-inventory-top">
            <div className="classic-paperdoll">
              <div className="classic-armor-column">{ARMOR_SLOTS.slice(0, 4).map(equipSlot)}</div>
              <CharacterPreview appearance={profile} equipment={hud.equipment} held={hud.inventory[hud.selected]} pack={settings.texturePack} />
              <div className="classic-offhand">{equipSlot('offhand')}</div>
            </div>
            <div className="classic-personal-crafting">
              <h3>Criação</h3>
              <div className="classic-craft-line"><div className="classic-craft-grid">{hud.personalCraft.map((slot, index) => slotButton(slot, 'craft', index))}</div><svg viewBox="0 0 28 20" className="classic-craft-arrow" aria-hidden="true"><path d="M0 7h17V1l11 9-11 9v-6H0z" fill="currentColor" /></svg>
                <button className={`classic-slot classic-output ${recipe ? 'has-recipe' : ''}`} disabled={!recipe} onClick={(event) => takeResult(event.shiftKey)} aria-label={recipe ? `Criar ${BLOCKS[recipe.out].name}` : 'Resultado da criação'} title={canTake ? 'Recolher resultado. Shift: criar em lote.' : 'Libere a pilha que está segurando.'}>
                  {output && <><BlockIcon src={icons[output.id]} size={48} /><span className="classic-count">{output.count > 1 ? output.count : ''}</span></>}
                </button>
              </div>
              <div className="classic-craft-controls"><button className={`classic-book-toggle ${book ? 'active' : ''}`} onClick={() => { setBook(!book); setQuery(''); }} aria-label="Abrir livro de receitas"><EquipmentGlyph kind="book" /></button><button className="classic-small-button" onClick={() => { engine.settleInventory(); engine.emitHud(); setMessage('Ingredientes devolvidos ao inventário.'); }}>Devolver</button></div>
              <p className="classic-craft-note">{recipe ? BLOCKS[recipe.out].name : 'Escolha uma receita ou coloque ingredientes.'}</p>
            </div>
          </div>

          <div className="classic-bag-caption"><span>Mochila</span><button onClick={() => setAppearanceOpen(!appearanceOpen)} className="classic-text-button">{appearanceOpen ? 'Ocultar visual' : 'Visual do explorador'}</button></div>
          {appearanceOpen && <div className="explorer-customize"><span>Traje</span>{OUTFITS.map((outfit) => <button key={outfit.id} className={settings.playerStyle === outfit.id ? 'chosen' : ''} style={{ background: outfit.coat }} onClick={() => onSettings({ ...settings, playerStyle: outfit.id })} aria-label={`Traje ${outfit.name}`} title={outfit.name}><i style={{ background: outfit.trim }} /></button>)}<span>Pele</span>{SKIN_TONES.map((skin, index) => <button key={skin} className={settings.skinTone === index ? 'chosen' : ''} style={{ background: skin }} aria-label={`Tom de pele ${index + 1}`} onClick={() => onSettings({ ...settings, skinTone: index })} />)}</div>}
          <div className="classic-storage-grid">{hud.inventory.slice(9).map((slot, index) => slotButton(slot, 'bag', index + 9))}</div>
        </> : <>
          <div className="classic-catalog-search"><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar itens..." aria-label="Buscar itens" /><select aria-label="Categoria" value={category} onChange={(event) => setCategory(event.target.value)}><option value="all">Tudo</option><option value="blocks">Blocos</option><option value="tool">Ferramentas</option><option value="weapon">Armas</option><option value="armor">Equipamento</option><option value="material">Materiais</option><option value="food">Comida</option><option value="utility">Utilidades</option></select></div>
          <div className="classic-catalog-grid scroll-thin">{catalog.map((id) => <button key={id} className="classic-slot" title={BLOCKS[id].name} onMouseEnter={(event) => labelSlot(makeSlot(id), BLOCKS[id].name, event)} onMouseLeave={() => setHover(null)}
            onClick={(event) => { engine.setSlot(hud.selected, makeSlot(id, event.shiftKey ? maxStack(id) : 1)); setMessage(`${BLOCKS[id].name} colocado na barra rápida.`); }}><BlockIcon src={icons[id]} size={48} /></button>)}</div>
          {!catalog.length && <p className="classic-empty">Nenhum item encontrado.</p>}
        </>}

        <div className="classic-hotbar-grid">{hud.inventory.slice(0, 9).map((slot, index) => page === 'creative'
          ? <button key={index} className={`classic-slot ${hud.selected === index ? 'selected' : ''}`} onClick={() => engine.selectSlot(index)} aria-label={`Espaço ${index + 1}`}><BlockIcon src={slot ? icons[slot.id] : undefined} size={48} />{slot && <><span className="classic-count">{slot.count > 1 ? slot.count : ''}</span><DurabilityBar slot={slot} /></>}</button>
          : slotButton(slot, 'bag', index, hud.selected === index ? 'active-hand' : ''))}</div>

        <div className="classic-inventory-actions">
          <button className="classic-small-button" onClick={() => { engine.returnCarried(); engine.sortBackpack(); setMessage('Mochila organizada; barra rápida preservada.'); }}>Organizar</button>
          {hud.cursor ? <><button className="classic-small-button" onClick={() => engine.returnCarried()}>Guardar na mochila</button><button className="classic-small-button" onClick={() => engine.dropCarried(true)}>Soltar pilha</button>{BLOCKS[hud.cursor.id].food && <button className="classic-small-button" onClick={() => { if (engine.eatCarried()) close(); else setMessage('Você já está bem alimentado.'); }}>Comer</button>}</> : <span>{hud.inventory.filter(Boolean).length}/36 espaços</span>}
          <button className={`classic-small-button classic-touch-mode ${singlePlace ? 'enabled' : ''}`} onClick={() => setSinglePlace(!singlePlace)}>{singlePlace ? 'Uma unidade' : 'Pilha inteira'}</button>
          {hud.reserveCount > 0 && <button className="classic-small-button" onClick={() => engine.collectReserve()}>Reserva ({hud.reserveCount})</button>}
        </div>
        {hud.cursor && <div className="classic-touch-carried"><BlockIcon src={icons[hud.cursor.id]} size={24} /><span>{hud.cursor.count}x {BLOCKS[hud.cursor.id].name}</span><small>Toque onde deseja colocar.</small></div>}
        <footer className="classic-inventory-footer" role="status">{message}</footer>
      </section>
    </div>
    <div className="classic-inventory-help"><kbd>E</kbd> fechar <span>·</span> Shift + clique: transferir <span>·</span> Direito: dividir / colocar 1 <span>·</span> <kbd>Q</kbd> soltar</div>
    {hover?.name && !hud.cursor && <div className="classic-item-tooltip" style={{ left: Math.min(window.innerWidth - 230, Math.max(8, hover.x + 16)), top: Math.min(window.innerHeight - 115, Math.max(8, hover.y + 15)) }} role="tooltip"><strong>{hover.name}</strong>{hover.slot && <ItemStats slot={hover.slot} />}{hover.slot?.id && BLOCKS[hover.slot.id].equip && <small>Coloque no espaço de armadura correspondente.</small>}</div>}
    {hud.cursor && <div ref={carried} className="classic-carried-item" aria-hidden="true"><BlockIcon src={icons[hud.cursor.id]} size={46} /><span>{hud.cursor.count > 1 ? hud.cursor.count : ''}</span></div>}
  </div>;
}