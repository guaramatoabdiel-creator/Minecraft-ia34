import { useState } from 'react';
import type { Engine, HudState } from '../game/engine';
import { B } from '../game/blocks';
import { BlockIcon, ItemSlot, McButton } from './ui';

export default function ChestPanel({ hud, engine, icons, onClose }: { hud: HudState; engine: Engine; icons: string[]; onClose: () => void }) {
  const [one, setOne] = useState(false);
  const [message, setMessage] = useState('Toque em um item para movê-lo entre o baú e a mochila.');
  const move = (fromChest: boolean, index: number) => {
    setMessage(engine.transferChest(fromChest, index, one) ? fromChest ? 'Item recolhido do baú.' : 'Item guardado no baú.' : 'Sem espaço no destino.');
  };
  return <div className="game-modal"><div className="inventory-window chest-window panel-enter">
    <header className="window-heading"><div className="flex items-center gap-3"><BlockIcon src={icons[B.CHEST]} size={49} /><div><span className="window-kicker">MINEBLOCK / ARMAZENAMENTO</span><h2>Baú</h2></div></div><McButton className="compact-btn" onClick={onClose}>Fechar</McButton></header>
    <div className="window-content scroll-thin">
      {!hud.chest ? <p>O baú não está mais acessível.</p> : <>
        <div className="section-label">Baú <span>{hud.chest.filter(Boolean).length}/27 espaços</span></div>
        <div className="bag-grid">{hud.chest.map((slot, i) => <ItemSlot key={i} slot={slot} icons={icons} onClick={() => { if (slot) move(true, i); }} />)}</div>
        <div className="chest-actions"><McButton className="compact-btn" onClick={() => engine.transferAllChest(true)}>Guardar mochila</McButton><McButton className="compact-btn" onClick={() => engine.transferAllChest(false)}>Recolher tudo</McButton><label><input type="checkbox" checked={one} onChange={(e) => setOne(e.target.checked)} /> Uma unidade por toque</label></div>
        <div className="section-label mt-4">Inventário <span>A barra rápida não entra em “Guardar mochila”.</span></div>
        <div className="bag-grid">{hud.inventory.slice(9).map((slot, i) => <ItemSlot key={i + 9} slot={slot} icons={icons} onClick={() => { if (slot) move(false, i + 9); }} />)}</div>
        <div className="section-label mt-3">Barra rápida</div>
        <div className="bag-grid">{hud.inventory.slice(0, 9).map((slot, i) => <ItemSlot key={i} slot={slot} icons={icons} onClick={() => { if (slot) move(false, i); }} />)}</div>
        <p className="panel-hint">O conteúdo é salvo neste baú. Quebrá-lo derruba os itens guardados.</p>
      </>}
    </div><footer className="window-footer" aria-live="polite"><span>{message}</span></footer>
  </div></div>;
}