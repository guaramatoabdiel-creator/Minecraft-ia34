import type { Settings } from './settings';
import { B, BLOCKS, GRASS_IDS, LEAF_IDS } from './blocks';
import { updateMusic } from './music';

type Channel = 'ui' | 'blocks' | 'player' | 'creatures' | 'ambient' | 'music';
type Position = { x: number; y: number; z: number };
let context: AudioContext | null = null;
let noise: AudioBuffer | null = null;
let master: GainNode | null = null;
let config: Partial<Settings> = {};
let listener = { x: 0, y: 0, z: 0, yaw: 0 };
let caption: ((text: string) => void) | null = null;
let voices = 0;
let focused = true;
export let soundEnabled = true;
export const setSoundEnabled = (enabled: boolean) => { soundEnabled = enabled; updateMaster(); };

function updateMaster() {
  if (context && master) {
    master.gain.cancelScheduledValues(context.currentTime);
    master.gain.setTargetAtTime(soundEnabled && (focused || !config.muteOnBlur) ? (config.masterVolume ?? 0.75) : 0, context.currentTime, 0.06);
  }
}

export function configureAudio(settings: Settings) { config = settings; soundEnabled = settings.sound; updateMaster(); updateMusic(context, master, config, soundEnabled && (focused || !config.muteOnBlur)); }
export function setAudioFocus(active: boolean) { if (active !== focused) { focused = active; updateMaster(); } }
export function setAudioListener(pos: Position, yaw: number) { listener = { ...pos, yaw }; }
export function subscribeCaptions(fn: ((text: string) => void) | null) { caption = fn; }

export function unlockAudio() {
  if (typeof window === 'undefined') return;
  try {
    if (!context) {
      const Constructor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Constructor) return;
      context = new Constructor();
      master = context.createGain();
      const limiter = context.createDynamicsCompressor();
      limiter.threshold.value = -14; limiter.ratio.value = 8; limiter.knee.value = 12;
      master.connect(limiter).connect(context.destination);
      noise = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
      const data = noise.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      updateMaster();
    }
    if (context.state === 'suspended') void context.resume().catch(() => {});
  } catch { /* Audio is optional when a browser disallows it. */ }
}

function volume(channel: Channel) {
  const key = `${channel}Volume` as keyof Settings;
  const value = config[key];
  return typeof value === 'number' ? value : channel === 'music' ? 0.22 : 0.8;
}

function announce(text: string, channel: Channel, pos?: Position) {
  if (channel === 'ui' || channel === 'music' || !config.subtitles) return;
  if (pos && Math.hypot(pos.x - listener.x, pos.y - listener.y, pos.z - listener.z) > 32) return;
  caption?.(text);
}

interface VoiceOptions { channel: Channel; label?: string; position?: Position; delay?: number; noise?: boolean; filter?: BiquadFilterType; slide?: number; wave?: OscillatorType }

function voice(frequency: number, duration: number, amplitude: number, options: VoiceOptions) {
  const { channel, position, delay = 0 } = options;
  if (options.label) announce(options.label, channel, position);
  if (!soundEnabled || !focused && config.muteOnBlur || !context || !master || !noise || context.state !== 'running' || voices > 30 || !volume(channel)) return;
  const dx = position ? position.x - listener.x : 0, dz = position ? position.z - listener.z : 0;
  const distance = position ? Math.hypot(dx, position.y - listener.y, dz) : 0;
  if (distance > 40) return;
  const attenuation = position ? 1 / (1 + distance * distance * 0.03) : 1;
  const t = context.currentTime + delay;
  const gain = context.createGain();
  const pan = context.createStereoPanner();
  const filter = context.createBiquadFilter();
  pan.pan.value = position ? Math.max(-0.9, Math.min(0.9, (dx * Math.cos(listener.yaw) - dz * Math.sin(listener.yaw)) / Math.max(3, distance))) : 0;
  filter.type = options.filter ?? 'lowpass'; filter.frequency.value = options.noise ? frequency : 4500;
  gain.gain.setValueAtTime(0.001, t);
  gain.gain.exponentialRampToValueAtTime(Math.max(0.001, amplitude * volume(channel) * attenuation), t + 0.008);
  gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
  gain.connect(pan).connect(master);
  filter.connect(gain);
  const src = options.noise ? context.createBufferSource() : context.createOscillator();
  if (options.noise) { const bufferSource = src as AudioBufferSourceNode; bufferSource.buffer = noise; bufferSource.loop = true; }
  else {
    const oscillator = src as OscillatorNode;
    oscillator.type = options.wave ?? 'sine'; oscillator.frequency.setValueAtTime(frequency, t);
    if (options.slide) oscillator.frequency.exponentialRampToValueAtTime(Math.max(25, frequency + options.slide), t + duration);
  }
  voices++;
  src.connect(filter); src.start(t); src.stop(t + duration + 0.025);
  src.onended = () => { voices--; src.disconnect(); filter.disconnect(); gain.disconnect(); pan.disconnect(); };
}

function surface(id: number = B.STONE) {
  if ([B.WATER, B.LAVA].includes(id as 10 | 85)) return { name: 'Água', freq: 1600 };
  if (BLOCKS[id]?.preferredTool === 'axe') return { name: 'Madeira', freq: 430 };
  if (GRASS_IDS.has(id) || LEAF_IDS.has(id) || id === B.TALLGRASS) return { name: 'Grama', freq: 3200 };
  if (BLOCKS[id]?.preferredTool === 'shovel') return { name: 'Terra', freq: 1200 };
  if (id === B.GLASS || id === B.ICE) return { name: 'Vidro', freq: 6000 };
  return { name: 'Pedra', freq: 850 };
}

const playSurface = (id: number | undefined, action: 'step' | 'dig' | 'break' | 'place') => {
  const material = surface(id);
  voice(material.freq * (0.85 + Math.random() * 0.3), action === 'break' ? 0.22 : 0.09, action === 'step' ? 0.11 : 0.27, { channel: 'blocks', noise: true, label: action === 'step' ? `Passos: ${material.name.toLowerCase()}` : `${material.name}: ${action === 'break' ? 'quebrar' : action === 'place' ? 'colocar' : 'minerar'}` });
  if (action === 'break' && material.name === 'Vidro') for (let i = 0; i < 4; i++) voice(1800 + i * 400, 0.13, 0.025, { channel: 'blocks', delay: i * 0.024 });
};

export const sfx = {
  click: () => voice(640, 0.05, 0.10, { channel: 'ui', wave: 'triangle', slide: -160 }),
  select: () => voice(440, 0.035, 0.06, { channel: 'ui', wave: 'triangle' }),
  open: () => voice(190, 0.13, 0.10, { channel: 'ui', wave: 'triangle', slide: 90 }),
  close: () => voice(270, 0.1, 0.08, { channel: 'ui', wave: 'triangle', slide: -80 }),
  dig: (id?: number) => playSurface(id, 'dig'),
  brk: (id?: number) => playSurface(id, 'break'),
  place: (id?: number) => playSurface(id, 'place'),
  step: (id?: number) => playSurface(id, 'step'),
  hurt: () => { voice(145, 0.19, 0.16, { channel: 'player', wave: 'sawtooth', slide: -65, label: 'Jogador ferido' }); voice(800, 0.1, 0.18, { channel: 'player', noise: true }); },
  death: () => voice(110, 0.7, 0.2, { channel: 'player', wave: 'triangle', slide: -65, label: 'Jogador morreu' }),
  jump: () => voice(300, 0.06, 0.07, { channel: 'player', noise: true }),
  eat: () => { for (let i = 0; i < 3; i++) voice(1900, 0.1, 0.15, { channel: 'player', noise: true, delay: i * 0.12, label: i === 0 ? 'Comendo' : undefined }); },
  splash: () => voice(2400, 0.45, 0.25, { channel: 'player', noise: true, filter: 'bandpass', label: 'Mergulho' }),
  swim: () => voice(1000, 0.25, 0.12, { channel: 'player', noise: true, label: 'Nadando' }),
  swing: () => voice(1600, 0.13, 0.15, { channel: 'player', noise: true, filter: 'bandpass', label: 'Ataque' }),
  bow: () => voice(260, 0.18, 0.17, { channel: 'player', wave: 'triangle', slide: -170, label: 'Flecha disparada' }),
  block: () => { voice(180, 0.13, 0.22, { channel: 'player', wave: 'triangle', label: 'Escudo bloqueia' }); voice(1000, 0.08, 0.2, { channel: 'player', noise: true }); },
  equip: () => voice(900, 0.11, 0.11, { channel: 'player', noise: true, filter: 'highpass', label: 'Equipamento vestido' }),
  toolBreak: () => { voice(3200, 0.18, 0.24, { channel: 'player', noise: true, label: 'Equipamento quebrou' }); voice(310, 0.12, 0.13, { channel: 'player', slide: -170 }); },
  drop: () => voice(500, 0.09, 0.12, { channel: 'player', wave: 'triangle', slide: -270, label: 'Item solto' }),
  pickup: () => voice(820 + Math.random() * 200, 0.1, 0.09, { channel: 'player', slide: 240, label: 'Item coletado' }),
  pop: () => voice(860, 0.1, 0.1, { channel: 'player', slide: 260 }),
  craft: () => { voice(650, 0.11, 0.10, { channel: 'player', label: 'Item criado' }); voice(980, 0.15, 0.08, { channel: 'player', delay: 0.08 }); },
  smelt: () => voice(2100, 0.55, 0.1, { channel: 'blocks', noise: true, label: 'Fornalha crepita' }),
  enchant: () => { [440, 554, 659, 880].forEach((f, i) => voice(f, 0.7, 0.09, { channel: 'player', delay: i * 0.11, label: i === 0 ? 'Encantamento' : undefined })); },
  ignite: () => voice(4700, 0.22, 0.16, { channel: 'blocks', noise: true, label: 'Pederneira acesa' }),
  fuse: (pos?: Position) => voice(4700, 1.0, 0.16, { channel: 'creatures', noise: true, filter: 'highpass', position: pos, label: 'Chiado de explosão' }),
  boom: (pos?: Position) => { voice(250, 1.0, 0.6, { channel: 'blocks', noise: true, position: pos, label: 'Explosão' }); voice(70, 0.8, 0.25, { channel: 'blocks', wave: 'sawtooth', slide: -40, position: pos }); },
  portal: (travel = false) => { voice(travel ? 160 : 100, travel ? 1.6 : 1.2, 0.12, { channel: 'ambient', wave: 'sine', slide: travel ? 360 : 40, label: travel ? 'Travessia do portal' : 'Portal ressoa' }); voice(350, 1, 0.035, { channel: 'ambient', noise: true }); },
  eye: () => voice(1100, 0.3, 0.12, { channel: 'blocks', slide: -500, label: 'Olho do End inserido' }),
  mob: (kind: string, event: 'idle' | 'hurt' | 'death', pos: Position) => {
    const f = kind === 'cow' ? 85 : kind === 'pig' ? 210 : kind === 'skeleton' ? 950 : kind === 'spider' ? 2600 : kind === 'blaze' ? 350 : kind === 'shadow' ? 260 : kind === 'dragon' ? 65 : 115;
    voice(f, event === 'idle' ? 0.65 : 0.23, 0.14, { channel: 'creatures', wave: kind === 'shadow' ? 'sine' : 'sawtooth', slide: event === 'hurt' ? 85 : -f * 0.3, position: pos, label: `${({ zombie: 'Zumbi', skeleton: 'Esqueleto', spider: 'Aranha', shadow: 'Enderman', blaze: 'Blaze', cow: 'Vaca', pig: 'Porco', dragon: 'Dragão' } as Record<string, string>)[kind] ?? 'Criatura'}: ${event === 'hurt' ? 'ferido' : event === 'death' ? 'morreu' : 'por perto'}` });
    if (kind === 'skeleton' || kind === 'spider') voice(f * 2, 0.18, 0.16, { channel: 'creatures', noise: true, position: pos });
  },
  teleport: (pos?: Position) => voice(250, 0.5, 0.16, { channel: 'creatures', slide: 650, position: pos, label: 'Teletransporte' }),
  victory: () => [261, 329, 392, 523, 659, 784].forEach((f, i) => voice(f, 1.4, 0.13, { channel: 'player', delay: i * 0.19, label: i === 0 ? 'Vitória' : undefined })),
  ambient: (realm: string) => voice(realm === 'nether' ? 180 : 900, 1.8, 0.024, { channel: 'ambient', noise: true, filter: 'lowpass', label: realm === 'nether' ? 'Vento nas profundezas' : 'Vento suave' }),
};

export function tickMusic(_dt: number) {
  updateMusic(context, master, config, soundEnabled && (focused || !config.muteOnBlur));
}