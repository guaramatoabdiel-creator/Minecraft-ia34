import { BLOCKS, I } from './blocks';

const masks: Record<string, string[]> = {
  sword: [
    '.............aa.', '............aaa.', '...........aaaa.', '..........aaaa..',
    '.........aaaa...', '........aaaa....', '.......aaaa.....', '..gg..aaaa......',
    '..gggaaaa.......', '...gggaa........', '....ggg.........', '...h.ggg........',
    '..hh..gg........', '.hh.............', 'hh..............', 'h...............',
  ],
  pickaxe: [
    '................', '..aaaaaaa.......', '..aaaaaaaaa.....', '...aaaa.aaaa....',
    '.......h.aaaa...', '......hh..aaa...', '.....hh....aa...', '....hh.....aa...',
    '...hh.......a...', '..hh............', '.hh.............', 'hh..............',
    'h...............', '................', '................', '................',
  ],
  axe: [
    '................', '.......aaaa.....', '......aaaaaa....', '.....aaaaaaa....',
    '.....aaaaaaa....', '......aaaaa.....', '......hh.aa.....', '.....hh.........',
    '....hh..........', '...hh...........', '..hh............', '.hh.............',
    'hh..............', 'h...............', '................', '................',
  ],
  shovel: [
    '................', '..........aaa...', '.........aaaaa..', '........aaaaaa..',
    '........aaaaaa..', '........aaaaa...', '.......haaaa....', '......hh........',
    '.....hh.........', '....hh..........', '...hh...........', '..hh............',
    '.hh.............', 'hh..............', 'h...............', '................',
  ],
  hoe: [
    '................', '...aaaaaaa......', '...aaaaaaaa.....', '.......haaa.....',
    '......hh.aa.....', '.....hh..aa.....', '....hh..........', '...hh...........',
    '..hh............', '.hh.............', 'hh..............', 'h...............',
    '................', '................', '................', '................',
  ],
  head: [
    '................', '....aaaaaaa.....', '...aaaaaaaaa....', '..aaaaaaaaaaa...',
    '..aaaaaaaaaaa...', '..aaaaaaaaaaa...', '..aaa.....aaa...', '..aa.......aa...',
    '..aa.......aa...', '..aaa.....aaa...', '...aa.....aa....', '................',
    '................', '................', '................', '................',
  ],
  chest: [
    '................', '..aaa.....aaa...', '.aaaaa...aaaaa..', 'aaaaaa...aaaaaa.',
    'aaaaaaaaaaaaaaa.', 'aaaaaaaaaaaaaaa.', 'aaaaaaggggaaaaa.', '..aaaaggggaaa...',
    '..aaaaaaaaaaa...', '..aaaaaaaaaaa...', '..aaaaaaaaaaa...', '..aaaaaaaaaaa...',
    '..aaaaaaaaaaa...', '...aaaaaaaaa....', '................', '................',
  ],
  legs: [
    '................', '...aaaaaaaaa....', '...ggggggggg....', '...aaaaaaaaa....',
    '...aaaaaaaaa....', '...aaaa.aaaa....', '...aaaa.aaaa....', '...aaaa.aaaa....',
    '...aaaa.aaaa....', '...aaaa.aaaa....', '...aaaa.aaaa....', '...aaaa.aaaa....',
    '...aaaa.aaaa....', '...aaaa.aaaa....', '................', '................',
  ],
  feet: [
    '................', '................', '...aaa...aaa....', '...aaa...aaa....',
    '...aaa...aaa....', '...aaa...aaa....', '...aaa...aaa....', '..aaaa...aaaa...',
    '.aaaaa...aaaaa..', '.aaaaa...aaaaa..', '.ggggg...ggggg..', '................',
    '................', '................', '................', '................',
  ],
  shield: [
    '................', '..aaaaaaaaaaa...', '..ahhhhhhhhha...', '..ahhhhhhhhha...',
    '..ahhggghhhha...', '..ahhggghhhha...', '..ahhggghhhha...', '..ahhhhhhhhha...',
    '..ahhhhhhhhha...', '..ahhhhhhhhha...', '...ahhhhhhha....', '....ahhhhha.....',
    '.....ahhha......', '......aaa.......', '.......a........', '................',
  ],
  gem: [
    '................', '......aaaa......', '....aaaaaaaa....', '...aaaaaaaaaa...',
    '..aaaaaaaaaaaa..', '..aaaaaaaaaaaa..', '...aaaaaaaaaa...', '....aaaaaaaa....',
    '.....aaaaaa.....', '......aaaa......', '.......aa.......', '................',
    '................', '................', '................', '................',
  ],
  ingot: [
    '................', '................', '....aaaaaaaa....', '...aaaaaaaaaa...',
    '..aaaaaaaaaaaa..', '.aaaaaaaaaaaaaa.', '.aaaaaaaaaaaaaa.', '..aaaaaaaaaaaa..',
    '...aaaaaaaaaa...', '....aaaaaaaa....', '................', '................',
    '................', '................', '................', '................',
  ],
  stick: [
    '................', '............hh..', '...........hhh..', '..........hhh...',
    '.........hhh....', '........hhh.....', '.......hhh......', '......hhh.......',
    '.....hhh........', '....hhh.........', '...hhh..........', '..hhh...........',
    '.hhh............', '.hh.............', '................', '................',
  ],
  trident: [
    '..a....a....a...', '..a....a....a...', '..aa...a...aa...', '...aa..a..aa....',
    '....aaaaaaa.....', '.......a........', '.......a........', '.......a........',
    '.......a........', '.......a........', '.......a........', '.......a........',
    '.......a........', '.......a........', '.......a........', '................',
  ],
  mace: [
    '................', '.....aaaaaa.....', '....aaaaaaaa....', '....aaaaaaaa....',
    '....aaaaaaaa....', '.....aaaaaa.....', '.......hh.......', '.......hh.......',
    '.......hh.......', '.......hh.......', '.......hh.......', '.......hh.......',
    '.......gg.......', '................', '................', '................',
  ],
};

function rgb(hex: string): [number, number, number] {
  const n = Number.parseInt(hex.replace('#', ''), 16);
  return [n >> 16 & 255, n >> 8 & 255, n & 255];
}

export function detailedItemPixels(id: number): Uint8ClampedArray | null {
  const item = BLOCKS[id];
  if (!item) return null;
  const shape = item.tool ?? item.sprite ?? '';
  const mask = masks[shape];
  if (!mask) return null;
  const tint = rgb(item.color ?? '#b0b8b6');
  const metallic = !!item.durability || shape === 'ingot';
  const palette: Record<string, number[]> = {
    a: id === I.SHIELD ? [163, 177, 181] : tint,
    h: shape === 'stick' ? tint : [140, 101, 57],
    g: id === I.SHIELD ? [185, 164, 109] : [Math.min(205, tint[0] * 0.58), Math.min(196, tint[1] * 0.57), Math.min(170, tint[2] * 0.56)],
  };
  const data = new Uint8ClampedArray(16 * 16 * 4);
  const occupied = (x: number, y: number) => x >= 0 && x < 16 && y >= 0 && y < 16 && mask[y]?.[x] !== '.' && !!mask[y]?.[x];
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const index = (y * 16 + x) * 4;
    if (!occupied(x, y)) {
      if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => occupied(x + dx, y + dy))) {
        data.set([38, 34, 35, 255], index);
      }
      continue;
    }
    const symbol = mask[y][x], color = palette[symbol] ?? tint;
    const upperEdge = !occupied(x, y - 1) || !occupied(x - 1, y);
    const lowerEdge = !occupied(x, y + 1) || !occupied(x + 1, y);
    let light = upperEdge ? 1.28 : lowerEdge ? 0.68 : 0.98 + ((x + y * 3) % 5) * 0.025;
    if ((shape === 'gem' || shape === 'ingot') && y >= 5) light *= 0.8;
    for (let c = 0; c < 3; c++) data[index + c] = Math.min(255, color[c] * light + (upperEdge && metallic && symbol === 'a' ? 14 : 0));
    data[index + 3] = 255;
  }
  return data;
}

export function detailedItemCanvas(id: number) {
  const data = detailedItemPixels(id);
  if (!data) return null;
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 16;
  const context = canvas.getContext('2d')!, image = context.createImageData(16, 16);
  image.data.set(data); context.putImageData(image, 0, 0);
  return canvas;
}