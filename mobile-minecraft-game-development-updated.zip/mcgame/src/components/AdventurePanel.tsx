import { useState } from 'react';
import { B, BLOCKS, I, MINERALS, TIERS, WOODS, toolId } from '../game/blocks';
import { currentObjective, journeySteps } from '../game/adventure';
import type { Adventure, Dimension, WorldSave } from '../game/settings';
import { BIOMES, BIOME_BY_ID, type BiomeId } from '../game/biomes';
import { BlockIcon, McButton } from './ui';

export default function AdventurePanel({ progress, icons, onClose, onPlay, creative = false, dimension, onReturn, onLocate, currentBiome, waypoint, onClearWaypoint }: {
  progress: Adventure; icons: string[]; onClose: () => void; onPlay?: () => void; creative?: boolean;
  dimension?: Dimension; onReturn?: () => void;
  onLocate?: (id: BiomeId) => boolean; currentBiome?: string; waypoint?: WorldSave['waypoint']; onClearWaypoint?: () => void;
}) {
  const [tab, setTab] = useState('journey');
  const current = currentObjective(progress);
  const [selectedStep, setSelectedStep] = useState(Math.min(current.index, current.total - 1));
  const steps = journeySteps(progress);
  const step = steps[selectedStep];
  const [selectedBiome, setSelectedBiome] = useState<BiomeId>(BIOMES.some((biome) => biome.id === currentBiome) ? currentBiome as BiomeId : 'forest');
  const [atlasMessage, setAtlasMessage] = useState('');
  const biome = BIOME_BY_ID[selectedBiome];
  const wood = WOODS.find((family) => family.key === biome.tree);

  return <div className="game-modal journal-modal">
    <div className="inventory-window journal-window panel-enter">
      <header className="window-heading"><div><span className="window-kicker">MINEBLOCK / GUIA DO AVENTUREIRO</span><h2>A jornada do Fim</h2></div><McButton className="compact-btn" onClick={onClose}>Voltar</McButton></header>
      <nav className="window-tabs" aria-label="Guia do aventureiro">
        <button className={tab === 'journey' ? 'selected' : ''} onClick={() => setTab('journey')}>Sua jornada</button>
        <button className={tab === 'minerals' ? 'selected' : ''} onClick={() => setTab('minerals')}>Guia de minerais</button>
        <button className={tab === 'gear' ? 'selected' : ''} onClick={() => setTab('gear')}>Equipamento e combate</button>
        <button className={tab === 'portals' ? 'selected' : ''} onClick={() => setTab('portals')}>Portais e itens</button>
        <button className={tab === 'biomes' ? 'selected' : ''} onClick={() => setTab('biomes')}>Atlas de biomas</button>
        <button className={tab === 'survival' ? 'selected' : ''} onClick={() => setTab('survival')}>Fome e cultivo</button>
      </nav>
      <div className="window-content scroll-thin">
        {tab === 'journey' && <div className="journey-layout">
          <nav className="chapter-list" aria-label="Etapas da aventura">{steps.map((s, index) => <button key={s.title} onClick={() => setSelectedStep(index)} className={`${selectedStep === index ? 'chosen' : ''} ${s.done ? 'finished' : ''}`}>
            <span className="chapter-number">{s.done ? '+' : String(index + 1).padStart(2, '0')}</span><span>{s.title}</span>{current.index === index && <i className="available-dot" />}
          </button>)}</nav>
          <section className="chapter-detail" key={selectedStep}>
            <span className="window-kicker">CAPÍTULO {String(selectedStep + 1).padStart(2, '0')} / {step.done ? 'CONCLUÍDO' : 'A DESCOBRIR'}</span>
            <BlockIcon src={icons[step.icon]} size={108} className="chapter-icon" />
            <h3>{step.title}</h3><p>{step.text}</p>
            <div className="journey-progress-label"><span>{current.completed} de {current.total} etapas</span><span>{Math.round(current.completed / current.total * 100)}%</span></div>
            <div className="journey-progress"><div style={{ width: `${current.completed / current.total * 100}%` }} /></div>
            <McButton className="active" onClick={onPlay ?? onClose}>{onPlay ? 'Começar a aventura' : 'Retomar jornada'}</McButton>
            {dimension && dimension !== 'overworld' && onReturn && (creative || progress.victory) && <button className="text-action" onClick={onReturn}>Voltar à superfície. O progresso da luta será mantido.</button>}
            {dimension && dimension !== 'overworld' && !creative && !progress.victory && <p className="panel-hint">Para voltar à superfície, entre no portal da área de chegada.</p>}
            {creative && <p className="panel-hint">Modo criativo: teste os equipamentos e o chefe livremente. Para a campanha com recursos e dano, escolha Sobrevivência.</p>}
          </section>
        </div>}
        {tab === 'minerals' && <section>
          <div className="guide-intro"><h3>Conheça o que está sob seus pés.</h3><p>Estas são as alturas do MineBlock. Os minérios da superfície também têm variantes de ardósia abaixo de Y 12. Esmeraldas podem virar pão na mesa; esmeralda com lã vira linha.</p></div>
          <div className="mineral-list">{MINERALS.map((mineral) => <div key={mineral.ore} className="mineral-row">
            <BlockIcon src={icons[mineral.ore]} size={50} /><div><h4>{BLOCKS[mineral.item].name}</h4><span>{mineral.where}</span></div><div className="mineral-use"><span>{mineral.use}</span><small>Picareta: {mineral.pick}</small></div><span className={progress.collected.includes(mineral.item) ? 'mineral-discovered' : 'mineral-unknown'}>{progress.collected.includes(mineral.item) ? 'Descoberto' : 'Explorar'}</span>
          </div>)}</div>
          <p className="panel-hint mt-4">Netherita não nasce como minério: funda detritos ancestrais em fragmentos e combine 4 fragmentos + 4 barras de ouro na ferraria. Ametista vem dos cristais, não de um minério metálico.</p>
        </section>}
        {tab === 'gear' && <section>
          <div className="guide-intro"><h3>Prepare-se para o último voo.</h3><p>Todo equipamento tem função, durabilidade e receitas. Materiais melhores desbloqueiam a mineração de blocos mais resistentes.</p></div>
          <div className="tier-list">{TIERS.map((tier) => <div key={tier.key}><BlockIcon src={icons[toolId(tier.key, 'pickaxe')]} size={44} /><span>{tier.name}</span><span>{tier.durability} usos</span><span>{tier.speed}x velocidade</span><BlockIcon src={icons[toolId(tier.key, 'sword')]} size={36} /></div>)}</div>
          <div className="combat-guide">
            <section><BlockIcon src={icons[I.BOW]} size={48} /><div><h4>Armas de verdade</h4><p>Espadas para combate rápido; machados são mais lentos e fortes. Arco e besta consomem flechas. Recolha o tridente depois de lançá-lo; a maça causa mais dano durante uma queda.</p></div></section>
            <section><BlockIcon src={icons[I.SHIELD]} size={48} /><div><h4>Vista sua proteção</h4><p>Abra o inventário, pegue uma peça e coloque no espaço de armadura à esquerda do personagem. O escudo vai na mão secundária. Segure R ou Defender para bloquear. A proteção não reduz dano de queda.</p></div></section>
            <section><BlockIcon src={icons[B.ENCHANTING]} size={48} /><div><h4>Mais do que mineração</h4><p>Encante na mesa de encantamentos com lápis-lazúli, ametista e XP. Use a enxada para arar e plante sementes: o trigo amadurece em 30 segundos e vira pão.</p></div></section>
          </div>
          <p className="panel-hint mt-4">Inspirado no Minecraft, com receitas e combate adaptados para esta edição. Esmeralda, redstone, lápis-lazúli, quartzo e ametista têm usos próprios; não são níveis de ferramentas. O ouro é veloz, mas frágil.</p>
        </section>}
        {tab === 'portals' && <section>
          <div className="guide-intro"><h3>Construa a passagem. Atravesse de verdade.</h3><p>Os portais precisam de estruturas completas. Quebrar uma peça apaga a passagem; ficar dentro do portal carrega a travessia.</p></div>
          <div className="portal-guide-layout">
            <section><h4>Nether / visão de frente</h4><div className="portal-diagram nether-diagram" aria-label="Moldura 4 por 5 com interior 2 por 3">{Array.from({ length: 20 }, (_, i) => { const x = i % 4, y = Math.floor(i / 4), border = x === 0 || x === 3 || y === 0 || y === 4, corner = (x === 0 || x === 3) && (y === 0 || y === 4); return <div key={i} className={border ? corner ? 'optional-frame' : 'obsidian-frame' : 'portal-inside'}>{border ? <BlockIcon src={icons[B.OBSIDIAN]} size={32} /> : null}</div>; })}</div><p>Exterior 4 x 5. Interior vazio 2 x 3. Use a pederneira na face superior da base. Os cantos são opcionais.</p><p>Funciona nos dois eixos; interiores de 2 a 4 blocos de largura e 3 a 5 de altura são aceitos.</p></section>
            <section><h4>Fim / visão de cima</h4><div className="portal-diagram end-diagram" aria-label="Anel de doze molduras com centro 3 por 3">{Array.from({ length: 25 }, (_, i) => { const x = i % 5, z = Math.floor(i / 5), corner = (x === 0 || x === 4) && (z === 0 || z === 4), border = x === 0 || x === 4 || z === 0 || z === 4; return <div key={i} className={corner ? 'empty-frame' : border ? 'eye-frame' : 'end-inside'}>{border && !corner && <BlockIcon src={icons[B.END_FRAME_EYE]} size={32} />}</div>; })}</div><p>12 molduras e 12 olhos. Deixe o centro livre na mesma altura das molduras e use um olho em cada peça.</p><p>Nesta edição, não é preciso orientar as molduras. Salte para o centro quando todos os olhos estiverem inseridos.</p></section>
          </div>
          <div className="combat-guide"><section><BlockIcon src={icons[I.DIAMOND]} size={45} /><div><h4>Seu loot fica no mundo</h4><p>Q solta 1; Ctrl + Q solta a pilha. No celular, toque em Soltar ou abra o inventário. Aproximar-se recolhe itens, se houver espaço. Com coleta automática desligada, use G ou Recolher.</p><p>Itens preservam durabilidade e encantamentos. Somem após 5 minutos de simulação próxima; lava e o vazio destroem itens comuns. As regras permitem manter ou derrubar equipamento na morte.</p></div></section></div>
        </section>}
        {tab === 'biomes' && <section>
          <div className="guide-intro"><h3>Um mundo com mais caminhos.</h3><p>{progress.biomes?.length ?? 0} de {BIOMES.length} biomas descobertos. O novo gerador combina clima, umidade e altitude, mantendo as construções dos mundos antigos.</p></div>
          <div className="atlas-layout"><nav className="atlas-list" aria-label="Escolher bioma">{BIOMES.map((region) => <button key={region.id} className={selectedBiome === region.id ? 'selected' : ''} onClick={() => setSelectedBiome(region.id)}><i style={{ background: region.color }} /><span>{region.name}</span><small>{progress.biomes?.includes(region.id) ? 'Descoberto' : 'Explorar'}</small></button>)}</nav>
            <div className="biome-detail" key={selectedBiome}>
              <div className={`biome-illustration ${selectedBiome}`} style={{ '--biome-color': biome.color } as React.CSSProperties} aria-hidden="true"><div className="pixel-sun" /><div className="pixel-cloud" /><div className="pixel-mountain" /><div className="pixel-ground" />
                {wood && <><div className={`pixel-tree ${wood.key}`}><i /><b /></div><div className={`pixel-tree secondary ${wood.key}`}><i /><b /></div></>}
                {!wood && <div className="pixel-water" />}
              </div>
              <span className="window-kicker">{currentBiome === selectedBiome ? 'VOCÊ ESTÁ AQUI' : 'TERRAS VIVAS / EXPLORAÇÃO'}</span>
              <h3>{biome.name}</h3><p>{biome.description}</p><p className="biome-resources">{biome.resources}</p>
              {wood && <div className="wood-sample"><BlockIcon src={icons[wood.log]} size={42} /><BlockIcon src={icons[wood.leaves]} size={42} /><BlockIcon src={icons[wood.planks]} size={42} /><BlockIcon src={icons[wood.sapling]} size={42} /><span>{wood.name}</span></div>}
              {onLocate && <McButton className="active compact-btn" onClick={() => setAtlasMessage(onLocate(selectedBiome) ? 'Destino marcado. Retome o jogo para seguir as coordenadas.' : 'Não encontrado perto de você. Tente mais longe ou em um mundo novo.')}>Localizar nas proximidades</McButton>}
              {waypoint && <p className="panel-hint">Destino: {waypoint.name}, X {waypoint.x} / Z {waypoint.z}. <button className="text-action" onClick={onClearWaypoint}>Limpar</button></p>}
              <p className="panel-hint" role="status">{atlasMessage || 'A localização marca coordenadas, sem teletransportar o jogador. Crie um mundo novo para todos os biomas.'}</p>
            </div>
          </div>
          <div className="wood-collection"><h4>Oito famílias de árvores</h4>{WOODS.map((family) => <div key={family.key}><BlockIcon src={icons[family.sapling]} size={34} /><span>{family.name}</span><BlockIcon src={icons[family.planks]} size={34} /></div>)}</div>
        </section>}
        {tab === 'survival' && <section>
          <div className="guide-intro"><h3>Explore. Cultive. Alimente-se.</h3><p>A barra de fome tem 20 pontos. Saciedade é a reserva invisível que a comida repõe antes de a barra começar a cair.</p></div>
          <div className="survival-guide-rules"><section><h4>O esforço tem um custo</h4><p>Correr, pular, minerar e atacar gastam energia. Com 6 pontos ou menos, você não consegue correr. Ficar parado e abrir menus não gasta fome.</p></section><section><h4>Alimento não é uma poção</h4><p>Coma pelo botão Usar ou pelo inventário. A comida repõe alimento e saciedade; com 18 pontos ou mais, você regenera vida aos poucos. A maçã dourada dá regeneração extra.</p></section><section><h4>Não deixe a barra zerar</h4><p>Sem comida, você sofre dano periódico. Fácil para em 5 corações, Normal em meio coração; Difícil pode matar. Pacífico recupera a alimentação. As regras de fome e regeneração podem ser ajustadas nas opções.</p></section></div>
          <div className="food-guide-list">{[I.APPLE, I.BERRIES, I.MELON_SLICE, I.BREAD, I.STEAK, I.COOKED_PORK, I.STEW, I.PUMPKIN_PIE, I.GOLDEN_APPLE].map((id) => <div key={id}><BlockIcon src={icons[id]} size={40} /><span>{BLOCKS[id].name}</span><b>+{BLOCKS[id].food} alimento</b><small>{BLOCKS[id].saturation} saciedade</small></div>)}</div>
          <div className="combat-guide"><section><BlockIcon src={icons[B.OAK_SAPLING]} size={50} /><div><h4>Plante seu próprio bosque</h4><p>Folhas deixam mudas da mesma árvore. Plante em terra, grama, musgo, lama ou podzol. Elas crescem em aproximadamente 60 segundos perto de você, com espaço livre. Farinha de osso acelera o crescimento.</p></div></section><section><BlockIcon src={icons[B.BERRY_BUSH]} size={50} /><div><h4>Alimentos renováveis</h4><p>Use um arbusto para colher três bagas sem destruí-lo; ele amadurece novamente em 45 segundos. Arbustos replantados começam sem frutos. Cultive trigo e faça pão na mesa, cozinhe carnes na fornalha e combine os dois cogumelos com uma tigela para fazer ensopado.</p></div></section><section><BlockIcon src={icons[B.CHEST]} size={50} /><div><h4>Um lugar para guardar suas descobertas</h4><p>Crie um baú com oito tábuas. Ele guarda 27 pilhas e mantém o conteúdo entre sessões. Você pode guardar a mochila inteira sem mover a barra rápida.</p></div></section></div>
        </section>}
      </div>
      <footer className="window-footer"><span>{progress.victory ? 'O dragão foi derrotado. Seu mundo continua.' : 'Da primeira ferramenta ao último dragão.'}</span><span>{Math.floor(progress.elapsed / 60)} min de aventura</span></footer>
    </div>
  </div>;
}