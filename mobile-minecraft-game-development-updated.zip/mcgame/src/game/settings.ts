import type { TexturePack } from './textures';
import type { EquipmentSlot } from './blocks';
import type { HungerState } from './hunger';
import type { ExplorerStyle } from './playerModel';

export type GraphicsPreset = 'rapido' | 'bonito' | 'ultra' | 'custom';
export type GameMode = 'survival' | 'creative';
export type WorldType = 'normal' | 'plano' | 'montanhas' | 'ilhas';

export interface Settings {
  preset: GraphicsPreset;
  resolution: number; // fraction of device pixel ratio
  renderDistance: number;
  texturePack: TexturePack;
  fov: number;
  sensitivity: number;
  showFps: boolean;
  fpsLimit: number; // 0 = unlimited
  ao: boolean;
  smoothLight: boolean;
  clouds: boolean;
  fancyLeaves: boolean;
  particles: boolean;
  antialias: boolean;
  viewBob: boolean;
  dayCycle: boolean;
  autoJump: boolean;
  buttonSize: number;
  sound: boolean;
  chunkBudget: number; // ms per frame
  invertY: boolean;
  brightness: number;
  dynamicResolution: boolean;
  targetFps: number;
  simulationDistance: number;
  maxMobs: number;
  particleDensity: number;
  mipmaps: boolean;
  anisotropy: number;
  animatedTextures: boolean;
  showCoordinates: boolean;
  showObjectives: boolean;
  showHand: boolean;
  hudScale: number;
  touchOpacity: number;
  tapToUse: boolean;
  screenEffects: boolean;
  difficulty: 'peaceful' | 'easy' | 'normal' | 'hard';
  keepInventory: boolean;
  mobGriefing: boolean;
  autoPickup: boolean;
  autosaveSeconds: number;
  masterVolume: number;
  musicVolume: number;
  blocksVolume: number;
  creaturesVolume: number;
  playerVolume: number;
  ambientVolume: number;
  uiVolume: number;
  subtitles: boolean;
  muteOnBlur: boolean;
  hungerEnabled: boolean;
  naturalRegeneration: boolean;
  musicMode: 'auto' | 'meadow' | 'forest' | 'night' | 'depths';
  musicContinuous: boolean;
  showBiome: boolean;
  placementPreview: boolean;
  playerStyle: ExplorerStyle;
  skinTone: number;
  leftHand: boolean;
  handScale: number;
  mobIntent: boolean;
}

export const isTouchDevice = () =>
  typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0 || matchMedia('(pointer: coarse)').matches);

export const PRESETS: Record<Exclude<GraphicsPreset, 'custom'>, Partial<Settings>> = {
  rapido: { ao: false, smoothLight: false, clouds: false, fancyLeaves: false, particles: true, particleDensity: 0.25, antialias: false, viewBob: false, renderDistance: 3, resolution: 0.5, chunkBudget: 3, simulationDistance: 24, maxMobs: 5, dynamicResolution: true, animatedTextures: false, anisotropy: 1, mipmaps: true },
  bonito: { ao: true, smoothLight: true, clouds: true, fancyLeaves: true, particles: true, particleDensity: 0.5, antialias: false, viewBob: true, renderDistance: 5, resolution: 0.75, chunkBudget: 5, simulationDistance: 40, maxMobs: 8, dynamicResolution: true, animatedTextures: true, anisotropy: 2, mipmaps: true },
  ultra: { ao: true, smoothLight: true, clouds: true, fancyLeaves: true, particles: true, particleDensity: 1, antialias: true, viewBob: true, renderDistance: 7, resolution: 1, chunkBudget: 7, simulationDistance: 64, maxMobs: 12, dynamicResolution: false, animatedTextures: true, anisotropy: 4, mipmaps: true },
};

export function defaultSettings(): Settings {
  const mobile = isTouchDevice();
  const base: Settings = {
    preset: 'bonito',
    resolution: 0.75,
    renderDistance: 5,
    texturePack: 'classico',
    fov: 75,
    sensitivity: 1,
    showFps: false,
    fpsLimit: 60,
    ao: true,
    smoothLight: true,
    clouds: true,
    fancyLeaves: true,
    particles: true,
    antialias: false,
    viewBob: true,
    dayCycle: true,
    autoJump: mobile,
    buttonSize: 1,
    sound: true,
    chunkBudget: 6,
    invertY: false,
    brightness: 0.5, dynamicResolution: true, targetFps: 60, simulationDistance: 40, maxMobs: 8,
    particleDensity: 0.5, mipmaps: true, anisotropy: 2, animatedTextures: true,
    showCoordinates: true, showObjectives: true, showHand: true, hudScale: 1,
    touchOpacity: 0.7, tapToUse: true, screenEffects: true,
    difficulty: 'normal', keepInventory: false, mobGriefing: true, autoPickup: true, autosaveSeconds: 60,
    masterVolume: 0.75, musicVolume: 0.22, blocksVolume: 0.8, creaturesVolume: 0.75,
    playerVolume: 0.8, ambientVolume: 0.45, uiVolume: 0.65, subtitles: false, muteOnBlur: true,
    hungerEnabled: true, naturalRegeneration: true, musicMode: 'auto', musicContinuous: true,
    showBiome: true, placementPreview: true,
    playerStyle: 'forest', skinTone: 1, leftHand: false, handScale: 1, mobIntent: false,
  };
  return { ...base, ...PRESETS[base.preset as 'bonito'] };
}

const SETTINGS_KEY = 'mineblock_settings_v1';
const WORLDS_KEY = 'mineblock_worlds_v1';

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Older worlds used keep-inventory. Do not silently change that rule on upgrade.
      return normalizeSettings({ ...parsed, keepInventory: parsed.keepInventory ?? true });
    }
  } catch {
    /* ignore */
  }
  return defaultSettings();
}

export function normalizeSettings(value: Partial<Settings>): Settings {
  const defaults = defaultSettings();
  const result = { ...defaults, ...value };
  const ranges: Partial<Record<keyof Settings, [number, number]>> = {
    resolution: [0.35, 1], renderDistance: [2, 10], fov: [50, 110], sensitivity: [0.2, 3],
    fpsLimit: [0, 120], chunkBudget: [2, 12], buttonSize: [0.7, 1.4], brightness: [0, 1],
    targetFps: [30, 60], simulationDistance: [16, 80], maxMobs: [3, 16], particleDensity: [0.25, 1],
    anisotropy: [1, 8], hudScale: [0.8, 1.25], touchOpacity: [0.25, 1], autosaveSeconds: [30, 180],
    masterVolume: [0, 1], musicVolume: [0, 1], blocksVolume: [0, 1], creaturesVolume: [0, 1],
    playerVolume: [0, 1], ambientVolume: [0, 1], uiVolume: [0, 1],
    skinTone: [0, 3], handScale: [0.8, 1.15],
  };
  for (const key of Object.keys(defaults) as (keyof Settings)[]) {
    const range = ranges[key];
    const raw = result[key];
    if (range) (result as unknown as Record<string, unknown>)[key] = typeof raw === 'number' && Number.isFinite(raw) ? Math.min(range[1], Math.max(range[0], raw)) : defaults[key];
    else if (typeof defaults[key] === 'boolean' && typeof raw !== 'boolean') (result as unknown as Record<string, unknown>)[key] = defaults[key];
  }
  result.renderDistance = Math.round(result.renderDistance);
  result.maxMobs = Math.round(result.maxMobs);
  result.skinTone = Math.round(result.skinTone);
  if (!['forest', 'dusk', 'sand'].includes(result.playerStyle)) result.playerStyle = 'forest';
  if (!['peaceful', 'easy', 'normal', 'hard'].includes(result.difficulty)) result.difficulty = 'normal';
  if (!['retro', 'classico', 'hd', 'realista'].includes(result.texturePack)) result.texturePack = 'classico';
  if (!['rapido', 'bonito', 'ultra', 'custom'].includes(result.preset)) result.preset = 'bonito';
  if (!['auto', 'meadow', 'forest', 'night', 'depths'].includes(result.musicMode)) result.musicMode = 'auto';
  return result;
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export interface WorldMeta {
  id: string;
  name: string;
  seed: number;
  seedText: string;
  mode: GameMode;
  type: WorldType;
  created: number;
  lastPlayed: number;
  completed?: boolean;
  generatorVersion?: number;
}

export interface Slot {
  id: number;
  count: number;
  durability?: number;
  enchant?: number;
}

export type Dimension = 'overworld' | 'nether' | 'end';
export type Equipment = Record<EquipmentSlot, Slot | null>;
export interface Adventure {
  collected: number[];
  crafted: number[];
  kills: number;
  blazes: number;
  deaths: number;
  mined: number;
  elapsed: number;
  xp: number;
  netherVisited: boolean;
  endVisited: boolean;
  crystals: number[];
  bossHealth: number;
  victory: boolean;
  victorySeen: boolean;
  biomes?: string[];
}

export interface WorldSave {
  version?: number;
  mods: Record<string, number[]>;
  player?: { x: number; y: number; z: number; yaw: number; pitch: number; health: number; flying: boolean; air?: number; hunger?: HungerState; regeneration?: number };
  inventory?: (Slot | null)[];
  selected?: number;
  time?: number;
  dimension?: Dimension;
  realms?: Partial<Record<Dimension, Record<string, number[]>>>;
  equipment?: Equipment;
  adventure?: Adventure;
  returnPoint?: [number, number, number];
  crops?: { x: number; y: number; z: number; dimension: Dimension; remaining: number; plant?: number; result?: number }[];
  reserve?: Slot[];
  drops?: SavedDrop[];
  portals?: SavedPortal[];
  deathPoint?: { position: [number, number, number]; dimension: Dimension };
  needsSpawn?: boolean;
  generatorVersion?: number;
  states?: Partial<Record<Dimension, Record<string, number>>>;
  chests?: Record<string, (Slot | null)[]>;
  saplings?: { x: number; y: number; z: number; dimension: Dimension; remaining: number; block: number }[];
  waypoint?: { x: number; z: number; name: string };
  cursor?: Slot | null;
  personalCraft?: (Slot | null)[];
  mobs?: Partial<Record<Dimension, SavedMob[]>>;
  primedTnt?: Partial<Record<Dimension, { x: number; y: number; z: number; remaining: number }[]>>;
}

export interface SavedMob {
  kind: 'zombie' | 'skeleton' | 'creeper' | 'spider' | 'shadow' | 'blaze' | 'cow' | 'pig' | 'sheep' | 'chicken';
  position: [number, number, number];
  health: number;
  yaw: number;
  age: number;
}

export interface SavedDrop {
  slot: Slot;
  position: [number, number, number];
  velocity: [number, number, number];
  dimension: Dimension;
  age: number;
  delay: number;
}

export interface SavedPortal {
  kind: 'nether' | 'end' | 'return';
  dimension: Dimension;
  x: number; y: number; z: number;
  axis: 'x' | 'z';
  width: number; height: number;
}

export function listWorlds(): WorldMeta[] {
  try {
    const raw = localStorage.getItem(WORLDS_KEY);
    if (raw) return (JSON.parse(raw) as WorldMeta[]).sort((a, b) => b.lastPlayed - a.lastPlayed);
  } catch {
    /* ignore */
  }
  return [];
}

export function saveWorldMeta(meta: WorldMeta) {
  const all = listWorlds().filter((w) => w.id !== meta.id);
  all.push(meta);
  try {
    localStorage.setItem(WORLDS_KEY, JSON.stringify(all));
    return true;
  } catch {
    return false;
  }
}

export function deleteWorld(id: string) {
  const all = listWorlds().filter((w) => w.id !== id);
  try {
    localStorage.setItem(WORLDS_KEY, JSON.stringify(all));
    localStorage.removeItem('mineblock_world_' + id);
  } catch {
    /* ignore */
  }
}

export function loadWorldSave(id: string): WorldSave | null {
  let raw: string | null = null;
  try {
    raw = localStorage.getItem('mineblock_world_' + id);
  } catch {
    throw new Error('O navegador não permitiu acessar os mundos salvos.');
  }
  if (!raw) return null;
  let saved: WorldSave;
  try { saved = JSON.parse(raw); } catch { throw new Error('O arquivo salvo está corrompido. Importe uma cópia de segurança.'); }
  if (!saved || typeof saved !== 'object' || !saved.mods || typeof saved.mods !== 'object' || Array.isArray(saved.mods)) throw new Error('Este salvamento não possui dados de terreno válidos.');
  if ((saved.version ?? 1) > 4) throw new Error('Este mundo precisa de uma versão mais recente do MineBlock.');
  if (saved.inventory && !Array.isArray(saved.inventory)) throw new Error('O inventário salvo não está em um formato válido.');
  return saved;
}

export function storeWorldSave(id: string, data: WorldSave): boolean {
  try {
    localStorage.setItem('mineblock_world_' + id, JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}
