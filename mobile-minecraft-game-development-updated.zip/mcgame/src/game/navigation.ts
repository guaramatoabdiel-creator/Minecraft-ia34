import { B } from './blocks';
import { blockBounds, overlapsWorld, type BlockReader } from './collision';

export type Waypoint = { x: number; y: number; z: number };
export interface NavigationProfile { radius: number; height: number; step: number; drop: number; swim?: boolean }
const defaultProfile: NavigationProfile = { radius: 0.28, height: 1.8, step: 1, drop: 2 };
const hazard = (id: number) => id === B.LAVA || id === B.CACTUS || id === B.NETHER_PORTAL_X || id === B.NETHER_PORTAL_Z || id === B.END_SURFACE;

function safeBody(world: BlockReader, x: number, y: number, z: number, profile: NavigationProfile) {
  if (overlapsWorld(world, [x - profile.radius, y + 0.003, z - profile.radius, x + profile.radius, y + profile.height, z + profile.radius])) return false;
  for (const ox of [-profile.radius, 0, profile.radius]) for (const oz of [-profile.radius, 0, profile.radius]) {
    const id = world.getBlock(Math.floor(x + ox), Math.floor(y + 0.04), Math.floor(z + oz));
    if (id === -1 || hazard(id) || !profile.swim && id === B.WATER) return false;
  }
  return true;
}

export function standingHeight(world: BlockReader, x: number, z: number, referenceY: number, height = 1.8, climb = 1, radius = 0.28, maxDrop = 2, swim = false) {
  const profile = { radius, height, step: climb, drop: maxDrop, swim };
  const ix = Math.floor(x), iz = Math.floor(z), candidates: number[] = [];
  for (let y = Math.floor(referenceY + climb); y >= Math.floor(referenceY - maxDrop) - 1; y--) {
    const id = world.getBlock(ix, y, iz);
    if (id === -1) continue;
    if (hazard(id)) continue;
    if (id === B.WATER && swim && world.getBlock(ix, y + 1, iz) !== B.WATER) candidates.push(y + 0.35);
    for (const box of blockBounds(id, world.getState?.(ix, y, iz))) {
      if (x - ix < box[0] || x - ix > box[3] || z - iz < box[2] || z - iz > box[5]) continue;
      const top = y + box[4];
      if (top <= referenceY + climb + 0.015 && top >= referenceY - maxDrop - 0.015) candidates.push(top);
    }
  }
  candidates.sort((a, b) => Math.abs(a - referenceY) - Math.abs(b - referenceY) || b - a);
  for (const top of candidates) if (top <= referenceY + climb + 0.015 && top >= referenceY - maxDrop - 0.015 && safeBody(world, x, top, z, profile)) return top;
  return null;
}

export function canTraverse(world: BlockReader, from: Waypoint, to: Waypoint, profile: NavigationProfile = defaultProfile) {
  if (to.y - from.y > profile.step + 0.015 || from.y - to.y > profile.drop + 0.015) return false;
  const top = Math.max(from.y, to.y);
  if (!safeBody(world, from.x, top, from.z, profile) || !safeBody(world, to.x, top, to.z, profile)) return false;
  const distance = Math.hypot(to.x - from.x, to.z - from.z), steps = Math.max(1, Math.ceil(distance / 0.22));
  for (let i = 1; i <= steps; i++) {
    const t = i / steps, x = from.x + (to.x - from.x) * t, z = from.z + (to.z - from.z) * t;
    if (!safeBody(world, x, top, z, profile)) return false;
    // Check feet-level hazards even while planning a jump over a low obstacle.
    const foot = world.getBlock(Math.floor(x), Math.floor(Math.min(from.y, to.y) + 0.05), Math.floor(z));
    if (hazard(foot) || foot === -1 || !profile.swim && foot === B.WATER) return false;
  }
  return true;
}

interface Node extends Waypoint { cost: number; score: number; parent: Node | null; key: string }
class MinHeap {
  values: Node[] = [];
  push(node: Node) {
    this.values.push(node); let index = this.values.length - 1;
    while (index > 0) {
      const parent = (index - 1) >> 1; if (this.values[parent].score <= node.score) break;
      this.values[index] = this.values[parent]; index = parent;
    }
    this.values[index] = node;
  }
  pop() {
    const first = this.values[0], tail = this.values.pop()!;
    if (!this.values.length) return first;
    let index = 0;
    while (true) {
      let child = index * 2 + 1; if (child >= this.values.length) break;
      if (child + 1 < this.values.length && this.values[child + 1].score < this.values[child].score) child++;
      if (this.values[child].score >= tail.score) break;
      this.values[index] = this.values[child]; index = child;
    }
    this.values[index] = tail; return first;
  }
}

export function findPath(world: BlockReader, start: Waypoint, goal: Waypoint, height = 1.8, maxNodes = 150, climb = 1, custom: Partial<NavigationProfile> = {}): Waypoint[] {
  const profile = { ...defaultProfile, height, step: climb, ...custom };
  const keyOf = (x: number, y: number, z: number) => `${Math.floor(x)},${Math.round(y * 16)},${Math.floor(z)}`;
  const heuristic = (x: number, y: number, z: number) => {
    const dx = Math.abs(x - goal.x), dz = Math.abs(z - goal.z);
    return Math.max(dx, dz) + Math.min(dx, dz) * 0.414 + Math.abs(y - goal.y) * 0.65;
  };
  const initial: Node = { x: start.x, y: start.y, z: start.z, cost: 0, score: heuristic(start.x, start.y, start.z), parent: null, key: keyOf(start.x, start.y, start.z) };
  const heap = new MinHeap(); heap.push(initial);
  const costs = new Map<string, number>([[initial.key, 0]]), visited = new Set<string>();
  const heights = new Map<string, number | null>();
  let closest = initial, best = initial.score;
  const getHeight = (x: number, z: number, y: number) => {
    const key = `${x},${Math.round(y * 16)},${z}`;
    if (!heights.has(key)) heights.set(key, standingHeight(world, x, z, y, profile.height, profile.step, profile.radius, profile.drop, !!profile.swim));
    return heights.get(key)!;
  };
  for (let examined = 0; heap.values.length && examined < maxNodes; examined++) {
    const current = heap.pop(); if (visited.has(current.key)) continue; visited.add(current.key);
    const remaining = heuristic(current.x, current.y, current.z);
    if (remaining < best || Math.abs(remaining - best) < 0.01 && current.cost < closest.cost) { best = remaining; closest = current; }
    if (Math.hypot(current.x - goal.x, current.z - goal.z) < 0.85 && Math.abs(current.y - goal.y) <= 1.01) { closest = current; break; }
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
      const x = Math.floor(current.x) + 0.5 + dx, z = Math.floor(current.z) + 0.5 + dz;
      if (Math.abs(x - start.x) > 17 || Math.abs(z - start.z) > 17) continue;
      const y = getHeight(x, z, current.y); if (y === null) continue;
      const next = { x, y, z }, key = keyOf(x, y, z);
      if (visited.has(key) || !canTraverse(world, current, next, profile)) continue;
      if (dx && dz) {
        const cornerX = getHeight(x, Math.floor(current.z) + 0.5, current.y);
        const cornerZ = getHeight(Math.floor(current.x) + 0.5, z, current.y);
        if (cornerX === null || cornerZ === null || !canTraverse(world, current, { x, y: cornerX, z: Math.floor(current.z) + 0.5 }, profile) || !canTraverse(world, current, { x: Math.floor(current.x) + 0.5, y: cornerZ, z }, profile)) continue;
      }
      const water = world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)) === B.WATER;
      const cost = current.cost + (dx && dz ? 1.414 : 1) + Math.max(0, y - current.y) * 0.65 + (water ? 3 : 0);
      if ((costs.get(key) ?? Infinity) <= cost) continue;
      costs.set(key, cost); heap.push({ ...next, key, cost, score: cost + heuristic(x, y, z) * 1.08, parent: current });
    }
  }
  const path: Waypoint[] = [];
  while (closest.parent) { path.push({ x: closest.x, y: closest.y, z: closest.z }); closest = closest.parent; }
  return path.reverse();
}