export const TILES = [
  'grass_top', 'grass_side', 'dirt', 'stone', 'sand', 'log_side', 'log_top', 'leaves',
  'planks', 'cobble', 'glass', 'water', 'bedrock', 'brick', 'snow', 'snow_side',
  'coal', 'iron', 'gold', 'diamond', 'gravel', 'cactus_side', 'cactus_top', 'obsidian',
  'glowstone', 'wool_white', 'wool_red', 'wool_blue', 'wool_yellow', 'wool_green', 'wool_black', 'bookshelf',
  'tnt_side', 'tnt_top', 'tnt_bottom', 'birch_side', 'birch_top', 'ice', 'stone_bricks', 'mossy',
  'birch_leaves', 'crafting_top', 'crafting_side', 'pumpkin_side', 'pumpkin_top', 'emerald',
  'torch', 'flower_red', 'flower_yellow', 'tallgrass', 'sandstone',
  'iron_block', 'gold_block', 'diamond_block', 'pumpkin_face',
  'copper', 'redstone', 'lapis', 'quartz_ore', 'nether_gold', 'ancient_debris', 'amethyst',
  'deepslate', 'deep_coal', 'deep_iron', 'deep_copper', 'deep_gold', 'deep_redstone',
  'deep_lapis', 'deep_diamond', 'deep_emerald', 'furnace', 'smithing', 'enchanting',
  'netherrack', 'end_stone', 'nether_gate', 'end_gate', 'farmland', 'crops', 'ripe_crops',
  'copper_block', 'redstone_block', 'lapis_block', 'emerald_block', 'quartz_block', 'netherite_block', 'lava',
  'portal', 'end_frame_top', 'end_frame_side', 'end_frame_eye', 'end_surface',
  'spruce_log', 'spruce_top', 'spruce_leaves', 'spruce_planks',
  'acacia_log', 'acacia_top', 'acacia_leaves', 'acacia_planks',
  'jungle_log', 'jungle_top', 'jungle_leaves', 'jungle_planks',
  'dark_log', 'dark_top', 'dark_leaves', 'dark_planks',
  'cherry_log', 'cherry_top', 'cherry_leaves', 'cherry_planks',
  'mangrove_log', 'mangrove_top', 'mangrove_leaves', 'mangrove_planks', 'birch_planks',
  'oak_sapling', 'birch_sapling', 'spruce_sapling', 'acacia_sapling', 'jungle_sapling',
  'dark_sapling', 'cherry_sapling', 'mangrove_sapling',
  'red_sand', 'terracotta', 'red_terracotta', 'mud', 'podzol', 'moss',
  'savanna_top', 'savanna_side', 'jungle_grass_top', 'jungle_grass_side', 'swamp_top', 'swamp_side',
  'berry_bush', 'berry_empty', 'mushroom_red', 'mushroom_brown', 'sugar_cane', 'melon_side', 'melon_top',
  'lily', 'cherry_flower', 'chest_top', 'chest_side', 'chest_front', 'path', 'coarse_dirt',
] as const;

export type TileName = (typeof TILES)[number];
const T = (n: TileName) => TILES.indexOf(n);

export const B = {
  AIR: 0, GRASS: 1, DIRT: 2, STONE: 3, SAND: 4, LOG: 5, LEAVES: 6, PLANKS: 7, COBBLE: 8, GLASS: 9,
  WATER: 10, BEDROCK: 11, BRICK: 12, SNOW: 13, COAL: 14, IRON: 15, GOLD: 16, DIAMOND: 17, GRAVEL: 18,
  CACTUS: 19, OBSIDIAN: 20, GLOWSTONE: 21, WOOL_WHITE: 22, WOOL_RED: 23, WOOL_BLUE: 24, WOOL_YELLOW: 25,
  WOOL_GREEN: 26, WOOL_BLACK: 27, BOOKSHELF: 28, TNT: 29, BIRCH_LOG: 30, ICE: 31, STONE_BRICKS: 32,
  MOSSY: 33, BIRCH_LEAVES: 34, CRAFTING: 35, PUMPKIN: 36, EMERALD: 37,
  TORCH: 38, PLANK_STAIRS: 39, COBBLE_STAIRS: 40, BRICK_STAIRS: 41, STONE_SLAB: 42,
  PLANK_SLAB: 43, COBBLE_SLAB: 44, FENCE: 45, FLOWER_RED: 46, FLOWER_YELLOW: 47,
  TALLGRASS: 48, SANDSTONE: 49, IRON_BLOCK: 50, GOLD_BLOCK: 51, DIAMOND_BLOCK: 52, PUMPKIN_LIT: 53,
  COPPER: 54, REDSTONE: 55, LAPIS: 56, QUARTZ_ORE: 57, NETHER_GOLD: 58, ANCIENT_DEBRIS: 59,
  AMETHYST: 60, DEEPSLATE: 61, DEEP_COAL: 62, DEEP_IRON: 63, DEEP_COPPER: 64,
  DEEP_GOLD: 65, DEEP_REDSTONE: 66, DEEP_LAPIS: 67, DEEP_DIAMOND: 68, DEEP_EMERALD: 69,
  FURNACE: 70, SMITHING: 71, ENCHANTING: 72, NETHERRACK: 73, END_STONE: 74,
  NETHER_GATE: 75, END_GATE: 76, FARMLAND: 77, CROPS: 78, COPPER_BLOCK: 79,
  REDSTONE_BLOCK: 80, LAPIS_BLOCK: 81, EMERALD_BLOCK: 82, QUARTZ_BLOCK: 83,
  NETHERITE_BLOCK: 84, LAVA: 85, RIPE_CROPS: 86,
  NETHER_PORTAL_X: 87, NETHER_PORTAL_Z: 88, END_FRAME: 89, END_FRAME_EYE: 90, END_SURFACE: 91,
  CHEST: 92, RED_SAND: 93, TERRACOTTA: 94, MUD: 95, PODZOL: 96,
  BERRY_BUSH: 97, MUSHROOM_RED: 98, MUSHROOM_BROWN: 99,
  SPRUCE_LOG: 213, SPRUCE_LEAVES: 214, SPRUCE_PLANKS: 215,
  ACACIA_LOG: 216, ACACIA_LEAVES: 217, ACACIA_PLANKS: 218,
  JUNGLE_LOG: 219, JUNGLE_LEAVES: 220, JUNGLE_PLANKS: 221,
  DARK_LOG: 222, DARK_LEAVES: 223, DARK_PLANKS: 224,
  CHERRY_LOG: 225, CHERRY_LEAVES: 226, CHERRY_PLANKS: 227,
  MANGROVE_LOG: 228, MANGROVE_LEAVES: 229, MANGROVE_PLANKS: 230, BIRCH_PLANKS: 231,
  OAK_SAPLING: 232, BIRCH_SAPLING: 233, SPRUCE_SAPLING: 234, ACACIA_SAPLING: 235,
  JUNGLE_SAPLING: 236, DARK_SAPLING: 237, CHERRY_SAPLING: 238, MANGROVE_SAPLING: 239,
  MOSS: 240, SAVANNA_GRASS: 241, JUNGLE_GRASS: 242, SWAMP_GRASS: 243, RED_TERRACOTTA: 244,
  SUGAR_CANE: 245, MELON: 246, LILY: 247, CHERRY_FLOWER: 248, BERRY_EMPTY: 249,
  DOUBLE_STONE_SLAB: 250, DOUBLE_PLANK_SLAB: 251, DOUBLE_COBBLE_SLAB: 252,
  PATH: 254, COARSE_DIRT: 255,
} as const;

export type ToolKind = 'pickaxe' | 'axe' | 'shovel' | 'hoe' | 'sword';
export type EquipmentSlot = 'head' | 'chest' | 'legs' | 'feet' | 'offhand';
export type Station = 'hand' | 'bench' | 'furnace' | 'smithing' | 'enchanting';

export interface BlockDef {
  name: string;
  tiles: [number, number, number]; // top, side, bottom
  transparent: boolean;
  solid: boolean;
  hardness: number; // seconds-ish, <0 unbreakable
  drop?: number; // block id dropped (0 = nothing)
  emissive?: boolean;
  liquid?: boolean;
  kind?: 'material' | 'tool' | 'weapon' | 'armor' | 'food' | 'utility';
  tool?: ToolKind;
  tier?: number;
  speed?: number;
  damage?: number;
  durability?: number;
  equip?: EquipmentSlot;
  protection?: number;
  heal?: number;
  food?: number;
  saturation?: number;
  regeneration?: number;
  returns?: number;
  color?: string;
  sprite?: string;
  minTier?: number;
  preferredTool?: ToolKind;
  dropCount?: number;
}

function def(name: string, top: TileName, side: TileName = top, bottom: TileName = top, extra: Partial<BlockDef> = {}): BlockDef {
  return { name, tiles: [T(top), T(side), T(bottom)], transparent: false, solid: true, hardness: 1, ...extra };
}

export const BLOCKS: BlockDef[] = [];
BLOCKS[B.AIR] = { name: 'Ar', tiles: [0, 0, 0], transparent: true, solid: false, hardness: 0 };
BLOCKS[B.GRASS] = def('Grama', 'grass_top', 'grass_side', 'dirt', { hardness: 0.6, drop: B.DIRT });
BLOCKS[B.DIRT] = def('Terra', 'dirt', 'dirt', 'dirt', { hardness: 0.5 });
BLOCKS[B.STONE] = def('Pedra', 'stone', 'stone', 'stone', { hardness: 1.5, drop: B.COBBLE });
BLOCKS[B.SAND] = def('Areia', 'sand', 'sand', 'sand', { hardness: 0.5 });
BLOCKS[B.LOG] = def('Tronco de Carvalho', 'log_top', 'log_side', 'log_top', { hardness: 2 });
BLOCKS[B.LEAVES] = def('Folhas', 'leaves', 'leaves', 'leaves', { hardness: 0.2, transparent: true, drop: 0 });
BLOCKS[B.PLANKS] = def('Tábuas', 'planks', 'planks', 'planks', { hardness: 2 });
BLOCKS[B.COBBLE] = def('Pedregulho', 'cobble', 'cobble', 'cobble', { hardness: 2 });
BLOCKS[B.GLASS] = def('Vidro', 'glass', 'glass', 'glass', { hardness: 0.3, transparent: true, drop: 0 });
BLOCKS[B.WATER] = def('Água', 'water', 'water', 'water', { hardness: -1, transparent: true, solid: false, liquid: true });
BLOCKS[B.BEDROCK] = def('Rocha Matriz', 'bedrock', 'bedrock', 'bedrock', { hardness: -1 });
BLOCKS[B.BRICK] = def('Tijolos', 'brick', 'brick', 'brick', { hardness: 2 });
BLOCKS[B.SNOW] = def('Grama com Neve', 'snow', 'snow_side', 'dirt', { hardness: 0.6, drop: B.DIRT });
BLOCKS[B.COAL] = def('Minério de Carvão', 'coal', 'coal', 'coal', { hardness: 3 });
BLOCKS[B.IRON] = def('Minério de Ferro', 'iron', 'iron', 'iron', { hardness: 3 });
BLOCKS[B.GOLD] = def('Minério de Ouro', 'gold', 'gold', 'gold', { hardness: 3 });
BLOCKS[B.DIAMOND] = def('Minério de Diamante', 'diamond', 'diamond', 'diamond', { hardness: 3.5 });
BLOCKS[B.GRAVEL] = def('Cascalho', 'gravel', 'gravel', 'gravel', { hardness: 0.6 });
BLOCKS[B.CACTUS] = def('Cacto', 'cactus_top', 'cactus_side', 'cactus_top', { hardness: 0.4 });
BLOCKS[B.OBSIDIAN] = def('Obsidiana', 'obsidian', 'obsidian', 'obsidian', { hardness: 8 });
BLOCKS[B.GLOWSTONE] = def('Pedra Luminosa', 'glowstone', 'glowstone', 'glowstone', { hardness: 0.3, emissive: true });
BLOCKS[B.WOOL_WHITE] = def('Lã Branca', 'wool_white', 'wool_white', 'wool_white', { hardness: 0.8 });
BLOCKS[B.WOOL_RED] = def('Lã Vermelha', 'wool_red', 'wool_red', 'wool_red', { hardness: 0.8 });
BLOCKS[B.WOOL_BLUE] = def('Lã Azul', 'wool_blue', 'wool_blue', 'wool_blue', { hardness: 0.8 });
BLOCKS[B.WOOL_YELLOW] = def('Lã Amarela', 'wool_yellow', 'wool_yellow', 'wool_yellow', { hardness: 0.8 });
BLOCKS[B.WOOL_GREEN] = def('Lã Verde', 'wool_green', 'wool_green', 'wool_green', { hardness: 0.8 });
BLOCKS[B.WOOL_BLACK] = def('Lã Preta', 'wool_black', 'wool_black', 'wool_black', { hardness: 0.8 });
BLOCKS[B.BOOKSHELF] = def('Estante', 'planks', 'bookshelf', 'planks', { hardness: 1.5 });
BLOCKS[B.TNT] = def('TNT', 'tnt_top', 'tnt_side', 'tnt_bottom', { hardness: 0.1 });
BLOCKS[B.BIRCH_LOG] = def('Tronco de Bétula', 'birch_top', 'birch_side', 'birch_top', { hardness: 2 });
BLOCKS[B.ICE] = def('Gelo', 'ice', 'ice', 'ice', { hardness: 0.5 });
BLOCKS[B.STONE_BRICKS] = def('Tijolos de Pedra', 'stone_bricks', 'stone_bricks', 'stone_bricks', { hardness: 1.5 });
BLOCKS[B.MOSSY] = def('Pedregulho Musgoso', 'mossy', 'mossy', 'mossy', { hardness: 2 });
BLOCKS[B.BIRCH_LEAVES] = def('Folhas de Bétula', 'birch_leaves', 'birch_leaves', 'birch_leaves', { hardness: 0.2, transparent: true, drop: 0 });
BLOCKS[B.CRAFTING] = def('Mesa de Trabalho', 'crafting_top', 'crafting_side', 'planks', { hardness: 2 });
BLOCKS[B.PUMPKIN] = def('Abóbora', 'pumpkin_top', 'pumpkin_side', 'pumpkin_top', { hardness: 1 });
BLOCKS[B.EMERALD] = def('Minério de Esmeralda', 'emerald', 'emerald', 'emerald', { hardness: 3.5 });
// novos
BLOCKS[B.TORCH] = def('Tocha', 'torch', 'torch', 'torch', { hardness: 0.1, transparent: true, solid: false, emissive: true });
BLOCKS[B.PLANK_STAIRS] = def('Escada de Madeira', 'planks', 'planks', 'planks', { hardness: 2, transparent: true });
BLOCKS[B.COBBLE_STAIRS] = def('Escada de Pedra', 'cobble', 'cobble', 'cobble', { hardness: 2, transparent: true });
BLOCKS[B.BRICK_STAIRS] = def('Escada de Tijolos', 'brick', 'brick', 'brick', { hardness: 2, transparent: true });
BLOCKS[B.STONE_SLAB] = def('Laje de Pedra', 'stone', 'stone', 'stone', { hardness: 1.5, transparent: true });
BLOCKS[B.PLANK_SLAB] = def('Laje de Madeira', 'planks', 'planks', 'planks', { hardness: 2, transparent: true });
BLOCKS[B.COBBLE_SLAB] = def('Laje de Pedregulho', 'cobble', 'cobble', 'cobble', { hardness: 2, transparent: true });
BLOCKS[B.FENCE] = def('Cerca', 'planks', 'planks', 'planks', { hardness: 2, transparent: true });
BLOCKS[B.FLOWER_RED] = def('Flor Vermelha', 'flower_red', 'flower_red', 'flower_red', { hardness: 0, transparent: true, solid: false });
BLOCKS[B.FLOWER_YELLOW] = def('Flor Amarela', 'flower_yellow', 'flower_yellow', 'flower_yellow', { hardness: 0, transparent: true, solid: false });
BLOCKS[B.TALLGRASS] = def('Grama Alta', 'tallgrass', 'tallgrass', 'tallgrass', { hardness: 0, transparent: true, solid: false, drop: 0 });
BLOCKS[B.SANDSTONE] = def('Arenito', 'sandstone', 'sandstone', 'sandstone', { hardness: 1.2 });
BLOCKS[B.IRON_BLOCK] = def('Bloco de Ferro', 'iron_block', 'iron_block', 'iron_block', { hardness: 3 });
BLOCKS[B.GOLD_BLOCK] = def('Bloco de Ouro', 'gold_block', 'gold_block', 'gold_block', { hardness: 3 });
BLOCKS[B.DIAMOND_BLOCK] = def('Bloco de Diamante', 'diamond_block', 'diamond_block', 'diamond_block', { hardness: 3.5 });
BLOCKS[B.PUMPKIN_LIT] = def('Abóbora Iluminada', 'pumpkin_top', 'pumpkin_face', 'pumpkin_top', { hardness: 1, emissive: true });

export const isSolid = (id: number) => id > 0 && !!BLOCKS[id]?.solid;
export const isOpaque = (id: number) => id > 0 && !!BLOCKS[id] && !BLOCKS[id].transparent;
export const isPlaceable = (id: number) => Number.isInteger(id) && id > 0 && id < 256 && !!BLOCKS[id] && !BLOCKS[id].kind;

export type RecipeCat = 'basico' | 'construcao' | 'decoracao' | 'especiais' | 'ferramentas' | 'armas' | 'armaduras' | 'minerais' | 'alimentos' | 'madeiras';

export interface Recipe {
  out: number;
  count: number;
  input: [number, number][];
  basic?: boolean; // disponível no inventário sem mesa
  cat: RecipeCat;
  station?: Station;
}

export const RECIPES: Recipe[] = [
  // básico (inventário)
  { out: B.PLANKS, count: 4, input: [[B.LOG, 1]], basic: true, cat: 'basico' },
  { out: B.BIRCH_PLANKS, count: 4, input: [[B.BIRCH_LOG, 1]], basic: true, cat: 'madeiras' },
  { out: B.CRAFTING, count: 1, input: [[B.PLANKS, 4]], basic: true, cat: 'basico' },
  { out: B.TORCH, count: 4, input: [[100, 1], [115, 1]], basic: true, cat: 'basico' },
  { out: B.GLASS, count: 4, input: [[B.SAND, 4], [100, 1]], station: 'furnace', cat: 'basico' },
  { out: B.STONE, count: 4, input: [[B.COBBLE, 4], [100, 1]], station: 'furnace', cat: 'basico' },
  { out: B.WOOL_WHITE, count: 1, input: [[B.LEAVES, 4]], basic: true, cat: 'basico' },
  { out: B.SANDSTONE, count: 2, input: [[B.SAND, 4]], basic: true, cat: 'basico' },
  // construção (mesa)
  { out: B.STONE_BRICKS, count: 4, input: [[B.STONE, 4]], cat: 'construcao' },
  { out: B.PLANK_STAIRS, count: 4, input: [[B.PLANKS, 6]], cat: 'construcao' },
  { out: B.COBBLE_STAIRS, count: 4, input: [[B.COBBLE, 6]], cat: 'construcao' },
  { out: B.BRICK_STAIRS, count: 4, input: [[B.BRICK, 6]], cat: 'construcao' },
  { out: B.STONE_SLAB, count: 6, input: [[B.STONE, 3]], cat: 'construcao' },
  { out: B.PLANK_SLAB, count: 6, input: [[B.PLANKS, 3]], cat: 'construcao' },
  { out: B.COBBLE_SLAB, count: 6, input: [[B.COBBLE, 3]], cat: 'construcao' },
  { out: B.FENCE, count: 4, input: [[B.PLANKS, 6]], cat: 'construcao' },
  { out: B.BRICK, count: 2, input: [[B.DIRT, 2], [B.SAND, 2]], cat: 'construcao' },
  { out: B.MOSSY, count: 2, input: [[B.COBBLE, 2], [B.LEAVES, 1]], cat: 'construcao' },
  { out: B.IRON_BLOCK, count: 1, input: [[105, 9]], cat: 'construcao' },
  { out: B.GOLD_BLOCK, count: 1, input: [[106, 9]], cat: 'construcao' },
  { out: B.DIAMOND_BLOCK, count: 1, input: [[107, 9]], cat: 'construcao' },
  // decoração (mesa)
  { out: B.BOOKSHELF, count: 1, input: [[B.PLANKS, 6]], cat: 'decoracao' },
  { out: B.WOOL_RED, count: 1, input: [[B.WOOL_WHITE, 1], [B.FLOWER_RED, 1]], cat: 'decoracao' },
  { out: B.WOOL_YELLOW, count: 1, input: [[B.WOOL_WHITE, 1], [B.FLOWER_YELLOW, 1]], cat: 'decoracao' },
  { out: B.WOOL_GREEN, count: 1, input: [[B.WOOL_WHITE, 1], [B.CACTUS, 1]], cat: 'decoracao' },
  { out: B.WOOL_BLUE, count: 1, input: [[B.WOOL_WHITE, 1], [110, 1]], cat: 'decoracao' },
  { out: B.WOOL_BLACK, count: 1, input: [[B.WOOL_WHITE, 1], [100, 1]], cat: 'decoracao' },
  { out: B.PUMPKIN_LIT, count: 1, input: [[B.PUMPKIN, 1], [B.TORCH, 1]], cat: 'decoracao' },
  // especiais (mesa)
  { out: B.TNT, count: 1, input: [[B.SAND, 4], [B.GRAVEL, 1]], cat: 'especiais' },
  { out: B.GLOWSTONE, count: 2, input: [[106, 1], [B.GLASS, 1]], cat: 'especiais' },
];

// IDs of existing blocks stay unchanged so older worlds keep their buildings.
export const I = {
  COAL: 100, RAW_COPPER: 101, RAW_IRON: 102, RAW_GOLD: 103, COPPER: 104, IRON: 105,
  GOLD: 106, DIAMOND: 107, EMERALD: 108, REDSTONE: 109, LAPIS: 110, QUARTZ: 111,
  AMETHYST: 112, SCRAP: 113, NETHERITE: 114, STICK: 115, STRING: 116, LEATHER: 117,
  FLINT: 118, PEARL: 119, BLAZE_ROD: 120, BLAZE_POWDER: 121, EYE: 122, APPLE: 123,
  BREAD: 124, SEEDS: 125, WHEAT: 126, ARROW: 127, BOW: 128, CROSSBOW: 129,
  TRIDENT: 130, MACE: 131, SHIELD: 132, FLINT_STEEL: 133, COMPASS: 134, STEAK: 135,
  TROPHY: 136, SPYGLASS: 137, GOLDEN_APPLE: 138, UPGRADE: 139,
  BONE: 208, GUNPOWDER: 209, RAW_BEEF: 210, RAW_PORK: 211, COOKED_PORK: 212,
  BERRIES: 300, MELON_SLICE: 301, BOWL: 302, STEW: 303, PAPER: 304, BOOK: 305,
  SUGAR: 306, PUMPKIN_PIE: 307, BONE_MEAL: 308, SWEET_BREAD: 309, FEATHER: 310, RAW_CHICKEN: 311,
} as const;

function material(id: number, name: string, color: string, sprite = 'gem', extra: Partial<BlockDef> = {}) {
  BLOCKS[id] = { ...def(name, 'stone'), kind: 'material', solid: false, transparent: true, color, sprite, ...extra };
}

const resources: [number, string, string, string?][] = [
  [I.COAL, 'Carvão', '#34353e', 'coal'], [I.RAW_COPPER, 'Cobre bruto', '#da855d', 'raw'],
  [I.RAW_IRON, 'Ferro bruto', '#cfa68e', 'raw'], [I.RAW_GOLD, 'Ouro bruto', '#f4cc4d', 'raw'],
  [I.COPPER, 'Barra de cobre', '#df925f', 'ingot'], [I.IRON, 'Barra de ferro', '#e3e8ed', 'ingot'],
  [I.GOLD, 'Barra de ouro', '#f7d45d', 'ingot'], [I.DIAMOND, 'Diamante', '#62e5df'],
  [I.EMERALD, 'Esmeralda', '#54da79'], [I.REDSTONE, 'Pó de redstone', '#e24649', 'dust'],
  [I.LAPIS, 'Lápis-lazúli', '#4e85e5'], [I.QUARTZ, 'Quartzo do Nether', '#f4e9df', 'crystal'],
  [I.AMETHYST, 'Fragmento de ametista', '#c99bf9', 'crystal'], [I.SCRAP, 'Fragmento de netherita', '#847477', 'raw'],
  [I.NETHERITE, 'Barra de netherita', '#635f6d', 'ingot'], [I.STICK, 'Graveto', '#c89455', 'stick'],
  [I.STRING, 'Linha', '#e8e7e1', 'string'], [I.LEATHER, 'Couro', '#b67b4e', 'leather'],
  [I.FLINT, 'Sílex', '#99929d', 'crystal'], [I.PEARL, 'Pérola do End', '#3dbba3', 'orb'],
  [I.BLAZE_ROD, 'Vara de blaze', '#ffc643', 'stick'], [I.BLAZE_POWDER, 'Pó de blaze', '#ffa744', 'dust'],
  [I.EYE, 'Olho do End', '#9fea74', 'eye'], [I.SEEDS, 'Sementes', '#8fc44b', 'dust'],
  [I.WHEAT, 'Trigo', '#eecb6f', 'wheat'], [I.ARROW, 'Flecha', '#dbdfeb', 'arrow'],
  [I.UPGRADE, 'Molde de melhoria', '#acbfef', 'template'],
];
resources.forEach(([id, name, color, sprite]) => material(id, name, color, sprite));
material(I.APPLE, 'Maçã', '#e35851', 'apple', { kind: 'food', food: 4, saturation: 2.4 });
material(I.BREAD, 'Pão', '#dba35c', 'bread', { kind: 'food', food: 5, saturation: 6 });
material(I.STEAK, 'Carne assada', '#b7654c', 'bread', { kind: 'food', food: 8, saturation: 12.8 });
material(I.GOLDEN_APPLE, 'Maçã dourada', '#ffe176', 'apple', { kind: 'food', food: 4, saturation: 9.6, regeneration: 8 });
material(I.BOW, 'Arco', '#b68b5b', 'bow', { kind: 'weapon', damage: 7, durability: 384 });
material(I.CROSSBOW, 'Besta', '#b0a893', 'crossbow', { kind: 'weapon', damage: 11, durability: 465 });
material(I.TRIDENT, 'Tridente', '#72ded6', 'trident', { kind: 'weapon', damage: 9, durability: 250 });
material(I.MACE, 'Maça', '#adbccf', 'mace', { kind: 'weapon', damage: 9, durability: 500 });
material(I.SHIELD, 'Escudo', '#cba776', 'shield', { kind: 'armor', equip: 'offhand', durability: 336 });
material(I.FLINT_STEEL, 'Pederneira', '#b5bec9', 'flint', { kind: 'utility', durability: 64 });
material(I.COMPASS, 'Bússola', '#e56565', 'compass', { kind: 'utility' });
material(I.SPYGLASS, 'Luneta', '#dda361', 'spyglass', { kind: 'utility' });
material(I.TROPHY, 'Coração do dragão', '#efbeff', 'trophy', { kind: 'utility' });
material(I.BONE, 'Osso', '#e9e4c9', 'stick');
material(I.FEATHER, 'Pena', '#eee9dc', 'feather');
material(I.RAW_CHICKEN, 'Frango cru', '#e7b5a0', 'bread', { kind: 'food', food: 2, saturation: 1.2 });
material(I.GUNPOWDER, 'Pólvora', '#767780', 'dust');
material(I.RAW_BEEF, 'Carne crua', '#c65b57', 'bread', { kind: 'food', food: 3, saturation: 1.8 });
material(I.RAW_PORK, 'Carne de porco crua', '#e3918e', 'bread', { kind: 'food', food: 3, saturation: 1.8 });
material(I.COOKED_PORK, 'Carne de porco assada', '#c9a37c', 'bread', { kind: 'food', food: 8, saturation: 12.8 });
material(I.BERRIES, 'Bagas doces', '#c35362', 'berries', { kind: 'food', food: 2, saturation: 0.4 });
material(I.MELON_SLICE, 'Fatia de melancia', '#e88377', 'melon', { kind: 'food', food: 2, saturation: 1.2 });
material(I.BOWL, 'Tigela', '#ba8857', 'bowl');
material(I.STEW, 'Ensopado de cogumelos', '#b68055', 'stew', { kind: 'food', food: 6, saturation: 7.2, returns: I.BOWL });
material(I.PAPER, 'Papel', '#e7e2cb', 'paper');
material(I.BOOK, 'Livro', '#b8885f', 'book');
material(I.SUGAR, 'Açúcar', '#eee7d6', 'dust');
material(I.PUMPKIN_PIE, 'Torta de abóbora', '#d89443', 'pie', { kind: 'food', food: 8, saturation: 4.8 });
material(I.BONE_MEAL, 'Farinha de osso', '#e4dcc5', 'dust', { kind: 'utility' });
material(I.SWEET_BREAD, 'Pão com frutas', '#bf8952', 'bread', { kind: 'food', food: 7, saturation: 8.4 });

export const TOOL_TYPES: ToolKind[] = ['pickaxe', 'axe', 'shovel', 'hoe', 'sword'];
export const TOOL_NAMES: Record<ToolKind, string> = { pickaxe: 'Picareta', axe: 'Machado', shovel: 'Pá', hoe: 'Enxada', sword: 'Espada' };
export const TIERS = [
  { key: 'wood', name: 'Madeira', ingredient: B.PLANKS, tier: 1, speed: 2, durability: 59, damage: 4, color: '#c39454' },
  { key: 'stone', name: 'Pedra', ingredient: B.COBBLE, tier: 2, speed: 4, durability: 131, damage: 5, color: '#a5acb2' },
  { key: 'copper', name: 'Cobre', ingredient: I.COPPER, tier: 2, speed: 5, durability: 191, damage: 5, color: '#e39868' },
  { key: 'iron', name: 'Ferro', ingredient: I.IRON, tier: 3, speed: 6, durability: 250, damage: 6, color: '#e1e9ef' },
  { key: 'gold', name: 'Ouro', ingredient: I.GOLD, tier: 1, speed: 12, durability: 32, damage: 4, color: '#ffe477' },
  { key: 'diamond', name: 'Diamante', ingredient: I.DIAMOND, tier: 4, speed: 8, durability: 1561, damage: 7, color: '#71e8df' },
  { key: 'netherite', name: 'Netherita', ingredient: I.NETHERITE, tier: 5, speed: 9, durability: 2031, damage: 8, color: '#918694' },
] as const;
export type TierKey = (typeof TIERS)[number]['key'];
export const toolId = (tier: TierKey, tool: ToolKind) => 140 + TIERS.findIndex((t) => t.key === tier) * 5 + TOOL_TYPES.indexOf(tool);

export const ARMOR_SLOTS: EquipmentSlot[] = ['head', 'chest', 'legs', 'feet', 'offhand'];
export const SLOT_NAMES: Record<EquipmentSlot, string> = { head: 'Capacete', chest: 'Peitoral', legs: 'Calças', feet: 'Botas', offhand: 'Escudo' };
const armorTiers = [
  { name: 'Couro', ingredient: I.LEATHER, color: '#b77c56', protection: [1, 3, 2, 1], durability: 80 },
  { name: 'Malha', ingredient: I.IRON, color: '#9fa9b8', protection: [2, 5, 4, 1], durability: 180 },
  { name: 'Cobre', ingredient: I.COPPER, color: '#df996c', protection: [2, 4, 3, 1], durability: 130 },
  { name: 'Ferro', ingredient: I.IRON, color: '#e3eaf0', protection: [2, 6, 5, 2], durability: 240 },
  { name: 'Ouro', ingredient: I.GOLD, color: '#ffe077', protection: [2, 5, 3, 1], durability: 100 },
  { name: 'Diamante', ingredient: I.DIAMOND, color: '#72e9e1', protection: [3, 8, 6, 3], durability: 520 },
  { name: 'Netherita', ingredient: I.NETHERITE, color: '#958b9c', protection: [3, 8, 6, 3], durability: 640 },
];

TIERS.forEach((t) => TOOL_TYPES.forEach((tool, j) => {
  const id = toolId(t.key, tool);
  material(id, `${TOOL_NAMES[tool]} de ${t.name.toLowerCase()}`, t.color, tool, {
    kind: tool === 'sword' ? 'weapon' : 'tool', tool, tier: t.tier, speed: t.speed,
    durability: t.durability, damage: tool === 'sword' ? t.damage : tool === 'axe' ? t.damage + 1 : tool === 'shovel' ? t.damage - 1.5 : tool === 'hoe' ? 1 : t.damage - 2,
  });
  RECIPES.push({ out: id, count: 1, cat: tool === 'sword' ? 'armas' : 'ferramentas',
    station: t.key === 'netherite' ? 'smithing' : 'bench',
    input: t.key === 'netherite' ? [[toolId('diamond', tool), 1], [I.NETHERITE, 1], [I.UPGRADE, 1]]
      : [[t.ingredient, [3, 3, 1, 2, 2][j]], [I.STICK, tool === 'sword' ? 1 : 2]],
  });
}));
armorTiers.forEach((t, i) => ARMOR_SLOTS.slice(0, 4).forEach((slot, j) => {
  const id = 180 + i * 4 + j;
  material(id, `${SLOT_NAMES[slot]} de ${t.name.toLowerCase()}`, t.color, slot, {
    kind: 'armor', equip: slot, protection: t.protection[j], durability: t.durability * [1, 1.45, 1.3, 1.15][j] | 0,
  });
  RECIPES.push({ out: id, count: 1, cat: 'armaduras', station: i === 6 ? 'smithing' : 'bench',
    input: i === 6 ? [[180 + 5 * 4 + j, 1], [I.NETHERITE, 1], [I.UPGRADE, 1]]
      : [[t.ingredient, [5, 8, 7, 4][j]], ...(i === 1 ? [[I.STRING, 3] as [number, number]] : [])],
  });
}));

const newBlocks: [number, string, TileName, Partial<BlockDef>?][] = [
  [B.COPPER, 'Minério de cobre', 'copper', { minTier: 2, drop: I.RAW_COPPER, dropCount: 2 }],
  [B.REDSTONE, 'Minério de redstone', 'redstone', { minTier: 3, drop: I.REDSTONE, dropCount: 4 }],
  [B.LAPIS, 'Minério de lápis-lazúli', 'lapis', { minTier: 2, drop: I.LAPIS, dropCount: 4 }],
  [B.QUARTZ_ORE, 'Minério de quartzo', 'quartz_ore', { minTier: 1, drop: I.QUARTZ }],
  [B.NETHER_GOLD, 'Minério de ouro do Nether', 'nether_gold', { minTier: 1, drop: I.RAW_GOLD }],
  [B.ANCIENT_DEBRIS, 'Detritos ancestrais', 'ancient_debris', { minTier: 4, hardness: 7 }],
  [B.AMETHYST, 'Cristal de ametista', 'amethyst', { minTier: 2, drop: I.AMETHYST, dropCount: 3 }],
  [B.DEEPSLATE, 'Ardósia', 'deepslate', { minTier: 1, drop: B.COBBLE }],
  [B.FURNACE, 'Fornalha', 'furnace', { minTier: 1 }],
  [B.SMITHING, 'Bancada de ferraria', 'smithing', { hardness: 2, preferredTool: 'axe' }],
  [B.ENCHANTING, 'Mesa de encantamentos', 'enchanting', { minTier: 1 }],
  [B.NETHERRACK, 'Netherrack', 'netherrack', { hardness: 0.8, minTier: 1 }],
  [B.END_STONE, 'Pedra do Fim', 'end_stone', { minTier: 1 }],
  [B.NETHER_GATE, 'Portal do Nether', 'nether_gate', { emissive: true, hardness: 4, minTier: 4 }],
  [B.END_GATE, 'Portal do Fim', 'end_gate', { emissive: true, hardness: 5, minTier: 4 }],
  [B.FARMLAND, 'Terra arada', 'farmland', { drop: B.DIRT, hardness: 0.5, preferredTool: 'shovel' }],
  [B.CROPS, 'Trigo crescendo', 'crops', { transparent: true, solid: false, hardness: 0, drop: I.SEEDS }],
  [B.RIPE_CROPS, 'Trigo maduro', 'ripe_crops', { transparent: true, solid: false, hardness: 0, drop: I.WHEAT, dropCount: 3 }],
  [B.COPPER_BLOCK, 'Bloco de cobre', 'copper_block', { minTier: 2 }],
  [B.REDSTONE_BLOCK, 'Bloco de redstone', 'redstone_block', { minTier: 3 }],
  [B.LAPIS_BLOCK, 'Bloco de lápis-lazúli', 'lapis_block', { minTier: 2 }],
  [B.EMERALD_BLOCK, 'Bloco de esmeralda', 'emerald_block', { minTier: 3 }],
  [B.QUARTZ_BLOCK, 'Bloco de quartzo', 'quartz_block', { minTier: 1 }],
  [B.NETHERITE_BLOCK, 'Bloco de netherita', 'netherite_block', { minTier: 4, hardness: 8 }],
  [B.LAVA, 'Lava', 'lava', { hardness: -1, solid: false, transparent: true, emissive: true, liquid: true }],
  [B.NETHER_PORTAL_X, 'Portal do Nether', 'portal', { hardness: -1, solid: false, transparent: true, emissive: true, drop: 0 }],
  [B.NETHER_PORTAL_Z, 'Portal do Nether', 'portal', { hardness: -1, solid: false, transparent: true, emissive: true, drop: 0 }],
  [B.END_FRAME, 'Moldura do portal do Fim', 'end_frame_side', { minTier: 4, hardness: 5, transparent: true }],
  [B.END_FRAME_EYE, 'Moldura com olho do End', 'end_frame_side', { minTier: 4, hardness: 5, transparent: true, drop: B.END_FRAME }],
  [B.END_SURFACE, 'Portal do Fim', 'end_surface', { hardness: -1, solid: false, transparent: true, emissive: true, drop: 0 }],
];
newBlocks.forEach(([id, name, tile, extra]) => {
  BLOCKS[id] = def(name, tile, tile, tile, { hardness: 2, preferredTool: 'pickaxe', ...extra });
});
BLOCKS[B.END_FRAME].tiles = [T('end_frame_top'), T('end_frame_side'), T('end_stone')];
BLOCKS[B.END_FRAME_EYE].tiles = [T('end_frame_eye'), T('end_frame_side'), T('end_stone')];
const deepOres: [number, number, TileName][] = [
  [B.DEEP_COAL, B.COAL, 'deep_coal'], [B.DEEP_IRON, B.IRON, 'deep_iron'], [B.DEEP_COPPER, B.COPPER, 'deep_copper'],
  [B.DEEP_GOLD, B.GOLD, 'deep_gold'], [B.DEEP_REDSTONE, B.REDSTONE, 'deep_redstone'],
  [B.DEEP_LAPIS, B.LAPIS, 'deep_lapis'], [B.DEEP_DIAMOND, B.DIAMOND, 'deep_diamond'], [B.DEEP_EMERALD, B.EMERALD, 'deep_emerald'],
];
export const DEEP_VARIANTS: Record<number, number> = Object.fromEntries(deepOres.map(([deep, base]) => [base, deep]));
const drops: [number, number, number, number?][] = [
  [B.COAL, I.COAL, 1], [B.IRON, I.RAW_IRON, 2], [B.GOLD, I.RAW_GOLD, 3],
  [B.DIAMOND, I.DIAMOND, 3], [B.EMERALD, I.EMERALD, 3], [B.OBSIDIAN, B.OBSIDIAN, 4],
  [B.STONE, B.COBBLE, 1], [B.COBBLE, B.COBBLE, 1],
];
drops.forEach(([id, drop, minTier, dropCount]) => Object.assign(BLOCKS[id], { drop, minTier, preferredTool: 'pickaxe', dropCount: dropCount ?? 1 }));
deepOres.forEach(([id, base, tile]) => { BLOCKS[id] = { ...BLOCKS[base], name: `${BLOCKS[base].name} de ardósia`, tiles: [T(tile), T(tile), T(tile)], hardness: 3.5 }; });
[B.LOG, B.PLANKS, B.BIRCH_LOG, B.CRAFTING, B.BOOKSHELF, B.FENCE, B.PLANK_STAIRS, B.PLANK_SLAB].forEach((id) => { BLOCKS[id].preferredTool = 'axe'; });
[B.DIRT, B.GRASS, B.SNOW, B.SAND, B.GRAVEL].forEach((id) => { BLOCKS[id].preferredTool = 'shovel'; });
[B.LEAVES, B.BIRCH_LEAVES].forEach((id) => { BLOCKS[id].preferredTool = 'hoe'; });

export const STATION_BLOCKS: Partial<Record<number, Station>> = { [B.CRAFTING]: 'bench', [B.FURNACE]: 'furnace', [B.SMITHING]: 'smithing', [B.ENCHANTING]: 'enchanting' };
export const STATION_NAMES: Record<Station, string> = { hand: 'Criação rápida', bench: 'Mesa de trabalho', furnace: 'Fornalha', smithing: 'Ferraria', enchanting: 'Encantamentos' };
export const recipeStation = (r: Recipe): Station => r.station ?? (r.basic ? 'hand' : 'bench');

const addRecipe = (out: number, count: number, input: [number, number][], cat: RecipeCat, station: Station = 'bench') => {
  RECIPES.push({ out, count, input, cat, station, basic: station === 'hand' });
};
addRecipe(I.STICK, 4, [[B.PLANKS, 2]], 'basico', 'hand');
addRecipe(B.FURNACE, 1, [[B.COBBLE, 8]], 'basico');
addRecipe(B.SMITHING, 1, [[B.PLANKS, 4], [I.IRON, 2]], 'basico');
addRecipe(B.ENCHANTING, 1, [[B.OBSIDIAN, 4], [I.DIAMOND, 2], [B.BOOKSHELF, 1]], 'especiais');
for (const [raw, refined, oreId] of [[I.RAW_COPPER, I.COPPER, B.COPPER], [I.RAW_IRON, I.IRON, B.IRON], [I.RAW_GOLD, I.GOLD, B.GOLD], [B.ANCIENT_DEBRIS, I.SCRAP, B.ANCIENT_DEBRIS]]) {
  addRecipe(refined, 1, [[raw, 1], [I.COAL, 1]], 'minerais', 'furnace');
  if (raw !== oreId) addRecipe(refined, 1, [[oreId, 1], [I.COAL, 1]], 'minerais', 'furnace');
}
addRecipe(I.COAL, 2, [[B.LOG, 1]], 'minerais', 'furnace');
addRecipe(I.COAL, 2, [[B.BIRCH_LOG, 1]], 'minerais', 'furnace');
addRecipe(I.NETHERITE, 1, [[I.SCRAP, 4], [I.GOLD, 4]], 'minerais', 'smithing');
addRecipe(I.UPGRADE, 1, [[I.DIAMOND, 3], [B.NETHERRACK, 4], [I.AMETHYST, 1]], 'especiais', 'smithing');
addRecipe(I.BOW, 1, [[I.STICK, 3], [I.STRING, 3]], 'armas');
addRecipe(I.CROSSBOW, 1, [[I.STICK, 3], [I.STRING, 2], [I.IRON, 1], [I.REDSTONE, 2]], 'armas');
addRecipe(I.ARROW, 8, [[I.STICK, 1], [I.FLINT, 1]], 'armas', 'hand');
addRecipe(I.TRIDENT, 1, [[I.IRON, 3], [I.DIAMOND, 2], [I.QUARTZ, 4]], 'armas', 'smithing');
addRecipe(I.MACE, 1, [[I.IRON, 6], [I.BLAZE_ROD, 1], [I.AMETHYST, 2]], 'armas', 'smithing');
addRecipe(I.SHIELD, 1, [[B.PLANKS, 6], [I.IRON, 1]], 'armaduras');
addRecipe(I.FLINT, 1, [[B.GRAVEL, 2]], 'basico', 'hand');
addRecipe(I.FLINT_STEEL, 1, [[I.FLINT, 1], [I.IRON, 1]], 'ferramentas', 'hand');
addRecipe(I.COMPASS, 1, [[I.IRON, 4], [I.REDSTONE, 1]], 'ferramentas');
addRecipe(I.SPYGLASS, 1, [[I.COPPER, 2], [I.AMETHYST, 1]], 'ferramentas');
addRecipe(I.BREAD, 1, [[I.WHEAT, 3]], 'alimentos');
addRecipe(I.GOLDEN_APPLE, 1, [[I.APPLE, 1], [I.GOLD, 8]], 'basico');
addRecipe(I.BREAD, 6, [[I.EMERALD, 1]], 'especiais');
addRecipe(I.STRING, 6, [[I.EMERALD, 1], [B.WOOL_WHITE, 1]], 'especiais');
addRecipe(I.BLAZE_POWDER, 2, [[I.BLAZE_ROD, 1]], 'especiais', 'hand');
addRecipe(I.EYE, 1, [[I.PEARL, 1], [I.BLAZE_POWDER, 1]], 'especiais', 'hand');
addRecipe(B.END_FRAME, 3, [[B.OBSIDIAN, 3], [B.STONE_BRICKS, 3], [I.BLAZE_POWDER, 1]], 'especiais');
addRecipe(I.STEAK, 4, [[I.RAW_BEEF, 4], [I.COAL, 1]], 'basico', 'furnace');
addRecipe(I.STEAK, 1, [[I.RAW_BEEF, 1], [I.COAL, 1]], 'basico', 'furnace');
addRecipe(I.COOKED_PORK, 1, [[I.RAW_PORK, 1], [I.COAL, 1]], 'basico', 'furnace');
const tntRecipe = RECIPES.find((recipe) => recipe.out === B.TNT);
if (tntRecipe) tntRecipe.input = [[B.SAND, 4], [I.GUNPOWDER, 5]];
for (const [block, item] of [[B.COPPER_BLOCK, I.COPPER], [B.IRON_BLOCK, I.IRON], [B.GOLD_BLOCK, I.GOLD], [B.DIAMOND_BLOCK, I.DIAMOND], [B.REDSTONE_BLOCK, I.REDSTONE], [B.LAPIS_BLOCK, I.LAPIS], [B.EMERALD_BLOCK, I.EMERALD], [B.QUARTZ_BLOCK, I.QUARTZ], [B.NETHERITE_BLOCK, I.NETHERITE]]) {
  if (![B.IRON_BLOCK, B.GOLD_BLOCK, B.DIAMOND_BLOCK].includes(block as 50 | 51 | 52)) addRecipe(block, 1, [[item, 9]], 'minerais');
  addRecipe(item, 9, [[block, 1]], 'minerais', 'hand');
}
// Stored ore blocks from pre-adventure saves remain useful.
for (const [block, item] of [[B.COAL, I.COAL], [B.DIAMOND, I.DIAMOND], [B.EMERALD, I.EMERALD]]) addRecipe(item, 1, [[block, 1]], 'minerais', 'furnace');

export type WoodKind = 'oak' | 'birch' | 'spruce' | 'acacia' | 'jungle' | 'dark' | 'cherry' | 'mangrove';
export interface WoodFamily { key: WoodKind; name: string; log: number; leaves: number; planks: number; sapling: number; color: string }
export const WOODS: WoodFamily[] = [
  { key: 'oak', name: 'Carvalho', log: B.LOG, leaves: B.LEAVES, planks: B.PLANKS, sapling: B.OAK_SAPLING, color: '#b58b52' },
  { key: 'birch', name: 'Bétula', log: B.BIRCH_LOG, leaves: B.BIRCH_LEAVES, planks: B.BIRCH_PLANKS, sapling: B.BIRCH_SAPLING, color: '#d9c58b' },
  { key: 'spruce', name: 'Pinheiro', log: B.SPRUCE_LOG, leaves: B.SPRUCE_LEAVES, planks: B.SPRUCE_PLANKS, sapling: B.SPRUCE_SAPLING, color: '#7b5738' },
  { key: 'acacia', name: 'Acácia', log: B.ACACIA_LOG, leaves: B.ACACIA_LEAVES, planks: B.ACACIA_PLANKS, sapling: B.ACACIA_SAPLING, color: '#c16c42' },
  { key: 'jungle', name: 'Selva', log: B.JUNGLE_LOG, leaves: B.JUNGLE_LEAVES, planks: B.JUNGLE_PLANKS, sapling: B.JUNGLE_SAPLING, color: '#b68a67' },
  { key: 'dark', name: 'Carvalho escuro', log: B.DARK_LOG, leaves: B.DARK_LEAVES, planks: B.DARK_PLANKS, sapling: B.DARK_SAPLING, color: '#55392a' },
  { key: 'cherry', name: 'Cerejeira', log: B.CHERRY_LOG, leaves: B.CHERRY_LEAVES, planks: B.CHERRY_PLANKS, sapling: B.CHERRY_SAPLING, color: '#e2afb0' },
  { key: 'mangrove', name: 'Mangue', log: B.MANGROVE_LOG, leaves: B.MANGROVE_LEAVES, planks: B.MANGROVE_PLANKS, sapling: B.MANGROVE_SAPLING, color: '#934c42' },
];
for (const wood of WOODS) {
  if (wood.key !== 'oak' && wood.key !== 'birch') {
    BLOCKS[wood.log] = def(`Tronco de ${wood.name.toLowerCase()}`, `${wood.key}_top` as TileName, `${wood.key}_log` as TileName, `${wood.key}_top` as TileName, { hardness: 2, preferredTool: 'axe' });
    BLOCKS[wood.leaves] = def(`Folhas de ${wood.name.toLowerCase()}`, `${wood.key}_leaves` as TileName, undefined, undefined, { hardness: 0.2, transparent: true, preferredTool: 'hoe', drop: 0 });
  }
  if (wood.key !== 'oak') BLOCKS[wood.planks] = def(`Tábuas de ${wood.name.toLowerCase()}`, `${wood.key}_planks` as TileName, undefined, undefined, { hardness: 2, preferredTool: 'axe' });
  BLOCKS[wood.sapling] = def(`Muda de ${wood.name.toLowerCase()}`, `${wood.key}_sapling` as TileName, undefined, undefined, { hardness: 0, solid: false, transparent: true });
  if (wood.key !== 'oak' && wood.key !== 'birch') addRecipe(wood.planks, 4, [[wood.log, 1]], 'madeiras', 'hand');
  if (wood.key !== 'oak' && wood.key !== 'birch') addRecipe(I.COAL, 2, [[wood.log, 1]], 'minerais', 'furnace');
}
export const LEAF_IDS = new Set(WOODS.map((wood) => wood.leaves));
export const LOG_IDS = new Set(WOODS.map((wood) => wood.log));
export const PLANK_IDS = new Set(WOODS.map((wood) => wood.planks));
export const SAPLING_IDS = new Set(WOODS.map((wood) => wood.sapling));
const naturalBlocks: [number, string, TileName, Partial<BlockDef>?][] = [
  [B.RED_SAND, 'Areia vermelha', 'red_sand', { hardness: 0.5, preferredTool: 'shovel' }],
  [B.TERRACOTTA, 'Terracota', 'terracotta', { minTier: 1 }],
  [B.RED_TERRACOTTA, 'Terracota vermelha', 'red_terracotta', { minTier: 1 }],
  [B.MUD, 'Lama', 'mud', { hardness: 0.5, preferredTool: 'shovel' }],
  [B.PODZOL, 'Podzol', 'podzol', { hardness: 0.5, preferredTool: 'shovel', drop: B.DIRT }],
  [B.MOSS, 'Musgo', 'moss', { hardness: 0.2, preferredTool: 'hoe' }],
  [B.BERRY_BUSH, 'Arbusto de bagas', 'berry_bush', { solid: false, transparent: true, hardness: 0.2, drop: I.BERRIES, dropCount: 2 }],
  [B.BERRY_EMPTY, 'Arbusto crescendo', 'berry_empty', { solid: false, transparent: true, hardness: 0.2, drop: B.BERRY_BUSH }],
  [B.MUSHROOM_RED, 'Cogumelo vermelho', 'mushroom_red', { solid: false, transparent: true, hardness: 0 }],
  [B.MUSHROOM_BROWN, 'Cogumelo marrom', 'mushroom_brown', { solid: false, transparent: true, hardness: 0 }],
  [B.SUGAR_CANE, 'Cana-de-açúcar', 'sugar_cane', { solid: false, transparent: true, hardness: 0 }],
  [B.MELON, 'Melancia', 'melon_side', { hardness: 0.7, preferredTool: 'axe', drop: I.MELON_SLICE, dropCount: 5 }],
  [B.LILY, 'Vitória-régia', 'lily', { solid: false, transparent: true, hardness: 0 }],
  [B.CHERRY_FLOWER, 'Flores rosadas', 'cherry_flower', { solid: false, transparent: true, hardness: 0 }],
  [B.CHEST, 'Baú', 'chest_top', { hardness: 2.5, preferredTool: 'axe', transparent: true }],
  [B.PATH, 'Caminho de terra', 'path', { hardness: 0.6, preferredTool: 'shovel', drop: B.DIRT, transparent: true }],
  [B.COARSE_DIRT, 'Terra infértil', 'coarse_dirt', { hardness: 0.5, preferredTool: 'shovel' }],
];
for (const [id, name, tile, options] of naturalBlocks) BLOCKS[id] = def(name, tile, undefined, undefined, { hardness: 1.2, ...options });
BLOCKS[B.CHEST].tiles = [T('chest_top'), T('chest_side'), T('chest_top')];
BLOCKS[B.MELON].tiles = [T('melon_top'), T('melon_side'), T('melon_top')];
for (const [id, prefix, name] of [[B.SAVANNA_GRASS, 'savanna', 'Grama da savana'], [B.JUNGLE_GRASS, 'jungle_grass', 'Grama da selva'], [B.SWAMP_GRASS, 'swamp', 'Grama do pântano']] as const) {
  BLOCKS[id] = def(name, `${prefix}_top`, `${prefix}_side`, 'dirt', { hardness: 0.6, preferredTool: 'shovel', drop: B.DIRT });
}
export const GRASS_IDS = new Set<number>([B.GRASS, B.SNOW, B.SAVANNA_GRASS, B.JUNGLE_GRASS, B.SWAMP_GRASS]);
export const SOIL_IDS = new Set<number>([...GRASS_IDS, B.DIRT, B.COARSE_DIRT, B.MOSS, B.MUD, B.PODZOL, B.FARMLAND]);
export const PLANT_IDS = new Set<number>([...SAPLING_IDS, B.TALLGRASS, B.FLOWER_RED, B.FLOWER_YELLOW, B.BERRY_BUSH, B.BERRY_EMPTY, B.MUSHROOM_RED, B.MUSHROOM_BROWN, B.SUGAR_CANE, B.CHERRY_FLOWER, B.CROPS, B.RIPE_CROPS]);
export const SLAB_IDS = new Set<number>([B.STONE_SLAB, B.PLANK_SLAB, B.COBBLE_SLAB]);
export const STAIR_IDS = new Set<number>([B.PLANK_STAIRS, B.COBBLE_STAIRS, B.BRICK_STAIRS]);
export const DOUBLE_SLABS: Record<number, number> = { [B.STONE_SLAB]: B.DOUBLE_STONE_SLAB, [B.PLANK_SLAB]: B.DOUBLE_PLANK_SLAB, [B.COBBLE_SLAB]: B.DOUBLE_COBBLE_SLAB };
for (const [slab, double] of Object.entries(DOUBLE_SLABS)) BLOCKS[double] = { ...BLOCKS[Number(slab)], name: `${BLOCKS[Number(slab)].name} dupla`, transparent: false, drop: Number(slab), dropCount: 2 };
addRecipe(B.CHEST, 1, [[B.PLANKS, 8]], 'construcao');
addRecipe(I.BOWL, 4, [[B.PLANKS, 3]], 'basico');
addRecipe(I.STEW, 1, [[B.MUSHROOM_RED, 1], [B.MUSHROOM_BROWN, 1], [I.BOWL, 1]], 'alimentos', 'hand');
addRecipe(I.PAPER, 3, [[B.SUGAR_CANE, 3]], 'basico');
addRecipe(I.BOOK, 1, [[I.PAPER, 3], [I.LEATHER, 1]], 'basico', 'hand');
addRecipe(I.SUGAR, 1, [[B.SUGAR_CANE, 1]], 'alimentos', 'hand');
addRecipe(I.BONE_MEAL, 3, [[I.BONE, 1]], 'basico', 'hand');
addRecipe(I.PUMPKIN_PIE, 1, [[B.PUMPKIN, 1], [I.SUGAR, 1], [I.WHEAT, 1]], 'alimentos', 'hand');
addRecipe(I.SWEET_BREAD, 1, [[I.BREAD, 1], [I.BERRIES, 2]], 'alimentos', 'hand');
addRecipe(B.MELON, 1, [[I.MELON_SLICE, 9]], 'alimentos');
addRecipe(B.COARSE_DIRT, 4, [[B.DIRT, 2], [B.GRAVEL, 2]], 'construcao', 'hand');
addRecipe(B.BERRY_BUSH, 1, [[I.BERRIES, 2]], 'decoracao', 'hand');
const shelfRecipe = RECIPES.find((r) => r.out === B.BOOKSHELF);
if (shelfRecipe) shelfRecipe.input = [[B.PLANKS, 6], [I.BOOK, 3]];
const fenceRecipe = RECIPES.find((r) => r.out === B.FENCE);
if (fenceRecipe) { fenceRecipe.input = [[B.PLANKS, 4], [I.STICK, 2]]; fenceRecipe.count = 3; }

export const ingredientMatches = (required: number, actual: number) => required === actual || required === B.PLANKS && PLANK_IDS.has(actual);
export const BLOCK_COUNT = 256;
const hiddenItems: Set<number> = new Set([B.NETHER_GATE, B.END_GATE, B.NETHER_PORTAL_X, B.NETHER_PORTAL_Z, B.END_SURFACE, B.END_FRAME_EYE, ...Object.values(DOUBLE_SLABS)]);
export const CREATIVE_BLOCKS = BLOCKS.flatMap((b, id) => b && id > 0 && !b.kind && !hiddenItems.has(id) ? [id] : []);
export const ALL_ITEMS = BLOCKS.flatMap((b, id) => b && id > 0 && !hiddenItems.has(id) ? [id] : []);
export const maxStack = (id: number) => BLOCKS[id]?.durability || id === I.STEW ? 1 : 64;
export const itemName = (id: number) => BLOCKS[id]?.name ?? 'Item desconhecido';
export const MINERALS = [
  { ore: B.COAL, item: I.COAL, where: 'Superfície, Y 8 a 90', use: 'Combustível e tochas', pick: 'Madeira' },
  { ore: B.COPPER, item: I.COPPER, where: 'Superfície, Y 8 a 64', use: 'Equipamento e luneta', pick: 'Pedra ou cobre' },
  { ore: B.IRON, item: I.IRON, where: 'Superfície, Y 8 a 60', use: 'Equipamento, escudo e ferraria', pick: 'Pedra ou cobre' },
  { ore: B.GOLD, item: I.GOLD, where: 'Y 4 a 32 e Nether', use: 'Equipamento e netherita', pick: 'Ferro; madeira no Nether' },
  { ore: B.REDSTONE, item: I.REDSTONE, where: 'Superfície, Y 4 a 24', use: 'Besta e bússola', pick: 'Ferro' },
  { ore: B.LAPIS, item: I.LAPIS, where: 'Superfície, Y 4 a 32', use: 'Encantar e tingir', pick: 'Pedra ou cobre' },
  { ore: B.DIAMOND, item: I.DIAMOND, where: 'Superfície, Y 4 a 18', use: 'Equipamento e obsidiana', pick: 'Ferro' },
  { ore: B.EMERALD, item: I.EMERALD, where: 'Y 4 a 50; mais nas montanhas', use: 'Trocar por pão e linha', pick: 'Ferro' },
  { ore: B.QUARTZ_ORE, item: I.QUARTZ, where: 'Nether, Y 4 a 40', use: 'Tridente e construção', pick: 'Madeira' },
  { ore: B.ANCIENT_DEBRIS, item: I.NETHERITE, where: 'Nether, Y 4 a 18', use: 'Fundir e melhorar diamante', pick: 'Diamante' },
  { ore: B.AMETHYST, item: I.AMETHYST, where: 'Superfície, Y 4 a 26', use: 'Encantar, luneta e moldes', pick: 'Pedra ou cobre' },
];
