import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { B, I, RECIPES, toolId } from '../src/game/blocks.ts';
import { overlapsWorld, pointBlocked, clearLine } from '../src/game/collision.ts';
import { findNetherFrame, netherFrameValid, findEndRing, endRingCells, PortalSystem } from '../src/game/portals.ts';
import { findPath } from '../src/game/navigation.ts';
import { makeSlot, craftInventory, normalizeSlot } from '../src/game/inventory.ts';
import { DropSystem, stackMatches } from '../src/game/drops.ts';
import { parseWorldBackup } from '../src/game/backups.ts';
import { normalizeSettings, type Slot, type SavedPortal } from '../src/game/settings.ts';
import type { Engine } from '../src/game/engine.ts';

function testWorld(floor = false) {
  const data = new Map<string, number>();
  return {
    getBlock(x: number, y: number, z: number): number { return data.get(`${x},${y},${z}`) ?? (floor && y === 0 ? B.STONE : B.AIR); },
    setBlock(x: number, y: number, z: number, id: number) { data.set(`${x},${y},${z}`, id); },
  };
}

function frame(world: ReturnType<typeof testWorld>, axis: 'x' | 'z' = 'x') {
  for (let y = 0; y < 5; y++) for (let u = 0; u < 4; u++) {
    const edge = y === 0 || y === 4 || u === 0 || u === 3;
    const corner = (y === 0 || y === 4) && (u === 0 || u === 3);
    if (edge && !corner) world.setBlock(axis === 'x' ? u : 0, y + 1, axis === 'z' ? u : 0, B.OBSIDIAN);
  }
}

test('Nether portal accepts ten obsidian blocks, in both axes, but not holes or obstructions', () => {
  for (const axis of ['x', 'z'] as const) {
    const world = testWorld(); frame(world, axis);
    const found = findNetherFrame(world, axis === 'x' ? 1 : 0, 2, axis === 'z' ? 1 : 0);
    assert.ok(found);
    assert.equal(found.axis, axis); assert.equal(found.width, 2); assert.equal(found.height, 3);
    world.setBlock(axis === 'x' ? 1 : 0, 2, axis === 'z' ? 1 : 0, B.DIRT);
    assert.equal(findNetherFrame(world, axis === 'x' ? 1 : 0, 2, axis === 'z' ? 1 : 0), null);
  }
  const world = testWorld(); frame(world);
  world.setBlock(0, 3, 0, B.AIR);
  assert.equal(findNetherFrame(world, 1, 2, 0), null);
});

test('unloaded borders are deferred rather than extinguishing a saved portal', () => {
  const record: SavedPortal = { kind: 'nether', dimension: 'overworld', x: 1, y: 2, z: 0, width: 2, height: 3, axis: 'x' };
  assert.equal(netherFrameValid({ getBlock: () => -1 }, record, true), true);
  assert.equal(netherFrameValid({ getBlock: () => -1 }, record), false);
});

test('the End ring needs exactly the twelve eye-bearing sides and an empty center', () => {
  const world = testWorld(); const cells = endRingCells(-4, 5, -4);
  assert.equal(cells.length, 12);
  cells.forEach(([x, y, z]) => world.setBlock(x, y, z, B.END_FRAME_EYE));
  assert.deepEqual(findEndRing(world, -3, 5, -4), { x: -4, y: 5, z: -4 });
  world.setBlock(...cells[0], B.END_FRAME);
  assert.equal(findEndRing(world, -3, 5, -4), null);
  world.setBlock(...cells[0], B.END_FRAME_EYE);
  world.setBlock(-2, 5, -2, B.STONE);
  assert.equal(findEndRing(world, -3, 5, -4), null);
});

test('slabs and stair cavities use their actual geometry for collision and visibility', () => {
  const world = testWorld(); world.setBlock(0, 0, 0, B.STONE_SLAB);
  assert.equal(overlapsWorld(world, [0.1, 0.51, 0.1, 0.9, 2.3, 0.9]), false);
  assert.equal(pointBlocked(world, 0.5, 0.3, 0.5), true);
  assert.equal(pointBlocked(world, 0.5, 0.8, 0.5), false);
  world.setBlock(0, 0, 0, B.PLANK_STAIRS);
  assert.equal(pointBlocked(world, 0.5, 0.8, 0.2), false);
  assert.equal(pointBlocked(world, 0.5, 0.8, 0.8), true);
  world.setBlock(1, 0, 0, B.STONE);
  assert.equal(clearLine(world, { x: 0.5, y: 0.8, z: 0.2 }, { x: 2.5, y: 0.8, z: 0.2 }), false);
});

test('bounded navigation detours around a two-block wall instead of walking through it', () => {
  const world = testWorld(true);
  for (let z = -1; z <= 1; z++) for (let y = 1; y <= 2; y++) world.setBlock(2, y, z, B.STONE);
  const path = findPath(world, { x: 0.5, y: 1, z: 0.5 }, { x: 4.5, y: 1, z: 0.5 }, 1.8, 160);
  assert.ok(path.length > 0);
  assert.ok(path.some((p) => p.z < -1 || p.z > 1.9));
  assert.ok(path.every((p) => !overlapsWorld(world, [p.x - 0.26, p.y + 0.01, p.z - 0.26, p.x + 0.26, p.y + 1.8, p.z + 0.26])));
});

test('smithing does not copy an enchantment from an unconsumed duplicate', () => {
  const bag: (Slot | null)[] = Array(36).fill(null);
  bag[0] = makeSlot(toolId('diamond', 'sword'));
  bag[1] = { ...makeSlot(toolId('diamond', 'sword')), enchant: 3 };
  bag[2] = makeSlot(I.NETHERITE); bag[3] = makeSlot(I.UPGRADE);
  const result = craftInventory(bag, RECIPES.find((r) => r.out === toolId('netherite', 'sword'))!);
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.inventory.find((slot) => slot?.id === toolId('netherite', 'sword'))?.enchant, undefined);
  assert.equal(result.inventory[1]?.enchant, 3);
});

test('dropping keeps durability and enchantment, with no transient mesh in the save', () => {
  const host = { dimension: 'overworld', scene: new THREE.Scene() } as unknown as Engine;
  const system = new DropSystem(host);
  const slot = { ...makeSlot(toolId('diamond', 'pickaxe')), durability: 420, enchant: 2 };
  assert.equal(system.spawn(slot, new THREE.Vector3(1, 40, 2), new THREE.Vector3(), 1.7), true);
  slot.durability = 2;
  const saved = system.serialize();
  assert.equal(saved[0].slot.durability, 420);
  assert.equal(saved[0].slot.enchant, 2);
  assert.equal(saved[0].delay, 1.7);
  assert.equal('mesh' in saved[0], false);
  assert.equal(stackMatches(saved[0].slot, slot), false);
  const restored = new DropSystem(host, saved);
  assert.equal(restored.serialize()[0].slot.durability, 420);
  system.dispose(); restored.dispose();
});

test('malformed settings and empty or broken stacks are rejected or clamped', () => {
  const settings = normalizeSettings({ renderDistance: 1e9, resolution: NaN, maxMobs: -12, masterVolume: 8 });
  assert.equal(settings.renderDistance, 10); assert.equal(settings.maxMobs, 3); assert.equal(settings.masterVolume, 1);
  assert.ok(Number.isFinite(settings.resolution));
  assert.equal(normalizeSlot({ id: B.STONE, count: 0.3 }), null);
  assert.equal(normalizeSlot({ id: toolId('wood', 'axe'), count: 1, durability: 0 }), null);
});

test('backups get fresh IDs and reject unsupported blocks without overwriting a world', () => {
  const data = { format: 'mineblock-world', meta: { id: 'old', name: 'Teste', mode: 'survival', type: 'normal', seed: 1 }, save: { version: 3, mods: { '0,0': [0, B.DIRT] }, inventory: [makeSlot(I.DIAMOND, 3)] } };
  const imported = parseWorldBackup(JSON.stringify(data));
  assert.notEqual(imported.meta.id, 'old'); assert.equal(imported.save.inventory?.[0]?.count, 3);
  data.save.mods['0,0'] = [0, 999];
  assert.throws(() => parseWorldBackup(JSON.stringify(data)));
});

test('portal records can be loaded without spawning any visual before entering the world', () => {
  const host = { scene: new THREE.Scene(), dimension: 'overworld' } as unknown as Engine;
  const portals = new PortalSystem(host, []);
  assert.equal(portals.records.filter((p) => p.dimension === 'nether').length, 1);
  portals.dispose();
});