import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Engine, type HudState } from '../game/engine';
import { saveWorldMeta, storeWorldSave, isTouchDevice, type Settings, type WorldMeta, type WorldSave } from '../game/settings';
import { getIcons } from '../game/textures';
import { BLOCKS, B, I, STATION_BLOCKS, STATION_NAMES } from '../game/blocks';
import { BOSS_MAX_HP, currentObjective, DIMENSION_NAMES } from '../game/adventure';
import { McButton, Heart, HungerIcon, BlockIcon, DirtBackground, DurabilityBar } from './ui';
import TouchControls from './TouchControls';
import InventoryPanel from './InventoryPanel';
import CraftingTablePanel from './CraftingTablePanel';
import SettingsScreen from './SettingsScreen';
import AdventurePanel from './AdventurePanel';
import { sfx } from '../game/sound';
import ChestPanel from './ChestPanel';

type Overlay = 'none' | 'pause' | 'settings' | 'inventory' | 'crafting' | 'journal' | 'chest';

export default function GameScreen({ meta, save, settings, onSettings, onExit }: { meta: WorldMeta; save: WorldSave | null; settings: Settings; onSettings: (s: Settings) => void; onExit: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const getEngine = useCallback(() => engineRef.current, []);
  const [hud, setHud] = useState<HudState | null>(null);
  const [overlay, setOverlay] = useState<Overlay>('none');
  const overlayRef = useRef<Overlay>('none');
  const [toast, setToast] = useState<{ text: string; k: number } | null>(null);
  const [saveMsg, setSaveMsg] = useState('');
  const [engineError, setEngineError] = useState('');
  const touch = useMemo(() => isTouchDevice(), []);
  const icons = getIcons(settings.texturePack);
  const creative = meta.mode === 'creative';
  overlayRef.current = overlay;

  const doSave = (data?: WorldSave) => {
    const e = engineRef.current;
    if (!e && !data) return false;
    const ok = storeWorldSave(meta.id, data ?? e!.serialize());
    saveWorldMeta({ ...meta, lastPlayed: Date.now(), completed: !!e?.adventure.victory && !creative });
    setSaveMsg(ok ? 'Mundo salvo ✔' : 'Erro ao salvar (armazenamento cheio)');
    setTimeout(() => setSaveMsg(''), 1800);
    return ok;
  };

  useEffect(() => {
    const canvas = canvasRef.current!;
    let engine: Engine;
    try {
    engine = new Engine(
      canvas,
      settings,
      meta,
      save,
      {
        onHud: (h) => setHud(h),
        onAutosave: (d) => doSave(d),
        onOpenCrafting: () => {
          if (overlayRef.current === 'none') {
            overlayRef.current = 'crafting';
            setOverlay('crafting');
            document.exitPointerLock?.();
          }
        },
        onOpenChest: () => {
          if (overlayRef.current === 'none') { overlayRef.current = 'chest'; setOverlay('chest'); document.exitPointerLock?.(); }
        },
        onPointerUnlock: () => {
          if (overlayRef.current === 'none') { overlayRef.current = 'pause'; engine.setPaused(true); setOverlay('pause'); }
        },
        onKey: (k) => {
          if (engine.dead || !engine.spawned || engine.adventure.victory && !engine.adventure.victorySeen) return;
          if (k === 'journal') {
            if (overlayRef.current === 'journal') { overlayRef.current = 'none'; setOverlay('none'); engine.setPaused(false); engine.lockPointer(); }
            else if (overlayRef.current === 'none') { overlayRef.current = 'journal'; setOverlay('journal'); engine.setPaused(true); document.exitPointerLock?.(); }
            return;
          }
          if (k === 'pause') {
            if (overlayRef.current !== 'none') { overlayRef.current = 'none'; setOverlay('none'); engine.setPaused(false); engine.lockPointer(); }
            else { overlayRef.current = 'pause'; setOverlay('pause'); engine.setPaused(true); }
            return;
          }
          if (k === 'inventory') {
            if (overlayRef.current === 'inventory' || overlayRef.current === 'crafting' || overlayRef.current === 'chest') {
              overlayRef.current = 'none';
              setOverlay('none');
              engine.setPaused(false);
              engine.lockPointer();
            } else if (overlayRef.current === 'none') {
              overlayRef.current = 'inventory';
              engine.setPaused(true);
              engine.emitHud();
              setOverlay('inventory');
              document.exitPointerLock?.();
            }
          }
        },
      },
      touch,
    );
    } catch (error) {
      setEngineError(error instanceof Error ? error.message : 'WebGL indisponível.');
      return;
    }
    engineRef.current = engine;
    engine.start();
    saveWorldMeta({ ...meta, lastPlayed: Date.now() });

    const onVis = () => {
      if (document.hidden) {
        engine.setPaused(true);
        storeWorldSave(meta.id, engine.serialize());
        if (overlayRef.current === 'none') setOverlay('pause');
      }
    };
    const onUnload = () => storeWorldSave(meta.id, engine.serialize());
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('beforeunload', onUnload);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('beforeunload', onUnload);
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engineRef.current?.setSettings(settings);
  }, [settings]);

  useEffect(() => {
    const won = hud?.adventure.victory && !hud.adventure.victorySeen;
    engineRef.current?.setPaused(overlay !== 'none' || !!hud?.dead || !!won);
    if (won) { overlayRef.current = 'pause'; document.exitPointerLock?.(); }
  }, [overlay, hud?.dead, hud?.adventure.victory, hud?.adventure.victorySeen]);

  // selected item toast
  const selId = hud ? hud.inventory[hud.selected]?.id ?? 0 : 0;
  const selIdx = hud?.selected ?? 0;
  useEffect(() => {
    if (selId && BLOCKS[selId]) setToast({ text: BLOCKS[selId].name, k: Date.now() });
  }, [selId, selIdx]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 1500);
    return () => clearTimeout(t);
  }, [toast]);

  const resume = () => {
    overlayRef.current = 'none';
    setOverlay('none');
    engineRef.current?.setPaused(false);
    engineRef.current?.lockPointer();
    sfx.close();
  };

  const exit = () => {
    if (!doSave()) { overlayRef.current = 'pause'; setOverlay('pause'); return; }
    if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    onExit();
  };

  const hearts = useMemo(() => {
    if (!hud) return [];
    const out: (0 | 1 | 2)[] = [];
    for (let i = 0; i < 10; i++) {
      const v = hud.health - i * 2;
      out.push(v >= 2 ? 2 : v === 1 ? 1 : 0);
    }
    return out;
  }, [hud?.health]);

  const slotSize = touch ? `min(8.6vw, ${Math.round(46 * settings.hudScale)}px)` : `${Math.round(46 * settings.hudScale)}px`;
  const objective = hud ? currentObjective(hud.adventure) : null;
  const station = hud ? STATION_BLOCKS[hud.targetId] : null;
  const portalTarget = hud?.targetId === B.NETHER_GATE || hud?.targetId === B.END_GATE;
  const openOverlay = (next: Overlay) => {
    overlayRef.current = next;
    engineRef.current?.setPaused(next !== 'none');
    setOverlay(next);
    if (document.pointerLockElement) document.exitPointerLock?.();
    sfx.open();
  };

  const exportBackup = () => {
    const engine = engineRef.current;
    if (!engine) return;
    const blob = new Blob([JSON.stringify({ format: 'mineblock-world', meta, save: engine.serialize() })], { type: 'application/json' });
    const url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url; link.download = `mineblock-${meta.id}.json`; link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
  };

  return (
    <div className="absolute inset-0 overflow-hidden bg-black">
      <canvas ref={canvasRef} className="game" />

      {hud?.underwater && <div className="pointer-events-none absolute inset-0 bg-blue-700/35" />}
      {hud && hud.hurt > 0 && settings.screenEffects && <div key={hud.hurt} className="hurt-flash pointer-events-none absolute inset-0 bg-red-600" />}
      {hud && hud.portalCharge > 0 && <div className="portal-transition" style={{ backgroundColor: settings.screenEffects ? `rgba(97,42,156,${hud.portalCharge * 0.32})` : 'transparent' }}><div>Atravessando o portal...</div><div className="portal-progress"><i style={{ width: `${Math.min(1, hud.portalCharge) * 100}%` }} /></div></div>}

      {/* crosshair */}
      {hud?.loaded && overlay === 'none' && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2 mix-blend-difference">
          <div className="absolute left-1/2 top-1/2 h-[22px] w-[3px] -translate-x-1/2 -translate-y-1/2 bg-white" />
          <div className="absolute left-1/2 top-1/2 h-[3px] w-[22px] -translate-x-1/2 -translate-y-1/2 bg-white" />
        </div>
      )}
      {hud && hud.breakProgress > 0 && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 mt-6 h-1.5 w-16 -translate-x-1/2 bg-black/60">
          <div className="h-full bg-white" style={{ width: `${Math.min(100, hud.breakProgress * 100)}%` }} />
        </div>
      )}

      {hud?.loaded && overlay === 'none' && hud.combatTarget && <div className="target-health"><span>{hud.combatTarget.name}</span><div><i style={{ width: `${hud.combatTarget.health / hud.combatTarget.maxHealth * 100}%` }} /></div>{settings.mobIntent && hud.combatTarget.intent && <small>{hud.combatTarget.intent}</small>}</div>}
      {hud?.loaded && overlay === 'none' && hud.attackReady < 1 && <div className="attack-charge"><i style={{ width: `${hud.attackReady * 100}%` }} /></div>}
      {hud?.loaded && hud.dimension === 'end' && !hud.adventure.victory && <div className="boss-hud"><div><span>DRAGÃO DO FIM</span><b>{Math.ceil(hud.adventure.bossHealth)} / {BOSS_MAX_HP}</b></div><div className="boss-health-track"><i style={{ width: `${hud.adventure.bossHealth / BOSS_MAX_HP * 100}%` }} /></div><p>{hud.bossPhase || 'Prepare seu equipamento.'}</p></div>}

      {/* touch controls */}
      {touch && hud?.loaded && overlay === 'none' && !hud.dead && (
        <TouchControls engine={getEngine} settings={settings} creative={creative} flying={hud.flying} hasShield={!!hud.equipment.offhand} />
      )}

      {/* debug / fps */}
      {(settings.showFps || settings.showCoordinates || settings.showBiome) && hud && (
        <div className="world-stats pointer-events-none absolute left-2 top-2 z-20 text-lg leading-tight text-white text-shadow" style={{ marginTop: 'env(safe-area-inset-top)' }}>
          <div className="bg-black/40 px-1.5 inline-block">
            {settings.showFps && <span className={hud.fps >= 50 ? 'text-green-300' : hud.fps >= 28 ? 'text-yellow-300' : 'text-red-400'}>{hud.fps} FPS </span>}
            {settings.showCoordinates && <>XYZ {hud.pos[0].toFixed(0)} {hud.pos[1].toFixed(0)} {hud.pos[2].toFixed(0)}</>}
          </div>
          <br />
          <div className="bg-black/40 px-1.5 inline-block text-base text-gray-200">
            {settings.showBiome ? hud.biome : DIMENSION_NAMES[hud.dimension]} {hud.flying ? '| Voando' : ''}
            {settings.showFps && <> | Res. {Math.round(hud.resolution * 100)}% | {hud.drawCalls} draw</>}
          </div>
        </div>
      )}

      {/* top-right buttons */}
      {hud?.loaded && overlay === 'none' && (
        <div className="absolute right-2 top-2 z-30 flex gap-2" style={{ marginTop: 'env(safe-area-inset-top)' }}>
          <button data-silent className="mc-btn px-2! py-1.5! text-lg!" disabled={!hud.inventory[hud.selected]} onClick={() => engineRef.current?.dropSlot(hud.selected)} title="Q: soltar 1; Ctrl + Q: soltar pilha">Soltar</button>
          <button className="mc-btn px-3! py-1.5! text-xl!" onClick={() => openOverlay('journal')} aria-label="Abrir jornada">Jornada{touch ? '' : ' [J]'}</button>
          <button
            className="mc-btn px-3! py-1.5! text-2xl!"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={() => {
              openOverlay('pause');
            }}
          >
            ❚❚
          </button>
        </div>
      )}

      {/* botão abrir mesa quando mirando nela */}
      {hud?.loaded && overlay === 'none' && !hud.dead && (station || portalTarget || hud.targetId === B.CHEST) && (
        <div className="absolute left-1/2 top-16 z-30 -translate-x-1/2" style={{ marginTop: 'env(safe-area-inset-top)' }}>
          <button
            className="mc-btn active text-xl! py-2!"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={() => engineRef.current?.tryOpenCrafting()}
          >
            {hud.targetId === B.CHEST ? 'Abrir baú' : station ? `Abrir ${STATION_NAMES[station]}` : 'Converter portal antigo'}{touch ? '' : ' [E]'}
          </button>
        </div>
      )}

      {hud?.loaded && settings.showObjectives && overlay === 'none' && objective && hud.dimension !== 'end' && !station && !portalTarget && <button className="objective-hud" onClick={() => openOverlay('journal')}><span>JORNADA {Math.min(objective.index + 1, 9)}/9</span><strong>{hud.adventure.victory ? 'Aventura concluída' : objective.step.title}</strong><span className="objective-link">Ver jornada &gt;</span></button>}
      {hud?.loaded && !settings.autoPickup && overlay === 'none' && <button className="manual-pickup mc-btn text-base! py-1!" onClick={() => engineRef.current?.drops.collectNearby(true)}>Recolher itens{touch ? '' : ' [G]'}</button>}
      {hud?.waypoint && hud.dimension === 'overworld' && overlay === 'none' && <button className="waypoint-hud" onClick={() => openOverlay('journal')}><span>DESTINO: {hud.waypoint.name}</span><strong>{Math.round(Math.hypot(hud.pos[0] - hud.waypoint.x, hud.pos[2] - hud.waypoint.z))} blocos</strong><small>X {hud.waypoint.x} / Z {hud.waypoint.z}</small></button>}

      {/* toast */}
      {toast && overlay === 'none' && (
        <div key={toast.k} className="pointer-events-none absolute left-1/2 z-20 -translate-x-1/2 text-2xl text-white text-shadow" style={{ bottom: touch ? 'calc(min(10vw,52px) + 46px)' : '96px' }}>
          {toast.text}
        </div>
      )}
      {saveMsg && <div className="pointer-events-none absolute left-1/2 top-3 z-50 -translate-x-1/2 bg-black/60 px-3 py-1 text-xl">{saveMsg}</div>}
      {hud?.notice && overlay === 'none' && <div role="status" className="game-notice">{hud.notice}</div>}
      {settings.subtitles && hud?.subtitle && overlay === 'none' && <div className="audio-caption" role="status">{hud.subtitle}</div>}
      {hud && hud.eating > 0 && overlay === 'none' && <div className="eating-progress" role="status"><span>Comendo...</span><div><i style={{ width: `${hud.eating * 100}%` }} /></div></div>}

      {/* hotbar */}
      {hud?.loaded && (
        <div className="absolute bottom-1 left-1/2 z-30 -translate-x-1/2 flex flex-col items-center gap-1" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
          {!creative && hud.air < 20 && <div className="air-meter" aria-label={`Oxigênio: ${Math.ceil(hud.air)} de 20`}>{Array.from({ length: 10 }, (_, i) => <i key={i} className={hud.air > i * 2 ? 'filled' : ''} />)}</div>}
          {!creative && (
            <div className="survival-hud">
              <div className="survival-labels"><span>{hud.armor ? `Armadura ${hud.armor}/20` : `${hud.health}/20 vida`}</span><span className={hud.hunger <= 6 ? 'hungry-label' : ''}>{settings.hungerEnabled ? hud.hunger <= 6 ? 'Hora de comer' : `Alimento ${Math.ceil(hud.hunger)}/20` : 'Fome desativada'}</span></div>
              <div className="survival-bars"><div className={`health-icons ${hud.health <= 4 ? 'low-hp' : ''}`} title={`Vida: ${hud.health}/20`}>
              {hearts.map((h, i) => (
                <Heart key={i} fill={h} size={touch ? 16 : 18} />
              ))}
              </div><div className={`hunger-icons ${hud.hunger <= 6 ? 'is-hungry' : ''}`} role="img" aria-label={`Alimento: ${Math.ceil(hud.hunger)}/20. Saciedade: ${hud.saturation.toFixed(1)}.`} title={`Alimento ${Math.ceil(hud.hunger)}/20 | Saciedade ${hud.saturation.toFixed(1)}`}>
                {Array.from({ length: 10 }, (_, i) => <HungerIcon key={i} fill={hud.hunger >= (i + 1) * 2 ? 2 : hud.hunger > i * 2 ? 1 : 0} />)}
              </div></div>
              <div className="experience-track" title={`${hud.adventure.xp} pontos de experiência`}><i style={{ width: `${hud.adventure.xp % 10 / 10 * 100}%` }} /><span>{Math.floor(hud.adventure.xp / 10) || ''}</span></div>
            </div>
          )}
          <div className="flex items-end gap-1">
            <div className="flex border-2 border-black bg-black/50 p-[2px]">
              {hud.inventory.slice(0, 9).map((s, i) => (
                <button
                  key={i}
                  data-silent
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    engineRef.current?.selectSlot(i);
                  }}
                  className={`relative flex items-center justify-center border-2 ${hud.selected === i ? 'border-white bg-white/20 scale-110 z-10' : 'border-gray-500/70'}`}
                  style={{ width: slotSize, height: slotSize, touchAction: 'none' }}
                >
                  {s && <BlockIcon src={icons[s.id]} size={64} className="h-[80%] w-[80%]" />}
                  {s && <DurabilityBar slot={s} />}
                  {s && !creative && s.count > 1 && <span className="absolute bottom-0 right-0.5 text-lg leading-none text-white text-shadow">{s.count}</span>}
                </button>
              ))}
            </div>
            <button
              className="mc-btn flex items-center justify-center p-0!"
              style={{ width: slotSize, height: slotSize, touchAction: 'none' }}
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() => {
                openOverlay('inventory');
              }}
            >
              •••
            </button>
          </div>
        </div>
      )}

      {/* desktop: click to play hint */}
      {!touch && hud?.loaded && overlay === 'none' && !hud.dead && !document.pointerLockElement && (
        <div className="pointer-events-none absolute left-1/2 top-[68%] z-20 -translate-x-1/2 bg-black/50 px-3 py-1 text-lg text-center">Clique para capturar o mouse.<br />Sem captura: arraste para olhar, Z ataca, V usa. Q solta.</div>
      )}

      {/* loading */}
      {(!hud || !hud.loaded) && !engineError && (
        <div className="absolute inset-0 z-50">
          <DirtBackground pack={settings.texturePack}>
            <div className="flex h-full flex-col items-center justify-center gap-4">
              <div className="font-pixel text-xs sm:text-base text-shadow">{!hud || hud.dimension === 'overworld' ? 'Preparando a aventura...' : `Entrando: ${DIMENSION_NAMES[hud.dimension]}...`}</div>
              <div className="h-3 w-64 border-2 border-black bg-gray-700">
                <div className="h-full bg-green-500 transition-all" style={{ width: `${Math.round((hud?.loading ?? 0) * 100)}%` }} />
              </div>
              <div className="text-xl text-gray-300">{meta.name} • Semente: {meta.seedText}</div>
            </div>
          </DirtBackground>
        </div>
      )}

      {/* overlays */}
      {overlay === 'pause' && (
        <div className="classic-pause absolute inset-0 z-50 flex flex-col items-center justify-center gap-2 bg-black/60 p-4">
          <div className="font-pixel mb-4 text-sm sm:text-lg text-shadow">Jogo Pausado</div>
          <div className="flex w-full max-w-sm flex-col gap-2">
            <McButton className="text-2xl!" onClick={resume}>
              Voltar ao Jogo
            </McButton>
            <div className="grid grid-cols-2 gap-2">
              <McButton onClick={() => setOverlay('settings')}>Opções...</McButton>
              <McButton onClick={() => doSave()}>Salvar mundo</McButton>
            </div>
            <McButton onClick={() => openOverlay('journal')}>Jornada e guia de minerais</McButton>
            <McButton onClick={exportBackup}>Exportar cópia do mundo</McButton>
            <McButton onClick={exit}>Salvar e Sair</McButton>
          </div>
          <div className="mt-3 text-xl text-gray-300">
            {meta.name} • {creative ? 'Criativo' : 'Sobrevivência'} • Semente: {meta.seedText}
          </div>
        </div>
      )}
      {overlay === 'settings' && (
        <div className="absolute inset-0 z-50">
          <DirtBackground pack={settings.texturePack} />
          <SettingsScreen settings={settings} onChange={onSettings} onBack={() => setOverlay('pause')} inGame />
        </div>
      )}
      {overlay === 'inventory' && hud && engineRef.current && (
        <InventoryPanel
          hud={hud}
          engine={engineRef.current}
          creative={creative}
          icons={icons}
          settings={settings}
          onSettings={onSettings}
          onClose={() => {
            overlayRef.current = 'none';
            setOverlay('none');
            engineRef.current?.setPaused(false);
            engineRef.current?.lockPointer();
          }}
        />
      )}
      {overlay === 'crafting' && hud && engineRef.current && (
        <CraftingTablePanel
          hud={hud}
          engine={engineRef.current}
          icons={icons}
          onClose={() => {
            overlayRef.current = 'none';
            setOverlay('none');
            engineRef.current?.setPaused(false);
            engineRef.current?.lockPointer();
          }}
        />
      )}
      {overlay === 'chest' && hud && engineRef.current && <ChestPanel hud={hud} engine={engineRef.current} icons={icons} onClose={resume} />}
      {overlay === 'journal' && hud && <AdventurePanel progress={hud.adventure} icons={icons} creative={creative} dimension={hud.dimension} onClose={resume} onReturn={() => { engineRef.current?.enterDimension('overworld'); resume(); }} onLocate={(biome) => engineRef.current?.locateBiome(biome) ?? false} currentBiome={hud.biomeId} waypoint={hud.waypoint} onClearWaypoint={() => engineRef.current?.clearWaypoint()} />}
      {hud?.adventure.victory && !hud.adventure.victorySeen && <div className="victory-screen panel-enter">
        <span className="window-kicker">MINEBLOCK / A JORNADA DO FIM</span>
        <BlockIcon src={icons[I.TROPHY]} size={112} className="victory-trophy" />
        <h1>{creative ? 'Desafio concluído!' : 'Você zerou!'}</h1>
        <p>Os cristais se apagaram. O dragão caiu.<br />Mas o seu mundo ainda tem muitas histórias.</p>
        <div className="victory-summary"><span>{Math.floor(hud.adventure.elapsed / 60)} min de aventura</span><span>{hud.adventure.kills} inimigos derrotados</span></div>
        {creative && <p className="panel-hint">Treino criativo. Jogue Sobrevivência para a campanha com recursos e dano.</p>}
        <div className="victory-actions"><McButton className="active" onClick={() => { engineRef.current?.acknowledgeVictory(); engineRef.current?.enterDimension('overworld'); resume(); }}>Voltar ao meu mundo</McButton><McButton onClick={() => { engineRef.current?.acknowledgeVictory(); exit(); }}>Salvar e sair</McButton></div>
        <span className="victory-credit">Uma aventura independente feita de blocos e possibilidades.</span>
      </div>}
      {hud?.dead && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-3 bg-red-900/60 p-4">
          <div className="font-pixel text-xl sm:text-3xl text-shadow">Você morreu!</div>
          <div className="text-xl text-gray-200 text-center">{settings.keepInventory ? 'Seus itens foram mantidos.' : <>Seus itens ficaram no local da morte.<br />{hud.deathPoint && `${DIMENSION_NAMES[hud.deathPoint.dimension]}: X ${Math.floor(hud.deathPoint.position[0])}, Y ${Math.floor(hud.deathPoint.position[1])}, Z ${Math.floor(hud.deathPoint.position[2])}`}</>}</div>
          <div className="flex w-full max-w-sm flex-col gap-2 mt-4">
            <McButton
              onClick={() => {
                engineRef.current?.respawn();
                resume();
              }}
            >
              Renascer
            </McButton>
            <McButton onClick={exit}>Menu Principal</McButton>
          </div>
        </div>
      )}
      {engineError && <div className="absolute inset-0 z-[80] flex flex-col items-center justify-center gap-4 bg-[#151b14] px-6 text-center"><h2 className="text-3xl">Não foi possível iniciar o mundo</h2><p className="max-w-md text-xl text-gray-300">Este jogo precisa de WebGL 2. Tente um navegador atualizado, ative a aceleração gráfica e feche outras abas.</p><details className="max-w-md text-base text-gray-400"><summary>Detalhes técnicos</summary>{engineError}</details><McButton onClick={onExit}>Voltar aos mundos</McButton></div>}
    </div>
  );
}
