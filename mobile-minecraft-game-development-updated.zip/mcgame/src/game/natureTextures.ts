import { classicTile } from './classicTextures';
import { hash3 } from './noise';

type RGB = [number, number, number];
const palettes: Record<string, { bark: RGB; top: RGB; leaves: RGB; planks: RGB }> = {
  oak: { bark: [102, 76, 42], top: [175, 141, 89], leaves: [65, 124, 39], planks: [173, 138, 81] },
  birch: { bark: [217, 215, 202], top: [212, 193, 142], leaves: [112, 155, 65], planks: [211, 195, 141] },
  spruce: { bark: [77, 58, 43], top: [141, 107, 66], leaves: [44, 91, 67], planks: [115, 81, 47] },
  acacia: { bark: [106, 105, 91], top: [188, 104, 62], leaves: [106, 142, 59], planks: [194, 108, 65] },
  jungle: { bark: [111, 106, 58], top: [178, 133, 89], leaves: [40, 132, 46], planks: [168, 125, 88] },
  dark: { bark: [58, 41, 29], top: [98, 70, 47], leaves: [49, 96, 38], planks: [75, 50, 34] },
  cherry: { bark: [75, 46, 52], top: [214, 156, 156], leaves: [225, 153, 177], planks: [221, 169, 166] },
  mangrove: { bark: [83, 71, 56], top: [151, 74, 66], leaves: [62, 127, 58], planks: [137, 65, 56] },
};

function tint(base: ImageData, reference: RGB, color: RGB) {
  for (let i = 0; i < base.data.length; i += 4) for (let c = 0; c < 3; c++) base.data[i + c] = Math.min(255, base.data[i + c] / Math.max(1, reference[c]) * color[c]);
  return base;
}

export function natureTile(name: string, size: number): ImageData | null {
  const wood = Object.keys(palettes).find((key) => name.startsWith(`${key}_`));
  if (wood && !name.endsWith('_sapling') && name !== 'cherry_flower') {
    const part = name.slice(wood.length + 1), palette = palettes[wood];
    if (part === 'log') return tint(classicTile('log_side', size)!, [104, 82, 47], palette.bark);
    if (part === 'top') return wood === 'birch' ? classicTile('birch_top', size)! : tint(classicTile('log_top', size)!, [171, 135, 80], palette.top);
    if (part === 'leaves') return tint(classicTile('leaves', size)!, [64, 123, 36], palette.leaves);
    if (part === 'planks') return tint(classicTile('planks', size)!, [173, 138, 81], palette.planks);
  }
  const tinted: Record<string, [string, RGB, RGB]> = {
    red_sand: ['sand', [221, 211, 163], [186, 107, 54]],
    terracotta: ['stone', [126, 126, 123], [159, 108, 79]],
    red_terracotta: ['stone', [126, 126, 123], [141, 68, 49]],
    mud: ['dirt', [125, 87, 58], [70, 66, 58]],
    coarse_dirt: ['dirt', [125, 87, 58], [131, 92, 63]],
    podzol: ['dirt', [125, 87, 58], [101, 71, 37]],
    moss: ['grass_top', [105, 158, 65], [91, 121, 49]],
    savanna_top: ['grass_top', [105, 158, 65], [151, 162, 74]],
    jungle_grass_top: ['grass_top', [105, 158, 65], [58, 149, 46]],
    swamp_top: ['grass_top', [105, 158, 65], [98, 121, 65]],
    path: ['dirt', [125, 87, 58], [160, 128, 78]],
  };
  if (tinted[name]) { const [base, reference, color] = tinted[name]; return tint(classicTile(base, size)!, reference, color); }
  if (['savanna_side', 'jungle_grass_side', 'swamp_side'].includes(name)) {
    const result = classicTile('grass_side', size)!;
    const color = tinted[name.replace('_side', '_top')][2];
    for (let i = 0; i < result.data.length; i += 4) if (result.data[i + 1] > result.data[i] * 1.1) {
      const factor = result.data[i + 1] / 158;
      result.data[i] = color[0] * factor; result.data[i + 1] = color[1] * factor; result.data[i + 2] = color[2] * factor;
    }
    return result;
  }
  const special = ['berry_bush', 'berry_empty', 'mushroom_red', 'mushroom_brown', 'sugar_cane', 'melon_side', 'melon_top', 'lily', 'cherry_flower', 'chest_top', 'chest_side', 'chest_front'];
  if (!name.endsWith('_sapling') && !special.includes(name)) return null;
  const image = new ImageData(size, size);
  for (let py = 0; py < size; py++) for (let px = 0; px < size; px++) {
    const x = Math.floor(px / size * 16), y = Math.floor(py / size * 16);
    const n = hash3(x, y, 0, 3701);
    let color: RGB = [0, 0, 0], alpha = 0, shade = 0.88 + n * 0.2;
    if (name.endsWith('_sapling')) {
      const palette = palettes[wood ?? 'oak'];
      if (x >= 7 && x <= 8 && y > 6) { color = palette.bark; alpha = 255; }
      if (((x - 8) ** 2 + (y - 5) ** 2 < 21 || y > 6 && y < 11 && Math.abs(x - 7.5) < 4) && n > 0.12) { color = palette.leaves; alpha = 255; }
    } else if (name.startsWith('berry')) {
      if (y > 2 && Math.abs(x - 7.5) < 7 - Math.max(0, 7 - y) * 0.6 && n > 0.13) { color = [56, 107, 40]; alpha = 255; }
      if (name === 'berry_bush' && alpha && (x + y * 3) % 13 < 2 && y > 4) color = [181, 47, 69];
    } else if (name.startsWith('mushroom')) {
      if (x > 6 && x < 10 && y > 8) { color = [212, 195, 151]; alpha = 255; }
      if (y >= 4 && y <= 9 && Math.abs(x - 7.5) < (y < 6 ? 4 : 6)) { color = name === 'mushroom_red' ? [181, 48, 40] : [151, 113, 73]; alpha = 255; if ((x * 3 + y * 5) % 17 < 4) color = [231, 211, 171]; }
    } else if (name === 'sugar_cane') {
      if (x % 5 < 2) { color = y % 5 === 4 ? [64, 105, 41] : [141, 180, 88]; alpha = 255; }
      if (y % 6 === 1 && x % 5 < 4) { color = [111, 160, 57]; alpha = 255; }
    } else if (name.startsWith('melon')) {
      alpha = 255; color = name === 'melon_side' && x % 4 < 2 ? [63, 115, 40] : [139, 168, 53];
      if (name === 'melon_top' && x > 6 && x < 9 && y > 5 && y < 10) color = [95, 81, 39];
    } else if (name === 'lily') {
      if ((x - 7.5) ** 2 + (y - 7.5) ** 2 < 50 && !(x > 7 && y < 6 && x - 7 > y)) { color = [58, 115, 46]; alpha = 255; if (x === y || x + y === 15) color = [94, 143, 55]; }
    } else if (name === 'cherry_flower') {
      if (x === 7 && y > 7) { color = [91, 134, 54]; alpha = 255; }
      if ((x - 7.5) ** 2 + (y - 6) ** 2 < 18) { color = [237, 163, 180]; alpha = 255; }
      if (x > 6 && x < 9 && y > 4 && y < 8) color = [238, 215, 113];
    } else if (name.startsWith('chest')) {
      alpha = 255; color = [164, 111, 51];
      if (x < 2 || x > 13 || y < 2 || y > 13 || y === 5 && name !== 'chest_top') color = [71, 48, 24];
      if (x === 2 || y === 2) color = [209, 154, 75];
      if (name === 'chest_front' && x >= 7 && x <= 8 && y >= 4 && y <= 9) { color = [190, 191, 177]; shade = 1; }
    }
    const index = (py * size + px) * 4;
    color.forEach((value, channel) => { image.data[index + channel] = value * shade; });
    image.data[index + 3] = alpha;
  }
  return image;
}