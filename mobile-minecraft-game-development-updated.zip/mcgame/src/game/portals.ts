import * as THREE from 'three';
import { B } from './blocks';
import type { Engine } from './engine';
import type { BlockReader } from './collision';
import type { SavedPortal } from './settings';
import { sfx } from './sound';

const isPortal = (id: number) => id === B.NETHER_PORTAL_X || id === B.NETHER_PORTAL_Z;
const isEmpty = (id: number) => id === B.AIR || isPortal(id);
export const portalCell = (portal: SavedPortal, u: number, v: number): [number, number, number] => portal.axis === 'x'
  ? [portal.x + u, portal.y + v, portal.z] : [portal.x, portal.y + v, portal.z + u];

export function netherFrameValid(world: BlockReader, portal: SavedPortal, allowUnloaded = false) {
  for (let v = -1; v <= portal.height; v++) for (let u = -1; u <= portal.width; u++) {
    const horizontal = v === -1 || v === portal.height, vertical = u === -1 || u === portal.width;
    if (horizontal && vertical) continue;
    const id = world.getBlock(...portalCell(portal, u, v));
    if (id === -1 && allowUnloaded) continue;
    if (horizontal || vertical) { if (id !== B.OBSIDIAN) return false; }
    else if (!isEmpty(id)) return false;
  }
  return true;
}

export function findNetherFrame(world: BlockReader, x: number, y: number, z: number): Omit<SavedPortal, 'dimension'> | null {
  for (const axis of ['x', 'z'] as const) for (let width = 2; width <= 4; width++) for (let height = 3; height <= 5; height++) {
    for (let u = 0; u < width; u++) for (let v = 0; v < height; v++) {
      const portal: SavedPortal = { kind: 'nether', dimension: 'overworld', axis, width, height, x: x - (axis === 'x' ? u : 0), y: y - v, z: z - (axis === 'z' ? u : 0) };
      if (netherFrameValid(world, portal)) return portal;
    }
  }
  return null;
}

export function endRingCells(x: number, y: number, z: number): [number, number, number][] {
  const cells: [number, number, number][] = [];
  for (let i = 1; i <= 3; i++) cells.push([x + i, y, z], [x + i, y, z + 4], [x, y, z + i], [x + 4, y, z + i]);
  return cells;
}

export function findEndRing(world: BlockReader, x: number, y: number, z: number, allEyes = true) {
  for (let dx = 0; dx <= 4; dx++) for (let dz = 0; dz <= 4; dz++) {
    const ox = x - dx, oz = z - dz;
    if (!endRingCells(ox, y, oz).every((p) => { const id = world.getBlock(...p); return id === B.END_FRAME_EYE || !allEyes && id === B.END_FRAME; })) continue;
    let free = true;
    for (let ix = 1; ix <= 3; ix++) for (let iz = 1; iz <= 3; iz++) {
      const id = world.getBlock(ox + ix, y, oz + iz);
      if (id !== B.AIR && id !== B.END_SURFACE) free = false;
    }
    if (free) return { x: ox, y, z: oz };
  }
  return null;
}

interface PortalVisual { record: SavedPortal; mesh: THREE.Mesh }

export class PortalSystem {
  records: SavedPortal[];
  charge = 0;
  cooldown = 3;
  private mustLeave = true;
  private visuals: PortalVisual[] = [];
  private timer = 0;
  private animationTime = 0;
  private hum = 0;
  private textures = new Map<string, THREE.CanvasTexture>();
  private materials = new Map<string, THREE.MeshBasicMaterial>();
  private renderedDimension = '';

  constructor(private host: Engine, records: SavedPortal[] = []) {
    this.records = records.filter((p) => ['nether', 'end', 'return'].includes(p.kind) && ['overworld', 'nether', 'end'].includes(p.dimension) && [p.x, p.y, p.z, p.width, p.height].every(Number.isFinite) && p.width >= 2 && p.width <= 5 && p.height >= 1 && p.height <= 5).map((p) => ({ ...p }));
    if (!this.records.some((p) => p.dimension === 'nether' && p.x === 7 && p.z === 5)) this.records.push({ kind: 'nether', dimension: 'nether', x: 7, y: 33, z: 5, axis: 'x', width: 2, height: 3 });
    if (!this.records.some((p) => p.kind === 'return' && p.dimension === 'end')) this.records.push({ kind: 'return', dimension: 'end', x: 7, y: 33, z: 4, axis: 'x', width: 3, height: 1 });
  }

  ignite(x: number, y: number, z: number) {
    if (this.host.dimension === 'end') { this.host.notify('O portal do Nether não pode ser aceso no Fim.'); return false; }
    const frame = findNetherFrame(this.host.world, x, y, z);
    if (!frame) { this.host.notify('Faça uma moldura de obsidiana: exterior 4 x 5, interior vazio 2 x 3. Acenda a base interna.'); return false; }
    const record: SavedPortal = { ...frame, dimension: this.host.dimension };
    if (this.records.some((p) => p.dimension === record.dimension && p.x === record.x && p.y === record.y && p.z === record.z && p.axis === record.axis)) return false;
    for (let v = 0; v < record.height; v++) for (let u = 0; u < record.width; u++) this.host.world.setBlock(...portalCell(record, u, v), record.axis === 'x' ? B.NETHER_PORTAL_X : B.NETHER_PORTAL_Z);
    this.records.push(record); this.refresh();
    sfx.ignite(); sfx.portal(); this.host.notify('Portal aceso. Entre e permaneça nele para atravessar.');
    return true;
  }

  activateEnd(x: number, y: number, z: number) {
    const ring = findEndRing(this.host.world, x, y, z);
    if (!ring) return false;
    const record: SavedPortal = { kind: 'end', dimension: this.host.dimension, axis: 'x', x: ring.x + 1, y, z: ring.z + 1, width: 3, height: 1 };
    if (this.records.some((p) => p.kind === 'end' && p.dimension === record.dimension && p.x === record.x && p.y === y && p.z === record.z)) return false;
    for (let dx = 0; dx < 3; dx++) for (let dz = 0; dz < 3; dz++) this.host.world.setBlock(record.x + dx, y, record.z + dz, B.END_SURFACE);
    this.records.push(record); this.refresh(); sfx.portal(true); this.host.notify('Os doze olhos abriram o portal. Entre no centro.'); return true;
  }

  // Convert old single-block portal kits without invalidating existing saves.
  expandLegacy(x: number, y: number, z: number, end: boolean) {
    const placements: [number, number, number, number][] = [];
    if (end) {
      for (const [px, py, pz] of endRingCells(x - 2, y, z - 2)) placements.push([px, py, pz, B.END_FRAME_EYE]);
    } else {
      for (let v = -1; v <= 3; v++) for (let u = -1; u <= 2; u++) if (v === -1 || v === 3 || u === -1 || u === 2) placements.push([x + u, y + v + 1, z, B.OBSIDIAN]);
    }
    for (const [px, py, pz, id] of placements) {
      const existing = this.host.world.getBlock(px, py, pz);
      if (!(px === x && py === y && pz === z) && existing !== 0 && existing !== id) { this.host.notify('Libere espaço ao redor do portal antigo para convertê-lo.'); return false; }
      if (py < 1 || py > 109) return false;
    }
    if (end) for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      if (!dx && !dz) continue;
      if (this.host.world.getBlock(x + dx, y, z + dz) !== B.AIR) { this.host.notify('Libere o centro 3 x 3 para converter o portal.'); return false; }
    }
    if (!end) for (let dx = 0; dx < 2; dx++) for (let dy = 1; dy <= 3; dy++) {
      if (this.host.world.getBlock(x + dx, y + dy, z) !== B.AIR) { this.host.notify('Libere o interior 2 x 3 antes de converter este portal.'); return false; }
    }
    this.host.world.setBlock(x, y, z, 0);
    placements.forEach(([px, py, pz, id]) => this.host.world.setBlock(px, py, pz, id));
    if (end) return this.activateEnd(x - 1, y, z - 2);
    return this.ignite(x, y + 1, z);
  }

  private material(kind: string) {
    let mat = this.materials.get(kind);
    if (!mat) {
      const canvas = document.createElement('canvas'); canvas.width = canvas.height = 32;
      const texture = new THREE.CanvasTexture(canvas);
      texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.NearestFilter;
      mat = new THREE.MeshBasicMaterial({ map: texture, transparent: kind === 'nether', opacity: kind === 'nether' ? 0.84 : 1, side: THREE.DoubleSide, depthWrite: kind !== 'nether', fog: true });
      this.textures.set(kind, texture); this.materials.set(kind, mat);
      this.paint(texture, kind, 0);
    }
    return mat;
  }

  private paint(texture: THREE.CanvasTexture, kind: string, time: number) {
    const context = (texture.image as HTMLCanvasElement).getContext('2d')!;
    const image = context.createImageData(32, 32);
    for (let y = 0; y < 32; y++) for (let x = 0; x < 32; x++) {
      const i = (y * 32 + x) * 4;
      if (kind === 'nether') {
        const distance = Math.hypot(x - 16, y - 16), angle = Math.atan2(y - 16, x - 16);
        const value = (Math.sin(distance * 0.6 - time * 2 + angle * 2) + Math.sin(x * 0.4 + y * 0.25 + time)) * 0.22 + 0.5;
        image.data[i] = 62 + value * 115; image.data[i + 1] = 18 + value * 36; image.data[i + 2] = 113 + value * 120;
      } else {
        const star = ((x * 73 + y * 139) % 137) < 3;
        const pulse = 0.7 + Math.sin(time + x) * 0.3;
        image.data[i] = star ? 107 * pulse : 10; image.data[i + 1] = star ? 225 * pulse : 20; image.data[i + 2] = star ? 210 * pulse : 25;
      }
      image.data[i + 3] = 255;
    }
    context.putImageData(image, 0, 0); texture.needsUpdate = true;
  }

  refresh() {
    this.visuals.forEach(({ mesh }) => { this.host.scene.remove(mesh); mesh.geometry.dispose(); });
    this.visuals = [];
    this.renderedDimension = this.host.dimension;
    for (const record of this.records) {
      if (record.dimension !== this.host.dimension) continue;
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(record.width, record.kind === 'nether' ? record.height : 3), this.material(record.kind === 'nether' ? 'nether' : 'end'));
      if (record.kind === 'nether') {
        mesh.position.set(record.x + (record.axis === 'x' ? record.width / 2 : 0.5), record.y + record.height / 2, record.z + (record.axis === 'z' ? record.width / 2 : 0.5));
        if (record.axis === 'z') mesh.rotation.y = Math.PI / 2;
      } else { mesh.rotation.x = -Math.PI / 2; mesh.position.set(record.x + 1.5, record.y + 0.72, record.z + 1.5); }
      mesh.renderOrder = 3;
      this.host.scene.add(mesh); this.visuals.push({ record, mesh });
    }
  }

  private validate(record: SavedPortal) {
    const world = this.host.world;
    if (record.kind === 'return') return true;
    if (record.kind === 'nether') return netherFrameValid(world, record, true);
    return endRingCells(record.x - 1, record.y, record.z - 1).every((pos) => { const id = world.getBlock(...pos); return id === -1 || id === B.END_FRAME_EYE; });
  }

  update(dt: number) {
    const h = this.host;
    if (this.renderedDimension !== h.dimension) this.refresh();
    this.cooldown = Math.max(0, this.cooldown - dt);
    this.timer += dt; this.hum += dt; this.animationTime += dt;
    if (this.timer > 0.2) {
      this.timer = 0;
      let changed = false;
      this.records = this.records.filter((record) => {
        if (record.dimension !== h.dimension || this.validate(record)) return true;
        changed = true;
        if (record.kind === 'nether') for (let v = 0; v < record.height; v++) for (let u = 0; u < record.width; u++) {
          const pos = portalCell(record, u, v); if (isPortal(h.world.getBlock(...pos))) h.world.setBlock(...pos, 0);
        }
        else for (let x = 0; x < 3; x++) for (let z = 0; z < 3; z++) if (h.world.getBlock(record.x + x, record.y, record.z + z) === B.END_SURFACE) h.world.setBlock(record.x + x, record.y, record.z + z, 0);
        return false;
      });
      if (changed) this.refresh();
      if (h.settings.animatedTextures) this.textures.forEach((texture, kind) => this.paint(texture, kind, this.animationTime));
    }
    let touching: SavedPortal | null = null, near = false;
    this.visuals.forEach(({ record: p, mesh }) => {
      const loaded = h.world.getBlock(p.x, p.y, p.z) !== -1;
      mesh.visible = loaded && mesh.position.distanceToSquared(h.pos) < (h.settings.renderDistance * 16) ** 2;
      if (!loaded) return;
      if (mesh.position.distanceToSquared(h.pos) < 36) near = true;
      if (p.kind === 'nether') {
        const u = p.axis === 'x' ? h.pos.x - p.x : h.pos.z - p.z;
        const side = p.axis === 'x' ? h.pos.z - p.z - 0.5 : h.pos.x - p.x - 0.5;
        if (u > -0.15 && u < p.width + 0.15 && Math.abs(side) < 0.45 && h.pos.y < p.y + p.height && h.pos.y + 1.5 > p.y) touching = p;
      } else if (h.pos.x > p.x && h.pos.x < p.x + 3 && h.pos.z > p.z && h.pos.z < p.z + 3 && h.pos.y < p.y + 1.2 && h.pos.y > p.y - 0.7) touching = p;
    });
    if (near && this.hum > 4) { this.hum = 0; sfx.portal(); }
    if (!touching) this.mustLeave = false;
    if (!touching || this.mustLeave || this.cooldown > 0 || !this.validate(touching)) { this.charge = Math.max(0, this.charge - dt * 2); return; }
    this.charge += dt / (h.meta.mode === 'creative' ? 0.4 : 1.8);
    if (this.charge >= 1) {
      const p = touching as SavedPortal;
      this.charge = 0; this.cooldown = 5; this.mustLeave = true;
      sfx.portal(true);
      const destination = p.kind === 'return' ? 'overworld' : p.kind === 'nether' ? h.dimension === 'nether' ? 'overworld' : 'nether' : h.dimension === 'end' ? 'overworld' : 'end';
      h.enterDimension(destination);
    }
  }

  dispose() {
    this.visuals.forEach(({ mesh }) => { this.host.scene.remove(mesh); mesh.geometry.dispose(); });
    this.textures.forEach((texture) => texture.dispose()); this.materials.forEach((mat) => mat.dispose());
    this.visuals = [];
  }
}