import * as THREE from 'three';
import type { Engine } from './engine';
import { B, BLOCKS, I, maxStack } from './blocks';
import { ItemModels } from './itemModels';
import { normalizeSlot } from './inventory';
import { blockBounds, clearLine, overlapsWorld } from './collision';
import type { SavedDrop, Slot } from './settings';
import { sfx } from './sound';

interface Drop extends SavedDrop { mesh?: THREE.Mesh; phase: number }

export function stackMatches(a: Slot, b: Slot) {
  return a.id === b.id && a.durability === b.durability && (a.enchant ?? 0) === (b.enchant ?? 0);
}

export class DropSystem {
  private items: Drop[] = [];
  private models: ItemModels | null = null;
  private mergeTimer = 0;
  constructor(private host: Engine, saved: SavedDrop[] = []) {
    for (const drop of Array.isArray(saved) ? saved : []) {
      if (!drop || !drop.slot) continue;
      const slot = normalizeSlot(drop.slot);
      if (!slot || !Array.isArray(drop.position) || drop.position.length !== 3 || !drop.position.every(Number.isFinite) || !['overworld', 'nether', 'end'].includes(drop.dimension)) continue;
      this.items.push({ ...drop, slot, velocity: Array.isArray(drop.velocity) && drop.velocity.length === 3 && drop.velocity.every(Number.isFinite) ? [...drop.velocity] : [0, 0, 0], age: Number.isFinite(drop.age) ? drop.age : 0, delay: Math.max(0.5, drop.delay || 0), phase: Math.random() * 6 });
    }
  }

  spawn(slot: Slot, position: THREE.Vector3, velocity = new THREE.Vector3(0, 2, 0), delay = 0.45) {
    if (!BLOCKS[slot.id] || slot.count <= 0) return false;
    if (this.items.length >= 350) this.merge();
    // Keep manual drops atomic if the entity budget is exhausted.
    if (this.items.length >= 384) return false;
    this.items.push({ slot: { ...slot }, position: position.toArray() as [number, number, number], velocity: velocity.toArray() as [number, number, number], dimension: this.host.dimension, age: 0, delay, phase: Math.random() * 6 });
    return true;
  }

  private remove(index: number) {
    const item = this.items[index];
    if (item.mesh) this.host.scene.remove(item.mesh);
    this.items.splice(index, 1);
  }

  private merge() {
    for (let i = 0; i < this.items.length; i++) {
      const a = this.items[i];
      if (a.dimension !== this.host.dimension || a.delay > 0) continue;
      const max = maxStack(a.slot.id);
      if (max === 1 || a.slot.count >= max) continue;
      for (let j = this.items.length - 1; j > i && a.slot.count < max; j--) {
        const b = this.items[j];
        if (b.dimension !== a.dimension || b.delay > 0 || !stackMatches(a.slot, b.slot)) continue;
        if (Math.hypot(...a.position.map((n, k) => n - b.position[k])) > 0.9) continue;
        const count = Math.min(max - a.slot.count, b.slot.count);
        a.slot.count += count; b.slot.count -= count;
        a.age = Math.min(a.age, b.age);
        if (!b.slot.count) this.remove(j);
      }
    }
  }

  refreshTextures() {
    this.items.forEach((item) => { if (item.mesh) { this.host.scene.remove(item.mesh); item.mesh = undefined; } });
    this.models?.dispose(); this.models = null;
  }

  collectNearby(manual = false) {
    if (this.host.dead || !this.host.spawned) return;
    if (!manual && !this.host.settings.autoPickup) return;
    const eye = this.host.pos.clone().add(new THREE.Vector3(0, 0.75, 0));
    let picked = false;
    for (let i = this.items.length - 1; i >= 0; i--) {
      const item = this.items[i];
      if (item.dimension !== this.host.dimension || item.delay > 0) continue;
      const pos = new THREE.Vector3(...item.position);
      if (pos.distanceToSquared(eye) > (manual ? 2.5 : 1.8) ** 2 || !clearLine(this.host.world, eye, pos)) continue;
      const before = item.slot.count;
      item.slot.count = this.host.receiveDrop(item.slot);
      if (item.slot.count < before) picked = true;
      if (!item.slot.count) this.remove(i);
    }
    if (picked) { sfx.pickup(); this.host.emitHud(); }
    else if (manual) this.host.notify('Aproxime-se dos itens e deixe espaço na mochila.');
  }

  update(dt: number) {
    this.mergeTimer += dt;
    if (this.mergeTimer >= 1) { this.mergeTimer = 0; this.merge(); }
    const h = this.host;
    let visible = 0;
    for (let i = this.items.length - 1; i >= 0; i--) {
      const item = this.items[i];
      const [x, y, z] = item.position;
      const distance = Math.hypot(x - h.pos.x, z - h.pos.z);
      const loaded = item.dimension === h.dimension && h.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)) !== -1;
      if (!loaded || distance > h.settings.simulationDistance) { if (item.mesh) item.mesh.visible = false; continue; }
      item.age += dt; item.delay = Math.max(0, item.delay - dt);
      const block = h.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
      const fireproof = item.slot.id === I.NETHERITE || item.slot.id === B.NETHERITE_BLOCK || BLOCKS[item.slot.id].name.includes('netherita');
      if (item.age >= 300 || y < -16 || (block === B.LAVA && !fireproof)) { this.remove(i); continue; }
      if (!item.mesh && visible < 80) {
        this.models ??= new ItemModels(h.settings.texturePack);
        item.mesh = this.models.create(item.slot.id, item.slot.enchant);
        item.mesh.scale.setScalar(BLOCKS[item.slot.id].kind ? 0.44 : 0.31);
        h.scene.add(item.mesh);
      }
      const p = item.position, v = item.velocity;
      const liquid = block === B.WATER || block === B.LAVA;
      v[1] = Math.max(-12, v[1] + (liquid ? 4 : -18) * dt);
      if (liquid) v[1] = Math.min(1.1, v[1]);
      const steps = Math.max(1, Math.ceil(Math.max(...v.map(Math.abs)) * dt / 0.14));
      for (let step = 0; step < steps; step++) {
        for (const axis of [0, 2] as const) {
          const old = p[axis]; p[axis] += v[axis] * dt / steps;
          if (overlapsWorld(h.world, [p[0] - 0.1, p[1] - 0.1, p[2] - 0.1, p[0] + 0.1, p[1] + 0.1, p[2] + 0.1])) { p[axis] = old; v[axis] *= -0.2; }
        }
        const oldY = p[1]; p[1] += v[1] * dt / steps;
        if (overlapsWorld(h.world, [p[0] - 0.09, p[1] - 0.1, p[2] - 0.09, p[0] + 0.09, p[1] + 0.1, p[2] + 0.09])) {
          p[1] = oldY;
          // A newly placed block may enclose a drop. Lift it to that block's surface.
          const ix = Math.floor(p[0]), iy = Math.floor(p[1]), iz = Math.floor(p[2]);
          const bounds = blockBounds(h.world.getBlock(ix, iy, iz), h.world.getState(ix, iy, iz));
          if (bounds.length && p[1] < iy + bounds[0][4] + 0.1) p[1] = iy + Math.max(...bounds.map((b) => b[4])) + 0.11;
          v[1] = 0; v[0] *= 0.65; v[2] *= 0.65;
        }
      }
      v[0] *= Math.exp(-dt * 2); v[2] *= Math.exp(-dt * 2);
      if (item.mesh) {
        item.mesh.visible = visible++ < 80;
        item.mesh.position.set(p[0], p[1] + 0.16 + Math.sin(item.age * 2.5 + item.phase) * 0.045, p[2]);
        item.mesh.rotation.y = item.age * 1.3 + item.phase;
      }
    }
    this.collectNearby();
  }

  serialize(): SavedDrop[] {
    return this.items.map(({ slot, position, velocity, dimension, age, delay }) => ({ slot: { ...slot }, position: [...position], velocity: [...velocity], dimension, age, delay }));
  }
  get count() { return this.items.filter((item) => item.dimension === this.host.dimension).length; }
  hideAll() { this.items.forEach((item) => { if (item.mesh) item.mesh.visible = false; }); }
  dispose() { this.refreshTextures(); this.items = []; }
}