import * as THREE from 'three';
import { BLOCKS } from './blocks';
import type { Equipment } from './settings';

export type ExplorerStyle = 'forest' | 'dusk' | 'sand';
export interface Appearance { style: ExplorerStyle; skin: number }
export const OUTFITS: { id: ExplorerStyle; name: string; coat: string; trim: string; pants: string }[] = [
  { id: 'forest', name: 'Explorador', coat: '#426d61', trim: '#d9ad62', pants: '#394552' },
  { id: 'dusk', name: 'Viajante', coat: '#58647f', trim: '#c58a75', pants: '#343847' },
  { id: 'sand', name: 'Desbravador', coat: '#ad8152', trim: '#75a2a1', pants: '#434b42' },
];
export const SKIN_TONES = ['#d5ab87', '#b98763', '#835b44', '#eed0b3'];

function paintTexture(part: string, appearance: Appearance, face = false) {
  const outfit = OUTFITS.find((item) => item.id === appearance.style) ?? OUTFITS[0];
  const skin = SKIN_TONES[appearance.skin] ?? SKIN_TONES[1];
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 16;
  const c = canvas.getContext('2d')!;
  const rect = (x: number, y: number, w: number, h: number, color: string) => { c.fillStyle = color; c.fillRect(x, y, w, h); };
  const base = part === 'head' || part === 'arm' ? skin : part === 'body' ? outfit.coat : outfit.pants;
  rect(0, 0, 16, 16, base);
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    if ((x * 7 + y * 13) % 19 < 4) rect(x, y, 1, 1, '#ffffff09');
    else if ((x * 11 + y * 5) % 23 < 4) rect(x, y, 1, 1, '#0000000c');
  }
  if (part === 'head') {
    if (face) {
      rect(0, 0, 16, 4, '#493c32'); rect(0, 4, 3, 5, '#514033'); rect(13, 4, 3, 3, '#493c32');
      rect(3, 3, 6, 3, '#514335'); rect(4, 1, 5, 1, '#655240'); rect(10, 3, 3, 2, '#3c322c');
      rect(3, 7, 4, 1, '#594936'); rect(10, 7, 3, 1, '#594936');
      rect(3, 9, 4, 2, '#ebdfc8'); rect(10, 9, 3, 2, '#ebdfc8');
      rect(5, 9, 2, 2, '#527969'); rect(10, 9, 2, 2, '#527969');
      rect(6, 10, 1, 1, '#293b31'); rect(10, 10, 1, 1, '#293b31');
      rect(7, 11, 2, 2, '#00000012'); rect(6, 14, 5, 1, '#8f6048');
      rect(1, 10, 1, 3, '#e0ae68');
    } else { rect(0, 0, 16, 12, '#4b3d32'); rect(2, 1, 4, 8, '#594735'); rect(8, 2, 5, 9, '#41352e'); }
  }
  if (part === 'body') {
    rect(0, 13, 16, 3, '#473a30'); rect(7, 13, 3, 2, '#c7ad79');
    if (face) {
      rect(4, 0, 8, 3, outfit.trim); rect(7, 2, 4, 4, outfit.trim); rect(9, 5, 2, 3, '#00000018');
      rect(2, 7, 4, 3, '#00000012'); rect(11, 8, 3, 3, '#00000012'); rect(3, 7, 2, 1, '#adbf9a');
      for (let i = 0; i < 13; i++) rect(Math.max(0, 13 - i), i + 1, 2, 1, '#745841');
      rect(8, 6, 2, 2, '#d0b68a');
    } else { rect(4, 2, 8, 9, '#59634e'); rect(5, 3, 6, 2, '#9a956d'); rect(3, 3, 1, 11, '#715c3d'); rect(12, 3, 1, 11, '#715c3d'); }
  }
  if (part === 'arm') {
    rect(0, 0, 16, 8, outfit.coat); rect(0, 7, 16, 2, '#75907a'); rect(0, 8, 16, 1, '#b6b994');
    rect(0, 12, 16, 2, '#694d36'); rect(6, 12, 4, 2, outfit.trim);
    rect(0, 15, 16, 1, '#00000012');
  }
  if (part === 'leg') { rect(0, 11, 16, 5, '#534232'); rect(0, 14, 16, 2, '#342c27'); rect(2, 7, 4, 2, '#00000015'); rect(3, 12, 7, 1, '#887352'); }
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.NearestFilter; texture.colorSpace = THREE.NoColorSpace;
  return texture;
}

export class ExplorerModel {
  root = new THREE.Group();
  head = new THREE.Group();
  rightArm = new THREE.Group();
  leftArm = new THREE.Group();
  rightLeg = new THREE.Group();
  leftLeg = new THREE.Group();
  private armor = new THREE.Group();
  private geometry = new THREE.BoxGeometry(1, 1, 1);
  private mats = new Map<string, THREE.MeshBasicMaterial>();
  private equipmentKey = '';

  constructor(public appearance: Appearance, private overlay = false, armOnly = false) {
    const colors: number[] = [];
    [0.82, 0.67, 1, 0.53, 0.95, 0.76].forEach((v) => { for (let i = 0; i < 4; i++) colors.push(v, v, v); });
    this.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    if (armOnly) { this.root.add(this.rightArm); this.bodyPart(this.rightArm, 'arm', [0.245, 0.72, 0.245], [0, -0.33, 0]); return; }
    this.root.add(this.head, this.rightArm, this.leftArm, this.rightLeg, this.leftLeg, this.armor);
    this.head.position.y = 1.64;
    this.bodyPart(this.head, 'head', [0.49, 0.49, 0.49], [0, 0, 0]);
    this.bodyPart(this.root, 'body', [0.52, 0.65, 0.27], [0, 1.07, 0]);
    this.rightArm.position.set(-0.395, 1.36, 0); this.leftArm.position.set(0.395, 1.36, 0);
    for (const arm of [this.rightArm, this.leftArm]) this.bodyPart(arm, 'arm', [0.23, 0.66, 0.24], [0, -0.30, 0]);
    this.rightLeg.position.set(-0.135, 0.73, 0); this.leftLeg.position.set(0.135, 0.73, 0);
    for (const leg of [this.rightLeg, this.leftLeg]) this.bodyPart(leg, 'leg', [0.245, 0.74, 0.265], [0, -0.37, 0]);
    this.box(this.root, '#8b7650', [0.27, 0.36, 0.12], [0, 1.06, -0.19]);
    this.box(this.root, '#baa681', [0.29, 0.11, 0.12], [0, 1.25, -0.21]);
  }

  private material(part: string, face = false) {
    const key = `${part}:${face}`;
    let material = this.mats.get(key);
    if (!material) {
      material = new THREE.MeshBasicMaterial({ map: paintTexture(part, this.appearance, face), vertexColors: true, depthTest: !this.overlay, depthWrite: !this.overlay, fog: false });
      this.mats.set(key, material);
    }
    return material;
  }

  private bodyPart(group: THREE.Group, part: string, size: number[], pos: number[]) {
    const side = this.material(part), face = this.material(part, true);
    const mesh = new THREE.Mesh(this.geometry, [side, side, side, side, face, side]);
    mesh.scale.set(size[0], size[1], size[2]); mesh.position.set(pos[0], pos[1], pos[2]);
    if (this.overlay) mesh.renderOrder = 1001; group.add(mesh); return mesh;
  }

  private box(group: THREE.Group, color: string, size: number[], pos: number[]) {
    let mat = this.mats.get(color);
    if (!mat) { mat = new THREE.MeshBasicMaterial({ color, vertexColors: true, depthTest: !this.overlay, depthWrite: !this.overlay, fog: false }); this.mats.set(color, mat); }
    const mesh = new THREE.Mesh(this.geometry, mat); mesh.scale.set(size[0], size[1], size[2]); mesh.position.set(pos[0], pos[1], pos[2]); group.add(mesh); return mesh;
  }

  setEquipment(equipment: Equipment) {
    const key = [equipment.head?.id, equipment.chest?.id, equipment.legs?.id, equipment.feet?.id].join(':');
    if (this.equipmentKey === key) return; this.equipmentKey = key;
    this.armor.clear();
    const color = (id: number) => BLOCKS[id]?.color ?? '#b6c3c7';
    if (equipment.head) {
      const c = color(equipment.head.id);
      this.box(this.armor, c, [0.545, 0.15, 0.545], [0, 1.885, 0]);
      this.box(this.armor, c, [0.09, 0.37, 0.53], [-0.27, 1.69, 0]);
      this.box(this.armor, c, [0.09, 0.37, 0.53], [0.27, 1.69, 0]);
      this.box(this.armor, c, [0.52, 0.35, 0.075], [0, 1.7, -0.25]);
    }
    if (equipment.chest) {
      const c = color(equipment.chest.id);
      this.box(this.armor, c, [0.56, 0.56, 0.32], [0, 1.07, 0]);
      for (const side of [-1, 1]) this.box(this.armor, c, [0.285, 0.19, 0.29], [side * 0.395, 1.32, 0]);
      this.box(this.armor, '#b9b6a4', [0.12, 0.11, 0.04], [0, 1.11, 0.18]);
    }
    if (equipment.legs) {
      const c = color(equipment.legs.id);
      this.box(this.armor, c, [0.51, 0.15, 0.29], [0, 0.75, 0]);
      for (const side of [-1, 1]) this.box(this.armor, c, [0.257, 0.43, 0.285], [side * 0.135, 0.47, 0]);
    }
    if (equipment.feet) for (const side of [-1, 1]) this.box(this.armor, color(equipment.feet.id), [0.267, 0.22, 0.31], [side * 0.135, 0.12, 0.015]);
  }

  setLight(value: number) { this.mats.forEach((mat, key) => mat.color.set(key.startsWith('#') ? key : '#ffffff').multiplyScalar(value)); }
  dispose() { this.root.removeFromParent(); this.geometry.dispose(); this.mats.forEach((m) => { m.map?.dispose(); m.dispose(); }); this.mats.clear(); }
}