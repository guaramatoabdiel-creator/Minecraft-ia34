import * as THREE from 'three';
import { hash3 } from './noise';

export type MobKind = 'zombie' | 'spider' | 'shadow' | 'blaze' | 'dragon' | 'crystal' | 'skeleton' | 'creeper' | 'cow' | 'pig' | 'sheep' | 'chicken';
export const MOB_NAMES: Record<MobKind, string> = { zombie: 'Zumbi', spider: 'Aranha', shadow: 'Enderman', blaze: 'Blaze', dragon: 'Dragão do Fim', crystal: 'Cristal do Fim', skeleton: 'Esqueleto', creeper: 'Creeper', cow: 'Vaca', pig: 'Porco', sheep: 'Ovelha', chicken: 'Galinha' };

export class MobModels {
  private cube = new THREE.BoxGeometry(1, 1, 1);
  private materials = new Map<string, THREE.MeshBasicMaterial>();
  private wingGeometry: THREE.BufferGeometry;
  constructor() {
    const shades = [0.76, 0.7, 1, 0.5, 0.88, 0.74];
    const colors: number[] = [];
    shades.forEach((shade) => { for (let i = 0; i < 4; i++) colors.push(shade, shade, shade); });
    this.cube.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    this.wingGeometry = new THREE.BufferGeometry();
    this.wingGeometry.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 1.4, 5, 0, -0.6, 3.2, 0, -2.4, 1.7, 0, -1.8, 0, 0, -1.3], 3));
    this.wingGeometry.setIndex([0, 1, 2, 0, 2, 3, 0, 3, 4]);
    this.wingGeometry.setAttribute('uv', new THREE.Float32BufferAttribute([0, 1, 1, 0.5, 0.64, 0, 0.34, 0.16, 0, 0.28], 2));
    this.wingGeometry.computeVertexNormals();
    this.wingGeometry.setAttribute('color', new THREE.Float32BufferAttribute(Array(15).fill(0.85), 3));
  }

  private material(color: string, motif = '') {
    const key = color + motif;
    let material = this.materials.get(key);
    if (material) return material;
    let map: THREE.CanvasTexture | null = null;
    if (typeof document !== 'undefined') {
      const canvas = document.createElement('canvas'); canvas.width = canvas.height = 16;
      const context = canvas.getContext('2d')!;
      const rgb = new THREE.Color(color);
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const grain = hash3(Math.floor(x / 2), Math.floor(y / 2), 4, color.length * 75 + color.charCodeAt(2));
        const shade = 0.84 + grain * 0.24;
        const patch = motif === 'cow' && grain > 0.5;
        context.fillStyle = patch ? '#cfc8b4' : `rgb(${Math.round(rgb.r * 255 * shade)},${Math.round(rgb.g * 255 * shade)},${Math.round(rgb.b * 255 * shade)})`;
        context.fillRect(x, y, 1, 1);
      }
      const rect = (x: number, y: number, w: number, h: number, c: string) => { context.fillStyle = c; context.fillRect(x, y, w, h); };
      if (motif === 'shirt') { rect(6, 0, 4, 3, '#6c8b73'); rect(0, 13, 16, 2, '#396d71'); rect(3, 6, 1, 4, '#2b696e'); }
      if (motif.startsWith('face')) {
        const kind = motif.slice(5);
        const eyes = kind === 'shadow' ? '#d491ff' : kind === 'blaze' ? '#442b12' : '#262a24';
        rect(3, 5, 3, 3, eyes); rect(10, 5, 3, 3, eyes);
        if (kind === 'shadow') { rect(4, 6, 1, 1, '#f4b9ff'); rect(11, 6, 1, 1, '#f4b9ff'); }
        else if (kind === 'creeper') { rect(6, 8, 4, 4, '#172a14'); rect(4, 10, 2, 4, '#172a14'); rect(10, 10, 2, 4, '#172a14'); }
        else if (kind === 'skeleton') { rect(7, 8, 2, 3, '#4f504b'); rect(4, 12, 8, 1, '#54554e'); }
        else { rect(6, 9, 4, 2, kind === 'zombie' ? '#587148' : '#5e351b'); rect(5, 12, 6, 1, '#3c4f2f'); }
      }
      map = new THREE.CanvasTexture(canvas); map.magFilter = THREE.NearestFilter; map.minFilter = THREE.NearestFilter;
      map.colorSpace = THREE.NoColorSpace;
    }
    material = new THREE.MeshBasicMaterial({ map, color: map ? '#ffffff' : color, vertexColors: true, side: THREE.DoubleSide });
    this.materials.set(key, material); return material;
  }

  part(group: THREE.Group, color: string, size: number[], position: number[], motif = '', face?: string) {
    const mat = this.material(color, motif);
    const materials = face ? [mat, mat, mat, mat, this.material(color, `face:${face}`), mat] : mat;
    const mesh = new THREE.Mesh(this.cube, materials);
    mesh.scale.set(size[0], size[1], size[2]); mesh.position.set(position[0], position[1], position[2]); group.add(mesh); return mesh;
  }

  create(kind: MobKind) {
    const group = new THREE.Group();
    const limbs: THREE.Object3D[] = [];
    let head: THREE.Object3D | undefined;
    const limb = (color: string, size: number[], pivotPosition: number[], motif = '', restX = 0, restZ = 0) => {
      const pivot = new THREE.Group(); pivot.position.set(...pivotPosition as [number, number, number]); group.add(pivot);
      this.part(pivot, color, size, [0, -size[1] / 2, 0], motif);
      pivot.rotation.x = restX; pivot.rotation.z = restZ; pivot.userData.restX = restX; pivot.userData.restZ = restZ;
      limbs.push(pivot); return pivot;
    };
    if (kind === 'zombie' || kind === 'skeleton' || kind === 'shadow') {
      const dark = kind === 'shadow', skeleton = kind === 'skeleton';
      const skin = dark ? '#22202b' : skeleton ? '#c8c5b5' : '#6c8b48';
      const legHeight = dark ? 1.35 : 0.72, bodyHeight = dark ? 0.9 : 0.75, top = legHeight + bodyHeight;
      head = this.part(group, skin, [0.5, 0.5, 0.5], [0, top + 0.25, 0], '', kind);
      if (skeleton) {
        this.part(group, skin, [0.18, 0.65, 0.18], [0, 1.05, 0]);
        for (let i = 0; i < 3; i++) this.part(group, skin, [0.58, 0.1, 0.28], [0, 0.95 + i * 0.18, 0]);
      } else this.part(group, dark ? '#26212c' : '#3e8986', [0.5, bodyHeight, 0.27], [0, legHeight + bodyHeight / 2, 0], dark ? '' : 'shirt');
      for (const side of [-1, 1]) limb(dark ? skin : skeleton ? skin : '#4b426b', [dark || skeleton ? 0.13 : 0.22, legHeight, dark ? 0.13 : 0.25], [side * 0.14, legHeight, 0]);
      for (const side of [-1, 1]) limb(skin, [dark || skeleton ? 0.13 : 0.22, dark ? 1.25 : 0.72, dark ? 0.13 : 0.24], [side * 0.4, top - 0.03, 0], '', kind === 'zombie' ? -1.4 : skeleton ? -1.1 : 0);
      if (skeleton) {
        const bow = new THREE.Group(); bow.position.set(0.46, 1.06, 0.65); group.add(bow);
        this.part(bow, '#9b713d', [0.08, 0.8, 0.08], [0.18, 0, 0]);
        this.part(bow, '#bdb7a2', [0.025, 0.75, 0.025], [-0.05, 0, 0]);
        for (const side of [-1, 1]) this.part(bow, '#9b713d', [0.28, 0.07, 0.07], [0.06, side * 0.37, 0]);
      }
    } else if (kind === 'creeper') {
      this.part(group, '#76a84a', [0.54, 0.83, 0.35], [0, 0.96, 0]);
      head = this.part(group, '#76a84a', [0.62, 0.6, 0.59], [0, 1.65, 0], '', 'creeper');
      for (const side of [-1, 1]) for (const front of [-1, 1]) limb('#67933d', [0.27, 0.45, 0.34], [side * 0.21, 0.5, front * 0.23]);
    } else if (kind === 'spider') {
      this.part(group, '#40302c', [0.85, 0.5, 0.86], [0, 0.52, -0.38]);
      this.part(group, '#332825', [0.48, 0.42, 0.57], [0, 0.54, 0.35]);
      for (const side of [-1, 1]) for (let i = 0; i < 4; i++) {
        const pivot = new THREE.Group(); pivot.position.set(side * 0.3, 0.48, i * 0.25 - 0.4); group.add(pivot);
        const leg = this.part(pivot, '#3b2c29', [0.8, 0.09, 0.11], [side * 0.4, -0.12, 0]); leg.rotation.z = -side * 0.3;
        pivot.rotation.y = (i - 1.5) * side * 0.3; limbs.push(pivot);
      }
      for (const side of [-1, 1]) for (let i = 0; i < 2; i++) this.part(group, '#ed3c2e', [0.08, 0.07, 0.03], [side * (0.09 + i * 0.09), 0.62 - i * 0.1, 0.65]);
    } else if (kind === 'cow' || kind === 'pig' || kind === 'sheep') {
      const pig = kind === 'pig', sheep = kind === 'sheep', skin = pig ? '#e0a19c' : sheep ? '#e8e4d9' : '#665344';
      this.part(group, skin, [0.85, 0.65, 1.25], [0, 0.83, 0], pig ? '' : sheep ? 'sheep' : 'cow');
      this.part(group, skin, [0.58, 0.59, 0.53], [0, 1, 0.77], pig ? '' : sheep ? 'sheep' : 'cow');
      this.part(group, pig ? '#c18080' : sheep ? '#c6b9a6' : '#b59b88', [0.35, 0.22, 0.13], [0, 0.91, 1.08]);
      for (const side of [-1, 1]) {
        this.part(group, '#26221f', [0.085, 0.08, 0.035], [side * 0.2, 1.12, 1.045]);
        if (!pig && !sheep) this.part(group, '#d1c7b0', [0.12, 0.24, 0.13], [side * 0.29, 1.39, 0.75]);
        for (const front of [-1, 1]) limb(skin, [0.22, 0.51, 0.24], [side * 0.29, 0.53, front * 0.45]);
      }
    } else if (kind === 'chicken') {
      this.part(group, '#f3eee0', [0.48, 0.5, 0.62], [0, 0.55, 0]);
      this.part(group, '#f8f4e9', [0.38, 0.38, 0.38], [0, 0.88, 0.3]);
      this.part(group, '#e3ad35', [0.2, 0.12, 0.22], [0, 0.78, 0.56]);
      this.part(group, '#b63c32', [0.12, 0.15, 0.1], [0, 1.1, 0.29]);
      for (const side of [-1, 1]) { limb('#d8a52e', [0.07, 0.28, 0.07], [side * 0.13, 0.28, 0]); this.part(group, '#252525', [0.045, 0.045, 0.025], [side * 0.1, 0.92, 0.49]); }
    } else if (kind === 'blaze') {
      this.part(group, '#e6bb4c', [0.54, 0.54, 0.54], [0, 1.6, 0], '', 'blaze');
      for (let i = 0; i < 12; i++) {
        const a = i / 4 * Math.PI * 2;
        limbs.push(this.part(group, '#dba129', [0.13, 0.55, 0.13], [Math.cos(a) * 0.65, 0.35 + Math.floor(i / 4) * 0.5, Math.sin(a) * 0.65]));
      }
    } else if (kind === 'crystal') {
      const core = this.part(group, '#d185ea', [0.7, 0.7, 0.7], [0, 0, 0]); core.rotation.z = Math.PI / 4; limbs.push(core);
      for (const side of [-1, 1]) {
        this.part(group, '#bfb4d1', [0.08, 1.25, 0.08], [side * 0.55, 0, side * 0.55]);
        this.part(group, '#bfb4d1', [1.1, 0.07, 1.1], [0, side * 0.62, 0]);
      }
      this.part(group, '#494150', [1.2, 0.12, 1.2], [0, -0.85, 0]);
    } else {
      this.part(group, '#302b38', [1.65, 1.25, 3.7], [0, 0, 0]);
      this.part(group, '#37313f', [1.05, 0.75, 1.25], [0, 0.15, 2.25]);
      this.part(group, '#393241', [0.85, 0.45, 1.3], [0, -0.02, 3.1]);
      for (const side of [-1, 1]) {
        this.part(group, '#d99afa', [0.19, 0.12, 0.36], [side * 0.54, 0.4, 2.65]);
        this.part(group, '#aba2b3', [0.13, 0.64, 0.22], [side * 0.43, 0.78, 2]);
        const pivot = new THREE.Group(); pivot.position.set(side * 0.65, 0.32, -0.2); group.add(pivot);
        const wing = new THREE.Mesh(this.wingGeometry, this.material('#55415e')); wing.scale.x = side; pivot.add(wing);
        const spar = this.part(pivot, '#9c889f', [5, 0.11, 0.14], [side * 2.4, 0, 0.35]); spar.rotation.y = side * 0.36;
        limbs.push(pivot);
        this.part(group, '#3e3546', [0.3, 0.8, 0.35], [side * 0.62, -0.72, 0.7]);
      }
      for (let i = 0; i < 5; i++) {
        this.part(group, '#3b3143', [0.65 - i * 0.08, 0.6 - i * 0.07, 1.1], [0, 0, -2.2 - i * 0.8]);
        this.part(group, '#afa0ba', [0.12, 0.35 - i * 0.04, 0.3], [0, 0.5, -1.3 - i]);
      }
    }
    return { group, limbs, head };
  }

  dispose() { this.cube.dispose(); this.wingGeometry.dispose(); this.materials.forEach((mat) => { mat.map?.dispose(); mat.dispose(); }); this.materials.clear(); }
}