import { B, BLOCKS, SLAB_IDS, STAIR_IDS } from './blocks';

export type Bounds = readonly [number, number, number, number, number, number];
const FULL: Bounds[] = [[0, 0, 0, 1, 1, 1]];
const SLAB: Bounds[] = [[0, 0, 0, 1, 0.5, 1]];
const STAIRS: Bounds[] = [[0, 0, 0, 1, 0.5, 1], [0, 0.5, 0.5, 1, 1, 1]];
const FENCE: Bounds[] = [[0.375, 0, 0.375, 0.625, 1.5, 0.625], [0, 0.3, 0.4375, 1, 1.5, 0.5625], [0.4375, 0.3, 0, 0.5625, 1.5, 1]];
const FRAME: Bounds[] = [[0, 0, 0, 1, 0.8125, 1]];
const CHEST: Bounds[] = [[0.0625, 0, 0.0625, 0.9375, 0.875, 0.9375]];
const LOW_SOIL: Bounds[] = [[0, 0, 0, 1, 0.9375, 1]];
const EMPTY: Bounds[] = [];
const SHAPES = new Map<string, Bounds[]>();

export function blockBounds(id: number, state = 0): Bounds[] {
  if (id === -1) return FULL;
  if (!BLOCKS[id]?.solid) return EMPTY;
  if (SLAB_IDS.has(id) || STAIR_IDS.has(id)) {
    if (!state) return SLAB_IDS.has(id) ? SLAB : STAIRS;
    const key = `${id}:${state}`;
    const cached = SHAPES.get(key); if (cached) return cached;
    const boxes = (SLAB_IDS.has(id) ? SLAB : STAIRS).map((source) => {
      let [x0, y0, z0, x1, y1, z1] = source;
      if (state & 4) [y0, y1] = [1 - y1, 1 - y0];
      for (let r = 0; r < (state & 3); r++) [x0, z0, x1, z1] = [z0, 1 - x1, z1, 1 - x0];
      return [x0, y0, z0, x1, y1, z1] as Bounds;
    });
    SHAPES.set(key, boxes); return boxes;
  }
  if (id === B.FENCE) return FENCE;
  if (id === B.END_FRAME || id === B.END_FRAME_EYE) return FRAME;
  if (id === B.CHEST) return CHEST;
  if (id === B.PATH || id === B.FARMLAND) return LOW_SOIL;
  return FULL;
}

export function intersects(a: Bounds, b: Bounds, x = 0, y = 0, z = 0) {
  return a[0] < b[3] + x - 1e-6 && a[3] > b[0] + x + 1e-6
    && a[1] < b[4] + y - 1e-6 && a[4] > b[1] + y + 1e-6
    && a[2] < b[5] + z - 1e-6 && a[5] > b[2] + z + 1e-6;
}

export interface BlockReader { getBlock(x: number, y: number, z: number): number; getState?(x: number, y: number, z: number): number }

export function overlapsWorld(world: BlockReader, box: Bounds) {
  for (let y = Math.floor(box[1]) - 1; y <= Math.floor(box[4] - 1e-6); y++)
    for (let z = Math.floor(box[2]); z <= Math.floor(box[5] - 1e-6); z++)
      for (let x = Math.floor(box[0]); x <= Math.floor(box[3] - 1e-6); x++) {
        for (const bounds of blockBounds(world.getBlock(x, y, z), world.getState?.(x, y, z))) if (intersects(box, bounds, x, y, z)) return true;
      }
  return false;
}

export function pointBlocked(world: BlockReader, x: number, y: number, z: number) {
  const ix = Math.floor(x), iz = Math.floor(z);
  for (let iy = Math.floor(y) - 1; iy <= Math.floor(y); iy++)
    for (const b of blockBounds(world.getBlock(ix, iy, iz), world.getState?.(ix, iy, iz))) {
      if (x >= ix + b[0] && x < ix + b[3] && y >= iy + b[1] && y < iy + b[4] && z >= iz + b[2] && z < iz + b[5]) return true;
    }
  return false;
}

export function clearLine(world: BlockReader, from: { x: number; y: number; z: number }, to: { x: number; y: number; z: number }, step = 0.2) {
  return firstBlockIntersection(world, from, to, step) === null;
}

export function segmentBox(from: { x: number; y: number; z: number }, to: { x: number; y: number; z: number }, box: Bounds): number | null {
  const origin = [from.x, from.y, from.z], direction = [to.x - from.x, to.y - from.y, to.z - from.z];
  let near = 0, far = 1;
  for (let axis = 0; axis < 3; axis++) {
    if (Math.abs(direction[axis]) < 1e-10) { if (origin[axis] < box[axis] || origin[axis] > box[axis + 3]) return null; continue; }
    let a = (box[axis] - origin[axis]) / direction[axis], b = (box[axis + 3] - origin[axis]) / direction[axis];
    if (a > b) [a, b] = [b, a]; near = Math.max(near, a); far = Math.min(far, b);
    if (near > far) return null;
  }
  return near >= 0 && near <= 1 ? near : null;
}

// Visit every crossed voxel, then test its actual boxes; thin fences cannot be skipped.
export function firstBlockIntersection(world: BlockReader, from: { x: number; y: number; z: number }, to: { x: number; y: number; z: number }, _step = 0.2) {
  const delta = [to.x - from.x, to.y - from.y, to.z - from.z], origin = [from.x, from.y, from.z];
  const voxel = origin.map(Math.floor), end = [to.x, to.y, to.z].map(Math.floor);
  const sign = delta.map(Math.sign), step = delta.map((d) => d ? Math.abs(1 / d) : Infinity);
  const next = delta.map((d, axis) => d > 0 ? (voxel[axis] + 1 - origin[axis]) / d : d < 0 ? (voxel[axis] - origin[axis]) / d : Infinity);
  const seen = new Set<string>(); let result: number | null = null;
  const budget = Math.min(2048, Math.abs(end[0] - voxel[0]) + Math.abs(end[1] - voxel[1]) + Math.abs(end[2] - voxel[2]) + 6);
  for (let count = 0; count < budget; count++) {
    const [x, y, z] = voxel;
    for (const py of [y, y - 1]) {
      const key = `${x},${py},${z}`; if (seen.has(key)) continue; seen.add(key);
      for (const bounds of blockBounds(world.getBlock(x, py, z), world.getState?.(x, py, z))) {
        const t = segmentBox(from, to, [x + bounds[0], py + bounds[1], z + bounds[2], x + bounds[3], py + bounds[4], z + bounds[5]]);
        if (t !== null && (result === null || t < result)) result = t;
      }
    }
    const t = Math.min(...next); if (t > 1 || result !== null && result <= t || voxel.every((v, i) => v === end[i])) break;
    const axis = next.indexOf(t); voxel[axis] += sign[axis]; next[axis] += step[axis];
  }
  return result;
}