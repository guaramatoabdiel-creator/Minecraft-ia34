import { useState } from 'react';
import type { Engine, HudState } from '../game/engine';
import { B, I, BLOCKS, RECIPES, STATION_NAMES, recipeStation, type RecipeCat, type Recipe } from '../game/blocks';
import { BlockIcon, ItemStats, McButton } from './ui';
import { makeSlot } from '../game/inventory';
import CraftingWorkspace from './CraftingWorkspace';
import { searchText } from '../utils/search';

const categories: { id: RecipeCat | 'all'; label: string }[] = [
  { id: 'all', label: 'Tudo' }, { id: 'ferramentas', label: 'Ferramentas' }, { id: 'armas', label: 'Armas' },
  { id: 'armaduras', label: 'Armaduras' }, { id: 'basico', label: 'Básico' },
  { id: 'minerais', label: 'Minerais' }, { id: 'construcao', label: 'Construção' }, { id: 'decoracao', label: 'Decoração' }, { id: 'especiais', label: 'Especiais' },
  { id: 'alimentos', label: 'Alimentos' }, { id: 'madeiras', label: 'Madeiras' },
];

function recipePreview(recipe: Recipe): ([number, number] | null)[] {
  const item = BLOCKS[recipe.out], material = recipe.input[0][0];
  const patterns: Record<string, string> = { pickaxe: 'MMM.S..S.', axe: 'MM.MS..S.', shovel: '.M..S..S.', hoe: 'MM..S..S.', sword: '.M..M..S.', head: 'MMMM.M...', chest: 'M.MMMMMMM', legs: 'MMMM.MM.M', feet: 'M.MM.M...' };
  const key = item.tool ?? item.equip;
  if (recipeStation(recipe) === 'bench' && key && patterns[key]) {
    const cells = patterns[key].split('').map((char): [number, number] | null => char === 'M' ? [material, 1] : char === 'S' ? [I.STICK, 1] : null);
    const count = (id: number) => cells.reduce((n, cell) => n + (cell?.[0] === id ? cell[1] : 0), 0);
    if (recipe.input.every(([id, n]) => count(id) === n)) return cells;
  }
  const cells: ([number, number] | null)[] = Array(9).fill(null);
  if (recipe.input.reduce((sum, [, n]) => sum + n, 0) <= 9) {
    let index = 0;
    recipe.input.forEach(([id, n]) => { for (let i = 0; i < n; i++) cells[index++] = [id, 1]; });
  } else recipe.input.forEach((ingredient, index) => { cells[index] = ingredient; });
  return cells;
}

export default function CraftingTablePanel({ hud, engine, icons, onClose }: { hud: HudState; engine: Engine; icons: string[]; onClose: () => void }) {
  const [category, setCategory] = useState<RecipeCat | 'all'>('all');
  const [query, setQuery] = useState('');
  const [craftableOnly, setCraftableOnly] = useState(false);
  const [selection, setSelection] = useState<number | null>(null);
  const [message, setMessage] = useState('');
  const station = engine.craftingStation;
  const creative = engine.meta.mode === 'creative';
  const list = RECIPES.map((r, i) => ({ r, i })).filter(({ r, i }) => {
    const source = recipeStation(r);
    return (source === station || source === 'hand' && station === 'bench') && (category === 'all' || r.cat === category)
      && searchText(BLOCKS[r.out].name).includes(searchText(query)) && (!craftableOnly || engine.canCraft(i, station));
  });
  const selected = list.find(({ i }) => i === selection) ?? list[0];
  const stationIcon = station === 'furnace' ? B.FURNACE : station === 'smithing' ? B.SMITHING : station === 'enchanting' ? B.ENCHANTING : B.CRAFTING;
  const craft = (all: boolean) => {
    if (!selected) return;
    let batches = 0;
    for (let n = 0; n < (all ? 16 : 1); n++) { if (!engine.craft(selected.i, station)) break; batches++; }
    setMessage(batches ? `${batches * selected.r.count}x ${BLOCKS[selected.r.out].name} criado.` : engine.craftError);
  };

  if (station === 'bench') return <div className="game-modal"><div className="inventory-window workshop-window panel-enter">
    <header className="window-heading"><div className="flex items-center gap-3"><BlockIcon src={icons[B.CRAFTING]} size={48} /><div><span className="window-kicker">MINEBLOCK / CRIAÇÃO</span><h2>Mesa de trabalho</h2></div></div><McButton className="compact-btn" onClick={onClose}>Fechar</McButton></header>
    <div className="window-content scroll-thin"><CraftingWorkspace hud={hud} engine={engine} icons={icons} size={3} station="bench" /></div>
    <footer className="window-footer"><span>Monte sua receita ou preencha a grade pelo livro.</span><span>{hud.adventure.xp} XP</span></footer>
  </div></div>;

  return <div className="game-modal" onContextMenu={(e) => e.preventDefault()}>
    <div className="inventory-window workshop-window panel-enter">
      <header className="window-heading"><div className="flex items-center gap-3"><BlockIcon src={icons[stationIcon]} size={48} /><div><span className="window-kicker">MINEBLOCK / OFICINA</span><h2>{STATION_NAMES[station]}</h2></div></div><McButton className="compact-btn" onClick={onClose}>Fechar</McButton></header>
      {station === 'enchanting' ? <div className="window-content scroll-thin">
        <h3 className="text-2xl mb-1">Um novo poder para seu equipamento</h3><p className="panel-hint mb-4">Cada melhoria custa 3 lápis-lazúli, 1 ametista e 5 XP. Aumenta o dano, a mineração ou a proteção e restaura a durabilidade. Máximo: III.</p>
        <div className="enchant-list">{hud.inventory.map((slot, i) => slot && BLOCKS[slot.id].durability ? <button key={i} className="quick-recipe" onClick={() => { setMessage(engine.enchantItem(i) ? `${BLOCKS[slot.id].name} encantado.` : engine.craftError); }}><BlockIcon src={icons[slot.id]} size={48} /><div><strong>{BLOCKS[slot.id].name}</strong><ItemStats slot={slot} /></div><span className="enchantment-text">Encantar</span></button> : null)}</div>
        {!hud.inventory.some((s) => s && BLOCKS[s.id].durability) && <p className="empty-result">Coloque uma ferramenta, arma ou peça de armadura na mochila.</p>}
      </div> : <>
        <div className="workshop-search"><input className="mc-input" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar receita..." aria-label="Buscar receita" /><label><input type="checkbox" checked={craftableOnly} onChange={(e) => setCraftableOnly(e.target.checked)} /> Só disponíveis</label></div>
        <nav className="window-tabs horizontal-scroll" aria-label="Categorias de receitas">{categories.map((cat) => <button key={cat.id} className={category === cat.id ? 'selected' : ''} onClick={() => setCategory(cat.id)}>{cat.label}</button>)}</nav>
        <div className="workshop-body">
          <div className="recipe-browser scroll-thin">{list.map(({ r, i }) => <button key={i} className={`recipe-entry ${selected?.i === i ? 'chosen' : ''}`} onClick={() => { setSelection(i); setMessage(''); }}>
            <BlockIcon src={icons[r.out]} size={42} /><div><strong>{BLOCKS[r.out].name}</strong><span>{r.count} por criação</span></div><i className={engine.canCraft(i, station) ? 'available-dot' : 'unavailable-dot'} />
          </button>)}{!list.length && <p className="empty-result">Nenhuma receita encontrada.</p>}</div>
          {selected && <section className="recipe-detail scroll-thin">
            <div className="recipe-result"><BlockIcon src={icons[selected.r.out]} size={88} /><div><span className="window-kicker">RESULTADO / {selected.r.count} UN.</span><h3>{BLOCKS[selected.r.out].name}</h3><ItemStats slot={makeSlot(selected.r.out)} /></div></div>
            <div className="craft-preview" aria-label="Prévia automática da receita">
              <div className="craft-preview-grid">{recipePreview(selected.r).map((cell, i) => <div key={i} className="mc-slot" title={cell ? `${cell[1]}x ${BLOCKS[cell[0]].name}` : 'Espaço vazio'}>{cell && <><BlockIcon src={icons[cell[0]]} size={31} />{cell[1] > 1 && <small>{cell[1]}</small>}</>}</div>)}</div>
              <span className="craft-preview-arrow" aria-hidden="true">&gt;</span>
              <button className="mc-slot craft-preview-result" disabled={!engine.canCraft(selected.i, station)} onClick={() => craft(false)} aria-label={`Criar ${BLOCKS[selected.r.out].name}`}><BlockIcon src={icons[selected.r.out]} size={51} /><small>{selected.r.count}</small></button>
            </div>
            <p className="panel-hint mb-3">Prévia automática. Toque no resultado ou em Criar.</p>
            <div className="section-label">Materiais necessários</div>
            <div className="ingredient-list">{selected.r.input.map(([id, count]) => {
              const have = engine.countIngredient(id);
              return <div key={id} className={have >= count || creative ? '' : 'missing-ingredient'}><BlockIcon src={icons[id]} size={36} /><span>{BLOCKS[id].name}</span><b>{creative ? 'Livre' : `${have}/${count}`}</b></div>;
            })}</div>
            <div className="recipe-craft-actions"><McButton className="active" disabled={!engine.canCraft(selected.i, station)} onClick={() => craft(false)}>{station === 'furnace' ? 'Fundir' : 'Criar'} {selected.r.count}</McButton><McButton disabled={!engine.canCraft(selected.i, station)} onClick={() => craft(true)}>Até 16 vezes</McButton></div>
            {!engine.canCraft(selected.i, station) && <p className="panel-hint">Confira os materiais e deixe espaço livre na mochila.</p>}
            {station === 'furnace' && <p className="panel-hint">Fusão simplificada: o combustível é consumido junto com o minério.</p>}
            {station === 'smithing' && <p className="panel-hint">A melhoria de netherita preserva os encantamentos do equipamento de diamante.</p>}
          </section>}
        </div>
      </>}
      <footer className="window-footer" aria-live="polite"><span>{message || `${list.length} receitas nesta estação`}</span><span>{hud.adventure.xp} XP</span></footer>
    </div>
  </div>;
}