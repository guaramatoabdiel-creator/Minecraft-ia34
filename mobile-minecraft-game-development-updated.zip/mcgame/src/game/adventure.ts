import { B, I, toolId } from './blocks';
import type { Adventure, Dimension, Equipment } from './settings';

export const BOSS_MAX_HP = 600; // Dragão final reforçado para uma campanha mais difícil
export const DIMENSION_NAMES: Record<Dimension, string> = { overworld: 'Superficie', nether: 'Nether', end: 'O Fim' };

export const emptyEquipment = (): Equipment => ({ head: null, chest: null, legs: null, feet: null, offhand: null });

export const newAdventure = (): Adventure => ({
  collected: [], crafted: [], kills: 0, blazes: 0, deaths: 0, mined: 0, elapsed: 0, xp: 0,
  netherVisited: false, endVisited: false, crystals: [], bossHealth: BOSS_MAX_HP,
  victory: false, victorySeen: false, biomes: [],
});

export function journeySteps(progress: Adventure) {
  const got = (id: number) => progress.collected.includes(id) || progress.crafted.includes(id);
  return [
    { title: 'O primeiro abrigo', icon: B.CRAFTING, done: got(B.CRAFTING), text: 'Quebre um tronco e crie tábuas. Na grade 2x2, monte sua mesa de trabalho para liberar as ferramentas iniciais.' },
    { title: 'A idade da pedra', icon: toolId('stone', 'pickaxe'), done: got(toolId('stone', 'pickaxe')) || got(I.IRON), text: 'Crie uma picareta de madeira para coletar pedregulho e evoluir para ferramentas de pedra.' },
    { title: 'Ferro em brasa', icon: I.IRON, done: got(I.IRON), text: 'Encontre ferro nas cavernas e crie uma fornalha para fundir os metais brutos usando carvão.' },
    { title: 'Bem equipado', icon: toolId('iron', 'sword'), done: got(toolId('iron', 'sword')) || got(toolId('diamond', 'sword')), text: 'Monte sua armadura completa e espada de ferro para sobreviver às hordas noturnas.' },
    { title: 'Diamantes nas profundezas', icon: I.DIAMOND, done: got(toolId('diamond', 'pickaxe')), text: 'Desça até as camadas mais profundas (abaixo de Y 18) para achar diamante. Use-o para quebrar obsidiana.' },
    { title: 'Atravessar o fogo', icon: B.OBSIDIAN, done: progress.netherVisited, text: 'Construa um portal vertical de Obsidiana (4x5) e acenda com a pederneira para acessar a dimensão do Nether.' },
    { title: 'Os olhos do caminho', icon: I.EYE, done: progress.endVisited, text: 'Derrote Blazes no Nether e Endermen na superfície. Junte os materiais para criar Olhos do Fim e lançá-los para achar o portal!' },
    { title: 'Quebrar o vínculo', icon: I.AMETHYST, done: progress.crystals.length >= 4, text: 'Atravesse para O Fim e destrua os 4 cristais no topo das torres. Eles curam o Dragão!' },
    { title: 'O último voo', icon: I.TROPHY, done: progress.victory, text: 'Enfrente o Dragão em sua força máxima. Bloqueie as rajadas com o escudo e ataque na hora certa para zerar a campanha.' },
  ].map((step) => ({ ...step, done: progress.victory || step.done }));
}

export function currentObjective(progress: Adventure) {
  const steps = journeySteps(progress);
  const index = steps.findIndex((step) => !step.done);
  return { step: index < 0 ? steps[steps.length - 1] : steps[index], index: index < 0 ? steps.length : index, total: steps.length, completed: steps.filter((s) => s.done).length };
}
