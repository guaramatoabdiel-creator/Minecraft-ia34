import type { Settings } from './settings';

export type TrackId = 'meadow' | 'forest' | 'night' | 'depths';
interface Track { id: TrackId; name: string; subtitle: string; tempo: number; root: number; chords: number[][]; melody: number[] }
export const MUSIC_TRACKS: Track[] = [
  { id: 'meadow', name: 'Primeiro Amanhecer', subtitle: 'Piano, luz e caminhos abertos', tempo: 78, root: 60,
    chords: [[0, 4, 7], [-3, 0, 4], [-5, 0, 4], [-7, -3, 2]],
    melody: [12, 16, 19, -99, 16, 14, 12, 7, 9, 12, 16, -99, 19, 16, 12, -99, 12, 14, 16, 19, 21, 19, 16, 14, 12, 7, 9, 12, 14, 12, -99, -99] },
  { id: 'forest', name: 'Entre as Copas', subtitle: 'Teclas suaves e ecos de madeira', tempo: 70, root: 62,
    chords: [[0, 3, 7], [-5, 0, 3], [-2, 2, 5], [-7, -3, 0]],
    melody: [7, 12, 15, -99, 19, 15, 14, 12, 10, 7, 5, -99, 7, 10, 12, -99, 15, 14, 12, 7, 10, 12, 14, -99, 12, 10, 7, 5, 7, -99, -99, -99] },
  { id: 'night', name: 'Constelações', subtitle: 'Uma melodia para abrigos e noites calmas', tempo: 62, root: 57,
    chords: [[0, 4, 7], [-2, 2, 5], [-5, -1, 2], [-7, -3, 0]],
    melody: [19, -99, 16, 12, 14, -99, 12, 7, 9, -99, 12, 16, 14, 12, -99, -99, 24, 19, -99, 16, 19, 21, 19, -99, 16, 14, 12, 9, 7, -99, -99, -99] },
  { id: 'depths', name: 'Além da Pedra', subtitle: 'Sons graves e notas suspensas', tempo: 66, root: 55,
    chords: [[0, 3, 7], [-1, 3, 6], [-5, -2, 2], [-7, -4, 0]],
    melody: [12, -99, 15, 14, 12, -99, 7, 6, 7, -99, 10, 12, 15, -99, 14, -99, 19, -99, 15, 12, 14, 10, 7, -99, 6, 7, 12, 10, 7, -99, -99, -99] },
];

let musicContext: AudioContext | null = null;
let bus: GainNode | null = null;
let wave: PeriodicWave | null = null;
let beatAt = 0;
let beatIndex = 0;
let selected: TrackId = 'meadow';
let automatic: TrackId = 'meadow';
let forced: TrackId | null = null;
let lastMode = 'auto';
let started = false;
let userPaused = false;
let lastGain = -1;
const active = new Set<OscillatorNode>();
const listeners = new Set<() => void>();
let status = { title: MUSIC_TRACKS[0].name, subtitle: MUSIC_TRACKS[0].subtitle, id: 'meadow' as TrackId, playing: false, unlocked: false };

export const getMusicStatus = () => status;
export const subscribeMusic = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };
function publish(playing: boolean, unlocked = started) {
  const track = MUSIC_TRACKS.find((item) => item.id === selected)!;
  if (status.id === selected && status.playing === playing && status.unlocked === unlocked) return;
  status = { title: track.name, subtitle: track.subtitle, id: selected, playing, unlocked };
  listeners.forEach((listener) => listener());
}

export function setMusicScene(realm: string, biome = '', night = false) {
  automatic = realm === 'nether' || realm === 'end' || realm === 'cave' ? 'depths' : night ? 'night'
    : ['forest', 'birch', 'taiga', 'jungle', 'swamp', 'dark_forest'].includes(biome) ? 'forest' : 'meadow';
}

export function toggleMusicPlayback() { userPaused = !userPaused; if (!userPaused) beatAt = 0; publish(!userPaused && started); }
export function setMusicPlayback(playing: boolean) { userPaused = !playing; if (playing) beatAt = 0; publish(playing && started); }
export function nextMusicTrack() {
  const index = MUSIC_TRACKS.findIndex((track) => track.id === selected);
  forced = MUSIC_TRACKS[(index + 1) % MUSIC_TRACKS.length].id;
  selected = forced; beatIndex = 0; beatAt = 0; userPaused = false;
  active.forEach((oscillator) => { try { oscillator.stop(); } catch { /* Already ended. */ } });
  publish(started);
}

function setup(context: AudioContext, output: AudioNode) {
  musicContext = context; bus = context.createGain(); bus.gain.value = 0; bus.connect(output);
  const reverb = context.createConvolver();
  const buffer = context.createBuffer(2, Math.floor(context.sampleRate * 1.7), context.sampleRate);
  let seed = 1847;
  for (let channel = 0; channel < 2; channel++) {
    const data = buffer.getChannelData(channel);
    for (let i = 0; i < data.length; i++) { seed = Math.imul(seed, 1664525) + 1013904223 | 0; data[i] = ((seed >>> 0) / 4294967296 * 2 - 1) * Math.pow(1 - i / data.length, 3) * 0.32; }
  }
  reverb.buffer = buffer;
  const wet = context.createGain(); wet.gain.value = 0.18;
  bus.connect(reverb).connect(wet).connect(output);
  wave = context.createPeriodicWave(new Float32Array([0, 0, 0, 0, 0, 0]), new Float32Array([0, 1, 0.22, 0.09, 0.035, 0.012]));
  started = true;
}

function note(midi: number, when: number, duration: number, amplitude: number, pan: number, soft = false) {
  if (!musicContext || !bus || !wave || active.size >= 30) return;
  const oscillator = musicContext.createOscillator(), gain = musicContext.createGain(), panner = musicContext.createStereoPanner();
  if (soft) oscillator.type = 'sine'; else oscillator.setPeriodicWave(wave);
  oscillator.frequency.value = 440 * 2 ** ((midi - 69) / 12);
  panner.pan.value = pan;
  gain.gain.setValueAtTime(0.0001, when);
  gain.gain.exponentialRampToValueAtTime(amplitude, when + (soft ? 0.3 : 0.012));
  gain.gain.exponentialRampToValueAtTime(amplitude * (soft ? 0.6 : 0.35), when + (soft ? 0.8 : 0.2));
  gain.gain.exponentialRampToValueAtTime(0.0001, when + duration);
  oscillator.connect(gain).connect(panner).connect(bus); active.add(oscillator);
  oscillator.start(when); oscillator.stop(when + duration + 0.025);
  oscillator.onended = () => { active.delete(oscillator); oscillator.disconnect(); gain.disconnect(); panner.disconnect(); };
}

export function updateMusic(context: AudioContext | null, output: AudioNode | null, settings: Partial<Settings>, enabled: boolean) {
  if (!context || !output || context.state !== 'running') { publish(false, started); return; }
  if (!musicContext) setup(context, output);
  const mode = settings.musicMode ?? 'auto';
  if (mode !== lastMode) { lastMode = mode; forced = null; beatIndex = 0; beatAt = 0; }
  const desired = forced ?? (mode === 'auto' ? automatic : mode);
  const volume = enabled && !userPaused ? settings.musicVolume ?? 0.3 : 0;
  if (lastGain !== volume) { bus!.gain.cancelScheduledValues(context.currentTime); bus!.gain.setTargetAtTime(volume, context.currentTime, 0.2); lastGain = volume; }
  publish(volume > 0, true);
  if (volume <= 0) { beatAt = context.currentTime; return; }
  if (selected !== desired && beatIndex % 8 === 0) { selected = desired; beatIndex = 0; publish(true); }
  if (!beatAt || beatAt < context.currentTime - 1) beatAt = context.currentTime + 0.04;
  let guard = 0;
  while (beatAt < context.currentTime + 0.35 && guard++ < 2) {
    const track = MUSIC_TRACKS.find((item) => item.id === selected)!;
    const beat = 60 / track.tempo, position = beatIndex % 32, chord = track.chords[Math.floor(position / 8)];
    const pitch = track.melody[position];
    if (pitch !== -99) note(track.root + pitch, beatAt, beat * 3.7, 0.19, -0.2 + position % 5 * 0.1);
    if (beatIndex % 2 === 0) note(track.root - 12 + chord[(beatIndex / 2) % 3], beatAt + beat * 0.45, beat * 3.5, 0.10, -0.35);
    if (beatIndex % 8 === 0) {
      note(track.root - 24 + chord[0], beatAt, beat * 7, 0.20, 0.15, true);
      note(track.root + chord[2], beatAt + 0.04, beat * 7, 0.06, 0.35, true);
    }
    beatAt += beat; beatIndex++;
    if (beatIndex % 64 === 0 && !settings.musicContinuous) beatAt += 14;
    if (beatIndex % 64 === 0) forced = null;
  }
}