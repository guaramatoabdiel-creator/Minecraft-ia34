import { useEffect, useMemo, useState } from 'react';
import { BlockIcon, McButton, Slider, Toggle, Choice } from './ui';
import { defaultSettings, PRESETS, type Settings, type GraphicsPreset } from '../game/settings';
import { PACKS, getIcons, type TexturePack } from '../game/textures';
import { B, I, toolId } from '../game/blocks';
import { sfx } from '../game/sound';
import MusicPlayer from './MusicPlayer';
import { MUSIC_TRACKS } from '../game/music';

type Page = 'home' | 'video' | 'performance' | 'audio' | 'controls' | 'gameplay' | 'textures' | 'interface';
const pages: { id: Exclude<Page, 'home'>; title: string; subtitle: string }[] = [
  { id: 'video', title: 'Configurações de vídeo...', subtitle: 'Gráficos, iluminação e distância' },
  { id: 'audio', title: 'Música e sons...', subtitle: 'Volume por categoria e legendas' },
  { id: 'controls', title: 'Controles...', subtitle: 'Mouse, toque e movimento' },
  { id: 'gameplay', title: 'Regras do jogo...', subtitle: 'Dificuldade, itens e salvamento' },
  { id: 'textures', title: 'Pacotes de recursos...', subtitle: 'Texturas próprias em pixel art' },
  { id: 'performance', title: 'Desempenho...', subtitle: 'Otimização para o seu aparelho' },
  { id: 'interface', title: 'Interface e acessibilidade...', subtitle: 'HUD, coordenadas e efeitos' },
];

export default function SettingsScreen({ settings, onChange, onBack, inGame }: { settings: Settings; onChange: (s: Settings) => void; onBack: () => void; inGame?: boolean }) {
  const [page, setPage] = useState<Page>('home');
  const [confirmReset, setConfirmReset] = useState(false);
  const [fullscreenMessage, setFullscreenMessage] = useState('');
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (event.code !== 'Escape' || event.repeat) return;
      event.preventDefault(); event.stopImmediatePropagation();
      if (confirmReset) setConfirmReset(false);
      else if (page === 'home') onBack();
      else setPage('home');
      sfx.close();
    };
    window.addEventListener('keydown', key, true);
    return () => window.removeEventListener('keydown', key, true);
  }, [page, confirmReset, onBack]);
  const change = (patch: Partial<Settings>, graphics = false) => onChange({ ...settings, ...patch, ...(graphics ? { preset: 'custom' as GraphicsPreset } : {}) });
  const percent = (v: number) => `${Math.round(v * 100)}%`;
  const title = page === 'home' ? 'Opções' : pages.find((p) => p.id === page)!.title.replace('...', '');
  const preview = useMemo(() => page === 'textures' ? Object.fromEntries((Object.keys(PACKS) as TexturePack[]).map((pack) => [pack, getIcons(pack)])) : {}, [page]);
  const difficultyNames = { peaceful: 'Pacífico', easy: 'Fácil', normal: 'Normal', hard: 'Difícil' };
  const switchDifficulty = () => {
    const choices = ['peaceful', 'easy', 'normal', 'hard'] as const;
    change({ difficulty: choices[(choices.indexOf(settings.difficulty) + 1) % choices.length] });
  };
  const soundVolumes: { key: 'masterVolume' | 'musicVolume' | 'blocksVolume' | 'creaturesVolume' | 'playerVolume' | 'ambientVolume' | 'uiVolume'; name: string }[] = [
    { key: 'masterVolume', name: 'Volume geral' }, { key: 'musicVolume', name: 'Música' },
    { key: 'blocksVolume', name: 'Blocos e passos' }, { key: 'creaturesVolume', name: 'Criaturas' },
    { key: 'playerVolume', name: 'Jogador e combate' }, { key: 'ambientVolume', name: 'Ambiente e portais' },
    { key: 'uiVolume', name: 'Interface' },
  ];
  const goBack = () => { if (page === 'home') onBack(); else setPage('home'); };

  return <div className="classic-options panel-enter" onKeyDown={(e) => { if (e.key === 'Escape') { e.stopPropagation(); goBack(); } }}>
    <header className="options-heading"><span>MineBlock / {page === 'home' ? 'Terras Vivas' : 'Opções'}</span><h1>{title}</h1><p>As alterações são aplicadas imediatamente.</p></header>
    <main className="options-content scroll-thin">
      {page === 'home' && <>
        <div className="classic-options-grid options-intro-row">
          <Slider label="Campo de visão" value={settings.fov} min={50} max={110} step={1} onChange={(v) => change({ fov: v })} format={(v) => v === 70 ? 'Normal' : `${v}°`} />
          <McButton onClick={switchDifficulty}>Dificuldade: {difficultyNames[settings.difficulty]}</McButton>
        </div>
        <div className="classic-options-grid options-category-grid">
          {pages.map((p) => <McButton key={p.id} onClick={() => setPage(p.id)} title={p.subtitle}>{p.title}</McButton>)}
          <McButton onClick={async () => {
            try { if (document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); setFullscreenMessage('Modo de tela atualizado.'); }
            catch { setFullscreenMessage('Este navegador não permite tela cheia aqui.'); }
          }}>Alternar tela cheia</McButton>
        </div>
        <div className="options-note"><span className="options-note-title">Seu mundo, do seu jeito.</span><p>Visual clássico, recursos próprios. Ajuste o desempenho sem perder a estética dos blocos.</p>{fullscreenMessage && <p role="status">{fullscreenMessage}</p>}</div>
      </>}

      {page === 'video' && <>
        <div className="options-presets">{(['rapido', 'bonito', 'ultra'] as const).map((preset) => <McButton key={preset} className={settings.preset === preset ? 'active' : ''} onClick={() => onChange({ ...settings, ...PRESETS[preset], preset })}>{preset === 'rapido' ? 'Rápido' : preset === 'bonito' ? 'Equilibrado' : 'Detalhado'}</McButton>)}</div>
        <div className="classic-options-grid">
          <Slider label="Renderização" value={settings.renderDistance} min={2} max={10} step={1} onChange={(v) => change({ renderDistance: v }, true)} format={(v) => `${v} chunks`} />
          <Slider label="Brilho" value={settings.brightness} min={0} max={1} step={0.05} onChange={(v) => change({ brightness: v })} format={percent} />
          <Toggle label="Iluminação suave" value={settings.smoothLight} onChange={(v) => change({ smoothLight: v }, true)} />
          <Toggle label="Sombras nos cantos" value={settings.ao} onChange={(v) => change({ ao: v }, true)} />
          <Toggle label="Folhas detalhadas" value={settings.fancyLeaves} onChange={(v) => change({ fancyLeaves: v }, true)} />
          <Toggle label="Nuvens" value={settings.clouds} onChange={(v) => change({ clouds: v }, true)} />
          <Toggle label="Partículas" value={settings.particles} onChange={(v) => change({ particles: v }, true)} />
          <Slider label="Quantidade de partículas" value={settings.particleDensity} min={0.25} max={1} step={0.25} onChange={(v) => change({ particleDensity: v }, true)} format={percent} />
          <Toggle label="Texturas animadas" value={settings.animatedTextures} onChange={(v) => change({ animatedTextures: v }, true)} />
          <Toggle label="Mipmap (menos cintilação)" value={settings.mipmaps} onChange={(v) => change({ mipmaps: v }, true)} />
          <McButton onClick={() => { const values = [1, 2, 4, 8]; change({ anisotropy: values[(values.indexOf(settings.anisotropy) + 1) % 4] }, true); }}>Filtragem anisotrópica: {settings.anisotropy}x</McButton>
          <Toggle label="Antisserrilhado" value={settings.antialias} onChange={(v) => change({ antialias: v }, true)} />
        </div>
        <p className="options-note">{inGame ? 'Antisserrilhado só muda ao sair e reentrar no mundo. As outras opções são aplicadas agora.' : 'Mais distância exige mais memória. As texturas mantêm os pixels nítidos de perto.'}</p>
      </>}

      {page === 'performance' && <>
        <div className="classic-options-grid">
          <Choice label="Resolução máxima" value={settings.resolution} options={[{ v: 0.35, l: '35%' }, { v: 0.5, l: '50%' }, { v: 0.75, l: '75%' }, { v: 1, l: '100%' }]} onChange={(v) => change({ resolution: v }, true)} />
          <Choice label="Limite de quadros" value={settings.fpsLimit} options={[{ v: 30, l: '30' }, { v: 60, l: '60' }, { v: 120, l: '120' }, { v: 0, l: 'Livre' }]} onChange={(v) => change({ fpsLimit: v })} />
          <Toggle label="Resolução adaptativa" value={settings.dynamicResolution} onChange={(v) => change({ dynamicResolution: v }, true)} />
          <McButton onClick={() => change({ targetFps: settings.targetFps === 60 ? 30 : 60 })}>Meta adaptativa: {settings.targetFps} FPS</McButton>
          <Slider label="Distância de simulação" value={settings.simulationDistance} min={16} max={80} step={8} onChange={(v) => change({ simulationDistance: v }, true)} format={(v) => `${v} blocos`} />
          <Slider label="Limite de criaturas" value={settings.maxMobs} min={3} max={16} step={1} onChange={(v) => change({ maxMobs: v }, true)} />
          <Slider label="Carregamento por quadro" value={settings.chunkBudget} min={2} max={12} step={1} onChange={(v) => change({ chunkBudget: v }, true)} format={(v) => `${v} ms`} />
          <Toggle label="Mostrar FPS" value={settings.showFps} onChange={(v) => change({ showFps: v })} />
        </div>
        <div className="options-note"><span className="options-note-title">Menos trabalho por quadro, mais estabilidade.</span><p>A resolução adaptativa reduz a imagem 3D quando o FPS cai, sem reduzir a nitidez dos menus. Mobs e itens distantes deixam de ser simulados. O chefe não conta para o limite de criaturas.</p><p>Para celular fraco, comece com Rápido, 3 chunks e 30 FPS. O resultado depende do aparelho.</p></div>
        <McButton className="options-wide-btn" onClick={() => onChange({ ...settings, ...PRESETS.rapido, preset: 'rapido', fpsLimit: 30, targetFps: 30 })}>Aplicar modo econômico</McButton>
      </>}

      {page === 'audio' && <>
        <MusicPlayer settings={settings} onChange={onChange} />
        <div className="classic-options-grid">
          <Toggle label="Áudio" value={settings.sound} onChange={(v) => change({ sound: v })} />
          <Toggle label="Silenciar em segundo plano" value={settings.muteOnBlur} onChange={(v) => change({ muteOnBlur: v })} />
          {soundVolumes.map(({ key, name }) => <Slider key={key} label={name} value={settings[key]} min={0} max={1} step={0.05} onChange={(v) => change({ [key]: v })} format={percent} />)}
          <Toggle label="Legendas de sons" value={settings.subtitles} onChange={(v) => change({ subtitles: v })} />
          <McButton onClick={() => {
            const modes = ['auto', 'meadow', 'forest', 'night', 'depths'] as const;
            change({ musicMode: modes[(modes.indexOf(settings.musicMode) + 1) % modes.length] });
          }}>Trilha: {settings.musicMode === 'auto' ? 'Por ambiente' : MUSIC_TRACKS.find((track) => track.id === settings.musicMode)?.name}</McButton>
          <Toggle label="Música contínua" value={settings.musicContinuous} onChange={(v) => change({ musicContinuous: v })} />
        </div>
        <div className="options-note"><p>Quatro composições próprias, com melodia, acompanhamento e reverberação. No automático, a trilha acompanha o bioma, a noite e as profundezas. O navegador só libera áudio depois do primeiro toque.</p></div>
        <McButton className="options-wide-btn" onClick={() => { sfx.step(B.GRASS); sfx.pickup(); }}>Testar áudio</McButton>
      </>}

      {page === 'controls' && <>
        <div className="classic-options-grid">
          <Slider label="Sensibilidade" value={settings.sensitivity} min={0.2} max={3} step={0.1} onChange={(v) => change({ sensitivity: v })} format={percent} />
          <Slider label="Tamanho dos botões" value={settings.buttonSize} min={0.7} max={1.4} step={0.05} onChange={(v) => change({ buttonSize: v })} format={percent} />
          <Slider label="Opacidade dos controles" value={settings.touchOpacity} min={0.25} max={1} step={0.05} onChange={(v) => change({ touchOpacity: v })} format={percent} />
          <Toggle label="Inverter eixo Y" value={settings.invertY} onChange={(v) => change({ invertY: v })} />
          <Toggle label="Pulo automático" value={settings.autoJump} onChange={(v) => change({ autoJump: v })} />
          <Toggle label="Toque rápido para usar" value={settings.tapToUse} onChange={(v) => change({ tapToUse: v })} />
          <Toggle label="Balanço ao caminhar" value={settings.viewBob} onChange={(v) => change({ viewBob: v })} />
        </div>
        <div className="keybind-list">{[['Mover', 'W A S D'], ['Pular / voar no Criativo', 'Espaço / 2x Espaço'], ['Atacar / minerar', 'Mouse esquerdo ou Z'], ['Usar / colocar / acender', 'Mouse direito ou V'], ['Inventário / abrir estação', 'E'], ['Soltar item / pilha', 'Q / Ctrl + Q'], ['Coleta manual', 'G'], ['Escudo / agachar', 'R / Shift'], ['Jornada / pausa', 'J / Esc']].map(([name, key]) => <div key={name}><span>{name}</span><kbd>{key}</kbd></div>)}</div>
        <p className="options-note">No celular, use SOLTAR na tela ou no inventário. AGACHAR evita cair das bordas. Se a captura do mouse for bloqueada, arraste para olhar e use Z/V.</p>
      </>}

      {page === 'gameplay' && <>
        <div className="classic-options-grid">
          <McButton onClick={switchDifficulty}>Dificuldade: {difficultyNames[settings.difficulty]}</McButton>
          <Toggle label="Manter itens ao morrer" value={settings.keepInventory} onChange={(v) => change({ keepInventory: v })} />
          <Toggle label="Creepers quebram blocos" value={settings.mobGriefing} onChange={(v) => change({ mobGriefing: v })} />
          <Toggle label="Coleta automática de itens" value={settings.autoPickup} onChange={(v) => change({ autoPickup: v })} />
          <Toggle label="Ciclo de dia e noite" value={settings.dayCycle} onChange={(v) => change({ dayCycle: v })} />
          <Toggle label="Fome e saciedade" value={settings.hungerEnabled} onChange={(v) => change({ hungerEnabled: v })} />
          <Toggle label="Regeneração natural" value={settings.naturalRegeneration} onChange={(v) => change({ naturalRegeneration: v })} />
          <Slider label="Salvar automaticamente" value={settings.autosaveSeconds} min={30} max={180} step={30} onChange={(v) => change({ autosaveSeconds: v })} format={(v) => `${v} s`} />
        </div>
        <div className="options-note"><p>Com “Manter itens” desligado, mochila e armadura caem no local da morte. Itens desaparecem após 5 minutos de simulação perto deles; o tempo fica parado em regiões descarregadas.</p><p>Pacífico remove hostis comuns. Para obter varas de blaze e pérolas na campanha, use Fácil ou superior. O dragão continua como desafio final.</p><p>Estes ajustes valem para suas partidas neste navegador. Não apagam seus mundos.</p></div>
      </>}

      {page === 'interface' && <>
        <div className="classic-options-grid">
          <Slider label="Escala da barra rápida" value={settings.hudScale} min={0.8} max={1.25} step={0.05} onChange={(v) => change({ hudScale: v })} format={percent} />
          <Toggle label="Mostrar coordenadas" value={settings.showCoordinates} onChange={(v) => change({ showCoordinates: v })} />
          <Toggle label="Mostrar bioma atual" value={settings.showBiome} onChange={(v) => change({ showBiome: v })} />
          <Toggle label="Prévia de construção" value={settings.placementPreview} onChange={(v) => change({ placementPreview: v })} />
          <Toggle label="Objetivo na tela" value={settings.showObjectives} onChange={(v) => change({ showObjectives: v })} />
          <Toggle label="Mostrar mão e escudo" value={settings.showHand} onChange={(v) => change({ showHand: v })} />
          <Toggle label="Mão principal esquerda" value={settings.leftHand} onChange={(v) => change({ leftHand: v })} />
          <Slider label="Tamanho da mão e item" value={settings.handScale} min={0.8} max={1.15} step={0.05} onChange={(v) => change({ handScale: v })} format={percent} />
          <Toggle label="Comportamento do mob na mira" value={settings.mobIntent} onChange={(v) => change({ mobIntent: v })} />
          <Toggle label="Efeitos de dano e portal" value={settings.screenEffects} onChange={(v) => change({ screenEffects: v })} />
          <Toggle label="Legendas de sons" value={settings.subtitles} onChange={(v) => change({ subtitles: v })} />
        </div>
        <p className="options-note">Desative efeitos de tela e balanço para uma câmera mais estável. Os menus respeitam a preferência de movimento reduzido do aparelho.</p>
      </>}

      {page === 'textures' && <>
        <p className="options-note">Escolha o pacote. O jogo mantém o mesmo estilo em todas as resoluções; não usa texturas oficiais.</p>
        <div className="resource-pack-list">{(Object.keys(PACKS) as TexturePack[]).map((pack) => <button key={pack} className={`resource-pack ${settings.texturePack === pack ? 'selected' : ''}`} onClick={() => change({ texturePack: pack })}>
          <BlockIcon src={preview[pack]?.[B.GRASS]} size={66} /><div><strong>{PACKS[pack].label}</strong><p>{PACKS[pack].desc}</p><div className="resource-preview">{[B.CHERRY_LEAVES, B.SPRUCE_LOG, B.DIAMOND, B.CHEST, B.END_FRAME, toolId('diamond', 'sword'), I.IRON].map((id) => <BlockIcon key={id} src={preview[pack]?.[id]} size={33} />)}</div></div><span>{settings.texturePack === pack ? 'Ativo' : 'Usar'}</span>
        </button>)}</div>
      </>}
    </main>
    <footer className="options-footer"><McButton onClick={goBack}>{page === 'home' ? 'Concluído' : 'Voltar'}</McButton><button className="options-reset" onClick={() => setConfirmReset(true)}>Restaurar opções...</button></footer>
    {confirmReset && <div className="options-confirm"><h2>Restaurar configurações?</h2><p>Seus mundos, inventário e progresso não serão apagados.</p><div><McButton onClick={() => { onChange(defaultSettings()); setConfirmReset(false); }}>Restaurar</McButton><McButton onClick={() => setConfirmReset(false)}>Cancelar</McButton></div></div>}
  </div>;
}