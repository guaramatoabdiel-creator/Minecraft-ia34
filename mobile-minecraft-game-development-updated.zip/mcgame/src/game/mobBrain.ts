export type Behavior = 'idle' | 'wander' | 'investigate' | 'chase' | 'search' | 'retreat' | 'aim' | 'flee' | 'follow' | 'shelter' | 'fuse' | 'recover';
export const BEHAVIOR_NAMES: Record<Behavior, string> = {
  idle: 'Observando', wander: 'Explorando', investigate: 'Investigando um som', chase: 'Perseguindo',
  search: 'Procurando', retreat: 'Recuando', aim: 'Mirando', flee: 'Fugindo', follow: 'Seguindo alimento',
  shelter: 'Buscando sombra', fuse: 'Preparando explosão', recover: 'Buscando outra rota',
};

export interface Senses {
  passive: boolean; seesPlayer: boolean; distance: number; anger: number; memory: number;
  afraid: number; tempted: boolean; exposed: boolean; ranged: boolean; creeper: boolean;
  heard: boolean; stuck: boolean;
}

export function chooseBehavior(s: Senses): Behavior {
  if (s.passive && s.afraid > 0) return 'flee';
  if (s.exposed) return 'shelter';
  if (s.passive) return s.tempted ? 'follow' : s.stuck ? 'recover' : 'wander';
  if (s.anger > 0) {
    if (!s.seesPlayer) return s.memory > 0 ? s.stuck ? 'recover' : 'search' : 'wander';
    if (s.creeper && s.distance < 2.7) return 'fuse';
    if (s.ranged) return s.distance < 5.5 ? 'retreat' : s.distance <= 15 ? 'aim' : 'chase';
    return s.stuck ? 'recover' : 'chase';
  }
  if (s.heard) return 'investigate';
  return s.stuck ? 'recover' : 'wander';
}

export function inVisionCone(forwardX: number, forwardZ: number, dx: number, dz: number, distance: number, alreadyAlert: boolean, sneaking = false) {
  const near = sneaking ? 2.4 : 4;
  if (distance < near || alreadyAlert) return true;
  const length = Math.hypot(dx, dz);
  return length > 0 && (forwardX * dx + forwardZ * dz) / length > (sneaking ? 0.25 : -0.15);
}

export function interceptSeconds(distance: number, projectileSpeed: number) {
  return Math.max(0, Math.min(0.65, distance / Math.max(1, projectileSpeed)));
}