import { useRef, useState, type ReactNode } from 'react';
import { McButton, BlockIcon } from './ui';
import { listWorlds, deleteWorld, saveWorldMeta, storeWorldSave, type WorldMeta, type GameMode, type WorldType } from '../game/settings';
import { parseWorldBackup } from '../game/backups';
import { hashString } from '../game/noise';
import { getIcons, type TexturePack } from '../game/textures';
import { B, RECIPES } from '../game/blocks';

export function TitleScreen({ onPlay, onSettings, onHelp, onInstall, onGuide, music }: { onPlay: () => void; onSettings: () => void; onHelp: () => void; onGuide: () => void; onInstall?: () => void; pack: TexturePack; music?: ReactNode }) {
  return (
    <div className="menu-screen classic-title absolute inset-0 flex flex-col items-center justify-center p-4" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <div className="adventure-title relative text-center">
        <h1 className="logo-text text-3xl sm:text-6xl md:text-7xl">MINEBLOCK</h1>
        <h2 className="classic-edition">TERRAS VIVAS</h2>
        <p className="classic-tagline">Explore novos horizontes. Construa o seu lar.</p>
      </div>
      <div className="classic-menu-buttons flex w-full flex-col gap-2">
        <McButton className="text-2xl! py-3!" onClick={onPlay}>
          Um jogador
        </McButton>
        <McButton onClick={onGuide}>Jornada e descobertas</McButton>
        {onInstall && (
          <McButton onClick={onInstall}>
              Instalar App
          </McButton>
        )}
        <div className="grid grid-cols-2 gap-2">
          <McButton onClick={onSettings}>Opções...</McButton>
          <McButton onClick={onHelp}>Como jogar</McButton>
        </div>
      </div>
      {music && <div className="title-music">{music}</div>}
      <div className="menu-footer absolute bottom-1 left-2 text-lg text-white/80 text-shadow" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
        MineBlock 4.1 / Explorador
      </div>
      <div className="menu-footer absolute bottom-1 right-2 text-lg text-white/80 text-shadow" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
        Jogo independente, não oficial
      </div>
    </div>
  );
}

export function HelpScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center p-3 sm:p-6">
      <div className="font-pixel text-sm sm:text-lg text-shadow mb-3">Como Jogar</div>
      <div className="scroll-thin mc-panel w-full max-w-2xl flex-1 overflow-y-auto p-4 text-xl leading-snug space-y-3">
        <section>
          <h3 className="text-yellow-300 text-2xl">Como zerar</h3>
          <p>Crie ferramentas, funda metais e equipe sua armadura. Construa e acenda o portal do Nether; derrote blazes e obtenha pérolas dos endermen. Monte 12 molduras do Fim e insira 12 olhos. Entre, destrua os quatro cristais e derrote o dragão.</p>
          <p>O MineBlock adapta receitas, dimensões e combate para uma aventura compacta. Não é uma reprodução completa do Minecraft.</p>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">📱 No celular</h3>
          <ul className="list-disc pl-5">
            <li>Joystick (lado esquerdo): andar. Empurre até o fim para correr.</li>
            <li>Arraste no lado direito da tela: olhar em volta.</li>
            <li>Toque rápido: colocar bloco • Segure: quebrar bloco.</li>
            <li>ATACAR/MINAR usa a ferramenta ou arma selecionada. USAR coloca blocos, come alimentos e usa itens.</li>
            <li>Equipe o escudo no inventário. Segure DEFENDER para bloquear ataques pela frente.</li>
            <li>Botão de pulo — toque 2x rápido no modo Criativo para voar.</li>
            <li>Gire o celular na horizontal para a melhor experiência!</li>
          </ul>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">⌨ No computador</h3>
          <ul className="list-disc pl-5">
            <li>WASD: andar • Mouse: olhar • Espaço: pular (2x para voar)</li>
            <li>Clique esquerdo: quebrar • Clique direito: colocar • Clique do meio: copiar bloco</li>
            <li>Shift: descer voando • Ctrl: correr • E: inventário ou estação à frente • C ou F: usar estação/portal • J: jornada • ESC: pausar</li>
            <li>R: defender com escudo • Clique esquerdo: atacar/minerar • Botão direito: usar item ou estação</li>
            <li>Q solta um item; Ctrl + Q solta a pilha. G recolhe itens próximos. No celular, use SOLTAR ou o inventário.</li>
            <li>Sem captura do mouse: arraste para olhar, segure Z para atacar/minerar e use V para colocar/usar.</li>
            <li>A tecla A é usada para andar para a esquerda, por isso a mesa abre com C!</li>
          </ul>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">⚒ Mesa de Trabalho (crafting table)</h3>
          <ul className="list-disc pl-5">
            <li><b>Como fazer:</b> quebre madeira → faça Tábuas no inventário (E) → junte 4 Tábuas e crie a Mesa → coloque a mesa no chão.</li>
            <li><b>Como abrir no PC:</b> clique com o botão direito na mesa, ou mire nela e aperte C ou F. Também aparece um botão "⚒ Abrir Mesa".</li>
            <li><b>Como abrir no celular:</b> toque na mesa, ou mire nela e aperte o botão "⚒ Abrir Mesa" que aparece.</li>
            <li><b>Construir na mesa:</b> no PC, segure Shift + botão direito; no celular, mire no chão ao lado.</li>
            <li><b>Receitas:</b> {RECIPES.length} receitas distribuídas entre inventário, mesa, fornalha e ferraria. Abra a estação correta para criar cada item.</li>
          </ul>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">🎮 Modos de jogo</h3>
          <ul className="list-disc pl-5">
            <li><b>Sobrevivência:</b> fome, saciedade, recursos, inimigos e chefe final. Comida enche a barra de fome; bem alimentado, você regenera vida. Abaixo de 7 pontos de alimento, não é possível correr.</li>
            <li><b>Criativo:</b> blocos infinitos, voo livre, quebra instantânea e sem dano.</li>
          </ul>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">Terras Vivas: explorar, criar e cultivar</h3>
          <p>Crie um mundo novo para explorar 15 biomas e oito árvores. O Atlas na Jornada mostra o que cada região oferece e pode marcar um destino próximo. Mundos antigos mantêm o terreno original.</p>
          <p>O inventário reúne personagem, armadura, mão secundária, criação 2 x 2 e a mochila na mesma tela. Clique para pegar e colocar; botão direito pega metade ou coloca uma unidade. Shift + clique transfere para a barra rápida. No celular, o botão de pilha alterna para uma unidade.</p>
          <p>Abra o livro verde para preencher receitas. Na criação 2 x 2, os ingredientes ficam nos espaços e são devolvidos ao fechar; o resultado só aparece com a combinação correta. A mesa mantém as receitas maiores 3 x 3.</p>
          <p>Em Visual do explorador, escolha traje e tom de pele. A prévia 3D mostra seu equipamento e pode ser girada. Tamanho da mão e mão esquerda ficam em Opções &gt; Interface.</p>
          <p>Baús guardam 27 pilhas. No inventário, você pode arrastar itens, mover com Shift + clique, dividir pilhas e organizar a mochila. A barra rápida é preservada ao organizar.</p>
          <p>Lajes podem ser colocadas em cima ou embaixo e duas formam um bloco completo. Escadas acompanham a direção do olhar. Segure Usar para construir em sequência.</p>
          <p>As novas músicas são originais. Use os controles no menu ou em Opções &gt; Música e sons.</p>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">💡 Dicas</h3>
          <ul className="list-disc pl-5">
            <li>Use a pederneira para acender TNT ou o interior do portal de obsidiana.</li>
            <li>Diamante: abaixo de Y 18, com picareta de ferro. Obsidiana: abaixo de Y 9, com picareta de diamante.</li>
            <li>Cobre, ferro e ouro brutos precisam da fornalha. Netherita exige detritos ancestrais do Nether, ouro e ferraria.</li>
            <li>Colha flores para tingir lãs na mesa de trabalho.</li>
            <li>Celular travando? Use a predefinição ⚡ Rápido e diminua a resolução.</li>
            <li>O mundo é salvo automaticamente no seu navegador.</li>
          </ul>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">Portais construídos</h3>
          <p>Nether: moldura vertical de obsidiana, exterior 4 x 5 e interior vazio 2 x 3. Os quatro cantos são opcionais: 10 obsidianas bastam. Use a pederneira na base interna e permaneça no campo roxo.</p>
          <p>Fim: faça um anel horizontal 5 x 5 com 12 molduras, sem cantos, deixando o centro 3 x 3 vazio. Use um olho em cada moldura. Nesta edição, não precisa orientar as molduras. O décimo segundo olho ativa o centro.</p>
          <p>Quebrar a moldura apaga o portal. Itens e alterações de cada dimensão são salvos.</p>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">Itens e criaturas</h3>
          <p>Mineração e inimigos deixam itens no chão. Aproxime-se para recolher; mochila cheia não apaga o loot. Itens duram 5 minutos de simulação. Ajuste “Manter itens ao morrer” nas regras do jogo.</p>
          <p>Zumbis e esqueletos procuram sombra quando expostos ao sol. Zumbis podem alertar aliados próximos. Esqueletos mantêm distância, miram antes de atirar e evitam disparar contra companheiros no caminho. Blazes voam com colisão e atacam em rajadas.</p>
          <p>Os mobs investigam sons e procuram a última posição onde viram o jogador, sem saber sua posição através das paredes. Agachar reduz a detecção. Aranhas são agressivas no escuro; encarar endermen por algum tempo os provoca. Creepers cancelam o pavio quando você se afasta ou corta a visão. Animais seguem trigo e fogem de ataques.</p>
        </section>
        <section>
          <h3 className="text-yellow-300 text-2xl">📲 Como instalar / criar o APK</h3>
          <ul className="list-disc pl-5">
            <li><b>Instalar direto:</b> se o navegador mostrar "Instalar app" / "Adicionar à tela inicial", você pode criar um atalho. O funcionamento offline depende do empacotamento e cache.</li>
            <li><b>Gerar APK (fácil):</b> publique o jogo num link HTTPS (Netlify, Vercel, GitHub Pages), depois acesse PWABuilder.com, cole o link e baixe o pacote Android (.apk/.aab).</li>
            <li><b>Via ZIP:</b> compacte o projeto completo sem node_modules. Um ZIP guarda o código; renomeá-lo para APK não cria um app. O Android Studio precisa compilar e assinar o aplicativo.</li>
            <li><b>Via código (Capacitor):</b> npm i @capacitor/core @capacitor/cli @capacitor/android → npx cap init → npx cap add android → npx cap sync → npx cap open android → gere o APK no Android Studio.</li>
          </ul>
        </section>
      </div>
      <McButton className="mt-3 w-full max-w-sm" onClick={onBack}>
        Voltar
      </McButton>
    </div>
  );
}

const MODE_L: Record<GameMode, string> = { survival: 'Sobrevivência', creative: 'Criativo' };
const TYPE_L: Record<WorldType, string> = { normal: 'Normal', plano: 'Plano', montanhas: 'Montanhas', ilhas: 'Ilhas' };

export function WorldSelect({ onPlay, onCreate, onBack, pack }: { onPlay: (w: WorldMeta) => void; onCreate: () => void; onBack: () => void; pack: TexturePack }) {
  const [worlds, setWorlds] = useState(listWorlds);
  const [sel, setSel] = useState<string | null>(worlds[0]?.id ?? null);
  const [confirm, setConfirm] = useState(false);
  const [importMessage, setImportMessage] = useState('');
  const [importing, setImporting] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const icons = getIcons(pack);
  const selected = worlds.find((w) => w.id === sel);
  const typeIcon: Record<WorldType, number> = { normal: B.GRASS, plano: B.DIRT, montanhas: B.SNOW, ilhas: B.SAND };

  return (
    <div className="absolute inset-0 flex flex-col items-center p-3 sm:p-6" style={{ paddingTop: 'max(env(safe-area-inset-top), 12px)' }}>
      <div className="font-pixel text-sm sm:text-lg text-shadow mb-3">Selecionar Mundo</div>
      <div className="scroll-thin mc-panel w-full max-w-2xl flex-1 overflow-y-auto p-2 flex flex-col gap-1">
        {worlds.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-2xl text-gray-300 text-center p-6">
            <BlockIcon src={icons[B.GRASS]} size={64} />
            <p className="mt-3">Nenhum mundo ainda.</p>
            <p className="text-xl text-gray-400">Crie seu primeiro mundo para começar a aventura!</p>
          </div>
        )}
        {worlds.map((w) => (
          <button
            key={w.id}
            onClick={() => { setSel(w.id); setConfirm(false); }}
            onDoubleClick={() => onPlay(w)}
            className={`flex items-center gap-3 p-2 text-left border-2 ${sel === w.id ? 'border-white bg-white/10' : 'border-transparent hover:bg-white/5'}`}
          >
            <BlockIcon src={icons[typeIcon[w.type]]} size={48} />
            <div className="min-w-0 flex-1">
              <div className="text-2xl truncate">{w.name}</div>
              {w.completed && <div className="text-lg text-green-300">Campanha concluída</div>}
              <div className="text-lg text-gray-400 truncate">
                {MODE_L[w.mode]} • {TYPE_L[w.type]} • {new Date(w.lastPlayed).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}
              </div>
            </div>
            <span className={`text-lg px-2 ${w.mode === 'creative' ? 'text-sky-300' : 'text-red-300'}`}>{w.mode === 'creative' ? '✦' : '♥'}</span>
          </button>
        ))}
      </div>
      {importMessage && <p className="text-center text-lg text-yellow-100 mt-2" role="status">{importMessage}</p>}
      <input ref={fileInput} type="file" accept="application/json,.json" className="hidden" aria-label="Importar uma cópia de mundo" onChange={async (event) => {
        const file = event.target.files?.[0]; event.target.value = '';
        if (!file) return;
        setImporting(true); setImportMessage('Lendo cópia do mundo...');
        try {
          if (file.size > 6_000_000) throw new Error('Este arquivo ultrapassa 6 MB.');
          const imported = parseWorldBackup(await file.text());
          if (!storeWorldSave(imported.meta.id, imported.save)) throw new Error('Não há espaço no navegador para importar este mundo.');
          if (!saveWorldMeta(imported.meta)) { deleteWorld(imported.meta.id); throw new Error('Falha ao registrar o mundo. Libere espaço e tente novamente.'); }
          setWorlds(listWorlds()); setSel(imported.meta.id); setConfirm(false); setImportMessage(`Mundo importado: ${imported.meta.name}`);
        } catch (error) { setImportMessage(error instanceof Error ? error.message : 'Não foi possível importar esse arquivo.'); }
        finally { setImporting(false); }
      }} />
      <div className="mt-3 grid w-full max-w-2xl grid-cols-2 gap-2" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
        <McButton disabled={!selected} onClick={() => selected && onPlay(selected)}>
          ▶ Jogar Mundo
        </McButton>
        <McButton onClick={onCreate}>✚ Criar Novo Mundo</McButton>
        {confirm && selected ? (
          <McButton
            className="danger"
            onClick={() => {
              deleteWorld(selected.id);
              const nw = listWorlds();
              setWorlds(nw);
              setSel(nw[0]?.id ?? null);
              setConfirm(false);
            }}
          >
            Confirmar exclusão?
          </McButton>
        ) : (
          <McButton disabled={!selected} onClick={() => setConfirm(true)}>
            🗑 Excluir
          </McButton>
        )}
        <McButton onClick={onBack}>Voltar</McButton>
        <McButton className="col-span-2" disabled={importing} onClick={() => fileInput.current?.click()}>{importing ? 'Importando...' : 'Importar cópia do mundo...'}</McButton>
      </div>
    </div>
  );
}

export function CreateWorld({ onCreate, onBack, pack }: { onCreate: (w: WorldMeta) => void; onBack: () => void; pack: TexturePack }) {
  const [name, setName] = useState('Novo Mundo');
  const [seed, setSeed] = useState('');
  const [mode, setMode] = useState<GameMode>('survival');
  const [type, setType] = useState<WorldType>('normal');
  const icons = getIcons(pack);

  const create = () => {
    const st = seed.trim();
    const num = st === '' ? Math.floor(Math.random() * 2147483647) : /^-?\d+$/.test(st) ? parseInt(st) | 0 : hashString(st);
    const now = Date.now();
    onCreate({ id: now.toString(36) + Math.random().toString(36).slice(2, 6), name: name.trim() || 'Novo Mundo', seed: num, seedText: st || String(num), mode, type, created: now, lastPlayed: now, generatorVersion: 2 });
  };

  const types: { v: WorldType; l: string; d: string; icon: number }[] = [
    { v: 'normal', l: 'Terras Vivas', d: '15 biomas, oito árvores e novas descobertas', icon: B.CHERRY_LEAVES },
    { v: 'montanhas', l: 'Montanhas', d: 'Picos gigantes e vales profundos', icon: B.SNOW },
    { v: 'ilhas', l: 'Ilhas', d: 'Arquipélago no meio do oceano', icon: B.SAND },
    { v: 'plano', l: 'Plano', d: 'Terreno plano com árvores e minérios', icon: B.DIRT },
  ];

  return (
    <div className="absolute inset-0 flex flex-col items-center p-3 sm:p-6" style={{ paddingTop: 'max(env(safe-area-inset-top), 12px)' }}>
      <div className="font-pixel text-sm sm:text-lg text-shadow mb-3">Criar Novo Mundo</div>
      <div className="scroll-thin mc-panel w-full max-w-2xl flex-1 overflow-y-auto p-3 flex flex-col gap-3">
        <label className="flex flex-col gap-1">
          <span className="text-xl text-gray-300">Nome do mundo</span>
          <input className="mc-input" value={name} maxLength={32} onChange={(e) => setName(e.target.value)} />
        </label>
        <div>
          <div className="text-xl text-gray-300 mb-1">Modo de jogo</div>
          <div className="grid grid-cols-2 gap-2">
            <McButton className={mode === 'survival' ? 'active' : ''} onClick={() => setMode('survival')}>
              ♥ Sobrevivência
            </McButton>
            <McButton className={mode === 'creative' ? 'active' : ''} onClick={() => setMode('creative')}>
              ✦ Criativo
            </McButton>
          </div>
          <div className="text-lg text-gray-400 mt-1">
            {mode === 'survival' ? 'Uma campanha para zerar: mine, equipe-se, abra portais e derrote o dragão.' : 'Todos os blocos, armas e equipamentos. Voe, construa e teste o chefe sem dano.'}
          </div>
        </div>
        <div>
          <div className="text-xl text-gray-300 mb-1">Tipo de mundo</div>
          <div className="grid grid-cols-2 gap-2">
            {types.map((t) => (
              <button key={t.v} onClick={() => setType(t.v)} className={`flex items-center gap-2 p-2 text-left border-2 ${type === t.v ? 'border-white bg-white/15' : 'border-gray-600 bg-black/30'}`}>
                <BlockIcon src={icons[t.icon]} size={40} />
                <div className="min-w-0">
                  <div className="text-xl">{t.l}</div>
                  <div className="text-base text-gray-400 leading-tight">{t.d}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
        <label className="flex flex-col gap-1">
          <span className="text-xl text-gray-300">Semente (deixe vazio para aleatória)</span>
          <input className="mc-input" value={seed} placeholder="ex: diamante123" onChange={(e) => setSeed(e.target.value)} />
        </label>
      </div>
      <div className="mt-3 grid w-full max-w-2xl grid-cols-2 gap-2" style={{ marginBottom: 'env(safe-area-inset-bottom)' }}>
        <McButton className="active" onClick={create}>
          Criar Mundo
        </McButton>
        <McButton onClick={onBack}>Cancelar</McButton>
      </div>
    </div>
  );
}
