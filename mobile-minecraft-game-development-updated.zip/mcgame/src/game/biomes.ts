import { B, WOODS, type WoodKind } from './blocks';
import { hash3 } from './noise';

export type BiomeId = 'ocean' | 'beach' | 'plains' | 'forest' | 'birch' | 'taiga' | 'tundra' | 'desert' | 'savanna' | 'jungle' | 'swamp' | 'cherry' | 'badlands' | 'mountains' | 'dark_forest';
export interface BiomeDef {
  id: BiomeId; name: string; color: string; surface: number; tree: WoodKind | null;
  density: number; description: string; resources: string;
}
export const BIOMES: BiomeDef[] = [
  { id: 'plains', name: 'Planícies', color: '#96b767', surface: B.GRASS, tree: 'oak', density: 0.12, description: 'Campos abertos, flores e espaço para seu primeiro abrigo.', resources: 'Carvalho, sementes, flores e animais.' },
  { id: 'forest', name: 'Floresta', color: '#64894c', surface: B.GRASS, tree: 'oak', density: 0.62, description: 'Copas arredondadas e trilhas verdes entre as árvores.', resources: 'Carvalho, maçãs e cogumelos.' },
  { id: 'birch', name: 'Bosque de bétulas', color: '#b6c689', surface: B.GRASS, tree: 'birch', density: 0.5, description: 'Troncos claros e uma floresta mais iluminada.', resources: 'Madeira clara, flores e sementes.' },
  { id: 'taiga', name: 'Taiga', color: '#5e8c7e', surface: B.PODZOL, tree: 'spruce', density: 0.64, description: 'Pinheiros altos, solo escuro e ar frio.', resources: 'Pinheiro, bagas doces e cogumelos.' },
  { id: 'tundra', name: 'Tundra nevada', color: '#c2d8dc', surface: B.SNOW, tree: 'spruce', density: 0.16, description: 'Neve, lagos congelados e pinheiros espaçados.', resources: 'Neve, gelo e madeira de pinheiro.' },
  { id: 'desert', name: 'Deserto', color: '#ddc591', surface: B.SAND, tree: null, density: 0, description: 'Dunas quentes, cactos e muito arenito.', resources: 'Areia, cacto e cana perto da água.' },
  { id: 'savanna', name: 'Savana', color: '#b9ad65', surface: B.SAVANNA_GRASS, tree: 'acacia', density: 0.2, description: 'Grama dourada e acácias com copas largas.', resources: 'Acácia, sementes e animais.' },
  { id: 'jungle', name: 'Selva', color: '#3f884e', surface: B.JUNGLE_GRASS, tree: 'jungle', density: 0.72, description: 'Árvores altas e vegetação densa, com frutos entre as raízes.', resources: 'Madeira da selva, melancias e cana.' },
  { id: 'swamp', name: 'Manguezal', color: '#6e8768', surface: B.MUD, tree: 'mangrove', density: 0.48, description: 'Lama, raízes aparentes e lagoas com vitórias-régias.', resources: 'Mangue, lama, cogumelos e cana.' },
  { id: 'cherry', name: 'Bosque de cerejeiras', color: '#d995ae', surface: B.GRASS, tree: 'cherry', density: 0.44, description: 'Copas rosadas e flores espalhadas pelo chão.', resources: 'Cerejeira, flores rosadas e sementes.' },
  { id: 'badlands', name: 'Terras áridas', color: '#bd754a', surface: B.RED_SAND, tree: null, density: 0, description: 'Areia vermelha e camadas de terracota nas encostas.', resources: 'Terracota, areia vermelha e cactos.' },
  { id: 'mountains', name: 'Montanhas', color: '#9bacae', surface: B.STONE, tree: 'spruce', density: 0.06, description: 'Paredões de pedra e neve nos pontos mais altos.', resources: 'Pedra, minérios expostos e neve.' },
  { id: 'dark_forest', name: 'Floresta escura', color: '#4a6551', surface: B.PODZOL, tree: 'dark', density: 0.63, description: 'Carvalhos robustos e copas densas sombreiam o solo.', resources: 'Carvalho escuro, cogumelos e musgo.' },
  { id: 'beach', name: 'Praia', color: '#e0d5a7', surface: B.SAND, tree: null, density: 0, description: 'A faixa de areia onde a terra encontra a água.', resources: 'Areia, cascalho e cana-de-açúcar.' },
  { id: 'ocean', name: 'Oceano', color: '#638fb7', surface: B.SAND, tree: null, density: 0, description: 'Águas abertas, ilhas e um fundo rico em pedra.', resources: 'Areia, cascalho e rotas de exploração.' },
];
export const BIOME_BY_ID = Object.fromEntries(BIOMES.map((biome) => [biome.id, biome])) as Record<BiomeId, BiomeDef>;

export function selectBiome(height: number, temperature: number, moisture: number, variation: number, flat = false): BiomeId {
  if (flat) return 'plains';
  if (height < 29) return 'ocean';
  if (height <= 31) return temperature < -0.43 ? 'tundra' : 'beach';
  if (height > 74) return 'mountains';
  if (temperature < -0.47) return 'tundra';
  if (temperature < -0.24) return 'taiga';
  if (temperature > 0.36 && moisture < -0.2) return variation > 0.04 ? 'badlands' : 'desert';
  if (temperature > 0.27 && moisture < 0.18) return 'savanna';
  if (temperature > 0.18 && moisture > 0.24) return 'jungle';
  if (moisture > 0.34 && height <= 41) return 'swamp';
  if (variation > 0.42 && moisture > -0.35) return 'cherry';
  if (moisture > 0.27) return 'dark_forest';
  if (variation < -0.35 && moisture > -0.22) return 'birch';
  if (moisture > -0.13) return 'forest';
  return 'plains';
}

export type TreeBlock = [number, number, number, number];

export function treeBlocks(kind: WoodKind, x: number, y: number, z: number, seed: number): TreeBlock[] {
  const wood = WOODS.find((w) => w.key === kind)!;
  const blocks = new Map<string, TreeBlock>();
  const put = (px: number, py: number, pz: number, id: number) => {
    const key = `${px},${py},${pz}`;
    if (!blocks.has(key) || id === wood.log) blocks.set(key, [px, py, pz, id]);
  };
  const crown = (cx: number, cy: number, cz: number, radius: number, layers: number) => {
    for (let layer = 0; layer < layers; layer++) {
      const r = Math.max(1, radius - (layer === layers - 1 ? 1 : 0));
      for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
        if (dx * dx + dz * dz > (r + 0.35) ** 2) continue;
        put(cx + dx, cy + layer, cz + dz, wood.leaves);
      }
    }
  };
  const random = hash3(x, y, z, seed);
  const height = kind === 'spruce' ? 8 + Math.floor(random * 3) : kind === 'jungle' ? 9 + Math.floor(random * 4) : kind === 'birch' ? 6 + Math.floor(random * 2) : 5 + Math.floor(random * 2);
  if (kind === 'spruce') {
    for (let dy = 3; dy <= height + 1; dy++) {
      const radius = dy >= height ? 1 : (dy - 3) % 3 === 0 ? 3 : 2;
      crown(x, y + dy, z, radius, 1);
    }
  } else if (kind === 'acacia') {
    const bend = random > 0.5 ? 1 : -1;
    for (let i = 0; i < 3; i++) put(x + i * bend, y + height - 2 + i, z, wood.log);
    crown(x + bend * 2, y + height, z, 3, 2);
    crown(x - bend, y + height - 1, z + 1, 2, 1);
  } else if (kind === 'cherry') {
    put(x - 1, y + height - 1, z, wood.log); put(x + 1, y + height - 1, z, wood.log);
    crown(x - 2, y + height - 1, z, 2, 3); crown(x + 2, y + height, z, 2, 2); crown(x, y + height + 1, z, 2, 2);
  } else if (kind === 'dark') {
    crown(x, y + height - 1, z, 4, 3);
    for (let dy = 1; dy < height; dy++) put(x + 1, y + dy, z, wood.log);
  } else if (kind === 'mangrove') {
    crown(x, y + height - 1, z, 3, 3);
    for (const [dx, dz] of [[2, 0], [-2, 0], [0, 2], [0, -2]]) {
      put(x + dx, y + 1, z + dz, wood.log);
      put(x + dx / 2, y + 2, z + dz / 2, wood.log);
    }
  } else if (kind === 'jungle') {
    crown(x, y + height - 1, z, 3, 3);
    put(x + 1, y + height - 3, z, wood.log); crown(x + 2, y + height - 3, z, 2, 2);
  } else crown(x, y + height - 2, z, 2, 4);
  for (let dy = 1; dy <= height; dy++) put(x, y + dy, z, wood.log);
  return [...blocks.values()];
}