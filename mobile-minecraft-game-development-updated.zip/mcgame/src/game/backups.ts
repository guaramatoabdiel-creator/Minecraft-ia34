import { B, BLOCKS, SAPLING_IDS, isPlaceable } from './blocks';
import { newAdventure, BOSS_MAX_HP, emptyEquipment } from './adventure';
import { normalizeSlot } from './inventory';
import type { WorldMeta, WorldSave, Dimension, SavedDrop, SavedPortal, SavedMob } from './settings';
import { normalizeHunger } from './hunger';
import { BIOMES } from './biomes';

const finite = (value: unknown, fallback: number, min: number, max: number) => typeof value === 'number' && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
const dimensions: Dimension[] = ['overworld', 'nether', 'end'];
const vector = (value: unknown): value is [number, number, number] => Array.isArray(value) && value.length === 3 && value.every((n) => typeof n === 'number' && Number.isFinite(n) && Math.abs(n) < 1e7);

function mods(value: unknown): Record<string, number[]> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Os blocos salvos estão em um formato inválido.');
  const out: Record<string, number[]> = {};
  for (const [key, entries] of Object.entries(value)) {
    if (!/^-?\d+,-?\d+$/.test(key) || !Array.isArray(entries) || entries.length % 2) throw new Error('Há um chunk inválido no arquivo.');
    for (let i = 0; i < entries.length; i += 2) if (!Number.isInteger(entries[i]) || entries[i] < 0 || entries[i] >= 16 * 16 * 112 || entries[i + 1] !== 0 && !isPlaceable(entries[i + 1])) throw new Error('Há blocos incompatíveis neste mundo.');
    out[key] = entries;
  }
  return out;
}

export function parseWorldBackup(text: string): { meta: WorldMeta; save: WorldSave } {
  if (text.length > 6_000_000) throw new Error('O arquivo ultrapassa o limite de 6 MB desta edição.');
  const data = JSON.parse(text);
  if (data?.format !== 'mineblock-world' || !data.meta || !data.save || typeof data.meta !== 'object') throw new Error('Selecione uma cópia de mundo exportada pelo MineBlock.');
  const raw = data.save as WorldSave;
  if ((raw.version ?? 1) > 4) throw new Error('Este mundo foi salvo por uma versão mais recente.');
  const m = data.meta as WorldMeta;
  if (!['survival', 'creative'].includes(m.mode) || !['normal', 'plano', 'montanhas', 'ilhas'].includes(m.type) || !Number.isFinite(m.seed)) throw new Error('As informações do mundo são inválidas.');
  const now = Date.now();
  const generatorVersion = raw.generatorVersion === 2 || m.generatorVersion === 2 ? 2 : 1;
  const meta: WorldMeta = { id: `import-${now.toString(36)}-${Math.random().toString(36).slice(2, 7)}`, name: String(m.name || 'Mundo importado').slice(0, 40), seed: m.seed | 0, seedText: String(m.seedText || m.seed).slice(0, 80), mode: m.mode, type: m.type, created: finite(m.created, now, 0, now), lastPlayed: now, completed: !!raw.adventure?.victory && m.mode === 'survival', generatorVersion };
  const save: WorldSave = { version: 4, generatorVersion, mods: mods(raw.mods), inventory: Array.from({ length: 36 }, (_, i) => normalizeSlot(raw.inventory?.[i])), selected: Math.floor(finite(raw.selected, 0, 0, 8)), time: finite(raw.time, 0.28, 0, 1), dimension: dimensions.includes(raw.dimension!) ? raw.dimension : 'overworld', needsSpawn: !!raw.needsSpawn };
  const player = raw.player;
  if (player && vector([player.x, player.y, player.z])) save.player = { x: player.x, y: finite(player.y, 33, -20, 200), z: player.z, yaw: finite(player.yaw, 0, -1e6, 1e6), pitch: finite(player.pitch, 0, -1.56, 1.56), health: finite(player.health, 20, 0, 20), flying: !!player.flying && m.mode === 'creative', air: finite(player.air, 20, 0, 20), hunger: normalizeHunger(player.hunger), regeneration: finite(player.regeneration, 0, 0, 8) };
  if (raw.realms) { save.realms = {}; for (const dimension of dimensions) if (raw.realms[dimension]) save.realms[dimension] = mods(raw.realms[dimension]); }
  if (vector(raw.returnPoint)) save.returnPoint = raw.returnPoint;
  const progress = newAdventure(), source = raw.adventure;
  if (source && typeof source === 'object') {
    progress.collected = Array.isArray(source.collected) ? source.collected.filter((id) => Number.isInteger(id) && !!BLOCKS[id]) : [];
    progress.crafted = Array.isArray(source.crafted) ? source.crafted.filter((id) => Number.isInteger(id) && !!BLOCKS[id]) : [];
    for (const key of ['kills', 'blazes', 'deaths', 'mined', 'elapsed', 'xp'] as const) progress[key] = finite(source[key], 0, 0, 1e9);
    for (const key of ['netherVisited', 'endVisited', 'victory', 'victorySeen'] as const) progress[key] = !!source[key];
    progress.crystals = Array.isArray(source.crystals) ? [...new Set(source.crystals.filter((id) => Number.isInteger(id) && id >= 0 && id < 4))] : [];
    progress.bossHealth = progress.victory ? 0 : finite(source.bossHealth, BOSS_MAX_HP, 1, BOSS_MAX_HP);
    progress.biomes = Array.isArray(source.biomes) ? [...new Set(source.biomes.filter((id) => BIOMES.some((biome) => biome.id === id)))] : [];
  }
  save.adventure = progress;
  save.equipment = emptyEquipment();
  for (const key of ['head', 'chest', 'legs', 'feet', 'offhand'] as const) { const item = normalizeSlot(raw.equipment?.[key]); if (item && BLOCKS[item.id].equip === key) save.equipment[key] = item; }
  if (Array.isArray(raw.drops)) save.drops = raw.drops.slice(0, 384).flatMap((drop): SavedDrop[] => {
    if (!drop || typeof drop !== 'object') return [];
    const slot = normalizeSlot(drop.slot);
    if (!slot || !vector(drop.position) || !dimensions.includes(drop.dimension)) return [];
    return [{ slot, position: drop.position, velocity: vector(drop.velocity) ? drop.velocity.map((n) => finite(n, 0, -20, 20)) as [number, number, number] : [0, 0, 0], dimension: drop.dimension, age: finite(drop.age, 0, 0, 300), delay: finite(drop.delay, 0.5, 0, 2) }];
  });
  if (Array.isArray(raw.portals)) save.portals = raw.portals.slice(0, 256).filter((portal): portal is SavedPortal => !!portal && dimensions.includes(portal.dimension) && ['nether', 'end', 'return'].includes(portal.kind) && ['x', 'z'].includes(portal.axis) && [portal.x, portal.y, portal.z, portal.width, portal.height].every(Number.isInteger) && portal.y >= 1 && portal.y < 110 && portal.width >= 2 && portal.width <= 4 && portal.height >= 1 && portal.height <= 5);
  if (Array.isArray(raw.reserve)) save.reserve = raw.reserve.map(normalizeSlot).filter((s): s is NonNullable<typeof s> => !!s);
  if (Array.isArray(raw.crops)) save.crops = raw.crops.filter((crop) => crop && vector([crop.x, crop.y, crop.z]) && dimensions.includes(crop.dimension)).map((crop) => ({ ...crop, remaining: finite(crop.remaining, 30, 0, 120), plant: crop.plant === B.BERRY_EMPTY ? B.BERRY_EMPTY : B.CROPS, result: crop.plant === B.BERRY_EMPTY ? B.BERRY_BUSH : B.RIPE_CROPS }));
  if (raw.chests && typeof raw.chests === 'object' && !Array.isArray(raw.chests)) {
    save.chests = {};
    Object.entries(raw.chests).forEach(([key, slots]) => {
      if (/^(overworld|nether|end):-?\d+,\d+,-?\d+$/.test(key) && Array.isArray(slots)) save.chests![key] = Array.from({ length: 27 }, (_, i) => normalizeSlot(slots[i]));
    });
  }
  if (raw.states && typeof raw.states === 'object') {
    save.states = {};
    for (const dimension of dimensions) {
      const states = raw.states[dimension]; if (!states || typeof states !== 'object' || Array.isArray(states)) continue;
      save.states[dimension] = Object.fromEntries(Object.entries(states).filter(([key, state]) => /^-?\d+,\d+,-?\d+$/.test(key) && Number.isInteger(state) && state >= 0 && state <= 7));
    }
  }
  if (Array.isArray(raw.saplings)) save.saplings = raw.saplings.filter((plant) => plant && vector([plant.x, plant.y, plant.z]) && dimensions.includes(plant.dimension) && SAPLING_IDS.has(plant.block)).map((plant) => ({ ...plant, remaining: finite(plant.remaining, 60, 0, 90) }));
  if (raw.waypoint && Number.isFinite(raw.waypoint.x) && Number.isFinite(raw.waypoint.z) && typeof raw.waypoint.name === 'string') save.waypoint = { x: finite(raw.waypoint.x, 0, -1e7, 1e7), z: finite(raw.waypoint.z, 0, -1e7, 1e7), name: raw.waypoint.name.slice(0, 60) };
  save.cursor = normalizeSlot(raw.cursor);
  save.personalCraft = Array.from({ length: 4 }, (_, index) => normalizeSlot(raw.personalCraft?.[index]));
  if (raw.mobs && typeof raw.mobs === 'object') {
    save.mobs = {};
    for (const realm of dimensions) {
      const list = raw.mobs[realm]; if (!Array.isArray(list)) continue;
      save.mobs[realm] = list.slice(0, 24).flatMap((mob): SavedMob[] => {
        if (!mob || !['zombie', 'skeleton', 'creeper', 'spider', 'shadow', 'blaze', 'cow', 'pig'].includes(mob.kind) || !vector(mob.position) || !Number.isFinite(mob.health) || mob.health <= 0) return [];
        return [{ kind: mob.kind, position: mob.position, health: finite(mob.health, 20, 1, 40), yaw: finite(mob.yaw, 0, -1e6, 1e6), age: finite(mob.age, 0, 0, 1e9) }];
      });
    }
  }
  if (raw.primedTnt && typeof raw.primedTnt === 'object') {
    save.primedTnt = {};
    for (const realm of dimensions) {
      const records = raw.primedTnt[realm]; if (!Array.isArray(records)) continue;
      save.primedTnt[realm] = records.slice(0, 128).filter((record) => record && [record.x, record.y, record.z].every(Number.isInteger) && record.y >= 0 && record.y < 112 && Number.isFinite(record.remaining))
        .map((record) => ({ x: record.x, y: record.y, z: record.z, remaining: finite(record.remaining, 1, 0.05, 4) }));
    }
  }
  if (raw.deathPoint && vector(raw.deathPoint.position) && dimensions.includes(raw.deathPoint.dimension)) save.deathPoint = raw.deathPoint;
  return { meta, save };
}