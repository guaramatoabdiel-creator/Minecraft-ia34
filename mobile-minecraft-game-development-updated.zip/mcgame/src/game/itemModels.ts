import * as THREE from 'three';
import { B, BLOCKS, I, PLANT_IDS, TILES, isPlaceable } from './blocks';
import { buildAtlas, itemSprite, ATLAS_COLS, ATLAS_ROWS, type TexturePack } from './textures';
import { blockBounds } from './collision';

function quad(positions: number[], colors: number[], a: number[], b: number[], c: number[], d: number[], color: number[], light: number) {
  for (const point of [a, b, c, a, c, d]) { positions.push(...point); colors.push(color[0] * light, color[1] * light, color[2] * light); }
}

// Only exposed pixel edges get side faces; each item is one cached mesh.
export function extrudeSprite(canvas: HTMLCanvasElement, thickness = 0.075) {
  const small = document.createElement('canvas'); small.width = small.height = 16;
  const context = small.getContext('2d')!; context.imageSmoothingEnabled = false; context.drawImage(canvas, 0, 0, 16, 16);
  const data = context.getImageData(0, 0, 16, 16).data;
  const filled = (x: number, y: number) => x >= 0 && y >= 0 && x < 16 && y < 16 && data[(y * 16 + x) * 4 + 3] > 96;
  const positions: number[] = [], colors: number[] = [];
  const z = thickness / 2;
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    if (!filled(x, y)) continue;
    const index = (y * 16 + x) * 4, color = [data[index] / 255, data[index + 1] / 255, data[index + 2] / 255];
    const x0 = x / 16 - 0.5, x1 = (x + 1) / 16 - 0.5, y0 = 0.5 - (y + 1) / 16, y1 = 0.5 - y / 16;
    quad(positions, colors, [x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z], color, 1);
    quad(positions, colors, [x1, y0, -z], [x0, y0, -z], [x0, y1, -z], [x1, y1, -z], color, 0.88);
    if (!filled(x - 1, y)) quad(positions, colors, [x0, y0, -z], [x0, y0, z], [x0, y1, z], [x0, y1, -z], color, 0.62);
    if (!filled(x + 1, y)) quad(positions, colors, [x1, y0, z], [x1, y0, -z], [x1, y1, -z], [x1, y1, z], color, 0.72);
    if (!filled(x, y - 1)) quad(positions, colors, [x0, y1, z], [x1, y1, z], [x1, y1, -z], [x0, y1, -z], color, 1.06);
    if (!filled(x, y + 1)) quad(positions, colors, [x0, y0, -z], [x1, y0, -z], [x1, y0, z], [x0, y0, z], color, 0.55);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals(); geometry.computeBoundingSphere(); return geometry;
}

export class ItemModels {
  private geometries = new Map<number, THREE.BufferGeometry>();
  private materials = new Map<number, THREE.MeshBasicMaterial>();
  private atlas: THREE.CanvasTexture;
  constructor(private pack: TexturePack, private overlay = false) {
    this.atlas = new THREE.CanvasTexture(buildAtlas(pack).canvas);
    this.atlas.magFilter = THREE.NearestFilter; this.atlas.minFilter = THREE.NearestFilter; this.atlas.colorSpace = THREE.NoColorSpace;
  }

  private geometry(id: number) {
    const existing = this.geometries.get(id); if (existing) return existing;
    let geometry: THREE.BufferGeometry;
    const block = isPlaceable(id), specialFlat = PLANT_IDS.has(id) || id === B.TORCH || id === B.LILY;
    if (!block || specialFlat) {
      const canvas = block ? buildAtlas(this.pack).tiles[BLOCKS[id].tiles[0]] : itemSprite(id);
      geometry = extrudeSprite(canvas, id === I.SHIELD ? 0.13 : 0.065);
    } else {
      const boxes = blockBounds(id); const bounds = boxes.length ? boxes : [[0, 0, 0, 1, 1, 1]];
      const positions: number[] = [], colors: number[] = [], uvs: number[] = [];
      for (const box of bounds) {
        const part = new THREE.BoxGeometry(box[3] - box[0], box[4] - box[1], box[5] - box[2]).toNonIndexed();
        const p = part.getAttribute('position'), uv = part.getAttribute('uv');
        const tiles = BLOCKS[id].tiles;
        const faces = [tiles[1], tiles[1], tiles[0], tiles[2], id === B.CHEST ? TILES.indexOf('chest_front') : tiles[1], tiles[1]];
        for (let i = 0; i < p.count; i++) {
          const face = Math.floor(i / 6), tile = faces[face];
          positions.push(p.getX(i) + (box[0] + box[3]) / 2 - 0.5, p.getY(i) + (box[1] + box[4]) / 2 - 0.5, p.getZ(i) + (box[2] + box[5]) / 2 - 0.5);
          uvs.push(tile % ATLAS_COLS / ATLAS_COLS + 0.00045 + uv.getX(i) * (1 / ATLAS_COLS - 0.0009), 1 - (Math.floor(tile / ATLAS_COLS) + 1) / ATLAS_ROWS + 0.00045 + uv.getY(i) * (1 / ATLAS_ROWS - 0.0009));
          const shade = [0.78, 0.65, 1, 0.48, 0.88, 0.74][face]; colors.push(shade, shade, shade);
        }
        part.dispose();
      }
      geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
      geometry.computeVertexNormals(); geometry.computeBoundingSphere();
    }
    this.geometries.set(id, geometry); return geometry;
  }

  create(id: number, enchant = 0) {
    const key = id * 2 + (enchant ? 1 : 0);
    let material = this.materials.get(key);
    if (!material) {
      const textured = isPlaceable(id) && !PLANT_IDS.has(id) && id !== B.TORCH && id !== B.LILY;
      material = new THREE.MeshBasicMaterial({ map: textured ? this.atlas : null, vertexColors: true, color: enchant ? 0xd7b9ff : 0xffffff,
        alphaTest: 0.35, transparent: id === B.GLASS || id === B.WATER, side: THREE.DoubleSide,
        depthTest: !this.overlay, depthWrite: !this.overlay, fog: !this.overlay });
      this.materials.set(key, material);
    }
    const mesh = new THREE.Mesh(this.geometry(id), material); mesh.renderOrder = this.overlay ? 1003 : 0; return mesh;
  }

  setLight(light: number) { this.materials.forEach((material, key) => material.color.setHex(key % 2 ? 0xd7b9ff : 0xffffff).multiplyScalar(light)); }
  dispose() { this.geometries.forEach((g) => g.dispose()); this.materials.forEach((m) => m.dispose()); this.atlas.dispose(); this.geometries.clear(); this.materials.clear(); }
}