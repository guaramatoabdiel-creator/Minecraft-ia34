import { useMemo, useState } from 'react';
import type { Engine, HudState } from '../game/engine';
import { B, BLOCKS, RECIPES, type Station } from '../game/blocks';
import { allowedRecipe, craftGrid, fillRecipeGrid, findGridRecipe, type CraftCell } from '../game/crafting';
import { BlockIcon, ItemSlot, McButton } from './ui';
import { searchText } from '../utils/search';

export default function CraftingWorkspace({ hud, engine, icons, size, station }: { hud: HudState; engine: Engine; icons: string[]; size: 2 | 3; station: Station }) {
  const [grid, setGrid] = useState<CraftCell[]>(() => Array(size * size).fill(null));
  const [ingredient, setIngredient] = useState<number | null>(null);
  const [query, setQuery] = useState('');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [message, setMessage] = useState('Selecione um ingrediente e toque nos espaços da grade.');
  const creative = engine.meta.mode === 'creative';
  const recipeIndex = findGridRecipe(grid, size, station);
  const recipe = recipeIndex >= 0 ? RECIPES[recipeIndex] : null;
  const result = craftGrid(hud.inventory, grid, size, station, creative);
  const canCraft = result.ok;
  const counts = useMemo(() => {
    const count: Record<number, number> = {};
    hud.inventory.forEach((slot) => { if (slot) count[slot.id] = (count[slot.id] ?? 0) + slot.count; });
    return count;
  }, [hud.inventory]);
  const list = RECIPES.map((r, i) => ({ r, i })).filter(({ r, i }) => allowedRecipe(r, station, size)
    && searchText(BLOCKS[r.out].name).includes(searchText(query)) && (!onlyAvailable || engine.canCraft(i, station)));

  const edit = (index: number, item = ingredient) => {
    const next = [...grid];
    if (item === null || next[index] === item) next[index] = null;
    else next[index] = item;
    setGrid(next);
    setMessage('A grade é um plano: materiais só são consumidos ao criar.');
  };
  const create = (multiple = false) => {
    let made = 0;
    for (let i = 0; i < (multiple ? 16 : 1); i++) { if (!engine.craftManual(grid, size, station)) break; made++; }
    setMessage(made && recipe ? `${made * recipe.count}x ${BLOCKS[recipe.out].name} criado. A grade foi mantida para repetir.` : engine.craftError);
  };

  return <div className="crafting-workspace">
    <aside className="crafting-book">
      <div className="craft-book-heading"><span>Livro de receitas</span><b>{list.length}</b></div>
      <input className="mc-input" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar receita..." aria-label="Buscar no livro de receitas" />
      <label className="craft-filter"><input type="checkbox" checked={onlyAvailable} onChange={(e) => setOnlyAvailable(e.target.checked)} /> Só o que posso criar</label>
      <div className="craft-book-list scroll-thin">{list.map(({ r, i }) => <button key={i} className={`${recipeIndex === i ? 'selected' : ''} ${engine.canCraft(i, station) ? 'available' : ''}`}
        onClick={() => { setGrid(fillRecipeGrid(r, size, hud.inventory)); setMessage(`Receita de ${BLOCKS[r.out].name}. Confira os materiais destacados.`); }}>
        <BlockIcon src={icons[r.out]} size={37} /><span>{BLOCKS[r.out].name}<small>{r.count} por criação</small></span><i />
      </button>)}{!list.length && <p className="empty-result">Nenhuma receita encontrada.</p>}</div>
      <p className="panel-hint">{size === 2 ? 'Abra uma mesa colocada no mundo para usar a grade 3 x 3.' : 'Receitas aceitam qualquer tipo de tábua e ferramentas podem ser espelhadas.'}</p>
    </aside>
    <section className="crafting-desk">
      <div className="craft-desk-heading"><h3>Criação {size} x {size}</h3><button className="text-action" onClick={() => { setGrid(Array(size * size).fill(null)); setIngredient(null); }}>Limpar grade</button></div>
      <div className="manual-craft-row">
        <div className="manual-grid" style={{ gridTemplateColumns: `repeat(${size}, 1fr)` }}>
          {grid.map((id, index) => {
            const used = grid.slice(0, index + 1).filter((cell) => cell === id).length;
            const missing = id !== null && !creative && (counts[id] ?? 0) < used;
            return <button key={index} type="button" className={`mc-slot manual-cell ${missing ? 'missing' : ''}`} onClick={() => edit(index)}
              onContextMenu={(e) => { e.preventDefault(); const next = [...grid]; next[index] = null; setGrid(next); }}
              onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const raw = e.dataTransfer.getData('application/x-mineblock-slot'); const slotIndex = Number(raw); if (raw !== '' && Number.isInteger(slotIndex) && hud.inventory[slotIndex]) edit(index, hud.inventory[slotIndex]!.id); }}
              aria-label={`Espaço ${index + 1}: ${id === null ? 'vazio' : BLOCKS[id].name}${missing ? ', falta material' : ''}`}>
              {id !== null && <BlockIcon src={icons[id]} size={49} className="w-[82%] h-[82%]" />}{missing && <small>!</small>}
            </button>;
          })}
        </div>
        <svg className="craft-arrow" viewBox="0 0 40 24" aria-hidden="true"><path d="M0 8h25V1l15 11-15 11v-7H0z" fill="currentColor" /></svg>
        <button className={`mc-slot manual-result ${canCraft ? 'ready' : ''}`} disabled={!canCraft} onClick={(e) => create(e.shiftKey)} aria-label={recipe ? `Criar ${recipe.count} ${BLOCKS[recipe.out].name}` : 'Resultado vazio'}>
          {recipe && <><BlockIcon src={icons[recipe.out]} size={64} /><span className="slot-count">{recipe.count > 1 ? recipe.count : ''}</span></>}
        </button>
      </div>
      <div className="craft-result-caption">{recipe ? <><strong>{BLOCKS[recipe.out].name}</strong><span>{canCraft ? 'Pronto. Toque no resultado.' : result.ok ? '' : result.reason}</span></> : <span>Monte uma receita ou escolha no livro.</span>}</div>
      <div className="craft-batch-actions"><McButton className="active compact-btn" disabled={!canCraft} onClick={() => create(false)}>Criar {recipe?.count ?? ''}</McButton><McButton className="compact-btn" disabled={!canCraft} onClick={() => create(true)}>Criar até 16 vezes</McButton></div>
      <div className="section-label mt-4">Ingredientes <span>{ingredient === null ? 'Escolha um item' : BLOCKS[ingredient].name}</span></div>
      <div className="bag-grid">{hud.inventory.slice(9).map((slot, index) => <ItemSlot key={index + 9} slot={slot} icons={icons} selected={slot?.id === ingredient} dragIndex={index + 9} onClick={() => { if (slot) setIngredient(slot.id); }} />)}</div>
      <div className="bag-grid mt-2">{hud.inventory.slice(0, 9).map((slot, index) => <ItemSlot key={index} slot={slot} icons={icons} selected={slot?.id === ingredient} dragIndex={index} onClick={() => { if (slot) setIngredient(slot.id); }} />)}</div>
      <p className="craft-message" aria-live="polite">{message}</p>
      {recipe?.input.some(([id]) => id === B.PLANKS) && <p className="panel-hint">Tábuas de madeiras diferentes podem ser combinadas nesta receita.</p>}
    </section>
  </div>;
}