import { useEffect, useState } from 'react';
import { MenuBackground, DirtBackground, McButton } from './components/ui';
import { TitleScreen, WorldSelect, CreateWorld, HelpScreen } from './components/Menus';
import SettingsScreen from './components/SettingsScreen';
import GameScreen from './components/GameScreen';
import AdventurePanel from './components/AdventurePanel';
import { newAdventure } from './game/adventure';
import { getIcons } from './game/textures';
import { loadSettings, saveSettings, saveWorldMeta, loadWorldSave, isTouchDevice, normalizeSettings, type Settings, type WorldMeta, type WorldSave } from './game/settings';
import { unlockAudio, configureAudio, setAudioFocus, sfx, tickMusic } from './game/sound';
import { setMusicScene } from './game/music';
import MusicPlayer from './components/MusicPlayer';

type Screen = 'title' | 'worlds' | 'create' | 'settings' | 'help' | 'game' | 'journal';

interface InstallEvent extends Event {
  prompt: () => void;
  userChoice: Promise<{ outcome: string }>;
}

function goFullscreen() {
  if (!isTouchDevice()) return;
  const el = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => void };
  try {
    const p = el.requestFullscreen?.({ navigationUI: 'hide' } as FullscreenOptions);
    if (p && 'then' in p) {
      p.then(() => {
        const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
        o?.lock?.('landscape').catch(() => {});
      }).catch(() => {});
    } else el.webkitRequestFullscreen?.();
  } catch {
    /* ignore */
  }
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('title');
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [game, setGame] = useState<{ meta: WorldMeta; save: WorldSave | null } | null>(null);
  const [installEvt, setInstallEvt] = useState<InstallEvent | null>(null);
  const [loadError, setLoadError] = useState('');

  useEffect(() => { configureAudio(settings); }, [settings]);
  useEffect(() => {
    const unlock = () => unlockAudio();
    const click = (event: MouseEvent) => {
      const target = event.target as Element | null;
      const button = target?.closest('button');
      if (button && !(button as HTMLButtonElement).disabled && !button.hasAttribute('data-silent')) sfx.click();
    };
    const visibility = () => setAudioFocus(!document.hidden && document.hasFocus());
    document.addEventListener('pointerdown', unlock, { passive: true });
    document.addEventListener('keydown', unlock);
    document.addEventListener('click', click);
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('focus', visibility); window.addEventListener('blur', visibility);
    return () => { document.removeEventListener('pointerdown', unlock); document.removeEventListener('keydown', unlock); document.removeEventListener('click', click); document.removeEventListener('visibilitychange', visibility); window.removeEventListener('focus', visibility); window.removeEventListener('blur', visibility); };
  }, []);
  useEffect(() => {
    if (screen === 'game') return;
    setMusicScene('overworld', 'plains', false);
    const timer = window.setInterval(() => { if (!document.hidden) tickMusic(0.25); }, 250);
    return () => clearInterval(timer);
  }, [screen]);

  useEffect(() => {
    const h = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as InstallEvent);
    };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);

  const install = () => {
    installEvt?.prompt();
    installEvt?.userChoice.then(() => setInstallEvt(null)).catch(() => setInstallEvt(null));
  };

  const updateSettings = (s: Settings) => {
    const normalized = normalizeSettings(s);
    setSettings(normalized);
    saveSettings(normalized);
  };

  const play = (meta: WorldMeta) => {
    let saved: WorldSave | null;
    try { saved = loadWorldSave(meta.id); }
    catch (error) { setLoadError(error instanceof Error ? error.message : 'Não foi possível ler este mundo.'); return; }
    unlockAudio();
    goFullscreen();
    const m = { ...meta, lastPlayed: Date.now() };
    saveWorldMeta(m);
    setGame({ meta: m, save: saved });
    setScreen('game');
  };

  if (screen === 'game' && game) {
    return (
      <GameScreen
        key={game.meta.id}
        meta={game.meta}
        save={game.save}
        settings={settings}
        onSettings={updateSettings}
        onExit={() => {
          setGame(null);
          setScreen('worlds');
        }}
      />
    );
  }

  return (
    <div className="relative h-full w-full overflow-hidden" onPointerDown={unlockAudio}>
      {screen === 'title' ? <MenuBackground /> : <DirtBackground pack={settings.texturePack} />}
      {screen === 'title' && (
        <TitleScreen
          pack={settings.texturePack}
          onPlay={() => setScreen('worlds')}
          onSettings={() => setScreen('settings')}
          onHelp={() => setScreen('help')}
          onGuide={() => setScreen('journal')}
          onInstall={installEvt ? install : undefined}
          music={<MusicPlayer settings={settings} onChange={updateSettings} compact />}
        />
      )}
      {screen === 'worlds' && <WorldSelect pack={settings.texturePack} onPlay={play} onCreate={() => setScreen('create')} onBack={() => setScreen('title')} />}
      {screen === 'create' && <CreateWorld pack={settings.texturePack} onCreate={play} onBack={() => setScreen('worlds')} />}
      {screen === 'settings' && <SettingsScreen settings={settings} onChange={updateSettings} onBack={() => setScreen('title')} />}
      {screen === 'help' && <HelpScreen onBack={() => setScreen('title')} />}
      {screen === 'journal' && <AdventurePanel progress={newAdventure()} icons={getIcons(settings.texturePack)} onClose={() => setScreen('title')} onPlay={() => setScreen('worlds')} />}
      {loadError && <div className="options-confirm z-[90]!"><h2>Não foi possível abrir o mundo</h2><p>{loadError}<br />Os dados existentes não foram substituídos.</p><McButton onClick={() => setLoadError('')}>Voltar</McButton></div>}
    </div>
  );
}
