import { test } from 'node:test';
import assert from 'node:assert/strict';
import { B, I, BLOCKS, RECIPES, WOODS, TILES, isPlaceable, recipeStation, toolId } from '../src/game/blocks.ts';
import { freshHunger, normalizeHunger, exhaust, feed, starvationFloor } from '../src/game/hunger.ts';
import { BIOMES, selectBiome, treeBlocks } from '../src/game/biomes.ts';
import { consume, insertItem, makeSlot, organizeSlots, transferStack } from '../src/game/inventory.ts';
import { allowedRecipe, craftGrid, fillRecipeGrid, findGridRecipe } from '../src/game/crafting.ts';
import { World } from '../src/game/world.ts';
import { blockBounds } from '../src/game/collision.ts';
import { parseWorldBackup } from '../src/game/backups.ts';
import { MUSIC_TRACKS } from '../src/game/music.ts';
import type { Slot } from '../src/game/settings.ts';

test('hunger spends saturation first, then food, and eating is capped', () => {
  const hunger = freshHunger();
  exhaust(hunger, 20);
  assert.equal(hunger.saturation, 0); assert.equal(hunger.food, 20);
  exhaust(hunger, 4); assert.equal(hunger.food, 19);
  feed(hunger, 8, 12.8); assert.equal(hunger.food, 20); assert.equal(hunger.saturation, 12.8);
  feed(hunger, 8, 12.8); assert.equal(hunger.saturation, 20);
  exhaust(hunger, 1000); assert.equal(hunger.food, 0); assert.equal(hunger.saturation, 0);
  assert.ok(hunger.exhaustion >= 0 && hunger.exhaustion < 4);
});

test('old saves start fed and starvation respects each difficulty', () => {
  assert.deepEqual(normalizeHunger(), freshHunger());
  assert.deepEqual(normalizeHunger({ food: NaN, saturation: -8, exhaustion: Infinity }), { food: 20, saturation: 0, exhaustion: 0 });
  assert.equal(normalizeHunger({ food: 5, saturation: 20 }).saturation, 5);
  assert.equal(starvationFloor('peaceful'), 20);
  assert.equal(starvationFloor('easy'), 10);
  assert.equal(starvationFloor('normal'), 1);
  assert.equal(starvationFloor('hard'), 0);
});

test('all food supplies nutrition rather than unconditional instant healing', () => {
  BLOCKS.forEach((item) => {
    if (item.kind !== 'food') return;
    assert.ok(item.food && item.food > 0);
    assert.ok((item.saturation ?? -1) >= 0);
    assert.equal(item.heal, undefined);
  });
});

test('the climate selector has fifteen reachable biome classifications', () => {
  const climates: [number, number, number, number][] = [
    [25, 0, 0, 0], [30, 0, 0, 0], [40, 0, -0.6, 0], [40, 0, 0, 0],
    [40, 0, 0, -0.5], [40, -0.3, 0, 0], [40, -0.6, 0, 0], [40, 0.6, -0.3, -0.4],
    [40, 0.3, 0.1, 0], [40, 0.4, 0.6, 0], [35, 0, 0.5, 0], [45, 0, 0, 0.6],
    [40, 0.6, -0.3, 0.2], [80, 0, 0, 0], [45, 0, 0.5, 0],
  ];
  const found = new Set(climates.map(([h, t, m, v]) => selectBiome(h, t, m, v)));
  assert.equal(found.size, BIOMES.length);
  for (const biome of BIOMES) assert.ok(found.has(biome.id));
});

test('eight tree families use safe voxel IDs, reproducible shapes and distinct planks', () => {
  assert.equal(WOODS.length, 8);
  assert.equal(new Set(WOODS.map((w) => w.planks)).size, 8);
  assert.ok(TILES.length <= 8 * 32);
  for (const wood of WOODS) {
    for (const id of [wood.log, wood.leaves, wood.planks, wood.sapling]) assert.ok(isPlaceable(id) && id < 256);
    const shape = treeBlocks(wood.key, -12, 40, 17, 1337);
    assert.deepEqual(shape, treeBlocks(wood.key, -12, 40, 17, 1337));
    assert.ok(shape.some((block) => block[3] === wood.log));
    assert.ok(shape.some((block) => block[3] === wood.leaves));
    assert.equal(new Set(shape.map(([x, y, z]) => `${x},${y},${z}`)).size, shape.length);
    assert.ok(RECIPES.some((r) => r.out === wood.planks && r.input[0][0] === wood.log));
  }
});

test('a workbench accepts four planks of different species without duplicating resources', () => {
  const inventory: (Slot | null)[] = Array(36).fill(null);
  const ingredients = [B.PLANKS, B.BIRCH_PLANKS, B.CHERRY_PLANKS, B.SPRUCE_PLANKS];
  ingredients.forEach((id, index) => { inventory[index] = makeSlot(id); });
  const result = craftGrid(inventory, ingredients, 2, 'hand');
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.inventory.filter(Boolean).length, 1);
  assert.equal(result.inventory.find(Boolean)?.id, B.CRAFTING);
  assert.equal(inventory.filter(Boolean).length, 4);
});

test('interactive crafting matches mirrored tools and rejects extra cells', () => {
  const grid = [B.IRON, null, null, null, null, null, null, null, null];
  assert.equal(findGridRecipe(grid, 3, 'bench'), -1);
  const axe = RECIPES.find((recipe) => recipe.out === toolId('iron', 'axe'))!;
  const inventory: (Slot | null)[] = Array(36).fill(null);
  inventory[0] = makeSlot(I.IRON, 3); inventory[1] = makeSlot(I.STICK, 2);
  const normal = fillRecipeGrid(axe, 3, inventory);
  const mirrored = normal.map((_, index) => normal[Math.floor(index / 3) * 3 + 2 - index % 3]);
  assert.equal(RECIPES[findGridRecipe(mirrored, 3, 'bench')].out, axe.out);
  const extra = [...mirrored]; extra[extra.indexOf(null)] = B.DIRT;
  assert.equal(findGridRecipe(extra, 3, 'bench'), -1);
  assert.equal(allowedRecipe(axe, 'hand', 2), false);
});

test('book autofill corresponds to a working recipe on its available grid', () => {
  for (const recipe of RECIPES) {
    const station = recipeStation(recipe);
    if (station !== 'hand' && station !== 'bench') continue;
    const size = station === 'hand' ? 2 : 3;
    if (!allowedRecipe(recipe, station, size)) continue;
    const bag: (Slot | null)[] = Array(36).fill(null);
    recipe.input.forEach(([id, count]) => insertItem(bag, id, count));
    const grid = fillRecipeGrid(recipe, size, bag);
    const index = findGridRecipe(grid, size, station);
    assert.ok(index >= 0, BLOCKS[recipe.out].name);
    assert.equal(RECIPES[index].out, recipe.out, BLOCKS[recipe.out].name);
    assert.ok(craftGrid(bag, grid, size, station).ok);
  }
});

test('storage transfers only what fits and sorting preserves worn enchanted equipment', () => {
  const bag: (Slot | null)[] = [makeSlot(B.STONE, 10), null];
  const chest: (Slot | null)[] = [makeSlot(B.STONE, 60)];
  assert.equal(transferStack(bag, chest, 0), 4);
  assert.equal(bag[0]?.count, 6); assert.equal(chest[0]?.count, 64);
  assert.equal(transferStack(bag, chest, 0), 0);
  const tool = { ...makeSlot(toolId('iron', 'pickaxe')), durability: 47, enchant: 2 };
  const sorted = organizeSlots([tool, makeSlot(B.STONE, 7), makeSlot(B.STONE, 8), null]);
  assert.equal(sorted.find((s) => s?.id === tool.id)?.durability, 47);
  assert.equal(sorted.find((s) => s?.id === tool.id)?.enchant, 2);
  assert.equal(sorted.find((s) => s?.id === B.STONE)?.count, 15);
});

test('specific and wildcard wood ingredients cannot count the same plank twice', () => {
  const bag: (Slot | null)[] = [makeSlot(B.CHERRY_PLANKS, 3), null];
  const before = JSON.stringify(bag);
  assert.equal(consume(bag, [[B.PLANKS, 2], [B.CHERRY_PLANKS, 2]]), false);
  assert.equal(JSON.stringify(bag), before);
  bag[1] = makeSlot(B.SPRUCE_PLANKS, 2);
  assert.equal(consume(bag, [[B.PLANKS, 2], [B.CHERRY_PLANKS, 2]]), true);
  assert.equal(bag.reduce((total, item) => total + (item?.count ?? 0), 0), 1);
});

test('slab halves and staircase rotations are stored independently of block IDs', () => {
  assert.deepEqual(blockBounds(B.STONE_SLAB, 4), [[0, 0.5, 0, 1, 1, 1]]);
  assert.notDeepEqual(blockBounds(B.PLANK_STAIRS, 1), blockBounds(B.PLANK_STAIRS, 0));
  const world = new World(1337, 'plano', {}, 'overworld', 2);
  world.generate(0, 0); world.setBlock(5, 45, 5, B.STONE_SLAB, 4);
  const loaded = new World(1337, 'plano', world.serializeMods(), 'overworld', 2, world.serializeStates());
  loaded.generate(0, 0);
  assert.equal(loaded.getBlock(5, 45, 5), B.STONE_SLAB);
  assert.equal(loaded.getState(5, 45, 5), 4);
});

test('the generator is deterministic across chunk load orders', () => {
  const a = new World(42, 'normal', {}, 'overworld', 2);
  const b = new World(42, 'normal', {}, 'overworld', 2);
  const left = a.generate(0, 0).data;
  const right = a.generate(1, 0).data;
  const reversedRight = b.generate(1, 0).data;
  const reversedLeft = b.generate(0, 0).data;
  assert.deepEqual(left, reversedLeft); assert.deepEqual(right, reversedRight);
});

test('version-four backups preserve hunger, chests, saplings and block orientation', () => {
  const data = {
    format: 'mineblock-world', meta: { name: 'Lar', seed: 7, type: 'normal', mode: 'survival', generatorVersion: 2 },
    save: { version: 4, generatorVersion: 2, mods: {},
      player: { x: 1, y: 40, z: 1, health: 14, yaw: 0, pitch: 0, flying: false, hunger: { food: 12, saturation: 2, exhaustion: 1.5 } },
      chests: { 'overworld:1,40,2': [makeSlot(I.DIAMOND, 4)] }, states: { overworld: { '1,40,3': 5 } },
      saplings: [{ x: 5, y: 40, z: 5, dimension: 'overworld', remaining: 25, block: B.CHERRY_SAPLING }],
    },
  };
  const { save } = parseWorldBackup(JSON.stringify(data));
  assert.equal(save.generatorVersion, 2);
  assert.equal(save.player?.hunger?.food, 12);
  assert.equal(save.chests?.['overworld:1,40,2'][0]?.count, 4);
  assert.equal(save.states?.overworld?.['1,40,3'], 5);
  assert.equal(save.saplings?.[0].block, B.CHERRY_SAPLING);
  const old = parseWorldBackup(JSON.stringify({ ...data, meta: { ...data.meta, generatorVersion: undefined }, save: { version: 3, mods: {} } }));
  assert.equal(old.save.generatorVersion, 1);
});

test('the four original music arrangements have finite playable note data', () => {
  assert.equal(new Set(MUSIC_TRACKS.map((track) => track.id)).size, 4);
  for (const track of MUSIC_TRACKS) {
    assert.equal(track.melody.length, 32); assert.equal(track.chords.length, 4);
    assert.ok(track.tempo > 0);
    assert.ok([...track.melody, ...track.chords.flat()].every(Number.isFinite));
  }
});