import { useSyncExternalStore } from 'react';
import { MUSIC_TRACKS, getMusicStatus, subscribeMusic, setMusicPlayback, nextMusicTrack } from '../game/music';
import { tickMusic, unlockAudio } from '../game/sound';
import type { Settings } from '../game/settings';

export default function MusicPlayer({ settings, onChange, compact = false }: { settings: Settings; onChange: (settings: Settings) => void; compact?: boolean }) {
  const music = useSyncExternalStore(subscribeMusic, getMusicStatus, getMusicStatus);
  const play = () => {
    unlockAudio();
    if (!settings.sound || settings.musicVolume === 0) onChange({ ...settings, sound: true, musicVolume: 0.35 });
    setMusicPlayback(!music.playing); tickMusic(0);
  };
  return <div className={`music-player ${compact ? 'compact' : ''}`}>
    <div className={`music-meter ${music.playing ? 'playing' : ''}`} aria-hidden="true"><i /><i /><i /><i /></div>
    <div className="music-track-info"><span>{music.playing ? 'TOCANDO AGORA' : 'TRILHA ORIGINAL'}</span><strong>{music.title}</strong>{!compact && <p>{music.unlocked ? music.subtitle : 'Toque em Reproduzir para liberar o áudio do navegador.'}</p>}</div>
    <button className="music-play-button" onClick={play} title={music.playing ? 'Pausar música' : 'Reproduzir música'} aria-label={music.playing ? 'Pausar música' : 'Reproduzir música'}>
      {music.playing ? <svg viewBox="0 0 20 20" width="19" height="19" aria-hidden="true"><path d="M4 3h4v14H4zm8 0h4v14h-4z" fill="currentColor" /></svg> : <svg viewBox="0 0 20 20" width="19" height="19" aria-hidden="true"><path d="M5 2v16l13-8z" fill="currentColor" /></svg>}
    </button>
    <button className="music-play-button" onClick={() => { unlockAudio(); nextMusicTrack(); tickMusic(0); }} title="Próxima composição" aria-label="Próxima composição"><svg viewBox="0 0 20 20" width="19" height="19" aria-hidden="true"><path d="M3 3v14l10-7zm11 0h3v14h-3z" fill="currentColor" /></svg></button>
    {!compact && <span className="music-track-number">{MUSIC_TRACKS.findIndex((track) => track.id === music.id) + 1} / {MUSIC_TRACKS.length}</span>}
  </div>;
}