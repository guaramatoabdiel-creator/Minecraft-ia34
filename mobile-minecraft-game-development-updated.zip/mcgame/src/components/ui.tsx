import { useMemo, type ReactNode, type ButtonHTMLAttributes, type MouseEvent } from 'react';
import { buildAtlas, type TexturePack } from '../game/textures';
import { TILES, BLOCKS } from '../game/blocks';
import type { Slot } from '../game/settings';
import { sfx } from '../game/sound';

export function McButton({ className = '', onClick, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) {
  return (
    <button
      {...rest}
      className={`mc-btn ${className}`}
      onClick={(e) => {
        onClick?.(e);
      }}
    >
      {children}
    </button>
  );
}

export function Toggle({ label, value, onChange, hint }: { label: string; value: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <McButton className={`w-full text-left flex items-center justify-between gap-2 ${value ? 'active' : ''}`} onClick={() => onChange(!value)} title={hint ?? label} aria-pressed={value}>
      <span className="truncate">{label}</span>
      <span className="shrink-0">{value ? 'LIGADO' : 'DESLIGADO'}</span>
    </McButton>
  );
}

export function Choice<T extends string | number>({ label, value, options, onChange }: { label: string; value: T; options: { v: T; l: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="flex flex-col gap-1">
      <div className="text-xl text-shadow text-gray-200">{label}</div>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0,1fr))` }}>
        {options.map((o) => (
          <McButton key={String(o.v)} className={`text-lg! px-1! ${o.v === value ? 'active' : ''}`} onClick={() => onChange(o.v)}>
            {o.l}
          </McButton>
        ))}
      </div>
    </div>
  );
}

export function Slider({ label, value, min, max, step, onChange, format }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; format?: (v: number) => string }) {
  return (
    <div className="relative">
      <input type="range" className="mc-range" aria-label={label} min={min} max={max} step={step} value={value} onPointerUp={() => sfx.select()} onKeyUp={(e) => { if (e.key.startsWith('Arrow')) sfx.select(); }} onChange={(e) => onChange(parseFloat(e.target.value))} />
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-xl text-shadow text-white">
        {label}: {format ? format(value) : value}
      </div>
    </div>
  );
}

const HEART = ['.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'];

export function Heart({ fill, size = 18 }: { fill: 0 | 1 | 2; size?: number }) {
  return (
    <svg width={size} height={(size * 6) / 7} viewBox="-0.5 -0.5 8 7" className="pixel-img" shapeRendering="crispEdges">
      {HEART.flatMap((row, y) =>
        row.split('').map((ch, x) =>
          ch === '#' ? (
            <rect key={`${x}-${y}`} x={x} y={y} width={1} height={1} fill={fill === 2 || (fill === 1 && x <= 3) ? (y === 1 && x === 1 ? '#ff9a9a' : '#e3201b') : '#3b1212'} stroke="#000" strokeWidth={0.12} />
          ) : null,
        ),
      )}
    </svg>
  );
}

export function useTileUrl(pack: TexturePack, tile: (typeof TILES)[number]) {
  return useMemo(() => buildAtlas(pack).tiles[TILES.indexOf(tile)].toDataURL(), [pack, tile]);
}

export function DirtBackground({ pack, children, className = '' }: { pack: TexturePack; children?: ReactNode; className?: string }) {
  const url = useTileUrl(pack, 'dirt');
  return (
    <div
      className={`absolute inset-0 pixel-img ${className}`}
      style={{ backgroundImage: `linear-gradient(rgba(0,0,0,0.62), rgba(0,0,0,0.62)), url(${url})`, backgroundSize: 'auto, 64px 64px', imageRendering: 'pixelated' }}
    >
      {children}
    </div>
  );
}

export function MenuBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden bg-sky-900">
      <img src="./images/menu-bg.jpg" alt="" className="pan-bg absolute inset-0 h-full w-full object-cover" draggable={false} />
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/10 to-black/60" />
    </div>
  );
}

export function BlockIcon({ src, size = 40, className = '' }: { src?: string; size?: number; className?: string }) {
  if (!src) return <div style={{ width: size, height: size }} />;
  return <img src={src} alt="" width={size} height={size} draggable={false} className={`pixel-img pointer-events-none ${className}`} />;
}

export function DurabilityBar({ slot }: { slot: Slot }) {
  const max = BLOCKS[slot.id]?.durability;
  if (!max) return null;
  const ratio = Math.max(0, Math.min(1, (slot.durability ?? max) / max));
  return <div className="durability-track" title={`Durabilidade: ${slot.durability ?? max}/${max}`}><div style={{ width: `${ratio * 100}%`, background: ratio > 0.5 ? '#85d44c' : ratio > 0.2 ? '#e9c14c' : '#df5d51' }} /></div>;
}

export function ItemSlot({ slot, icons, onClick, selected = false, label, onDoubleClick, dragIndex, onDropSlot, dimmed = false }: { slot: Slot | null; icons: string[]; onClick: (event: MouseEvent<HTMLButtonElement>) => void; onDoubleClick?: () => void; selected?: boolean; label?: string; dragIndex?: number; onDropSlot?: (index: number) => void; dimmed?: boolean }) {
  return (
    <button type="button" onClick={onClick} onDoubleClick={onDoubleClick} aria-label={label ?? (slot ? `${BLOCKS[slot.id]?.name}, ${slot.count}` : 'Espaço vazio')}
      draggable={!!slot && dragIndex !== undefined} onDragStart={(e) => { if (dragIndex !== undefined) { e.dataTransfer.setData('application/x-mineblock-slot', String(dragIndex)); e.dataTransfer.effectAllowed = 'move'; } }}
      onDragOver={(e) => { if (onDropSlot) e.preventDefault(); }} onDrop={(e) => { e.preventDefault(); const raw = e.dataTransfer.getData('application/x-mineblock-slot'); if (raw !== '' && Number.isInteger(Number(raw))) onDropSlot?.(Number(raw)); }}
      title={slot ? BLOCKS[slot.id]?.name : label} className={`item-slot ${selected ? 'is-selected' : ''} ${slot?.enchant ? 'is-enchanted' : ''} ${dimmed ? 'is-dimmed' : ''}`}>
      {slot && <><BlockIcon src={icons[slot.id]} size={54} className="h-[84%] w-[84%]" />{slot.count > 1 && <span className="slot-count">{slot.count}</span>}<DurabilityBar slot={slot} /></>}
      {!slot && label && <span className="slot-placeholder">{label.slice(0, 1)}</span>}
    </button>
  );
}

export function ItemStats({ slot }: { slot: Slot }) {
  const item = BLOCKS[slot.id];
  if (!item) return null;
  return <div className="item-stats">
    {item.damage && <span>{item.damage + (slot.enchant ?? 0) * 1.5} dano</span>}
    {item.speed && <span>{item.speed}x mineração</span>}
    {item.protection && <span>+{item.protection + (slot.enchant ?? 0)} proteção</span>}
    {item.food && <span>+{item.food} alimento</span>}
    {item.saturation && <span>+{item.saturation} saciedade</span>}
    {item.regeneration && <span>Regeneração: {item.regeneration}s</span>}
    {item.durability && <span>{slot.durability ?? item.durability}/{item.durability} usos</span>}
    {!!slot.enchant && <span className="enchantment-text">Encantamento {['', 'I', 'II', 'III'][slot.enchant]}</span>}
  </div>;
}

export function HungerIcon({ fill }: { fill: 0 | 1 | 2 }) {
  const pixels = ['....MMM.', '...MMMMM', '..MMMMMM', '..MMMMM.', '..MMMM..', '.BB.....', 'BBB.....', '.B......'];
  return <svg width="16" height="16" viewBox="0 0 9 9" shapeRendering="crispEdges" aria-hidden="true">
    {pixels.flatMap((row, y) => row.split('').map((char, x) => char === '.' ? null : <rect key={`${x},${y}`} x={x} y={y} width="1" height="1" fill={fill === 2 || fill === 1 && x < 4 ? char === 'B' ? '#e5d7b9' : y < 2 ? '#dcad64' : '#b87842' : '#45352c'} stroke="#241d16" strokeWidth=".16" />))}
  </svg>;
}
