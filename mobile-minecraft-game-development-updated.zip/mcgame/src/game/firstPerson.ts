import * as THREE from 'three';
import { BLOCKS, I, isPlaceable } from './blocks';
import type { Equipment, Settings, Slot } from './settings';
import { ExplorerModel } from './playerModel';
import { ItemModels } from './itemModels';

export class FirstPersonView {
  private scene = new THREE.Scene();
  private viewCamera = new THREE.PerspectiveCamera();
  private group = new THREE.Group();
  private grip = new THREE.Group();
  private offhand = new THREE.Group();
  private arm: ExplorerModel;
  private items: ItemModels;
  private held: THREE.Mesh | null = null;
  private shield: THREE.Mesh | null = null;
  private key = '';
  private offhandKey = '';
  private styleKey = '';
  private id = 0;
  private equipDip = 0;
  private sway = new THREE.Vector2();
  private oldYaw = 0;
  private oldPitch = 0;
  private handSide = 1;

  constructor(private camera: THREE.PerspectiveCamera, private settings: Settings) {
    this.arm = new ExplorerModel({ style: settings.playerStyle, skin: settings.skinTone }, false, true);
    this.items = new ItemModels(settings.texturePack);
    this.group.add(this.arm.root, this.grip); this.scene.add(this.group, this.offhand);
    this.styleKey = `${settings.playerStyle}:${settings.skinTone}`; this.handSide = settings.leftHand ? -1 : 1;
  }

  setSettings(settings: Settings) {
    if (settings.texturePack !== this.settings.texturePack) { this.grip.clear(); this.offhand.clear(); this.items.dispose(); this.items = new ItemModels(settings.texturePack); this.key = this.offhandKey = ''; }
    const style = `${settings.playerStyle}:${settings.skinTone}`;
    if (style !== this.styleKey) {
      this.styleKey = style; this.arm.dispose(); this.arm = new ExplorerModel({ style: settings.playerStyle, skin: settings.skinTone }, false, true); this.group.add(this.arm.root);
    }
    this.settings = settings; this.handSide = settings.leftHand ? -1 : 1;
  }

  setState(slot: Slot | null, equipment: Equipment) {
    const key = `${slot?.id ?? 0}:${slot?.enchant ?? 0}`;
    if (key !== this.key) {
      this.key = key; this.id = slot?.id ?? 0; this.grip.clear(); this.held = null; this.equipDip = 0.15;
      if (slot) { this.held = this.items.create(slot.id, slot.enchant); this.grip.add(this.held); }
    }
    const shield = equipment.offhand, shieldKey = `${shield?.id ?? 0}:${shield?.enchant ?? 0}`;
    if (shieldKey !== this.offhandKey) {
      this.offhandKey = shieldKey; this.offhand.clear(); this.shield = null;
      if (shield) { this.shield = this.items.create(shield.id, shield.enchant); this.shield.scale.setScalar(0.58); this.offhand.add(this.shield); }
    }
  }

  setLight(value: number) { this.arm.setLight(value); this.items.setLight(value); }

  render(renderer: THREE.WebGLRenderer) {
    if (!this.group.visible) return false;
    this.viewCamera.projectionMatrix.copy(this.camera.projectionMatrix);
    this.viewCamera.projectionMatrixInverse.copy(this.camera.projectionMatrixInverse);
    const autoClear = renderer.autoClear; renderer.autoClear = false; renderer.clearDepth();
    renderer.render(this.scene, this.viewCamera); renderer.autoClear = autoClear;
    return true;
  }

  update(dt: number, state: { time: number; swing: number; mining: boolean; eating: number; bob: number; phase: number; yaw: number; pitch: number; blocking: boolean; visible: boolean; paused: boolean }) {
    this.group.visible = state.visible; this.offhand.visible = state.visible && !!this.shield;
    if (!state.visible) return;
    const aspect = Math.min(1, Math.max(0.5, this.camera.aspect));
    const scale = this.settings.handScale * Math.max(0.7, aspect);
    const side = this.handSide;
    const deltaYaw = Math.atan2(Math.sin(state.yaw - this.oldYaw), Math.cos(state.yaw - this.oldYaw));
    this.oldYaw = state.yaw;
    const deltaPitch = state.pitch - this.oldPitch; this.oldPitch = state.pitch;
    this.sway.x += (THREE.MathUtils.clamp(deltaYaw * 0.7, -0.055, 0.055) - this.sway.x) * Math.min(1, dt * 12);
    this.sway.y += (THREE.MathUtils.clamp(deltaPitch * 0.7, -0.055, 0.055) - this.sway.y) * Math.min(1, dt * 12);
    this.equipDip = Math.max(0, this.equipDip - dt * 0.8);
    const swing = state.paused ? 0 : state.mining ? (Math.sin(state.time * 13) + 1) / 2 : Math.sin(state.swing * Math.PI);
    const bobX = Math.cos(state.phase) * 0.014 * state.bob, bobY = Math.abs(Math.sin(state.phase)) * 0.02 * state.bob;
    const hasItem = !!this.id, item = BLOCKS[this.id];
    this.group.scale.setScalar(scale);
    this.group.position.set(side * (0.39 * aspect + bobX - swing * 0.13) - this.sway.x, -0.29 - bobY - this.equipDip - this.sway.y - swing * 0.035, -0.61 - swing * 0.09);
    this.group.rotation.set(-0.18 - swing * 0.4, side * (hasItem ? -0.24 : -0.17), side * (-0.06 + swing * 0.17));
    this.arm.root.position.set(side * 0.09, -0.47, 0.12);
    this.arm.root.rotation.set(0.16, 0, side * -2.72); this.arm.root.scale.setScalar(hasItem ? 0.64 : 0.9);
    if (this.held) {
      const block = isPlaceable(this.id), weapon = item?.tool || item?.kind === 'weapon';
      const size = block ? 0.34 : this.id === I.TRIDENT ? 0.78 : weapon ? 0.69 : 0.43;
      this.held.scale.setScalar(size);
      this.grip.position.set(side * (weapon ? 0.13 : -0.025), block ? -0.025 : weapon ? 0.13 : 0.035, -0.04);
      this.grip.rotation.set(block ? -0.14 : 0, block ? side * 0.62 : side * -0.2, block ? 0 : side * -0.09);
      if (this.id === I.BOW || this.id === I.CROSSBOW) { this.grip.rotation.y = side * -0.1; this.grip.position.y = 0.015; }
    }
    if (state.eating > 0) {
      this.group.position.set(side * 0.13 * aspect, -0.19 + Math.sin(state.eating * 28) * 0.022, -0.47);
      this.group.rotation.set(-0.25, side * -0.2, side * (0.16 + Math.sin(state.eating * 28) * 0.08));
    }
    const y = state.blocking ? -0.08 : -0.36;
    this.offhand.position.x = -side * 0.4 * aspect;
    this.offhand.position.y += (y - this.offhand.position.y) * Math.min(1, dt * 12);
    this.offhand.position.z = -0.64; this.offhand.scale.setScalar(scale);
    this.offhand.rotation.y = side * (state.blocking ? 0.16 : 0.54);
    this.offhand.rotation.z = side * (state.blocking ? 0.06 : -0.06);
  }

  dispose() { this.arm.dispose(); this.items.dispose(); this.group.removeFromParent(); this.offhand.removeFromParent(); }
}