import * as THREE from 'three';
import { CS, CH, World, Chunk } from './world';
import { BLOCKS, B, PLANT_IDS, LEAF_IDS, SLAB_IDS, STAIR_IDS, TILES, type BlockDef } from './blocks';
import { ATLAS_COLS, ATLAS_ROWS } from './textures';
import { blockBounds } from './collision';

interface Corner {
  pos: [number, number, number];
  uv: [number, number];
}
interface Face {
  dir: [number, number, number];
  corners: Corner[];
  shade: number;
  tile: 0 | 1 | 2;
}

const FACES: Face[] = [
  { dir: [-1, 0, 0], shade: 0.72, tile: 1, corners: [
    { pos: [0, 1, 0], uv: [0, 1] }, { pos: [0, 0, 0], uv: [0, 0] }, { pos: [0, 1, 1], uv: [1, 1] }, { pos: [0, 0, 1], uv: [1, 0] } ] },
  { dir: [1, 0, 0], shade: 0.72, tile: 1, corners: [
    { pos: [1, 1, 1], uv: [0, 1] }, { pos: [1, 0, 1], uv: [0, 0] }, { pos: [1, 1, 0], uv: [1, 1] }, { pos: [1, 0, 0], uv: [1, 0] } ] },
  { dir: [0, -1, 0], shade: 0.5, tile: 2, corners: [
    { pos: [1, 0, 1], uv: [1, 0] }, { pos: [0, 0, 1], uv: [0, 0] }, { pos: [1, 0, 0], uv: [1, 1] }, { pos: [0, 0, 0], uv: [0, 1] } ] },
  { dir: [0, 1, 0], shade: 1, tile: 0, corners: [
    { pos: [0, 1, 1], uv: [1, 1] }, { pos: [1, 1, 1], uv: [0, 1] }, { pos: [0, 1, 0], uv: [1, 0] }, { pos: [1, 1, 0], uv: [0, 0] } ] },
  { dir: [0, 0, -1], shade: 0.86, tile: 1, corners: [
    { pos: [1, 0, 0], uv: [0, 0] }, { pos: [0, 0, 0], uv: [1, 0] }, { pos: [1, 1, 0], uv: [0, 1] }, { pos: [0, 1, 0], uv: [1, 1] } ] },
  { dir: [0, 0, 1], shade: 0.86, tile: 1, corners: [
    { pos: [0, 0, 1], uv: [0, 0] }, { pos: [1, 0, 1], uv: [1, 0] }, { pos: [0, 1, 1], uv: [0, 1] }, { pos: [1, 1, 1], uv: [1, 1] } ] },
];

// precomputed AO sample offsets: [face][corner] -> [side1, side2, corner] (each xyz)
const AO_OFF: number[][][][] = FACES.map((f) =>
  f.corners.map((c) => {
    const axes = [0, 1, 2].filter((a) => f.dir[a] === 0);
    const s = axes.map((a) => (c.pos[a] === 1 ? 1 : -1));
    const s1 = [...f.dir];
    s1[axes[0]] += s[0];
    const s2 = [...f.dir];
    s2[axes[1]] += s[1];
    const cc = [...f.dir];
    cc[axes[0]] += s[0];
    cc[axes[1]] += s[1];
    return [s1, s2, cc];
  }),
);

const AO_CURVE = [0.42, 0.6, 0.8, 1];

const CROSSES = PLANT_IDS;
const SPECIAL: Set<number> = new Set([...SLAB_IDS, ...STAIR_IDS, ...CROSSES, B.TORCH, B.FENCE, B.END_FRAME, B.END_FRAME_EYE, B.CHEST, B.LILY, B.PATH, B.FARMLAND]);

const OPAQUE = new Uint8Array(256);
const TRANSP = new Uint8Array(256);
const CASTS = new Uint8Array(256);
BLOCKS.forEach((b, i) => {
  OPAQUE[i] = i !== 0 && !b.transparent ? 1 : 0;
  TRANSP[i] = i === 0 || b.transparent ? 1 : 0;
});
for (let i = 1; i < BLOCKS.length; i++) {
  CASTS[i] =
    !BLOCKS[i]?.solid || i === B.GLASS || i === B.FENCE || CROSSES.has(i) ? 0 : 1;
}

export interface MeshOptions {
  ao: boolean;
  smoothLight: boolean;
  fancyLeaves: boolean;
}

class Buf {
  pos: number[] = [];
  uv: number[] = [];
  col: number[] = [];
  ind: number[] = [];
  n = 0;
  toGeometry(): THREE.BufferGeometry | null {
    if (this.n === 0) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setIndex(this.n > 65535 ? new THREE.Uint32BufferAttribute(this.ind, 1) : new THREE.Uint16BufferAttribute(this.ind, 1));
    g.computeBoundingSphere();
    return g;
  }
}

const EPS = 0.0008;
const TW = 1 / ATLAS_COLS;
const TH = 1 / ATLAS_ROWS;

function tileOrigin(tile: number): [number, number] {
  return [(tile % ATLAS_COLS) * TW, 1 - (Math.floor(tile / ATLAS_COLS) + 1) * TH];
}

/** box arbitrário (para lajes, escadas, tocha, cerca) */
function emitBox(buf: Buf, bx: number, by: number, bz: number, mn: number[], mx: number[], tiles: [number, number, number], light: number, emissive: boolean, front?: { face: number; tile: number }) {
  const sx = mx[0] - mn[0], sy = mx[1] - mn[1], sz = mx[2] - mn[2];
  for (let f = 0; f < 6; f++) {
    const face = FACES[f];
    const shade = emissive ? 1 : face.shade * light;
    const tile = front?.face === f ? front.tile : tiles[face.tile];
    const [u0, v0] = tileOrigin(tile);
    const base = buf.n;
    for (let k = 0; k < 4; k++) {
      const c = face.corners[k];
      buf.pos.push(bx + mn[0] + c.pos[0] * sx, by + mn[1] + c.pos[1] * sy, bz + mn[2] + c.pos[2] * sz);
      buf.uv.push(u0 + EPS + c.uv[0] * (TW - 2 * EPS), v0 + EPS + c.uv[1] * (TH - 2 * EPS));
      buf.col.push(shade, shade, shade);
    }
    buf.n += 4;
    buf.ind.push(base, base + 1, base + 3, base, base + 3, base + 2);
  }
}

/** quad visível dos dois lados (flores, grama) */
function emitDoubleQuad(buf: Buf, bx: number, by: number, bz: number, pts: [number, number, number][], tile: number, shade: number) {
  const [u0, v0] = tileOrigin(tile);
  const uvs: [number, number][] = [[0, 0], [1, 0], [1, 1], [0, 1]];
  const base = buf.n;
  for (let k = 0; k < 4; k++) {
    buf.pos.push(bx + pts[k][0], by + pts[k][1], bz + pts[k][2]);
    buf.uv.push(u0 + EPS + uvs[k][0] * (TW - 2 * EPS), v0 + EPS + uvs[k][1] * (TH - 2 * EPS));
    buf.col.push(shade, shade, shade);
  }
  buf.n += 4;
  buf.ind.push(base, base + 1, base + 2, base, base + 2, base + 3);
  buf.ind.push(base, base + 2, base + 1, base, base + 3, base + 2);
}

function emitSpecial(buf: Buf, bx: number, by: number, bz: number, id: number, def: BlockDef, light: number, state = 0) {
  const tiles = def.tiles;
  const em = !!def.emissive;
  if (id === B.LILY) {
    emitDoubleQuad(buf, bx, by, bz, [[0.04, 0.015, 0.04], [0.96, 0.015, 0.04], [0.96, 0.015, 0.96], [0.04, 0.015, 0.96]], tiles[0], light); return;
  }
  if (SLAB_IDS.has(id) || STAIR_IDS.has(id) || id === B.CHEST || id === B.PATH || id === B.FARMLAND) {
    for (const box of blockBounds(id, state)) emitBox(buf, bx, by, bz, box.slice(0, 3), box.slice(3), tiles, light, em, id === B.CHEST ? { face: [5, 1, 4, 0][state & 3], tile: TILES.indexOf('chest_front') } : undefined);
    return;
  }
  if (id === B.END_FRAME || id === B.END_FRAME_EYE) {
    emitBox(buf, bx, by, bz, [0, 0, 0], [1, 0.8125, 1], tiles, light, false);
    if (id === B.END_FRAME_EYE) emitBox(buf, bx, by, bz, [0.28, 0.8125, 0.28], [0.72, 0.98, 0.72], [tiles[0], tiles[0], tiles[0]], 1, true);
    return;
  }
  if (id === B.TORCH) {
    emitBox(buf, bx, by, bz, [0.4375, 0, 0.4375], [0.5625, 0.625, 0.5625], tiles, 1, true);
    return;
  }
  if (id === B.FENCE) {
    emitBox(buf, bx, by, bz, [0.375, 0, 0.375], [0.625, 1, 0.625], tiles, light, em);
    emitBox(buf, bx, by, bz, [0, 0.375, 0.4375], [1, 0.5, 0.5625], tiles, light, em);
    emitBox(buf, bx, by, bz, [0, 0.6875, 0.4375], [1, 0.8125, 0.5625], tiles, light, em);
    emitBox(buf, bx, by, bz, [0.4375, 0.375, 0], [0.5625, 0.5, 1], tiles, light, em);
    emitBox(buf, bx, by, bz, [0.4375, 0.6875, 0], [0.5625, 0.8125, 1], tiles, light, em);
    return;
  }
  // flores / grama alta: X de dois quads
  const t = tiles[1];
  emitDoubleQuad(buf, bx, by, bz, [[0.15, 0, 0.15], [0.85, 0, 0.85], [0.85, 1, 0.85], [0.15, 1, 0.15]], t, light);
  emitDoubleQuad(buf, bx, by, bz, [[0.85, 0, 0.15], [0.15, 0, 0.85], [0.15, 1, 0.85], [0.85, 1, 0.15]], t, light);
}

export function buildChunkGeometry(world: World, chunk: Chunk, opts: MeshOptions) {
  const data = chunk.data;
  const CS2 = CS * CS;
  const nb: (Uint8Array | null)[] = [];
  const nbMax: number[] = [];
  for (let dz = -1; dz <= 1; dz++)
    for (let dx = -1; dx <= 1; dx++) {
      const c = world.getChunk(chunk.cx + dx, chunk.cz + dz);
      nb.push(c ? c.data : null);
      nbMax.push(c ? c.maxY : 0);
    }

  const get = (x: number, y: number, z: number): number => {
    if (y < 0) return world.dimension === 'end' ? B.AIR : B.BEDROCK;
    if (y >= CH) return 0;
    if (x >= 0 && x < CS && z >= 0 && z < CS) return data[x + z * CS + y * CS2];
    const ox = x < 0 ? -1 : x >= CS ? 1 : 0;
    const oz = z < 0 ? -1 : z >= CS ? 1 : 0;
    const nd = nb[ox + 1 + (oz + 1) * 3];
    if (!nd) return 0;
    return nd[x - ox * CS + (z - oz * CS) * CS + y * CS2];
  };

  // heightmap for soft sky-light
  let hm: Int16Array | null = null;
  if (opts.smoothLight) {
    hm = new Int16Array(18 * 18);
    for (let z = -1; z <= CS; z++)
      for (let x = -1; x <= CS; x++) {
        const ox = x < 0 ? -1 : x >= CS ? 1 : 0;
        const oz = z < 0 ? -1 : z >= CS ? 1 : 0;
        const top = Math.min(CH - 1, nbMax[ox + 1 + (oz + 1) * 3]);
        let h = 0;
        for (let y = top; y >= 0; y--) {
          if (CASTS[get(x, y, z)]) {
            h = y + 1;
            break;
          }
        }
        hm[x + 1 + (z + 1) * 18] = h;
      }
  }

  const opaque = new Buf();
  const water = new Buf();
  const maxY = Math.min(CH, chunk.maxY);
  const ao = [1, 1, 1, 1];
  const aoRaw = [3, 3, 3, 3];

  for (let y = 0; y < maxY; y++)
    for (let z = 0; z < CS; z++)
      for (let x = 0; x < CS; x++) {
        const id = data[x + z * CS + y * CS2];
        if (id === 0 || id === B.NETHER_PORTAL_X || id === B.NETHER_PORTAL_Z || id === B.END_SURFACE) continue;
        const def = BLOCKS[id];

        // blocos com formato especial (laje, escada, tocha, cerca, flores)
        if (SPECIAL.has(id)) {
          let light = 1;
          if (hm && !def.emissive) {
            const h = hm[x + 1 + (z + 1) * 18];
            if (y + 1 < h) light = Math.max(0.3, 0.84 - (h - (y + 1)) * 0.045);
          }
          emitSpecial(opaque, x, y, z, id, def, light, world.getState(chunk.cx * CS + x, y, chunk.cz * CS + z));
          continue;
        }

        const isWater = id === B.WATER || id === B.LAVA || id === B.GLASS || id === B.ICE;
        const isLeaf = LEAF_IDS.has(id);
        const buf = isWater ? water : opaque;
        const waterLow = (id === B.WATER || id === B.LAVA) && get(x, y + 1, z) !== id;

        for (let f = 0; f < 6; f++) {
          const face = FACES[f];
          const dx = face.dir[0], dy = face.dir[1], dz = face.dir[2];
          const nx = x + dx, ny = y + dy, nz = z + dz;
          const nid = get(nx, ny, nz);
          let show: boolean;
          if (isWater) {
            show = nid === 0 || (TRANSP[nid] === 1 && nid !== id);
          } else if (nid === 0) show = true;
          else if (OPAQUE[nid]) show = false;
          else if (nid === id) show = isLeaf && opts.fancyLeaves;
          else show = true;
          if (!show) continue;

          let light = 1;
          if (hm && !def.emissive) {
            const h = hm[nx + 1 + (nz + 1) * 18];
            if (ny < h) light = Math.max(0.3, 0.84 - (h - ny) * 0.045);
          }
          const shade = def.emissive ? 1 : face.shade * light;

          if (opts.ao && !isWater && !def.emissive) {
            const offs = AO_OFF[f];
            for (let k = 0; k < 4; k++) {
              const o = offs[k];
              const s1 = OPAQUE[get(x + o[0][0], y + o[0][1], z + o[0][2])];
              const s2 = OPAQUE[get(x + o[1][0], y + o[1][1], z + o[1][2])];
              const cc = OPAQUE[get(x + o[2][0], y + o[2][1], z + o[2][2])];
              const a = s1 && s2 ? 0 : 3 - (s1 + s2 + cc);
              aoRaw[k] = a;
              ao[k] = AO_CURVE[a];
            }
          } else {
            ao[0] = ao[1] = ao[2] = ao[3] = 1;
            aoRaw[0] = aoRaw[1] = aoRaw[2] = aoRaw[3] = 3;
          }

          const tile = def.tiles[face.tile];
          const u0 = (tile % ATLAS_COLS) * TW;
          const v0 = 1 - (Math.floor(tile / ATLAS_COLS) + 1) * TH;
          const base = buf.n;
          for (let k = 0; k < 4; k++) {
            const c = face.corners[k];
            let py = y + c.pos[1];
            if (waterLow && c.pos[1] === 1) py -= 0.12;
            buf.pos.push(x + c.pos[0], py, z + c.pos[2]);
            buf.uv.push(u0 + EPS + c.uv[0] * (TW - 2 * EPS), v0 + EPS + c.uv[1] * (TH - 2 * EPS));
            const v = shade * ao[k];
            buf.col.push(v, v, v);
          }
          buf.n += 4;
          if (aoRaw[0] + aoRaw[3] > aoRaw[1] + aoRaw[2]) {
            buf.ind.push(base, base + 1, base + 3, base, base + 3, base + 2);
          } else {
            buf.ind.push(base, base + 1, base + 2, base + 2, base + 1, base + 3);
          }
        }
      }

  return { opaque: opaque.toGeometry(), water: water.toGeometry() };
}
