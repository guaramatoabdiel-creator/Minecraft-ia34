import { B, I, BLOCKS, RECIPES, ingredientMatches, recipeStation, type Recipe, type Station } from './blocks';
import type { Slot } from './settings';
import { craftInventory } from './inventory';

export type CraftCell = number | null;
const patterns: Record<string, string[]> = {
  pickaxe: ['MMM', '.S.', '.S.'], axe: ['MM', 'MS', '.S'], shovel: ['M', 'S', 'S'], hoe: ['MM', '.S', '.S'], sword: ['M', 'M', 'S'],
  head: ['MMM', 'M.M'], chest: ['M.M', 'MMM', 'MMM'], legs: ['MMM', 'M.M', 'M.M'], feet: ['M.M', 'M.M'],
};

export function recipeShape(recipe: Recipe): CraftCell[][] | null {
  if (recipeStation(recipe) === 'furnace' || recipeStation(recipe) === 'smithing') return null;
  const item = BLOCKS[recipe.out], material = recipe.input[0][0];
  let shape: CraftCell[][] | null = null;
  const key = item.tool ?? item.equip;
  const from = (rows: string[], symbols: Record<string, number>): CraftCell[][] => rows.map((row) => row.split('').map((symbol) => symbols[symbol] ?? null));
  if (key && patterns[key]) shape = from(patterns[key], { M: material, S: I.STICK });
  const special: Record<number, [string[], Record<string, number>]> = {
    [B.CRAFTING]: [['PP', 'PP'], { P: B.PLANKS }], [B.CHEST]: [['PPP', 'P.P', 'PPP'], { P: B.PLANKS }],
    [B.FURNACE]: [['CCC', 'C.C', 'CCC'], { C: B.COBBLE }], [I.STICK]: [['P', 'P'], { P: B.PLANKS }],
    [I.BREAD]: [['WWW'], { W: I.WHEAT }], [I.PAPER]: [['CCC'], { C: B.SUGAR_CANE }],
    [I.BOWL]: [['P.P', '.P.'], { P: B.PLANKS }], [B.BOOKSHELF]: [['PPP', 'BBB', 'PPP'], { P: B.PLANKS, B: I.BOOK }],
    [B.FENCE]: [['PSP', 'PSP'], { P: B.PLANKS, S: I.STICK }], [B.TORCH]: [['C', 'S'], { C: I.COAL, S: I.STICK }],
    [I.SHIELD]: [['PIP', 'PPP', '.P.'], { P: B.PLANKS, I: I.IRON }], [I.BOW]: [['.SL', 'S.L', '.SL'], { S: I.STICK, L: I.STRING }],
    [I.GOLDEN_APPLE]: [['GGG', 'GAG', 'GGG'], { G: I.GOLD, A: I.APPLE }],
  };
  if (special[recipe.out]) { const [rows, symbols] = special[recipe.out]; shape = from(rows, symbols); }
  if ([B.PLANK_STAIRS, B.COBBLE_STAIRS, B.BRICK_STAIRS].includes(recipe.out as 39 | 40 | 41)) shape = from(['M..', 'MM.', 'MMM'], { M: material });
  if ([B.STONE_SLAB, B.PLANK_SLAB, B.COBBLE_SLAB].includes(recipe.out as 42 | 43 | 44)) shape = [[material, material, material]];
  if (recipe.count === 1 && recipe.input.length === 1 && recipe.input[0][1] === 9) shape = Array.from({ length: 3 }, () => [material, material, material]);
  if (shape) {
    const counts = new Map<number, number>();
    shape.flat().forEach((id) => { if (id !== null) counts.set(id, (counts.get(id) ?? 0) + 1); });
    if (recipe.input.length !== counts.size || recipe.input.some(([id, n]) => counts.get(id) !== n)) shape = null;
  }
  return shape;
}

export function allowedRecipe(recipe: Recipe, station: Station, size: number) {
  const required = recipeStation(recipe);
  if (required !== station && !(required === 'hand' && station === 'bench')) return false;
  const shape = recipeShape(recipe);
  return shape ? shape.length <= size && shape[0].length <= size : recipe.input.reduce((sum, [, n]) => sum + n, 0) <= size * size;
}

function trimGrid(grid: CraftCell[], size: number): CraftCell[][] {
  const occupied = grid.flatMap((id, i) => id === null ? [] : [{ x: i % size, y: Math.floor(i / size) }]);
  if (!occupied.length) return [];
  const minX = Math.min(...occupied.map((p) => p.x)), maxX = Math.max(...occupied.map((p) => p.x));
  const minY = Math.min(...occupied.map((p) => p.y)), maxY = Math.max(...occupied.map((p) => p.y));
  return Array.from({ length: maxY - minY + 1 }, (_, y) => Array.from({ length: maxX - minX + 1 }, (_, x) => grid[(y + minY) * size + x + minX]));
}

export function findGridRecipe(grid: CraftCell[], size: 2 | 3, station: Station): number {
  if (grid.length !== size * size || grid.some((id) => id !== null && (!Number.isInteger(id) || !BLOCKS[id]))) return -1;
  const trimmed = trimGrid(grid, size);
  if (!trimmed.length) return -1;
  return RECIPES.findIndex((recipe) => {
    if (!allowedRecipe(recipe, station, size)) return false;
    const shape = recipeShape(recipe);
    if (shape) return [false, true].some((mirror) => shape.length === trimmed.length && shape[0].length === trimmed[0].length
      && shape.every((row, y) => row.every((id, x) => { const actual = trimmed[y][mirror ? row.length - 1 - x : x]; return id === null ? actual === null : actual !== null && ingredientMatches(id, actual); })));
    const ingredients = recipe.input.flatMap(([id, n]) => Array<number>(n).fill(id));
    const cells = grid.filter((id): id is number => id !== null);
    if (ingredients.length !== cells.length) return false;
    for (const id of ingredients) { const index = cells.findIndex((actual) => ingredientMatches(id, actual)); if (index < 0) return false; cells.splice(index, 1); }
    return true;
  });
}

export function fillRecipeGrid(recipe: Recipe, size: 2 | 3, inventory: (Slot | null)[]): CraftCell[] {
  const grid: CraftCell[] = Array(size * size).fill(null);
  const shape = recipeShape(recipe);
  const available = inventory.map((slot) => slot ? { ...slot } : null);
  const ingredient = (required: number) => {
    const slot = available.find((item) => item && item.count > 0 && ingredientMatches(required, item.id));
    if (!slot) return required;
    slot.count--; return slot.id;
  };
  if (shape && shape.length <= size && shape[0].length <= size) shape.forEach((row, y) => row.forEach((id, x) => { grid[y * size + x] = id === null ? null : ingredient(id); }));
  else {
    let index = 0; recipe.input.forEach(([id, count]) => { for (let n = 0; n < count && index < grid.length; n++) grid[index++] = ingredient(id); });
  }
  return grid;
}

export function craftGrid(inventory: (Slot | null)[], grid: CraftCell[], size: 2 | 3, station: Station, free = false) {
  const index = findGridRecipe(grid, size, station);
  if (index < 0) return { ok: false as const, reason: 'Nenhuma receita combina com esta grade.' };
  const counts = new Map<number, number>();
  grid.forEach((id) => { if (id !== null) counts.set(id, (counts.get(id) ?? 0) + 1); });
  const result = craftInventory(inventory, { ...RECIPES[index], input: [...counts] }, free, true);
  return result.ok ? { ...result, recipeIndex: index } : result;
}