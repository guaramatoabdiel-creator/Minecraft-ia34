import * as THREE from 'three';
import type { Engine } from './engine';
import { B, I, LEAF_IDS, LOG_IDS, isSolid } from './blocks';
import { BOSS_MAX_HP } from './adventure';
import { CH } from './world';
import { blockBounds, clearLine, firstBlockIntersection, intersects, overlapsWorld, segmentBox, type Bounds } from './collision';
import { findPath, standingHeight, canTraverse, type NavigationProfile, type Waypoint } from './navigation';
import { MobModels, MOB_NAMES, type MobKind } from './mobModels';
import { BEHAVIOR_NAMES, chooseBehavior, inVisionCone, interceptSeconds, type Behavior } from './mobBrain';
import { sfx } from './sound';
import type { SavedDrop, SavedMob, Slot } from './settings';

interface Actor {
  id: number; kind: MobKind; group: THREE.Group; limbs: THREE.Object3D[]; head?: THREE.Object3D;
  health: number; maxHealth: number; hitRadius: number; height: number; speed: number; profile: NavigationProfile;
  attackTime: number; flash: number; age: number; index: number; state: Behavior;
  anger: number; memory: number; afraid: number; gaze: number; fuse: number; aimTime: number;
  sensorTimer: number; decisionTimer: number; soundTimer: number; environmentTimer: number;
  seesPlayer: boolean; exposed: boolean; tempted: boolean; shade: THREE.Vector3 | null;
  lastSeen: THREE.Vector3; goal: THREE.Vector3; home: THREE.Vector3; noiseId: number; investigate: number;
  path: Waypoint[]; pathTimer: number; pathRevision: number; pathGoal: THREE.Vector3; wanderTimer: number;
  velocity: THREE.Vector3; onGround: boolean; stuck: number; recoverTime: number; lastPosition: THREE.Vector3;
  turn: number; alarmTime: number; teleportTime: number; burst: number; burstTimer: number; walk: number;
}
interface Projectile {
  mesh: THREE.Mesh; velocity: THREE.Vector3; player: boolean; damage: number; life: number;
  gravity: number; arrow: boolean; recoveredItem?: Slot;
}
interface NoiseEvent { id: number; position: THREE.Vector3; radius: number; time: number }
export const CRYSTAL_POSITIONS = [[24.5, 36.1, 8.5], [-7.5, 36.1, 8.5], [8.5, 36.1, 24.5], [8.5, 36.1, -7.5]];
const attributes: Record<MobKind, [number, number, number, number]> = {
  zombie: [20, 0.31, 1.95, 1.65], skeleton: [20, 0.28, 1.95, 1.75], creeper: [20, 0.31, 1.98, 1.6],
  spider: [16, 0.52, 0.88, 2.15], shadow: [40, 0.28, 2.88, 3.0], blaze: [24, 0.42, 1.96, 1.5],
  cow: [10, 0.4, 1.55, 0.85], pig: [10, 0.39, 1.35, 0.9], sheep: [8, 0.4, 1.45, 0.82], chicken: [4, 0.22, 0.75, 0.75], crystal: [12, 0.95, 1.1, 0], dragon: [BOSS_MAX_HP, 2.5, 2, 4],
};
const passive = (kind: MobKind) => ['cow', 'pig', 'sheep', 'chicken'].includes(kind);
const isBoss = (kind: MobKind) => kind === 'dragon' || kind === 'crystal';
const ranged = (kind: MobKind) => kind === 'skeleton' || kind === 'blaze';

export class CombatSystem {
  private actors: Actor[] = [];
  private projectiles: Projectile[] = [];
  private models = new MobModels();
  private box = new THREE.BoxGeometry(1, 1, 1);
  private mats = new Map<string, THREE.MeshBasicMaterial>();
  private spawnTime = 5;
  private spawnIndex = 0;
  private endReady = false;
  private clock = 0;
  private nextId = 1;
  private noise: NoiseEvent[] = [];
  private noiseId = 0;
  private pathBudget = 2;
  private dragonDestination = new THREE.Vector3(8.5, 39, -4);
  private dragonMode = '';
  phase = '';

  constructor(private host: Engine, saved: SavedMob[] = []) { this.restore(saved); }

  private material(color: string) {
    let mat = this.mats.get(color);
    if (!mat) { mat = new THREE.MeshBasicMaterial({ color }); this.mats.set(color, mat); }
    return mat;
  }

  private createActor(kind: MobKind, position: THREE.Vector3, index = -1) {
    const { group, limbs, head } = this.models.create(kind);
    const [maxHealth, radius, height, speed] = attributes[kind];
    group.position.copy(position); this.host.scene.add(group);
    const actor: Actor = {
      id: this.nextId++, kind, group, limbs, head, maxHealth, health: kind === 'dragon' ? this.host.adventure.bossHealth : maxHealth,
      hitRadius: radius, height, speed, profile: { radius, height, step: kind === 'spider' ? 2 : 1, drop: 2, swim: kind !== 'shadow' && kind !== 'creeper' },
      attackTime: 1.2, flash: 0, age: 0, index, state: 'idle', anger: 0, memory: 0, afraid: 0, gaze: 0, fuse: 0, aimTime: 0,
      sensorTimer: Math.random() * 0.4, decisionTimer: Math.random() * 0.4, soundTimer: 5 + Math.random() * 12, environmentTimer: 0,
      seesPlayer: false, exposed: false, tempted: false, shade: null,
      lastSeen: position.clone(), goal: position.clone(), home: position.clone(), noiseId: 0, investigate: 0,
      path: [], pathTimer: Math.random(), pathRevision: -1, pathGoal: position.clone(), wanderTimer: 0,
      velocity: new THREE.Vector3(), onGround: false, stuck: 0, recoverTime: 0, lastPosition: position.clone(),
      turn: Math.random() < 0.5 ? -1 : 1, alarmTime: 0, teleportTime: 0, burst: 0, burstTimer: 0, walk: 0,
    };
    this.actors.push(actor); return actor;
  }

  private body(actor: Actor, position = actor.group.position): Bounds {
    const r = actor.profile.radius;
    return [position.x - r, position.y + 0.002, position.z - r, position.x + r, position.y + actor.height, position.z + r];
  }
  private eye(actor: Actor) { return actor.group.position.clone().add(new THREE.Vector3(0, actor.kind === 'spider' ? 0.65 : actor.height * 0.85, 0)); }
  private visible(from: THREE.Vector3, to: THREE.Vector3) { return clearLine(this.host.world, from, to); }

  private aimedActor(origin: THREE.Vector3, direction: THREE.Vector3, reach: number) {
    const end = origin.clone().addScaledVector(direction, reach);
    const wall = firstBlockIntersection(this.host.world, origin, end);
    let found: { actor: Actor; fraction: number } | null = null;
    for (const actor of this.actors) {
      if (actor.health <= 0) continue;
      const p = actor.group.position;
      const bounds: Bounds = isBoss(actor.kind)
        ? [p.x - actor.hitRadius, p.y - (actor.kind === 'dragon' ? 1 : 0.8), p.z - actor.hitRadius, p.x + actor.hitRadius, p.y + (actor.kind === 'dragon' ? 1 : 0.8), p.z + actor.hitRadius]
        : [p.x - actor.hitRadius - 0.08, p.y, p.z - actor.hitRadius - 0.08, p.x + actor.hitRadius + 0.08, p.y + actor.height, p.z + actor.hitRadius + 0.08];
      const fraction = segmentBox(origin, end, bounds);
      if (fraction === null || wall !== null && fraction > wall + 0.001 || found && fraction >= found.fraction) continue;
      found = { actor, fraction };
    }
    return found?.actor ?? null;
  }

  getTarget() {
    const actor = this.aimedActor(this.host.camera.position, this.host.camera.getWorldDirection(new THREE.Vector3()), 45);
    return actor ? { name: MOB_NAMES[actor.kind], health: actor.health, maxHealth: actor.maxHealth, intent: isBoss(actor.kind) ? '' : BEHAVIOR_NAMES[actor.state] } : null;
  }

  melee(damage: number, reach = 4.2) {
    const actor = this.aimedActor(this.host.camera.position, this.host.camera.getWorldDirection(new THREE.Vector3()), reach);
    if (!actor) return false;
    this.hit(actor, damage, true); return true;
  }

  hear(position: THREE.Vector3, radius: number) {
    if (!Number.isFinite(radius) || radius < 1) return;
    this.noise.push({ id: ++this.noiseId, position: position.clone(), radius: Math.min(32, radius), time: this.clock });
    if (this.noise.length > 8) this.noise.shift();
  }

  private despawn(actor: Actor) { this.host.scene.remove(actor.group); this.actors = this.actors.filter((a) => a !== actor); }

  private alarm(actor: Actor) {
    if (actor.alarmTime > 0) return;
    actor.alarmTime = 7;
    for (const friend of this.actors) {
      if (friend === actor || passive(friend.kind) || isBoss(friend.kind) || friend.kind === 'shadow') continue;
      if (friend.group.position.distanceToSquared(actor.group.position) > 81 || !this.visible(this.eye(actor), this.eye(friend))) continue;
      friend.memory = Math.max(friend.memory, 5); friend.anger = Math.max(friend.anger, 6); friend.lastSeen.copy(actor.lastSeen);
      friend.goal.copy(actor.lastSeen); friend.pathTimer = Math.min(friend.pathTimer, 0.2);
    }
  }

  private hit(actor: Actor, damage: number, byPlayer = false) {
    if (actor.health <= 0 || !Number.isFinite(damage) || damage <= 0) return;
    if (actor.kind === 'dragon' && this.host.adventure.crystals.length < 4) { this.host.notify('O dragão está protegido. Destrua os quatro cristais!'); return; }
    actor.health = Math.max(0, actor.health - damage); actor.flash = 0.26;
    if (byPlayer) {
      actor.anger = passive(actor.kind) ? 0 : 20; actor.memory = 10; actor.lastSeen.copy(this.host.pos);
      if (passive(actor.kind)) {
        actor.afraid = 6;
        for (const friend of this.actors) if (passive(friend.kind) && friend.group.position.distanceToSquared(actor.group.position) < 36) { friend.afraid = Math.max(friend.afraid, 3); friend.lastSeen.copy(this.host.pos); friend.decisionTimer = 0; }
      }
      actor.decisionTimer = 0; actor.pathTimer = 0;
      const away = actor.group.position.clone().sub(this.host.pos).setY(0).normalize();
      actor.velocity.x += away.x * 3; actor.velocity.z += away.z * 3;
      if (!isBoss(actor.kind)) actor.velocity.y = Math.max(actor.velocity.y, 3.2);
      if (actor.kind === 'zombie') this.alarm(actor);
    }
    sfx.mob(actor.kind, actor.health ? 'hurt' : 'death', actor.group.position);
    if (actor.kind === 'dragon') this.host.adventure.bossHealth = actor.health;
    if (actor.health > 0) { if (actor.kind === 'shadow' && byPlayer && actor.teleportTime <= 0) this.teleport(actor, true); return; }
    this.despawn(actor);
    const h = this.host;
    if (actor.kind === 'crystal') {
      if (!h.adventure.crystals.includes(actor.index)) h.adventure.crystals.push(actor.index);
      h.notify(`Cristal destruído: ${h.adventure.crystals.length}/4.`); h.adventure.xp += 5; sfx.boom(actor.group.position);
    } else if (actor.kind === 'dragon') {
      h.adventure.victory = true; h.adventure.xp += 100; h.health = 20; h.addItem(I.TROPHY, 1);
      h.setPaused(true); h.notify('O último voo terminou. Você venceu!'); h.cb.onAutosave?.(h.serialize()); sfx.victory();
    } else {
      if (byPlayer) { h.adventure.kills++; h.adventure.xp += passive(actor.kind) ? 1 : 3; }
      const pos = actor.group.position.clone().add(new THREE.Vector3(0, 0.45, 0));
      const loot = (id: number, count: number) => h.dropLoot(id, count, pos.clone());
      if (actor.kind === 'blaze') { if (byPlayer) h.adventure.blazes++; loot(I.BLAZE_ROD, 1); }
      if (actor.kind === 'shadow') loot(I.PEARL, 1);
      if (actor.kind === 'spider') loot(I.STRING, 2);
      if (actor.kind === 'skeleton') { loot(I.BONE, 1); loot(I.ARROW, 2); }
      if (actor.kind === 'creeper') loot(I.GUNPOWDER, 2);
      if (actor.kind === 'zombie') loot(I.COAL, 1);
      if (actor.kind === 'cow') { loot(I.LEATHER, 2); loot(I.RAW_BEEF, 2); }
      if (actor.kind === 'pig') loot(I.RAW_PORK, 3);
      if (actor.kind === 'sheep') loot(B.WOOL_WHITE, 1 + (Math.random() < 0.5 ? 1 : 0));
      if (actor.kind === 'chicken') { loot(I.FEATHER, 2); loot(I.RAW_CHICKEN, 1); }
    }
    h.emitHud();
  }

  blast(origin: THREE.Vector3, radius: number) {
    for (const actor of [...this.actors]) {
      const distance = actor.group.position.distanceTo(origin);
      if (distance < radius && this.visible(origin, this.eye(actor))) this.hit(actor, Math.ceil((radius - distance) * 3));
    }
  }

  blocksPlacement(x: number, y: number, z: number, id: number, state = 0) {
    const boxes = blockBounds(id, state);
    if (!boxes.length) return false;
    return this.actors.some((actor) => actor.health > 0 && !isBoss(actor.kind) && boxes.some((box) => intersects(this.body(actor), box, x, y, z)));
  }

  canShoot() { return this.projectiles.length < 24; }
  shootPlayer(damage: number, trident = false, recoveredItem?: Slot) {
    const direction = this.host.camera.getWorldDirection(new THREE.Vector3());
    this.projectile(this.host.camera.position.clone().addScaledVector(direction, 0.2), direction.multiplyScalar(trident ? 26 : 35), true, damage, trident ? '#78e4df' : '#e9d5b3', 2.4, !trident, recoveredItem);
    sfx.bow();
  }
  private projectile(origin: THREE.Vector3, velocity: THREE.Vector3, player: boolean, damage: number, color: string, gravity = 0, arrow = false, recoveredItem?: Slot) {
    if (!this.canShoot()) return;
    const mesh = new THREE.Mesh(this.box, this.material(color));
    mesh.scale.set(player || arrow ? 0.055 : 0.24, player || arrow ? 0.055 : 0.24, player || arrow ? 0.75 : 0.24);
    mesh.position.copy(origin); mesh.lookAt(origin.clone().add(velocity)); this.host.scene.add(mesh);
    this.projectiles.push({ mesh, velocity, player, damage, life: 5, gravity, arrow, recoveredItem });
  }

  private openSkyAt(x: number, y: number, z: number) {
    for (let py = Math.floor(y); py < CH; py++) {
      const id = this.host.world.getBlock(Math.floor(x), py, Math.floor(z));
      if (id === -1 || isSolid(id)) return false;
    }
    return true;
  }

  private floorAt(x: number, z: number, profile: NavigationProfile, cave = false) {
    const h = this.host;
    const top = cave ? Math.min(CH - 4, Math.floor(h.pos.y + 3)) : Math.min(CH - 4, h.world.heightAt(x, z) + 14);
    for (let y = top; y > Math.max(0, cave ? h.pos.y - 8 : 0); y--) {
      const id = h.world.getBlock(Math.floor(x), y, Math.floor(z));
      if (id === -1 || id === B.WATER || id === B.LAVA) return null;
      if (LEAF_IDS.has(id)) continue;
      if (LOG_IDS.has(id)) return null;
      if (isSolid(id)) {
        const ground = standingHeight(h.world, x, z, y + 1, profile.height, 0, profile.radius, 0.1, false);
        if (ground !== null) return ground;
      }
    }
    return null;
  }

  private litAt(x: number, y: number, z: number) {
    for (let dy = -1; dy <= 2; dy++) for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) {
      if (Math.abs(dx) + Math.abs(dz) + Math.abs(dy) > 6) continue;
      const id = this.host.world.getBlock(Math.floor(x) + dx, Math.floor(y) + dy, Math.floor(z) + dz);
      if (id === B.TORCH || id === B.GLOWSTONE || id === B.PUMPKIN_LIT) return true;
    }
    return false;
  }

  private spawnMob() {
    const h = this.host, sequence = this.spawnIndex++;
    const night = Math.sin(h.time * Math.PI * 2) < 0.1, cave = h.pos.y < h.world.heightAt(h.pos.x, h.pos.z) - 4;
    const shaded = !this.openSkyAt(h.pos.x, h.pos.y + 1.9, h.pos.z);
    let animals = h.dimension === 'overworld' && !cave && (!night && !shaded || sequence % 5 === 0);
    if (animals && this.actors.filter((actor) => passive(actor.kind)).length >= 3) { if (!night && !cave && !shaded) return; animals = false; }
    if (!animals && (h.settings.difficulty === 'peaceful' || h.adventure.elapsed < 45)) return;
    const kind: MobKind = animals ? (['cow', 'pig', 'sheep', 'chicken'] as MobKind[])[sequence % 4] : h.dimension === 'nether' ? 'blaze' : (['zombie', 'skeleton', 'spider', 'creeper', 'shadow'] as MobKind[])[sequence % 5];
    const profile: NavigationProfile = { radius: attributes[kind][1], height: attributes[kind][2], step: 1, drop: 2 };
    for (let attempt = 0; attempt < 10; attempt++) {
      const angle = Math.random() * Math.PI * 2, radius = 12 + Math.random() * Math.min(16, Math.max(2, h.settings.simulationDistance - 15));
      const x = h.pos.x + Math.cos(angle) * radius, z = h.pos.z + Math.sin(angle) * radius;
      const y = this.floorAt(x, z, profile, cave);
      if (y === null || Math.abs(y - h.pos.y) > 14 || !animals && this.litAt(x, y, z)) continue;
      if (!animals && h.dimension === 'overworld' && !night && this.openSkyAt(x, y + profile.height, z)) continue;
      if (this.actors.some((a) => a.group.position.distanceToSquared(new THREE.Vector3(x, y, z)) < 4)) continue;
      const actor = this.createActor(kind, new THREE.Vector3(x, y, z)); actor.onGround = true;
      actor.group.rotation.y = Math.random() * Math.PI * 2; return;
    }
  }

  private teleport(actor: Actor, combat = false) {
    if (actor.teleportTime > 0) return false;
    const center = combat ? this.host.pos : actor.group.position;
    for (let attempt = 0; attempt < 12; attempt++) {
      const angle = Math.random() * Math.PI * 2, distance = 6 + Math.random() * 7;
      const x = center.x + Math.cos(angle) * distance, z = center.z + Math.sin(angle) * distance;
      const y = this.floorAt(x, z, actor.profile, actor.group.position.y < this.host.world.heightAt(x, z) - 4);
      if (y === null || !combat && this.host.dimension === 'overworld' && Math.sin(this.host.time * Math.PI * 2) > 0.3 && this.openSkyAt(x, y + actor.height, z)) continue;
      if (this.actors.some((other) => other !== actor && other.group.position.distanceToSquared(new THREE.Vector3(x, y, z)) < 2)) continue;
      sfx.teleport(actor.group.position); actor.group.position.set(x, y, z); actor.lastPosition.copy(actor.group.position);
      actor.path = []; actor.pathTimer = 0; actor.teleportTime = 5; actor.velocity.set(0, 0, 0); actor.onGround = true; return true;
    }
    actor.teleportTime = 1.5; return false;
  }

  private sense(actor: Actor, distance: number, interval: number) {
    const h = this.host, p = actor.group.position;
    const sneak = h.input.down || h.keys.has('ShiftLeft') || h.keys.has('ShiftRight');
    const range = actor.kind === 'shadow' ? 22 : sneak ? 13 : 21;
    const alerted = actor.anger > 0;
    actor.seesPlayer = !h.dead && distance < range && inVisionCone(Math.sin(actor.group.rotation.y), Math.cos(actor.group.rotation.y), h.pos.x - p.x, h.pos.z - p.z, distance, alerted, sneak)
      && this.visible(this.eye(actor), h.pos.clone().add(new THREE.Vector3(0, 1.25, 0)));
    const day = h.dimension === 'overworld' && Math.sin(h.time * Math.PI * 2) > 0.25;
    const sky = day && this.openSkyAt(p.x, p.y + actor.height, p.z);
    actor.exposed = !!sky && (actor.kind === 'zombie' || actor.kind === 'skeleton');
    const hostile = !passive(actor.kind) && actor.kind !== 'shadow' && (actor.kind !== 'spider' || !day || !sky || actor.anger > 0);
    if (actor.kind === 'shadow' && actor.seesPlayer && h.meta.mode !== 'creative') {
      const head = p.clone().add(new THREE.Vector3(0, actor.height - 0.25, 0));
      const toHead = head.sub(h.camera.position).normalize();
      actor.gaze = h.camera.getWorldDirection(new THREE.Vector3()).dot(toHead) > 0.983 ? actor.gaze + interval : 0;
      if (actor.gaze > 0.6) actor.anger = 18;
    } else actor.gaze = 0;
    if (actor.seesPlayer && (hostile && h.meta.mode !== 'creative' || alerted) && !passive(actor.kind)) {
      actor.anger = Math.max(actor.anger, 9); actor.memory = 9; actor.lastSeen.copy(h.pos);
      if (actor.kind === 'zombie') this.alarm(actor);
    }
    actor.tempted = passive(actor.kind) && actor.afraid <= 0 && distance < 11 && actor.seesPlayer && h.inventory[h.selected]?.id === I.WHEAT;
    if (actor.anger <= 0 && !passive(actor.kind) && actor.kind !== 'shadow') {
      for (const noise of this.noise) {
        if (noise.id <= actor.noiseId || this.clock - noise.time > 2.5) continue;
        actor.noiseId = noise.id;
        if (noise.position.distanceToSquared(p) <= noise.radius ** 2 && h.meta.mode !== 'creative') {
          actor.lastSeen.copy(noise.position); actor.investigate = 5; actor.wanderTimer = 0;
        }
      }
    }
  }

  private chooseSafePoint(actor: Actor, purpose: 'flee' | 'shelter' | 'wander' | 'recover') {
    const p = actor.group.position, h = this.host;
    let best: THREE.Vector3 | null = null, score = -Infinity;
    for (let i = 0; i < (purpose === 'shelter' ? 20 : 12); i++) {
      const angle = i * 2.39996 + actor.id * 0.7, distance = purpose === 'recover' ? 2 + i % 3 : 3 + i % 4 * 2;
      const x = p.x + Math.cos(angle) * distance, z = p.z + Math.sin(angle) * distance;
      const y = standingHeight(h.world, x, z, p.y, actor.height, 2, actor.profile.radius, 3, !!actor.profile.swim);
      if (y === null) continue;
      if (purpose === 'shelter' && this.openSkyAt(x, y + actor.height, z)) continue;
      const candidate = new THREE.Vector3(x, y, z);
      const clear = this.visible(this.eye(actor), candidate.clone().add(new THREE.Vector3(0, actor.height * 0.7, 0)));
      const value = (purpose === 'flee' ? candidate.distanceToSquared(actor.lastSeen) * 0.06 : purpose === 'recover' ? -candidate.distanceTo(actor.goal) : -candidate.distanceTo(actor.home) * 0.08)
        + (clear ? 3 : 0) - Math.abs(y - p.y) * 0.8 - this.actors.filter((a) => a !== actor && a.group.position.distanceToSquared(candidate) < 2).length * 4;
      if (value > score) { score = value; best = candidate; }
    }
    return best;
  }

  private decide(actor: Actor, distance: number) {
    const h = this.host, p = actor.group.position;
    const old = actor.state;
    actor.state = chooseBehavior({ passive: passive(actor.kind), seesPlayer: actor.seesPlayer, distance,
      anger: actor.anger, memory: actor.memory, afraid: actor.afraid, tempted: actor.tempted,
      exposed: actor.exposed, ranged: ranged(actor.kind), creeper: actor.kind === 'creeper',
      heard: actor.investigate > 0, stuck: actor.stuck > 1.6 || actor.recoverTime > 0 });
    if (old !== actor.state) { actor.pathTimer = 0; if (actor.state !== 'aim') actor.aimTime = 0; }
    switch (actor.state) {
      case 'chase': {
        actor.goal.copy(actor.lastSeen);
        if (actor.kind === 'zombie' && distance > 3 && distance < 12) {
          const angle = actor.id * 2.4; actor.goal.x += Math.cos(angle) * 1.45; actor.goal.z += Math.sin(angle) * 1.45;
        }
        break;
      }
      case 'search': case 'investigate':
        actor.goal.copy(actor.lastSeen);
        if (p.distanceToSquared(actor.lastSeen) < 2) { actor.goal.add(new THREE.Vector3(Math.cos(actor.id + actor.age) * 2.5, 0, Math.sin(actor.id + actor.age) * 2.5)); actor.wanderTimer = 2; }
        break;
      case 'follow': actor.goal.copy(h.pos); break;
      case 'fuse': actor.goal.copy(p); break;
      case 'aim': case 'retreat': {
        const away = p.clone().sub(h.pos).setY(0).normalize();
        const side = new THREE.Vector3(-away.z, 0, away.x).multiplyScalar(actor.turn);
        const next = p.clone().addScaledVector(away, actor.state === 'retreat' ? 4.5 : 0).addScaledVector(side, actor.state === 'aim' ? 2.4 : 1.4);
        const y = standingHeight(h.world, next.x, next.z, p.y, actor.height, 1, actor.profile.radius, 2, !!actor.profile.swim);
        if (y !== null) { next.y = y; actor.goal.copy(next); } else { actor.turn *= -1; actor.goal.copy(p); }
        break;
      }
      case 'shelter': {
        if (!actor.shade || actor.wanderTimer <= 0) { actor.shade = this.chooseSafePoint(actor, 'shelter'); actor.wanderTimer = 3; }
        if (actor.shade) actor.goal.copy(actor.shade);
        else if (actor.seesPlayer && actor.anger > 0) actor.goal.copy(actor.lastSeen);
        break;
      }
      case 'flee': {
        if (actor.wanderTimer <= 0 || old !== 'flee') { const point = this.chooseSafePoint(actor, 'flee'); if (point) actor.goal.copy(point); actor.wanderTimer = 1.4; }
        break;
      }
      case 'recover': {
        if (actor.recoverTime <= 0) { const point = this.chooseSafePoint(actor, 'recover'); if (point) actor.goal.copy(point); actor.path = []; actor.recoverTime = 1.3; actor.stuck = 0; }
        break;
      }
      default:
        if (actor.wanderTimer <= 0) {
          actor.wanderTimer = 3 + Math.random() * 4;
          if (Math.random() < 0.3) { actor.state = 'idle'; actor.goal.copy(p); }
          else { const point = this.chooseSafePoint(actor, 'wander'); if (point) actor.goal.copy(point); }
        }
    }
  }

  private moveAxis(actor: Actor, axis: 0 | 1 | 2, amount: number) {
    if (!amount) return false;
    const p = actor.group.position; p.setComponent(axis, p.getComponent(axis) + amount);
    const body = this.body(actor); let bound = amount > 0 ? Infinity : -Infinity, hit = false;
    for (let y = Math.floor(body[1]) - 1; y <= Math.floor(body[4] - 0.0001); y++)
      for (let z = Math.floor(body[2]); z <= Math.floor(body[5] - 0.0001); z++)
        for (let x = Math.floor(body[0]); x <= Math.floor(body[3] - 0.0001); x++) {
          for (const box of blockBounds(this.host.world.getBlock(x, y, z), this.host.world.getState(x, y, z))) {
            if (!intersects(body, box, x, y, z)) continue;
            hit = true; const offset = axis === 0 ? x : axis === 1 ? y : z, edge = offset + box[amount > 0 ? axis : axis + 3];
            bound = amount > 0 ? Math.min(bound, edge) : Math.max(bound, edge);
          }
        }
    if (hit) p.setComponent(axis, axis === 1 ? amount > 0 ? bound - actor.height - 0.001 : bound : amount > 0 ? bound - actor.profile.radius - 0.001 : bound + actor.profile.radius + 0.001);
    return hit;
  }

  private move(actor: Actor, dt: number) {
    const h = this.host, p = actor.group.position, profile = actor.profile;
    actor.pathTimer -= dt; actor.wanderTimer -= dt;
    const moving = p.distanceToSquared(actor.goal) > 0.3 && actor.state !== 'idle' && actor.state !== 'fuse';
    if (moving && actor.kind !== 'blaze' && actor.pathTimer <= 0 && this.pathBudget >= 1) {
      const changed = actor.pathGoal.distanceToSquared(actor.goal) > 1 || actor.pathRevision !== h.world.revision || !actor.path.length || actor.stuck > 0.7;
      if (changed) {
        this.pathBudget--; actor.path = findPath(h.world, p, actor.goal, actor.height, h.settings.preset === 'rapido' ? 85 : 200, profile.step, profile);
        actor.pathGoal.copy(actor.goal); actor.pathRevision = h.world.revision;
      }
      actor.pathTimer = 0.55 + (actor.id % 5) * 0.08;
    }
    while (actor.path.length && Math.hypot(actor.path[0].x - p.x, actor.path[0].z - p.z) < 0.22 && Math.abs(actor.path[0].y - p.y) < 0.55) actor.path.shift();
    let waypoint = actor.path[0];
    if (!waypoint && moving && Math.hypot(p.x - actor.goal.x, p.z - actor.goal.z) < 2.5 && canTraverse(h.world, p, actor.goal, profile)) waypoint = actor.goal;
    const direction = waypoint && moving ? new THREE.Vector3(waypoint.x - p.x, 0, waypoint.z - p.z).normalize() : new THREE.Vector3();
    const playerDistance = Math.hypot(p.x - h.pos.x, p.z - h.pos.z);
    if ((actor.state === 'follow' && playerDistance < 2.2) || actor.state === 'chase' && playerDistance < 1.4) direction.set(0, 0, 0);
    for (const other of this.actors) {
      if (other === actor || isBoss(other.kind) || Math.abs(p.y - other.group.position.y) > 1.4) continue;
      const offset = p.clone().sub(other.group.position).setY(0), distance = offset.length();
      const radius = profile.radius + other.profile.radius + 0.25;
      if (distance > 0.01 && distance < radius) direction.addScaledVector(offset.normalize(), (radius - distance) * 1.4);
    }
    if (direction.lengthSq() > 1) direction.normalize();
    if (actor.kind === 'blaze') { this.fly(actor, dt); return; }
    const speed = actor.speed * (actor.state === 'flee' ? 2.5 : actor.state === 'wander' ? 0.6 : actor.state === 'aim' ? 0.42 : actor.state === 'shelter' ? 1.25 : 1);
    actor.velocity.x += (direction.x * speed - actor.velocity.x) * Math.min(1, dt * 9);
    actor.velocity.z += (direction.z * speed - actor.velocity.z) * Math.min(1, dt * 9);
    const water = h.world.getBlock(Math.floor(p.x), Math.floor(p.y + 0.25), Math.floor(p.z)) === B.WATER;
    if (water && profile.swim) actor.velocity.y = Math.min(3, actor.velocity.y + 9 * dt);
    else actor.velocity.y = Math.max(-22, actor.velocity.y - 25 * dt);
    if (actor.onGround && waypoint && waypoint.y > p.y + 0.55 && direction.lengthSq() > 0.01) { actor.velocity.y = 8; actor.onGround = false; }
    const steps = Math.max(1, Math.ceil(actor.velocity.length() * dt / 0.14));
    let wall = false; const start = p.clone(); const wasGround = actor.onGround; actor.onGround = false;
    for (let i = 0; i < steps; i++) {
      const vy = actor.velocity.y * dt / steps;
      if (this.moveAxis(actor, 1, vy)) { if (vy < 0) actor.onGround = true; actor.velocity.y = 0; }
      for (const axis of [0, 2] as const) {
        const amount = actor.velocity.getComponent(axis) * dt / steps;
        const old = p.clone();
        if ((wasGround || actor.onGround) && actor.velocity.y <= 0 && Math.abs(amount) > 0) {
          const trial = p.clone(); trial.setComponent(axis, trial.getComponent(axis) + amount);
          const safeFloor = standingHeight(h.world, trial.x, trial.z, p.y, actor.height, profile.step, profile.radius, profile.drop, !!profile.swim);
          if (safeFloor === null) { wall = true; actor.velocity.setComponent(axis, 0); continue; }
        }
        if (this.moveAxis(actor, axis, amount)) {
          wall = true;
          const candidate = old.clone(); candidate.setComponent(axis, candidate.getComponent(axis) + amount); candidate.y += 0.51;
          if ((wasGround || actor.onGround) && !overlapsWorld(h.world, this.body(actor, candidate))) { p.copy(candidate); this.moveAxis(actor, 1, -0.51); }
          else actor.velocity.setComponent(axis, 0);
        }
      }
    }
    if (actor.kind === 'spider' && wall && actor.goal.y > p.y + 0.3 && actor.anger > 0) actor.velocity.y = 4.5;
    const moved = p.distanceTo(start);
    actor.walk += moved * 6;
    const waitingNearPlayer = actor.state === 'follow' && playerDistance < 2.2 || actor.state === 'chase' && playerDistance < 1.4;
    if (moving && !waitingNearPlayer && moved < dt * speed * 0.12) actor.stuck += dt;
    else actor.stuck = Math.max(0, actor.stuck - dt * 1.5);
    if (wall) actor.pathTimer = Math.min(actor.pathTimer, 0.18);
    this.turnAndAnimate(actor, dt, direction, moved > 0.002);
  }

  private fly(actor: Actor, dt: number) {
    const h = this.host, p = actor.group.position;
    const target = actor.goal.clone(); target.y = Math.max(actor.home.y + 0.6, Math.min(actor.home.y + 5, actor.lastSeen.y + 1));
    if (actor.anger <= 0) target.y = actor.home.y + 0.65 + Math.sin(actor.age * 0.8) * 0.4;
    const preferred = target.sub(p).normalize();
    const candidates = [preferred, new THREE.Vector3(preferred.z, 0.45, -preferred.x), new THREE.Vector3(-preferred.z, 0.55, preferred.x), new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, -0.5, 0)];
    let direction = new THREE.Vector3(), best = -Infinity;
    for (const test of candidates) {
      test.normalize(); const end = p.clone().addScaledVector(test, Math.max(0.35, dt * actor.speed));
      if (h.world.getBlock(Math.floor(end.x), Math.floor(end.y), Math.floor(end.z)) === -1 || overlapsWorld(h.world, this.body(actor, end))) continue;
      const score = test.dot(preferred); if (score > best) { best = score; direction = test; }
    }
    if (p.distanceTo(actor.goal) > 1 || Math.abs(preferred.y) > 0.1) p.addScaledVector(direction, dt * actor.speed);
    actor.walk += dt;
    this.turnAndAnimate(actor, dt, direction, true);
  }

  private turnAndAnimate(actor: Actor, dt: number, direction: THREE.Vector3, moving: boolean) {
    const p = actor.group.position;
    const face = actor.seesPlayer && ['aim', 'retreat', 'fuse'].includes(actor.state) ? this.host.pos.clone().sub(p) : direction;
    if (Math.hypot(face.x, face.z) > 0.01) {
      const angle = Math.atan2(face.x, face.z);
      actor.group.rotation.y += Math.atan2(Math.sin(angle - actor.group.rotation.y), Math.cos(angle - actor.group.rotation.y)) * Math.min(1, dt * 7);
    }
    if (actor.head && actor.seesPlayer) {
      const angle = Math.atan2(this.host.pos.x - p.x, this.host.pos.z - p.z) - actor.group.rotation.y;
      actor.head.rotation.y = THREE.MathUtils.clamp(Math.atan2(Math.sin(angle), Math.cos(angle)), -0.65, 0.65);
    }
    actor.limbs.forEach((part, index) => {
      if (actor.kind === 'blaze') {
        const angle = actor.age * (actor.burst ? 3 : 1.5) + index / 4 * Math.PI * 2;
        part.position.set(Math.cos(angle) * 0.6, 0.35 + Math.floor(index / 4) * 0.5 + Math.sin(actor.age + index) * 0.05, Math.sin(angle) * 0.6);
      } else {
        const rest = Number(part.userData.restX ?? 0);
        const amplitude = actor.kind === 'spider' ? 0.22 : 0.5;
        part.rotation.x = rest + (moving ? Math.sin(actor.walk + index * Math.PI) * amplitude : Math.sin(actor.age * 1.3) * 0.025);
        if (actor.kind === 'zombie' && index >= 2 && actor.attackTime > 1) part.rotation.x -= 0.25;
      }
    });
  }

  private shootAtPlayer(actor: Actor, speed: number, fire = false) {
    const origin = this.eye(actor), target = this.host.pos.clone().add(new THREE.Vector3(0, 1.05, 0));
    const lead = interceptSeconds(origin.distanceTo(target), speed);
    if (this.host.vel) target.addScaledVector(this.host.vel.clone().setY(0), lead * 0.7);
    if (!this.visible(origin, target)) return false;
    for (const friend of this.actors) {
      if (friend === actor || isBoss(friend.kind) || friend.health <= 0) continue;
      if (segmentBox(origin, target, this.body(friend)) !== null) return false;
    }
    const aim = target.sub(origin); if (!fire) aim.y += 0.5 * lead * lead;
    this.projectile(origin, aim.normalize().multiplyScalar(speed), false, fire ? 4 : 3.5, fire ? '#ffb652' : '#dfd2ad', fire ? 0 : 1, !fire);
    return true;
  }

  private fight(actor: Actor, dt: number) {
    const h = this.host, distance = actor.group.position.distanceTo(h.pos);
    if (passive(actor.kind) || actor.anger <= 0 || h.meta.mode === 'creative') { actor.fuse = Math.max(0, actor.fuse - dt * 2); return; }
    const clear = distance < 25 && this.visible(this.eye(actor), h.pos.clone().add(new THREE.Vector3(0, 1, 0)));
    if (actor.kind === 'creeper') {
      const near = clear && distance < (actor.fuse > 0 ? 3.5 : 2.7);
      if (near && actor.fuse === 0) sfx.fuse(actor.group.position);
      actor.fuse = Math.max(0, actor.fuse + dt * (near ? 1 : -2.8));
      if (actor.fuse > 0) { actor.velocity.x *= 0.65; actor.velocity.z *= 0.65; actor.group.scale.setScalar(1 + Math.sin(actor.fuse * 24) * 0.03 + actor.fuse * 0.05); }
      if (actor.fuse >= 1.8) { const p = actor.group.position.clone(); this.despawn(actor); h.explode(Math.floor(p.x), Math.floor(p.y + 0.5), Math.floor(p.z), true); }
      return;
    }
    if (actor.kind === 'skeleton') {
      if (clear && distance < 24 && actor.attackTime <= 0) {
        actor.aimTime += dt;
        if (actor.aimTime >= 0.85) { if (this.shootAtPlayer(actor, 17)) actor.attackTime = 1.55; actor.aimTime = 0; }
      } else actor.aimTime = Math.max(0, actor.aimTime - dt * 2);
      return;
    }
    if (actor.kind === 'blaze') {
      if (actor.burst > 0) {
        actor.burstTimer -= dt;
        if (actor.burstTimer <= 0) { if (clear) this.shootAtPlayer(actor, 11, true); actor.burst--; actor.burstTimer = 0.32; if (!actor.burst) actor.attackTime = 3; }
      } else if (clear && distance < 23 && actor.attackTime <= 0) {
        actor.aimTime += dt;
        if (actor.aimTime >= 0.85) { actor.burst = 3; actor.burstTimer = 0; actor.aimTime = 0; sfx.mob('blaze', 'idle', actor.group.position); }
      } else actor.aimTime = 0;
      return;
    }
    if (clear && distance < 2.05 && actor.attackTime <= 0) { h.damage(actor.kind === 'shadow' ? 6 : 3, actor.group.position); actor.attackTime = 1.3; }
  }

  private updateDragon(actor: Actor, dt: number) {
    const h = this.host, enraged = actor.health < BOSS_MAX_HP / 2, phase = actor.age % 19;
    const protectedByCrystals = h.adventure.crystals.length < 4;
    const mode = protectedByCrystals ? 'orbit' : phase > 8 && phase < 13 ? 'dive' : phase >= 13 ? 'perch' : 'orbit';
    if (mode !== this.dragonMode) {
      this.dragonMode = mode;
      if (mode === 'dive') { this.dragonDestination.copy(h.pos).add(new THREE.Vector3(0, 2.1, 0)); if (h.vel) this.dragonDestination.addScaledVector(h.vel.clone().setY(0), 0.6); }
    }
    const destination = mode === 'perch' ? new THREE.Vector3(8.5, 35.1, 12.5) : mode === 'dive' ? this.dragonDestination
      : new THREE.Vector3(8.5 + Math.cos(actor.age * 0.26) * 17, 39 + Math.sin(actor.age * 0.7) * 2, 8.5 + Math.sin(actor.age * 0.26) * 17);
    const delta = destination.clone().sub(actor.group.position);
    actor.group.position.addScaledVector(delta, Math.min(1, dt * (mode === 'orbit' ? 0.9 : 1.4)));
    if (delta.length() > 0.3) actor.group.rotation.y = Math.atan2(delta.x, delta.z);
    actor.limbs.forEach((wing, index) => { wing.rotation.z = (index ? 1 : -1) * (0.16 + Math.sin(actor.age * (mode === 'dive' ? 5 : 3)) * (mode === 'perch' ? 0.07 : 0.45)); });
    this.phase = protectedByCrystals ? `Protegido por ${4 - h.adventure.crystals.length} cristais` : mode === 'perch' ? 'Pousado. Aproxime-se e ataque!' : mode === 'dive' ? 'Investida: saia do caminho!' : 'Em voo. Prepare o arco.';
    if (actor.attackTime <= 0) {
      const target = h.pos.clone().add(new THREE.Vector3(0, 1, 0));
      if (mode === 'dive' && target.distanceTo(actor.group.position) < 4) { h.damage(enraged ? 9 : 7, actor.group.position); actor.attackTime = 1.7; }
      else if (mode === 'orbit') {
        const origin = actor.group.position.clone().add(new THREE.Vector3(0, 0.4, 0));
        this.projectile(origin, target.sub(origin).normalize().multiplyScalar(enraged ? 14 : 10), false, enraged ? 7 : 5, '#ce91f2'); actor.attackTime = enraged ? 1.9 : 3;
      }
    }
  }

  update(dt: number) {
    const h = this.host; if (h.dead || h.paused) return;
    this.clock += dt;
    this.pathBudget = Math.min(h.settings.preset === 'ultra' ? 2 : 1, this.pathBudget + dt * (h.settings.preset === 'rapido' ? 4 : 9));
    this.noise = this.noise.filter((n) => this.clock - n.time < 2.5);
    if (h.dimension === 'end' && !this.endReady) {
      this.endReady = true;
      if (!h.adventure.victory) {
        CRYSTAL_POSITIONS.forEach((pos, index) => { if (!h.adventure.crystals.includes(index)) this.createActor('crystal', new THREE.Vector3(...pos as [number, number, number]), index); });
        this.createActor('dragon', new THREE.Vector3(8.5, 39, -4));
      }
    }
    this.spawnTime -= dt;
    if (h.dimension !== 'end' && this.spawnTime <= 0 && h.adventure.elapsed > 8) {
      this.spawnTime = h.dimension === 'nether' ? 8 : Math.sin(h.time * Math.PI * 2) < 0.1 ? 7 : 11;
      if (this.actors.length < h.settings.maxMobs) this.spawnMob();
    }
    for (const actor of [...this.actors]) {
      if (h.dead || h.paused || h.adventure.victory && !h.adventure.victorySeen) break;
      if (actor.health <= 0) continue;
      if (!isBoss(actor.kind) && !passive(actor.kind) && h.settings.difficulty === 'peaceful') { this.despawn(actor); continue; }
      const p = actor.group.position, distance = p.distanceTo(h.pos);
      if (!isBoss(actor.kind) && distance > Math.max(80, h.settings.simulationDistance + 20)) { this.despawn(actor); continue; }
      actor.group.visible = distance < h.settings.renderDistance * 16;
      if (!isBoss(actor.kind) && (distance > h.settings.simulationDistance || h.world.getBlock(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)) === -1)) continue;
      actor.age += dt; actor.attackTime -= dt; actor.flash = Math.max(0, actor.flash - dt);
      actor.anger = Math.max(0, actor.anger - dt); actor.memory = Math.max(0, actor.memory - dt); actor.afraid = Math.max(0, actor.afraid - dt);
      actor.investigate = Math.max(0, actor.investigate - dt); actor.recoverTime = Math.max(0, actor.recoverTime - dt); actor.alarmTime -= dt; actor.teleportTime -= dt;
      actor.group.scale.setScalar(actor.flash > 0 ? 1.02 : 1);
      if (p.y < -8) { this.despawn(actor); continue; }
      actor.soundTimer -= dt;
      if (actor.soundTimer <= 0 && distance < 25 && actor.kind !== 'crystal') { sfx.mob(actor.kind, 'idle', p); actor.soundTimer = 8 + Math.random() * 12; }
      if (actor.kind === 'crystal') { actor.limbs[0].rotation.y += dt; actor.limbs[0].position.y = Math.sin(actor.age * 2) * 0.1; continue; }
      if (actor.kind === 'dragon') { this.updateDragon(actor, dt); continue; }
      actor.sensorTimer -= dt; actor.decisionTimer -= dt;
      if (actor.sensorTimer <= 0) { const interval = distance > 20 ? 0.6 : 0.25 + actor.id % 4 * 0.04; actor.sensorTimer = interval; this.sense(actor, distance, interval); }
      if (actor.decisionTimer <= 0) { actor.decisionTimer = 0.3 + actor.id % 4 * 0.06; this.decide(actor, distance); }
      actor.environmentTimer += dt;
      if (actor.environmentTimer >= 1.5) {
        actor.environmentTimer = 0;
        const block = h.world.getBlock(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z));
        if (actor.exposed) { this.hit(actor, 2); if (!actor.health) continue; }
        if (actor.kind === 'shadow' && (block === B.WATER || h.dimension === 'overworld' && Math.sin(h.time * Math.PI * 2) > 0.3 && this.openSkyAt(p.x, p.y + actor.height, p.z))) {
          this.teleport(actor); if (block === B.WATER) { this.hit(actor, 2); if (!actor.health) continue; }
        }
        if (block === B.LAVA && actor.kind !== 'blaze' || block === B.WATER && actor.kind === 'blaze') { this.hit(actor, 4); if (!actor.health) continue; }
      }
      this.move(actor, dt); this.fight(actor, dt);
    }
    this.updateProjectiles(dt);
  }

  private updateProjectiles(dt: number) {
    const h = this.host;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const shot = this.projectiles[i], from = shot.mesh.position.clone();
      shot.velocity.y -= shot.gravity * dt;
      const move = shot.velocity.clone().multiplyScalar(dt), to = from.clone().add(move);
      shot.life -= dt; let removed = shot.life <= 0, impact = false;
      const wall = firstBlockIntersection(h.world, from, to);
      if (!removed && shot.player && move.lengthSq() > 0) {
        const hit = this.aimedActor(from, move.clone().normalize(), move.length());
        if (hit) {
          if (hit.kind === 'shadow' && hit.teleportTime <= 0 && this.teleport(hit, true)) { hit.anger = 16; hit.lastSeen.copy(h.pos); hit.memory = 10; }
          else { this.hit(hit, shot.damage, true); removed = true; }
        }
      }
      if (!removed && !shot.player && !h.dead && !h.paused) {
        const p = h.pos;
        const playerHit = segmentBox(from, to, [p.x - 0.34, p.y, p.z - 0.34, p.x + 0.34, p.y + 1.8, p.z + 0.34]);
        if (playerHit !== null && (wall === null || playerHit < wall)) { h.damage(shot.damage, from); removed = true; }
      }
      if (!removed && wall !== null) { removed = true; impact = true; }
      if (removed) {
        if (shot.recoveredItem) h.dropLoot(shot.recoveredItem.id, 1, from, shot.recoveredItem);
        if (impact && shot.arrow && shot.player) h.dropLoot(I.ARROW, 1, from);
        h.scene.remove(shot.mesh); this.projectiles.splice(i, 1);
      } else { shot.mesh.position.copy(to); shot.mesh.lookAt(to.clone().add(shot.velocity)); }
    }
  }

  recoverThrownItems() {
    this.projectiles.forEach((shot) => { if (shot.recoveredItem) { this.host.dropLoot(shot.recoveredItem.id, 1, shot.mesh.position.clone(), shot.recoveredItem); shot.recoveredItem = undefined; } });
  }
  serializeFlyingItems(): SavedDrop[] {
    return this.projectiles.flatMap((shot) => shot.recoveredItem ? [{ slot: { ...shot.recoveredItem }, position: shot.mesh.position.toArray() as [number, number, number], velocity: shot.velocity.toArray() as [number, number, number], dimension: this.host.dimension, age: 0, delay: 0.5 }] : []);
  }
  serialize(): SavedMob[] {
    return this.actors.filter((actor) => !isBoss(actor.kind) && actor.health > 0).map((actor) => ({ kind: actor.kind as SavedMob['kind'], position: actor.group.position.toArray() as [number, number, number], health: actor.health, yaw: actor.group.rotation.y, age: actor.age }));
  }
  restore(saved: SavedMob[] = []) {
    if (!Array.isArray(saved)) return;
    for (const mob of saved.slice(0, 24)) {
      if (!mob || !attributes[mob.kind] || isBoss(mob.kind) || !Array.isArray(mob.position) || mob.position.length !== 3 || !mob.position.every((n) => Number.isFinite(n) && Math.abs(n) < 1e7) || !Number.isFinite(mob.health) || mob.health <= 0) continue;
      const actor = this.createActor(mob.kind, new THREE.Vector3(...mob.position));
      actor.health = Math.min(actor.maxHealth, mob.health); actor.group.rotation.y = Number.isFinite(mob.yaw) ? mob.yaw : 0; actor.age = Number.isFinite(mob.age) ? Math.max(0, mob.age) : 0;
    }
  }
  reset() { this.actors.forEach((a) => this.host.scene.remove(a.group)); this.projectiles.forEach((p) => this.host.scene.remove(p.mesh)); this.actors = []; this.projectiles = []; this.noise = []; this.endReady = false; this.spawnTime = 5; this.phase = ''; }
  get count() { return this.actors.length; }
  dispose() { this.reset(); this.models.dispose(); this.box.dispose(); this.mats.forEach((mat) => mat.dispose()); }
}