import type * as THREE from 'three';
import { Noise, hash3, mulberry32 } from './noise';
import { B, DEEP_VARIANTS, isPlaceable, WOODS, LEAF_IDS, PLANT_IDS, SOIL_IDS, type WoodKind } from './blocks';
import { BIOME_BY_ID, selectBiome, treeBlocks, type BiomeId } from './biomes';
import type { Dimension, WorldType } from './settings';

export const CS = 16;
export const CH = 112;
export const SEA = 30;

export const idx = (x: number, y: number, z: number) => x + z * CS + y * CS * CS;

export class Chunk {
  data = new Uint8Array(CS * CS * CH);
  maxY = 0;
  dirty = true;
  meshed = false;
  opaque: THREE.Mesh | null = null;
  water: THREE.Mesh | null = null;
  constructor(public cx: number, public cz: number) {}
}

export class World {
  revision = 0;
  chunks = new Map<string, Chunk>();
  mods = new Map<string, Map<number, number>>();
  private n1: Noise;
  private n2: Noise;
  private n3: Noise;
  private n4: Noise;
  private moistureNoise: Noise;
  private variationNoise: Noise;
  private spawnPoint?: [number, number];
  private states = new Map<string, number>();

  constructor(public seed: number, public type: WorldType, mods?: Record<string, number[]>, public dimension: Dimension = 'overworld', public generatorVersion = 2, states?: Record<string, number>) {
    this.n1 = new Noise(seed);
    this.n2 = new Noise(seed + 101);
    this.n3 = new Noise(seed + 202);
    this.n4 = new Noise(seed + 303);
    this.moistureNoise = new Noise(seed + 404);
    this.variationNoise = new Noise(seed + 505);
    if (states) Object.entries(states).forEach(([key, value]) => {
      if (/^-?\d+,\d+,-?\d+$/.test(key) && Number.isInteger(value) && value >= 0 && value < 8) this.states.set(key, value);
    });
    if (mods) {
      for (const k of Object.keys(mods)) {
        const arr = mods[k];
        const m = new Map<number, number>();
        if (!Array.isArray(arr)) continue;
        for (let i = 0; i < arr.length; i += 2) if (Number.isInteger(arr[i]) && arr[i] >= 0 && arr[i] < CS * CS * CH && (arr[i + 1] === 0 || isPlaceable(arr[i + 1]))) m.set(arr[i], arr[i + 1]);
        this.mods.set(k, m);
      }
    }
  }

  static key(cx: number, cz: number) {
    return cx + ',' + cz;
  }

  getChunk(cx: number, cz: number) {
    return this.chunks.get(World.key(cx, cz));
  }

  /** returns -1 when chunk is not loaded */
  getBlock(x: number, y: number, z: number): number {
    if (y < 0) return this.dimension === 'end' ? B.AIR : B.BEDROCK;
    if (y >= CH) return 0;
    const cx = Math.floor(x / CS), cz = Math.floor(z / CS);
    const c = this.chunks.get(cx + ',' + cz);
    if (!c) return -1;
    return c.data[idx(x - cx * CS, y, z - cz * CS)];
  }

  setBlock(x: number, y: number, z: number, id: number, state = 0) {
    if (y < 0 || y >= CH || ![x, y, z].every(Number.isInteger) || (id !== 0 && !isPlaceable(id))) return;
    const cx = Math.floor(x / CS), cz = Math.floor(z / CS);
    const key = cx + ',' + cz;
    const c = this.chunks.get(key);
    if (!c) return;
    const lx = x - cx * CS, lz = z - cz * CS;
    const i = idx(lx, y, lz);
    c.data[i] = id;
    this.revision++;
    const stateKey = `${x},${y},${z}`;
    if (state) this.states.set(stateKey, state & 7); else this.states.delete(stateKey);
    let m = this.mods.get(key);
    if (!m) {
      m = new Map();
      this.mods.set(key, m);
    }
    m.set(i, id);
    if (id !== 0) c.maxY = Math.max(c.maxY, y + 1);
    c.dirty = true;
    const mark = (dx: number, dz: number) => {
      const n = this.chunks.get(cx + dx + ',' + (cz + dz));
      if (n) n.dirty = true;
    };
    if (lx === 0) mark(-1, 0);
    if (lx === CS - 1) mark(1, 0);
    if (lz === 0) mark(0, -1);
    if (lz === CS - 1) mark(0, 1);
    if (lx === 0 && lz === 0) mark(-1, -1);
    if (lx === CS - 1 && lz === 0) mark(1, -1);
    if (lx === 0 && lz === CS - 1) mark(-1, 1);
    if (lx === CS - 1 && lz === CS - 1) mark(1, 1);
  }

  getState(x: number, y: number, z: number) { return this.states.get(`${x},${y},${z}`) ?? 0; }
  serializeStates() { return Object.fromEntries(this.states); }

  serializeMods(): Record<string, number[]> {
    const out: Record<string, number[]> = {};
    this.mods.forEach((m, k) => {
      const arr: number[] = [];
      m.forEach((v, i) => arr.push(i, v));
      if (arr.length) out[k] = arr;
    });
    return out;
  }

  heightAt(x: number, z: number): number {
    const n1 = this.n1, n2 = this.n2;
    if (this.dimension === 'end') return Math.hypot(x - 8, z - 8) <= 44 ? 32 : -1;
    if (this.dimension === 'nether') return Math.hypot(x - 8, z - 8) < 14 ? 32 : Math.floor(32 + n1.noise2(x * 0.035, z * 0.035) * 7);
    let h: number;
    switch (this.type) {
      case 'plano':
        return 36;
      case 'ilhas': {
        const i = n1.noise2(x * 0.007, z * 0.007) + n2.noise2(x * 0.02, z * 0.02) * 0.3;
        h = SEA - 12 + Math.max(0, i + 0.25) * 34 + n1.noise2(x * 0.05, z * 0.05) * 2;
        const m = n2.noise2(x * 0.01 + 50, z * 0.01);
        if (i > 0.3 && m > 0.3) h += (m - 0.3) * 40;
        break;
      }
      case 'montanhas': {
        const cont = n1.noise2(x * 0.002, z * 0.002);
        h = SEA + 6 + cont * 16 + n1.noise2(x * 0.012, z * 0.012) * 10 + n1.noise2(x * 0.05, z * 0.05) * 2.5;
        const m = n2.noise2(x * 0.005, z * 0.005);
        if (m > 0) h += Math.pow(m, 1.3) * 75;
        break;
      }
      default: {
        const cont = n1.noise2(x * 0.0025, z * 0.0025);
        h = SEA + 2 + cont * 14 + n1.noise2(x * 0.012, z * 0.012) * 7 + n1.noise2(x * 0.05, z * 0.05) * 2;
        const m = n2.noise2(x * 0.006, z * 0.006);
        if (m > 0.2) h += Math.pow(m - 0.2, 1.4) * 50;
      }
    }
    return Math.floor(Math.max(3, Math.min(CH - 14, h)));
  }

  temperature(x: number, z: number) {
    return this.n3.noise2(x * 0.004, z * 0.004);
  }

  biomeAt(x: number, z: number, h = this.heightAt(x, z), temperature = this.temperature(x, z)): BiomeId {
    if (this.type === 'plano') return 'plains';
    if (this.generatorVersion < 2) return h < SEA ? 'ocean' : temperature > 0.38 ? 'desert' : temperature < -0.42 || h > 78 ? 'tundra' : 'forest';
    return selectBiome(h, temperature, this.moistureNoise.noise2(x * 0.005, z * 0.005), this.variationNoise.noise2(x * 0.007, z * 0.007));
  }

  generate(cx: number, cz: number): Chunk {
    const existing = this.getChunk(cx, cz);
    if (existing) return existing;
    if (this.dimension !== 'overworld') return this.generateRealm(cx, cz);
    const c = new Chunk(cx, cz);
    const d = c.data;
    const seed = this.seed;
    const heights = new Int16Array(CS * CS);
    const biome = new Uint8Array(CS * CS); // 0 plains 1 desert 2 snow
    let maxY = 0;
    const flat = this.type === 'plano';

    for (let z = 0; z < CS; z++)
      for (let x = 0; x < CS; x++) {
        const wx = cx * CS + x, wz = cz * CS + z;
        const h = this.heightAt(wx, wz);
        heights[x + z * CS] = h;
        const t = flat ? 0 : this.temperature(wx, wz);
        const region = this.generatorVersion >= 2 ? this.biomeAt(wx, wz, h, t) : null;
        const desert = region ? region === 'desert' || region === 'badlands' : t > 0.38;
        const snowy = region ? region === 'tundra' || region === 'mountains' && h > 80 : t < -0.42 || h > 78;
        biome[x + z * CS] = desert ? 1 : snowy ? 2 : 0;
        const beach = h <= SEA + 1 && !snowy;
        const underwater = h < SEA;
        const rocky = h > 70 && !snowy;
        const gravelBed = this.n4.noise2(wx * 0.05, wz * 0.05) > 0.3;
        const top = Math.max(h, SEA);
        for (let y = 0; y <= top; y++) {
          let id = 0;
          if (y === 0 || (y <= 2 && hash3(wx, y, wz, seed) < 0.5)) id = B.BEDROCK;
          else if (y < h - 3) {
            id = y < 12 ? B.DEEPSLATE : B.STONE;
            const r = hash3(Math.floor(wx / 2), Math.floor(y / 2), Math.floor(wz / 2), seed + 9);
            if (r < 0.10 && y < 90) id = B.COAL;
            else if (r < 0.17 && r >= 0.10 && y < 60) id = B.IRON;
            else if (r < 0.23 && r >= 0.17 && y < 64) id = B.COPPER;
            else if (r < 0.255 && r >= 0.23 && y < 32) id = B.GOLD;
            else if (r < 0.285 && r >= 0.255 && y < 24) id = B.REDSTONE;
            else if (r < 0.310 && r >= 0.285 && y < 32) id = B.LAPIS;
            else if (r < 0.328 && r >= 0.310 && y < 18) id = B.DIAMOND;
            else if (r < 0.342 && r >= 0.328 && y < 50) id = B.EMERALD;
            else if (r < 0.352 && r >= 0.342 && y < 26) id = B.AMETHYST;
            else if (r < 0.375 && r >= 0.352 && y < 9) id = B.OBSIDIAN;
            else if (r < 0.39 && r >= 0.375) id = B.GRAVEL;
            if (y < 12 && DEEP_VARIANTS[id]) id = DEEP_VARIANTS[id];
          } else if (y < h) {
            if ((desert || beach) && y >= h - 2) id = B.SANDSTONE;
            else id = desert || beach ? B.SAND : rocky ? B.STONE : underwater && gravelBed ? B.GRAVEL : B.DIRT;
          } else if (y === h) {
            if (underwater) id = gravelBed ? B.GRAVEL : B.SAND;
            else if (desert || beach) id = B.SAND;
            else if (snowy) id = B.SNOW;
            else if (rocky) id = h > 76 ? B.STONE : B.GRASS;
            else id = B.GRASS;
            if (region && !underwater) id = snowy ? B.SNOW : BIOME_BY_ID[region].surface;
          } else if (y <= SEA) {
            id = snowy && y === SEA ? B.ICE : B.WATER;
          }
          if (region === 'badlands' && y > h - 8 && y < h) id = y % 5 < 2 ? B.RED_TERRACOTTA : B.TERRACOTTA;
          if (region === 'swamp' && y >= h - 2 && y <= h) id = B.MUD;
          if (region === 'swamp' && y === h && this.n4.noise2(wx * 0.11, wz * 0.11) > 0.4) id = B.WATER;
          // caves
          if (!flat && id !== 0 && id !== B.BEDROCK && id !== B.WATER && id !== B.ICE && y <= h && y > 3) {
            const safe = underwater ? y < h - 5 : true;
            if (safe) {
              const n = this.n4.noise3(wx * 0.045, y * 0.075, wz * 0.045);
              if (n > 0.58) id = 0;
            }
          }
          if (id !== 0) {
            d[idx(x, y, z)] = id;
            if (y + 1 > maxY) maxY = y + 1;
          }
        }
        if (region === 'swamp' && d[idx(x, h, z)] === B.WATER && hash3(wx, h, wz, this.seed + 933) < 0.09) {
          d[idx(x, h + 1, z)] = B.LILY; maxY = Math.max(maxY, h + 2);
        }
      }

    // decorations
    if (this.generatorVersion < 2) {
      const rand = mulberry32((cx * 73856093) ^ (cz * 19349663) ^ seed);
      const forest = this.n3.noise2(cx * 0.15 + 300, cz * 0.15);
      const attempts = flat ? 2 : forest > 0.2 ? 9 : forest > -0.3 ? 3 : 1;
      for (let a = 0; a < attempts; a++) {
        const x = 2 + Math.floor(rand() * 12), z = 2 + Math.floor(rand() * 12);
        const h = heights[x + z * CS];
        const surf = d[idx(x, h, z)];
        if (h <= SEA || h > CH - 12) continue;
        if (surf === B.GRASS || surf === B.SNOW) {
          const birch = biome[x + z * CS] === 2 || rand() < 0.2;
          const log = birch ? B.BIRCH_LOG : B.LOG;
          const leaf = birch ? B.BIRCH_LEAVES : B.LEAVES;
          const th = 4 + Math.floor(rand() * 3);
          const topY = h + th;
          for (let ly = topY - 2; ly <= topY + 1; ly++) {
            const r = ly <= topY - 1 ? 2 : 1;
            for (let dz = -r; dz <= r; dz++)
              for (let dx = -r; dx <= r; dx++) {
                if (Math.abs(dx) === r && Math.abs(dz) === r && (ly > topY - 1 || rand() < 0.5)) continue;
                const i = idx(x + dx, ly, z + dz);
                if (d[i] === 0) d[i] = leaf;
              }
          }
          for (let y = h + 1; y <= topY; y++) d[idx(x, y, z)] = log;
          d[idx(x, h, z)] = B.DIRT;
          maxY = Math.max(maxY, topY + 2);
        } else if (surf === B.SAND && biome[x + z * CS] === 1 && rand() < 0.6) {
          const ch = 1 + Math.floor(rand() * 3);
          for (let y = h + 1; y <= h + ch; y++) d[idx(x, y, z)] = B.CACTUS;
          maxY = Math.max(maxY, h + ch + 1);
        }
      }
      if (rand() < 0.04) {
        const x = Math.floor(rand() * CS), z = Math.floor(rand() * CS);
        const h = heights[x + z * CS];
        if (d[idx(x, h, z)] === B.GRASS && h < CH - 2 && d[idx(x, h + 1, z)] === 0) d[idx(x, h + 1, z)] = B.PUMPKIN;
      }
      // flores e grama alta sobre a grama
      for (let f = 0; f < 5; f++) {
        const x = Math.floor(rand() * CS), z = Math.floor(rand() * CS);
        const h = heights[x + z * CS];
        if (h <= SEA || h > CH - 2) continue;
        if (d[idx(x, h, z)] === B.GRASS && d[idx(x, h + 1, z)] === 0) {
          const r = rand();
          d[idx(x, h + 1, z)] = r < 0.22 ? B.FLOWER_RED : r < 0.44 ? B.FLOWER_YELLOW : B.TALLGRASS;
        }
      }
    }

    if (this.generatorVersion >= 2) maxY = Math.max(maxY, this.decorateBiomes(c));
    const [spawnX, spawnZ] = this.findSpawn();
    const treeX = Math.floor(spawnX) + 5, treeZ = Math.floor(spawnZ) + 2;
    const treeY = this.heightAt(treeX, treeZ);
    const put = (wx: number, y: number, wz: number, id: number) => {
      const x = wx - cx * CS, z = wz - cz * CS;
      if (x < 0 || z < 0 || x >= CS || z >= CS || y < 0 || y >= CH) return;
      d[idx(x, y, z)] = id;
      maxY = Math.max(maxY, y + 1);
    };
    if (Math.abs(cx * CS - treeX) < 20 && Math.abs(cz * CS - treeZ) < 20) {
      for (let y = treeY + 3; y <= treeY + 6; y++) for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        if (Math.abs(dx) + Math.abs(dz) <= 3) put(treeX + dx, y, treeZ + dz, B.LEAVES);
      }
      for (let y = treeY + 1; y <= treeY + 5; y++) put(treeX, y, treeZ, B.LOG);
    }

    const m = this.mods.get(World.key(cx, cz));
    if (m) {
      m.forEach((id, i) => {
        d[i] = id;
        const y = Math.floor(i / (CS * CS));
        if (id !== 0 && y + 1 > maxY) maxY = y + 1;
      });
    }
    c.maxY = Math.min(CH, maxY + 1);
    this.chunks.set(World.key(cx, cz), c);
    return c;
  }

  findSpawn(): [number, number] {
    if (this.spawnPoint) return this.spawnPoint;
    if (this.dimension !== 'overworld') return [8.5, 14.5];
    for (let r = 0; r < 400; r += 8) {
      for (let a = 0; a < 8; a++) {
        const x = Math.round(Math.cos((a / 8) * Math.PI * 2) * r) + 8;
        const z = Math.round(Math.sin((a / 8) * Math.PI * 2) * r) + 8;
        if (this.type === 'plano' || this.heightAt(x, z) > SEA + 1) {
          this.spawnPoint = [x + 0.5, z + 0.5];
          return this.spawnPoint;
        }
        if (r === 0) break;
      }
    }
    return [8.5, 8.5];
  }

  private decorateBiomes(chunk: Chunk) {
    const startX = chunk.cx * CS, startZ = chunk.cz * CS;
    let maxY = 0;
    const put = (wx: number, y: number, wz: number, id: number) => {
      const x = wx - startX, z = wz - startZ;
      if (x < 0 || z < 0 || x >= CS || z >= CS || y < 1 || y >= CH) return;
      const index = idx(x, y, z), existing = chunk.data[index];
      if (existing !== 0 && !LEAF_IDS.has(existing) && !PLANT_IDS.has(existing)) return;
      chunk.data[index] = id; maxY = Math.max(maxY, y + 1);
    };
    const [sx, sz] = this.findSpawn();
    // Evaluate anchors beyond chunk borders: crowns remain whole regardless of load order.
    for (let gz = Math.floor((startZ - 6) / 8); gz <= Math.floor((startZ + CS + 5) / 8); gz++) {
      for (let gx = Math.floor((startX - 6) / 8); gx <= Math.floor((startX + CS + 5) / 8); gx++) {
        const x = gx * 8 + 2 + Math.floor(hash3(gx, 3, gz, this.seed + 808) * 4);
        const z = gz * 8 + 2 + Math.floor(hash3(gx, 7, gz, this.seed + 808) * 4);
        const h = this.heightAt(x, z), biome = BIOME_BY_ID[this.biomeAt(x, z, h)];
        if (h <= SEA || h > CH - 17 || Math.hypot(x - sx, z - sz) < 7) continue;
        if (!biome.tree || hash3(gx, 11, gz, this.seed + 808) > biome.density) continue;
        let wood = biome.tree;
        if (wood === 'oak' && hash3(gx, 12, gz, this.seed) > 0.83) wood = 'birch';
        treeBlocks(wood, x, h, z, this.seed).forEach(([px, py, pz, id]) => put(px, py, pz, id));
      }
    }
    const random = mulberry32((chunk.cx * 73856093) ^ (chunk.cz * 19349663) ^ this.seed ^ 671);
    for (let i = 0; i < 13; i++) {
      const x = Math.floor(random() * CS), z = Math.floor(random() * CS);
      const wx = startX + x, wz = startZ + z, h = this.heightAt(wx, wz);
      const region = this.biomeAt(wx, wz, h), ground = chunk.data[idx(x, h, z)];
      if (h < SEA || h >= CH - 5 || chunk.data[idx(x, h + 1, z)] !== 0) continue;
      let id: number = B.TALLGRASS;
      if (region === 'desert' || region === 'badlands') {
        if (i > 2) continue;
        for (let y = 1; y <= 2 + Math.floor(random() * 2); y++) put(wx, h + y, wz, B.CACTUS);
        continue;
      }
      if (region === 'beach' || region === 'swamp' || region === 'jungle') {
        const waterNear = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dz]) => this.heightAt(wx + dx, wz + dz) < SEA);
        if (waterNear) { for (let y = 1; y <= 3; y++) put(wx, h + y, wz, B.SUGAR_CANE); continue; }
      }
      if (!SOIL_IDS.has(ground)) continue;
      if (region === 'taiga') id = i < 4 ? B.BERRY_BUSH : i < 7 ? B.MUSHROOM_BROWN : B.TALLGRASS;
      else if (region === 'jungle') id = i < 3 ? B.MELON : B.TALLGRASS;
      else if (region === 'swamp' || region === 'dark_forest') id = i % 2 ? B.MUSHROOM_RED : B.MUSHROOM_BROWN;
      else if (region === 'cherry') id = i < 8 ? B.CHERRY_FLOWER : B.TALLGRASS;
      else if (region === 'tundra' || region === 'mountains') continue;
      else if ((region === 'plains' || region === 'forest') && i === 0 && random() < 0.16) id = B.PUMPKIN;
      else id = i < 2 ? B.FLOWER_RED : i < 4 ? B.FLOWER_YELLOW : B.TALLGRASS;
      put(wx, h + 1, wz, id);
    }
    // A renewable food source near the initial clearing avoids a hunger soft-lock.
    const bx = Math.floor(sx) + 3, bz = Math.floor(sz) - 3, by = this.heightAt(bx, bz);
    if (by > SEA) put(bx, by + 1, bz, B.BERRY_BUSH);
    return maxY;
  }

  growTree(kind: WoodKind, x: number, y: number, z: number) {
    const wood = WOODS.find((w) => w.key === kind)!;
    if (!SOIL_IDS.has(this.getBlock(x, y - 1, z))) return false;
    const blocks = treeBlocks(kind, x, y - 1, z, this.seed);
    if (blocks.some(([px, py, pz]) => {
      if (py >= CH) return true;
      const id = this.getBlock(px, py, pz);
      return id !== 0 && id !== wood.sapling && !LEAF_IDS.has(id) && !PLANT_IDS.has(id);
    })) return false;
    blocks.forEach(([px, py, pz, id]) => this.setBlock(px, py, pz, id));
    return true;
  }

  private generateRealm(cx: number, cz: number) {
    const c = new Chunk(cx, cz);
    for (let z = 0; z < CS; z++) for (let x = 0; x < CS; x++) {
      const wx = cx * CS + x, wz = cz * CS + z;
      const h = this.heightAt(wx, wz);
      if (this.dimension === 'end') {
        if (h < 0) continue;
        for (let y = 24; y <= h; y++) c.data[idx(x, y, z)] = B.END_STONE;
        const towers = [[24, 8], [-8, 8], [8, 24], [8, -8]];
        for (const [tx, tz] of towers) if (Math.abs(wx - tx) <= 1 && Math.abs(wz - tz) <= 1) {
          for (let y = 33; y <= 34; y++) c.data[idx(x, y, z)] = B.OBSIDIAN;
        }
        if (wx >= 6 && wx <= 10 && wz >= 3 && wz <= 7) {
          c.data[idx(x, 32, z)] = B.BEDROCK;
          if (wx === 6 || wx === 10 || wz === 3 || wz === 7) c.data[idx(x, 33, z)] = B.BEDROCK;
          else c.data[idx(x, 33, z)] = B.END_SURFACE;
        }
        c.maxY = 37;
      } else {
        for (let y = 0; y <= h; y++) {
          let id: number = y === 0 ? B.BEDROCK : B.NETHERRACK;
          const r = hash3(Math.floor(wx / 2), Math.floor(y / 2), Math.floor(wz / 2), this.seed + 877);
          if (y > 2 && r < 0.12) id = B.QUARTZ_ORE;
          else if (y > 2 && r < 0.18) id = B.NETHER_GOLD;
          else if (y > 3 && y < 18 && r > 0.96) id = B.ANCIENT_DEBRIS;
          if (y === h && Math.hypot(wx - 8, wz - 8) > 18 && this.n4.noise2(wx * 0.06, wz * 0.06) > 0.62) id = B.LAVA;
          c.data[idx(x, y, z)] = id;
        }
        if (wz === 5 && wx >= 6 && wx <= 9) for (let y = 32; y <= 36; y++) {
          if (wx === 6 || wx === 9 || y === 32 || y === 36) c.data[idx(x, y, z)] = B.OBSIDIAN;
          else c.data[idx(x, y, z)] = B.NETHER_PORTAL_X;
        }
        c.maxY = Math.max(c.maxY, h + 2, 39);
      }
    }
    this.mods.get(World.key(cx, cz))?.forEach((id, i) => {
      c.data[i] = id;
      if (id) c.maxY = Math.max(c.maxY, Math.floor(i / (CS * CS)) + 2);
    });
    this.chunks.set(World.key(cx, cz), c);
    return c;
  }
}
