export interface HungerState { food: number; saturation: number; exhaustion: number }
const finite = (value: number | undefined, fallback: number, maximum: number) => Number.isFinite(value) ? Math.max(0, Math.min(maximum, value!)) : fallback;
export const freshHunger = (): HungerState => ({ food: 20, saturation: 5, exhaustion: 0 });

export function normalizeHunger(state?: Partial<HungerState>): HungerState {
  const food = finite(state?.food, 20, 20);
  return { food, saturation: Math.min(food, finite(state?.saturation, 5, 20)), exhaustion: finite(state?.exhaustion, 0, 4) };
}

export function exhaust(state: HungerState, amount: number) {
  if (!Number.isFinite(amount) || amount <= 0) return;
  state.exhaustion += amount;
  const units = Math.floor(state.exhaustion / 4);
  if (!units) return;
  state.exhaustion -= units * 4;
  const saturationUnits = Math.min(units, Math.ceil(state.saturation));
  state.saturation = Math.max(0, state.saturation - saturationUnits);
  state.food = Math.max(0, state.food - (units - saturationUnits));
}

export function feed(state: HungerState, food: number, saturation: number) {
  if (!Number.isFinite(food) || food < 0 || !Number.isFinite(saturation) || saturation < 0) return;
  state.food = Math.min(20, state.food + food);
  state.saturation = Math.min(state.food, state.saturation + saturation);
}

export function starvationFloor(difficulty: string) {
  return difficulty === 'peaceful' ? 20 : difficulty === 'easy' ? 10 : difficulty === 'normal' ? 1 : 0;
}