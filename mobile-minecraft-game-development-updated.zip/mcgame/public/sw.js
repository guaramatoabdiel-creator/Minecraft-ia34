const CACHE = 'mineblock-explorer-v41';
const CORE = ['./', './index.html', './manifest.webmanifest', './images/menu-bg.jpg', './icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()).catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => k.startsWith('mineblock-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.pathname.startsWith('/src/') || url.pathname.startsWith('/@')) return;
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((cache) => cache.put(e.request, copy)); }
      return res;
    }).catch(async () => (await caches.match(e.request)) || (await caches.match('./index.html')) || Response.error()));
    return;
  }
  e.respondWith(
    caches.match(e.request).then(
      (hit) =>
        hit ||
        fetch(e.request).then((res) => {
          const copy = res.clone();
          if (res.ok || res.type === 'opaque') caches.open(CACHE).then((c) => c.put(e.request, copy));
          return res;
        }).catch(() => Response.error())
    )
  );
});
