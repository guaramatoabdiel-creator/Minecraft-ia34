import { TILES, BLOCKS, B, PLANT_IDS, type TileName } from './blocks';
import { classicTile } from './classicTextures';
import { natureTile } from './natureTextures';
import { detailedItemCanvas } from './itemArt';
import { blockBounds } from './collision';

const FLAT_ICONS: Set<number> = new Set([B.TORCH, B.LILY, ...PLANT_IDS]);
import { mulberry32 } from './noise';

export type TexturePack = 'retro' | 'classico' | 'hd' | 'realista';

export const PACKS: Record<TexturePack, { label: string; size: number; smooth: boolean; desc: string }> = {
  retro: { label: 'Retrô 8x', size: 8, smooth: false, desc: 'Pixels grandes, máximo desempenho' },
  classico: { label: 'Clássico 16x', size: 16, smooth: false, desc: 'Pixel art redesenhada, leve e familiar' },
  hd: { label: 'Detalhado 32x', size: 32, smooth: true, desc: 'O mesmo estilo, com detalhes mais finos' },
  realista: { label: 'Detalhado 64x', size: 64, smooth: true, desc: 'Mais definição. Recomendado para aparelhos fortes' },
};

export const ATLAS_COLS = 8;
export const ATLAS_ROWS = 32;

type RGB = [number, number, number];

interface Ctx {
  S: number;
  img: ImageData;
  rnd: () => number;
  vary: (u: number, v: number, amp: number) => number;
  smoothN: (u: number, v: number, freq: number) => number;
  set: (x: number, y: number, c: RGB, f?: number, a?: number) => void;
  get: (x: number, y: number) => [number, number, number, number];
}

function makeCtx(S: number, seed: number, smooth: boolean): Ctx {
  const img = new ImageData(S, S);
  const rnd = mulberry32(seed);
  const grids: Record<number, Float32Array> = {};
  const grid = (freq: number) => {
    if (!grids[freq]) {
      const g = new Float32Array(freq * freq);
      for (let i = 0; i < g.length; i++) g[i] = rnd();
      grids[freq] = g;
    }
    return grids[freq];
  };
  const smoothN = (u: number, v: number, freq: number) => {
    const g = grid(freq);
    const x = u * freq, y = v * freq;
    const x0 = Math.floor(x), y0 = Math.floor(y);
    const fx = x - x0, fy = y - y0;
    const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const i = (a: number, b: number) => g[(((b % freq) + freq) % freq) * freq + (((a % freq) + freq) % freq)];
    const a = i(x0, y0) + (i(x0 + 1, y0) - i(x0, y0)) * sx;
    const b = i(x0, y0 + 1) + (i(x0 + 1, y0 + 1) - i(x0, y0 + 1)) * sx;
    return a + (b - a) * sy;
  };
  const vary = (u: number, v: number, amp: number) => {
    if (smooth) {
      const f = smoothN(u, v, 4) * 0.5 + smoothN(u, v, 8) * 0.3 + smoothN(u, v, 16) * 0.2;
      return ((f - 0.5) * 1.6 + (rnd() - 0.5) * 0.9) * amp;
    }
    return (rnd() - 0.5) * 2 * amp;
  };
  const set = (x: number, y: number, c: RGB, f = 0, a = 255) => {
    if (x < 0 || y < 0 || x >= S || y >= S) return;
    const i = (y * S + x) * 4;
    const m = 1 + f;
    img.data[i] = Math.max(0, Math.min(255, c[0] * m));
    img.data[i + 1] = Math.max(0, Math.min(255, c[1] * m));
    img.data[i + 2] = Math.max(0, Math.min(255, c[2] * m));
    img.data[i + 3] = a;
  };
  const get = (x: number, y: number): [number, number, number, number] => {
    const i = (y * S + x) * 4;
    return [img.data[i], img.data[i + 1], img.data[i + 2], img.data[i + 3]];
  };
  return { S, img, rnd, vary, smoothN, set, get };
}

function fill(c: Ctx, col: RGB, amp: number, alpha = 255) {
  const S = c.S;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) c.set(x, y, col, c.vary(x / S, y / S, amp), alpha);
}

function speckle(c: Ctx, col: RGB, chance: number, amp = 0.1) {
  const S = c.S;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) if (c.rnd() < chance) c.set(x, y, col, c.vary(x / S, y / S, amp));
}

const DIRT: RGB = [134, 96, 67];
const GRASS: RGB = [98, 162, 56];
const STONE: RGB = [126, 126, 126];

function dirt(c: Ctx) {
  fill(c, DIRT, 0.16);
  speckle(c, [105, 75, 52], 0.12);
  speckle(c, [160, 120, 90], 0.05);
}

function stone(c: Ctx) {
  const S = c.S;
  fill(c, STONE, 0.1);
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const n = c.smoothN(x / S, y / S * 0.5, 8);
      if (n > 0.72) c.set(x, y, [100, 100, 100], c.vary(x / S, y / S, 0.05));
      else if (c.rnd() < 0.05) c.set(x, y, [145, 145, 145]);
    }
}

function sideStrip(c: Ctx, top: RGB, base: (c: Ctx) => void) {
  base(c);
  const S = c.S;
  let depth = S * 0.22;
  for (let x = 0; x < S; x++) {
    depth = Math.max(S * 0.12, Math.min(S * 0.38, depth + (c.rnd() - 0.5) * S * 0.18));
    for (let y = 0; y < depth; y++) c.set(x, y, top, c.vary(x / S, y / S, 0.14) - (y / depth) * 0.1);
  }
}

function voronoi(c: Ctx, n: number, cb: (x: number, y: number, edge: boolean, cell: number, d: number) => void) {
  const S = c.S;
  const pts: [number, number][] = [];
  for (let i = 0; i < n; i++) pts.push([c.rnd(), c.rnd()]);
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const u = (x + 0.5) / S, v = (y + 0.5) / S;
      let d1 = 9, d2 = 9, cell = 0;
      for (let i = 0; i < n; i++) {
        let dx = Math.abs(u - pts[i][0]);
        let dy = Math.abs(v - pts[i][1]);
        if (dx > 0.5) dx = 1 - dx;
        if (dy > 0.5) dy = 1 - dy;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < d1) {
          d2 = d1;
          d1 = d;
          cell = i;
        } else if (d < d2) d2 = d;
      }
      cb(x, y, d2 - d1 < 1.4 / S + 0.02, cell, d1);
    }
}

function cobble(c: Ctx, moss = false) {
  const bright: number[] = [];
  for (let i = 0; i < 12; i++) bright.push((c.rnd() - 0.5) * 0.3);
  voronoi(c, 9, (x, y, edge, cell, d) => {
    const S = c.S;
    if (edge) c.set(x, y, [78, 78, 78], c.vary(x / S, y / S, 0.08));
    else c.set(x, y, [132, 132, 132], bright[cell] - d * 0.6 + c.vary(x / S, y / S, 0.08));
    if (moss && c.smoothN(x / S, y / S, 4) > 0.55 && c.rnd() < 0.85) c.set(x, y, [80, 128, 50], c.vary(x / S, y / S, 0.2));
  });
}

function ore(c: Ctx, col: RGB) {
  stone(c);
  const S = c.S;
  const n = 4 + Math.floor(c.rnd() * 3);
  for (let k = 0; k < n; k++) {
    const cx = 0.15 + c.rnd() * 0.7, cy = 0.15 + c.rnd() * 0.7;
    const r = 0.07 + c.rnd() * 0.05;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const dx = (x + 0.5) / S - cx, dy = (y + 0.5) / S - cy;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < r + 0.5 / S) c.set(x, y, col, (dy < 0 ? 0.2 : -0.15) + c.vary(x / S, y / S, 0.1));
      }
  }
}

function logTop(c: Ctx, bark: RGB, inner: RGB) {
  const S = c.S;
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const dx = (x + 0.5) / S - 0.5, dy = (y + 0.5) / S - 0.5;
      const d = Math.max(Math.abs(dx), Math.abs(dy)) * 0.6 + Math.sqrt(dx * dx + dy * dy) * 0.4;
      if (x === 0 || y === 0 || x === S - 1 || y === S - 1 || d > 0.46) c.set(x, y, bark, c.vary(x / S, y / S, 0.12));
      else {
        const ring = Math.sin(d * Math.PI * 2 * 4.5) * 0.08;
        c.set(x, y, inner, ring + c.vary(x / S, y / S, 0.05));
      }
    }
}

function wool(c: Ctx, col: RGB) {
  const S = c.S;
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const p = ((x + y) % 4 === 0 ? -0.06 : 0) + ((x - y + S) % 4 === 0 ? -0.04 : 0);
      c.set(x, y, col, p + c.vary(x / S, y / S, 0.06));
    }
}

function planks(c: Ctx) {
  const S = c.S;
  const bh = Math.max(2, Math.floor(S / 4));
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const row = Math.floor(y / bh);
      const seam = Math.floor(((row * 0.37 + 0.2) % 1) * S);
      const grain = c.smoothN(x / S * 0.5, y / S * 4, 8) * 0.14 - 0.07;
      let f = grain + c.vary(x / S, y / S, 0.05);
      if (y % bh === bh - 1) f -= 0.32;
      if (x === seam) f -= 0.28;
      c.set(x, y, [164, 132, 80], f);
    }
}

const TNT_BITMAP = ['11101001011', '01001101010', '01001111010', '01001011010', '01001001010'];

const DRAW: Partial<Record<TileName, (c: Ctx) => void>> = {
  grass_top: (c) => {
    fill(c, GRASS, 0.16);
    speckle(c, [80, 140, 44], 0.15);
    speckle(c, [120, 185, 70], 0.06);
  },
  grass_side: (c) => sideStrip(c, GRASS, dirt),
  dirt,
  stone,
  sand: (c) => {
    fill(c, [219, 207, 160], 0.06);
    speckle(c, [200, 186, 140], 0.12);
  },
  log_side: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const stripe = c.smoothN(x / S, y / S * 0.15, 8) * 0.3 - 0.15 + (x % Math.max(2, S / 4) === 0 ? -0.15 : 0);
        c.set(x, y, [106, 84, 50], stripe + c.vary(x / S, y / S, 0.06));
      }
  },
  log_top: (c) => logTop(c, [106, 84, 50], [176, 142, 88]),
  leaves: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const r = c.rnd();
        if (r < 0.14) c.set(x, y, [0, 0, 0], 0, 0);
        else c.set(x, y, [58, 135, 36], c.vary(x / S, y / S, 0.28) + (r > 0.85 ? 0.2 : 0));
      }
  },
  planks,
  cobble: (c) => cobble(c),
  glass: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const edge = x === 0 || y === 0 || x === S - 1 || y === S - 1;
        const diag = x - y;
        if (edge) c.set(x, y, [210, 235, 245], -0.05);
        else if ((diag > S * 0.15 && diag < S * 0.15 + Math.max(1, S / 16)) || (diag > S * 0.35 && diag < S * 0.35 + Math.max(1, S / 16) && y < S * 0.5))
          c.set(x, y, [255, 255, 255], 0, 170);
        else c.set(x, y, [200, 230, 255], 0, 18);
      }
  },
  water: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const w = Math.sin((x / S) * Math.PI * 4 + c.smoothN(x / S, y / S, 4) * 6) * 0.08;
        c.set(x, y, [44, 96, 222], w + c.vary(x / S, y / S, 0.06), 185);
      }
  },
  bedrock: (c) => {
    fill(c, [84, 84, 84], 0.55);
    speckle(c, [30, 30, 30], 0.2);
  },
  brick: (c) => {
    const S = c.S;
    const bh = Math.max(2, Math.floor(S / 4));
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const row = Math.floor(y / bh);
        const mortar = y % bh === 0 || (x + (row % 2) * (S / 4)) % (S / 2) === 0;
        if (mortar) c.set(x, y, [180, 172, 160], c.vary(x / S, y / S, 0.05));
        else c.set(x, y, [150, 72, 56], c.vary(x / S, y / S, 0.12));
      }
  },
  snow: (c) => fill(c, [242, 248, 252], 0.04),
  snow_side: (c) => sideStrip(c, [242, 248, 252], dirt),
  coal: (c) => ore(c, [40, 40, 40]),
  iron: (c) => ore(c, [216, 175, 147]),
  gold: (c) => ore(c, [250, 220, 60]),
  diamond: (c) => ore(c, [90, 230, 225]),
  emerald: (c) => ore(c, [40, 200, 90]),
  gravel: (c) => {
    const S = c.S;
    const cols: RGB[] = [[132, 126, 122], [100, 96, 94], [154, 144, 138], [118, 108, 100]];
    const bs = Math.max(1, Math.floor(S / 16));
    for (let y = 0; y < S; y += bs)
      for (let x = 0; x < S; x += bs) {
        const col = cols[Math.floor(c.rnd() * cols.length)];
        const f = c.vary(x / S, y / S, 0.08);
        for (let j = 0; j < bs; j++) for (let i = 0; i < bs; i++) c.set(x + i, y + j, col, f);
      }
  },
  cactus_side: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        let f = c.vary(x / S, y / S, 0.08);
        const u = x / S;
        if (Math.abs(u - 0.25) < 0.04 || Math.abs(u - 0.75) < 0.04) f -= 0.2;
        if (x === 0 || x === S - 1) f -= 0.25;
        c.set(x, y, [86, 142, 46], f);
        if (c.rnd() < 0.03) c.set(x, y, [220, 230, 170]);
      }
  },
  cactus_top: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const edge = x === 0 || y === 0 || x === S - 1 || y === S - 1;
        c.set(x, y, [100, 155, 54], (edge ? -0.25 : 0) + c.vary(x / S, y / S, 0.08));
      }
  },
  obsidian: (c) => {
    fill(c, [22, 16, 34], 0.3);
    speckle(c, [70, 46, 110], 0.08);
  },
  glowstone: (c) => {
    voronoi(c, 10, (x, y, edge, cell, d) => {
      const S = c.S;
      if (edge) c.set(x, y, [140, 96, 44], c.vary(x / S, y / S, 0.1));
      else c.set(x, y, cell % 2 ? [255, 228, 140] : [236, 180, 90], -d * 0.5 + c.vary(x / S, y / S, 0.06));
    });
  },
  wool_white: (c) => wool(c, [234, 236, 236]),
  wool_red: (c) => wool(c, [176, 40, 36]),
  wool_blue: (c) => wool(c, [52, 62, 160]),
  wool_yellow: (c) => wool(c, [248, 198, 40]),
  wool_green: (c) => wool(c, [84, 110, 28]),
  wool_black: (c) => wool(c, [26, 26, 30]),
  bookshelf: (c) => {
    planks(c);
    const S = c.S;
    const palette: RGB[] = [[150, 40, 40], [40, 80, 150], [60, 120, 50], [170, 140, 50], [110, 60, 120], [190, 180, 160]];
    for (const [y0, y1] of [[S * 0.12, S * 0.45], [S * 0.56, S * 0.88]] as [number, number][]) {
      let x = 1;
      while (x < S - 1) {
        const w = Math.max(1, Math.round((S / 16) * (1 + Math.floor(c.rnd() * 2))));
        const col = palette[Math.floor(c.rnd() * palette.length)];
        const top = Math.floor(y0 + c.rnd() * S * 0.08);
        for (let yy = top; yy < Math.floor(y1); yy++)
          for (let xx = x; xx < Math.min(S - 1, x + w); xx++) c.set(xx, yy, col, (yy === top ? 0.2 : 0) + c.vary(xx / S, yy / S, 0.05));
        x += w + (c.rnd() < 0.2 ? 1 : 0);
      }
    }
  },
  tnt_side: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const v = y / S, u = x / S;
        if (v > 0.33 && v < 0.67) {
          let col: RGB = [232, 232, 226];
          if (u >= 0.08 && u < 0.92 && v >= 0.39 && v < 0.61) {
            const cx = Math.floor(((u - 0.08) / 0.84) * 11);
            const cy = Math.floor(((v - 0.39) / 0.22) * 5);
            if (TNT_BITMAP[cy]?.[cx] === '1') col = [30, 30, 30];
          }
          c.set(x, y, col, c.vary(u, v, 0.03));
        } else {
          const stripe = x % Math.max(2, S / 4) === 0 ? -0.2 : 0;
          c.set(x, y, [204, 54, 40], stripe + c.vary(u, v, 0.08));
        }
      }
  },
  tnt_top: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const dx = (x + 0.5) / S - 0.5, dy = (y + 0.5) / S - 0.5;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 0.14) c.set(x, y, [70, 70, 70], c.vary(x / S, y / S, 0.1));
        else c.set(x, y, [204, 54, 40], (d < 0.2 ? -0.2 : 0) + c.vary(x / S, y / S, 0.08));
      }
  },
  tnt_bottom: (c) => fill(c, [190, 50, 38], 0.1),
  birch_side: (c) => {
    const S = c.S;
    fill(c, [222, 222, 212], 0.05);
    const n = Math.max(3, S / 3);
    for (let k = 0; k < n; k++) {
      const y = Math.floor(c.rnd() * S), x0 = Math.floor(c.rnd() * S), w = Math.max(1, Math.floor(c.rnd() * S * 0.3));
      for (let i = 0; i < w; i++) c.set((x0 + i) % S, y, [40, 40, 36], c.vary(0, 0, 0.1));
    }
  },
  birch_top: (c) => logTop(c, [222, 222, 212], [196, 176, 120]),
  ice: (c) => {
    const S = c.S;
    fill(c, [150, 190, 250], 0.04);
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) if ((x * 2 + y) % Math.max(5, S / 3) === 0 && c.rnd() < 0.7) c.set(x, y, [210, 230, 255]);
  },
  stone_bricks: (c) => {
    const S = c.S;
    const bh = Math.max(2, Math.floor(S / 2));
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const row = Math.floor(y / bh);
        const lx = (x + (row % 2) * (S / 2)) % S;
        const ly = y % bh;
        let f = c.vary(x / S, y / S, 0.08);
        if (ly === 0 || lx === 0) c.set(x, y, [80, 80, 80], f);
        else {
          if (ly === 1 || lx === 1) f += 0.12;
          if (ly === bh - 1 || lx === S - 1) f -= 0.12;
          c.set(x, y, [122, 122, 122], f);
        }
      }
  },
  mossy: (c) => cobble(c, true),
  birch_leaves: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const r = c.rnd();
        if (r < 0.14) c.set(x, y, [0, 0, 0], 0, 0);
        else c.set(x, y, [110, 160, 70], c.vary(x / S, y / S, 0.25));
      }
  },
  crafting_top: (c) => {
    planks(c);
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        if (x === 0 || y === 0 || x === S - 1 || y === S - 1) c.set(x, y, [90, 64, 36]);
        else if (x % Math.floor(S / 3) === 0 || y % Math.floor(S / 3) === 0) c.set(x, y, [120, 88, 50]);
      }
  },
  crafting_side: (c) => {
    planks(c);
    const S = c.S;
    for (let y = 0; y < S * 0.2; y++) for (let x = 0; x < S; x++) c.set(x, y, [110, 80, 46], c.vary(x / S, y / S, 0.08));
    // tools
    for (let i = Math.floor(S * 0.3); i < S * 0.8; i++) {
      c.set(Math.floor(S * 0.3), i, [70, 50, 30]);
      c.set(Math.floor(S * 0.7), i, [70, 50, 30]);
    }
    for (let i = Math.floor(S * 0.2); i < S * 0.42; i++) c.set(i, Math.floor(S * 0.32), [160, 160, 160]);
    for (let i = Math.floor(S * 0.6); i < S * 0.82; i++) c.set(i, Math.floor(S * 0.32), [160, 160, 160]);
  },
  pumpkin_side: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const rib = Math.abs(Math.sin((x / S) * Math.PI * 4)) * 0.18 - 0.12;
        c.set(x, y, [214, 120, 22], rib + c.vary(x / S, y / S, 0.05));
      }
  },
  pumpkin_top: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const dx = (x + 0.5) / S - 0.5, dy = (y + 0.5) / S - 0.5;
        if (Math.abs(dx) < 0.08 && Math.abs(dy) < 0.08) c.set(x, y, [90, 120, 40]);
        else c.set(x, y, [200, 112, 20], -Math.sqrt(dx * dx + dy * dy) * 0.3 + c.vary(x / S, y / S, 0.05));
      }
  },
  torch: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const du = Math.abs(u - 0.5);
        if (du < 0.13 && v > 0.32) c.set(x, y, [122, 88, 52], c.vary(u, v, 0.1));
        else if (du < 0.2 && v <= 0.34 && v > 0.14) c.set(x, y, [255, 190, 50], c.vary(u, v, 0.08));
        else if (du < 0.1 && v <= 0.16) c.set(x, y, [255, 242, 190]);
        else c.set(x, y, [0, 0, 0], 0, 0);
      }
  },
  flower_red: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const stem = Math.abs(u - 0.5) < 0.045 && v > 0.35;
        const leaf = Math.abs(u - 0.3) < 0.15 && Math.abs(v - 0.62) < 0.05;
        const d = Math.sqrt((u - 0.5) ** 2 + ((v - 0.24) * 1.25) ** 2);
        if (d < 0.19) c.set(x, y, d < 0.07 ? [255, 222, 80] : [205, 45, 40], c.vary(u, v, 0.08));
        else if (stem || leaf) c.set(x, y, [58, 140, 48], c.vary(u, v, 0.12));
        else c.set(x, y, [0, 0, 0], 0, 0);
      }
  },
  flower_yellow: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const stem = Math.abs(u - 0.5) < 0.045 && v > 0.35;
        const leaf = Math.abs(u - 0.7) < 0.15 && Math.abs(v - 0.6) < 0.05;
        const d = Math.sqrt((u - 0.5) ** 2 + ((v - 0.24) * 1.25) ** 2);
        if (d < 0.19) c.set(x, y, d < 0.07 ? [230, 130, 40] : [245, 225, 70], c.vary(u, v, 0.08));
        else if (stem || leaf) c.set(x, y, [58, 140, 48], c.vary(u, v, 0.12));
        else c.set(x, y, [0, 0, 0], 0, 0);
      }
  },
  tallgrass: (c) => {
    const S = c.S;
    const hs = [0.45, 0.7, 0.55, 0.85, 0.65, 0.8, 0.5, 0.6];
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const col = Math.min(7, Math.floor(u * 8));
        const blade = v > 1 - hs[col] && (x + col * 3) % 2 === 0;
        if (blade || v > 0.92) c.set(x, y, [82, 158, 58], c.vary(u, v, 0.2));
        else c.set(x, y, [0, 0, 0], 0, 0);
      }
  },
  sandstone: (c) => {
    fill(c, [219, 207, 160], 0.05);
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const edge = u < 0.07 || u > 0.93 || v < 0.07 || v > 0.93;
        if (edge) c.set(x, y, [174, 160, 118], c.vary(u, v, 0.05));
        else if (v > 0.42 && v < 0.58 && u > 0.22 && u < 0.78 && (x * 2 + y) % 4 < 2) c.set(x, y, [188, 172, 130]);
      }
  },
  iron_block: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const edge = x === 0 || y === 0 || x === S - 1 || y === S - 1;
        const hi = x === 1 || y === 1;
        const lo = x === S - 2 || y === S - 2;
        let col: RGB = [224, 224, 226];
        let f = c.vary(u, v, 0.04);
        if (edge) col = [148, 148, 152];
        else if (hi) col = [246, 246, 248];
        else if (lo) col = [186, 186, 190];
        else if (u > 0.3 && u < 0.45 && v > 0.25 && v < 0.6) f += 0.08;
        c.set(x, y, col, f);
      }
  },
  gold_block: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const edge = x === 0 || y === 0 || x === S - 1 || y === S - 1;
        const hi = x === 1 || y === 1;
        const lo = x === S - 2 || y === S - 2;
        let col: RGB = [250, 220, 80];
        let f = c.vary(u, v, 0.04);
        if (edge) col = [168, 138, 42];
        else if (hi) col = [255, 240, 150];
        else if (lo) col = [205, 170, 50];
        else if (u > 0.3 && u < 0.45 && v > 0.25 && v < 0.6) f += 0.1;
        c.set(x, y, col, f);
      }
  },
  diamond_block: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const edge = x === 0 || y === 0 || x === S - 1 || y === S - 1;
        const hi = x === 1 || y === 1;
        const lo = x === S - 2 || y === S - 2;
        let col: RGB = [125, 232, 232];
        let f = c.vary(u, v, 0.04);
        if (edge) col = [66, 158, 168];
        else if (hi) col = [190, 250, 250];
        else if (lo) col = [90, 190, 200];
        else if (u > 0.3 && u < 0.45 && v > 0.25 && v < 0.6) f += 0.1;
        c.set(x, y, col, f);
      }
  },
  pumpkin_face: (c) => {
    const S = c.S;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const u = (x + 0.5) / S, v = (y + 0.5) / S;
        const rib = Math.abs(Math.sin(u * Math.PI * 4)) * 0.18 - 0.12;
        const eyeL = u > 0.18 && u < 0.36 && v > 0.3 && v < 0.48;
        const eyeR = u > 0.64 && u < 0.82 && v > 0.3 && v < 0.48;
        const mouth = v > 0.62 && v < 0.78 && u > 0.2 && u < 0.8 && (u < 0.3 || u > 0.7 || v < 0.7);
        if (eyeL || eyeR || mouth) c.set(x, y, [70, 38, 8]);
        else c.set(x, y, [224, 132, 28], rib + c.vary(u, v, 0.05));
      }
  },
};

export interface Atlas {
  canvas: HTMLCanvasElement;
  tiles: HTMLCanvasElement[];
  colors: RGB[];
  size: number;
}

function adventureTile(name: TileName, c: Ctx) {
  const oreColors: Record<string, RGB> = {
    coal: [36, 36, 43], iron: [219, 177, 146], gold: [252, 218, 58], diamond: [82, 232, 219],
    emerald: [49, 204, 98], copper: [215, 136, 80], redstone: [225, 45, 48], lapis: [57, 105, 215],
    quartz_ore: [245, 229, 211], nether_gold: [254, 209, 51],
  };
  const base = name.replace('deep_', '');
  if (oreColors[base]) {
    ore(c, oreColors[base]);
    if (name.startsWith('deep_') || name === 'quartz_ore' || name === 'nether_gold') {
      for (let y = 0; y < c.S; y++) for (let x = 0; x < c.S; x++) {
        const [r, g, b] = c.get(x, y);
        if (Math.abs(r - g) < 8 && Math.abs(g - b) < 8) {
          c.set(x, y, name.startsWith('deep_') ? [r * 0.51, g * 0.53, b * 0.59] : [r * 0.72, g * 0.26, b * 0.29]);
        }
      }
    }
    return;
  }
  const palette: Record<string, RGB> = {
    deepslate: [63, 65, 73], netherrack: [117, 43, 45], ancient_debris: [99, 70, 65],
    end_stone: [224, 222, 161], amethyst: [158, 105, 221], farmland: [91, 61, 37],
    copper_block: [209, 130, 90], redstone_block: [166, 28, 32], lapis_block: [44, 74, 160],
    emerald_block: [51, 180, 93], quartz_block: [232, 224, 214], netherite_block: [65, 60, 69],
    furnace: [94, 96, 101], smithing: [67, 48, 46], enchanting: [44, 41, 61],
    nether_gate: [118, 52, 190], end_gate: [32, 115, 101], lava: [247, 95, 19],
  };
  if (name === 'crops' || name === 'ripe_crops') {
    for (let y = 0; y < c.S; y++) for (let x = 0; x < c.S; x++) {
      const blade = x % Math.max(2, c.S / 4) < c.S / 8;
      if (blade && y > c.S * (name === 'crops' ? 0.48 : 0.15)) c.set(x, y, name === 'crops' ? [112, 168, 54] : [222, 180, 69], c.vary(x / c.S, y / c.S, 0.12));
    }
    return;
  }
  fill(c, palette[name] ?? [117, 111, 130], 0.15);
  for (let y = 0; y < c.S; y++) for (let x = 0; x < c.S; x++) {
    const u = x / c.S, v = y / c.S;
    if (name === 'furnace' && u > 0.18 && u < 0.82 && ((v > 0.2 && v < 0.38) || (v > 0.58 && v < 0.83))) c.set(x, y, v > 0.65 ? [219, 125, 37] : [31, 32, 36]);
    if (name === 'smithing' && ((u < 0.13 || u > 0.87) || v < 0.15)) c.set(x, y, [142, 152, 168]);
    if (name === 'enchanting' && ((u + v) % 0.3 < 0.04 || v > 0.75)) c.set(x, y, [75, 224, 207]);
    if (name.endsWith('_gate')) {
      if (u < 0.16 || u > 0.84 || v < 0.16 || v > 0.84) c.set(x, y, [34, 28, 43]);
      else if ((x * 3 + y * 7) % 13 < 2) c.set(x, y, name === 'nether_gate' ? [229, 154, 255] : [150, 252, 198]);
    }
    if (name === 'amethyst' && (x + y) % Math.max(3, c.S / 3) < 1) c.set(x, y, [233, 208, 255]);
    if (name === 'ancient_debris' && Math.floor(u * 6) % 2 === 0 && v % 0.25 < 0.07) c.set(x, y, [180, 147, 122]);
    if (name === 'farmland' && y % Math.max(2, c.S / 4) === 0) c.set(x, y, [56, 36, 27]);
    if (name === 'lava' && Math.sin(u * 20 + v * 10) > 0.6) c.set(x, y, [255, 187, 40]);
  }
}

const spriteCache = new Map<number, HTMLCanvasElement>();

export function itemSprite(id: number): HTMLCanvasElement {
  const cached = spriteCache.get(id);
  if (cached) return cached;
  const detailed = detailedItemCanvas(id);
  if (detailed) { spriteCache.set(id, detailed); return detailed; }
  const def = BLOCKS[id];
  const cv = document.createElement('canvas');
  cv.width = cv.height = 32;
  const ctx = cv.getContext('2d')!;
  ctx.scale(2, 2);
  ctx.imageSmoothingEnabled = false;
  const color = def?.color ?? '#ddd';
  const shape = def?.sprite ?? 'gem';
  const rect = (x: number, y: number, w: number, h: number, c: string) => { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); };
  const poly = (pts: number[][], c: string) => {
    ctx.beginPath(); pts.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.closePath();
    ctx.strokeStyle = '#282632'; ctx.lineWidth = 1; ctx.stroke(); ctx.fillStyle = c; ctx.fill();
  };
  const handle = () => {
    for (let i = 0; i < 9; i++) { rect(3 + i, 12 - i, 2, 3, '#433324'); rect(3 + i, 12 - i, 1, 2, '#b98650'); }
  };
  if (['pickaxe', 'axe', 'shovel', 'hoe', 'sword', 'trident', 'mace'].includes(shape)) {
    handle();
    if (shape === 'sword') {
      poly([[5, 9], [12, 2], [15, 1], [14, 5], [8, 11]], color);
      poly([[3, 8], [4, 7], [10, 13], [9, 14]], '#a3956b');
      rect(12, 3, 1, 2, '#f0f7e9');
    } else if (shape === 'pickaxe' || shape === 'hoe') {
      poly([[3, 2], [9, 2], [14, 7], [15, 11], [13, 10], [10, 6], [8, 5], [3, 4]], color);
      if (shape === 'hoe') rect(3, 3, 5, 2, '#483a32');
    } else if (shape === 'axe') {
      poly([[7, 1], [11, 1], [14, 4], [14, 8], [10, 9], [6, 5]], color);
      rect(8, 2, 3, 1, '#eff5e9');
    } else if (shape === 'shovel') poly([[10, 1], [14, 2], [15, 6], [12, 9], [7, 4]], color);
    else if (shape === 'trident') poly([[8, 2], [9, 1], [10, 4], [12, 2], [14, 1], [14, 4], [12, 6], [15, 6], [15, 8], [10, 8], [7, 5]], color);
    else poly([[6, 1], [13, 1], [15, 4], [11, 9], [5, 4]], color);
  } else if (['head', 'chest', 'legs', 'feet', 'shield'].includes(shape)) {
    if (shape === 'head') poly([[3, 3], [13, 3], [14, 12], [11, 12], [11, 8], [5, 8], [5, 12], [2, 12]], color);
    if (shape === 'chest') poly([[4, 2], [6, 2], [6, 5], [10, 5], [10, 2], [12, 2], [15, 6], [12, 8], [12, 14], [4, 14], [4, 8], [1, 6]], color);
    if (shape === 'legs') poly([[3, 2], [13, 2], [13, 14], [9, 14], [9, 7], [7, 7], [7, 14], [3, 14]], color);
    if (shape === 'feet') { poly([[3, 3], [7, 3], [7, 14], [1, 14], [1, 11], [3, 11]], color); poly([[10, 3], [14, 3], [14, 11], [15, 11], [15, 14], [9, 14], [9, 11], [10, 11]], color); }
    if (shape === 'shield') { poly([[3, 2], [13, 2], [13, 10], [8, 15], [3, 10]], '#c8cdd0'); poly([[5, 4], [11, 4], [11, 10], [8, 13], [5, 10]], color); rect(7, 5, 2, 6, '#8f6543'); }
  } else if (shape === 'bow' || shape === 'crossbow') {
    poly([[4, 1], [7, 2], [12, 6], [13, 9], [10, 13], [6, 15], [5, 13], [9, 11], [10, 8], [8, 5], [4, 3]], color);
    rect(4, 2, 1, 12, '#e8ded1');
    if (shape === 'crossbow') poly([[2, 13], [11, 4], [13, 6], [4, 15]], '#ae8160');
  } else if (shape === 'arrow' || shape === 'stick' || shape === 'spyglass') {
    handle();
    if (shape === 'arrow') poly([[10, 1], [15, 1], [15, 6], [12, 5]], color);
    else poly([[7, 4], [11, 1], [14, 4], [10, 8]], color);
    if (shape === 'spyglass') rect(11, 2, 2, 2, '#a6ecf2');
  } else if (shape === 'ingot' || shape === 'bread') {
    poly([[3, 5], [12, 4], [15, 8], [13, 12], [3, 12], [1, 9]], color);
    rect(4, 6, 7, 1, '#fff1b3');
  } else if (shape === 'eye' || shape === 'orb' || shape === 'compass') {
    poly([[5, 2], [11, 2], [14, 5], [14, 11], [11, 14], [5, 14], [2, 11], [2, 5]], color);
    rect(4, 4, 3, 2, '#c3ffeb');
    if (shape === 'eye') { rect(6, 5, 5, 6, '#224652'); rect(8, 6, 2, 4, '#0d252e'); }
    if (shape === 'compass') { rect(7, 3, 2, 6, '#e4ecef'); rect(7, 9, 2, 4, '#34343f'); }
  } else if (shape === 'berries') {
    rect(7, 1, 2, 4, '#66863c'); rect(9, 2, 3, 2, '#86af51');
    for (const [x, y] of [[3, 6], [8, 5], [6, 10]]) { poly([[x, y], [x + 4, y], [x + 5, y + 3], [x + 2, y + 5], [x - 1, y + 2]], color); rect(x, y + 1, 2, 1, '#f49aad'); }
  } else if (shape === 'melon') {
    poly([[1, 5], [14, 5], [13, 10], [9, 14], [4, 12]], '#4a8b3b');
    poly([[2, 5], [13, 5], [11, 10], [8, 12], [4, 10]], color);
    rect(5, 7, 1, 2, '#532e32'); rect(9, 7, 1, 2, '#532e32');
  } else if (shape === 'bowl' || shape === 'stew') {
    poly([[1, 6], [15, 6], [12, 13], [4, 13]], '#86552f');
    poly([[2, 5], [13, 5], [15, 7], [12, 9], [4, 9], [1, 7]], color);
    if (shape === 'stew') { rect(3, 6, 10, 2, '#d9af71'); rect(5, 5, 2, 2, '#a34f39'); rect(9, 7, 2, 1, '#6c8641'); }
  } else if (shape === 'paper' || shape === 'book') {
    poly([[3, 2], [12, 1], [14, 12], [4, 14]], shape === 'paper' ? '#e8e4d0' : color);
    rect(5, 4, 6, 1, '#a59c87'); rect(5, 7, 6, 1, '#a59c87');
    if (shape === 'book') rect(3, 2, 2, 11, '#6c4730');
  } else if (shape === 'pie') {
    poly([[3, 4], [12, 4], [15, 8], [12, 13], [3, 13], [1, 8]], '#b57b41');
    poly([[3, 3], [12, 3], [14, 7], [11, 10], [4, 10], [1, 7]], color);
    rect(4, 5, 7, 1, '#e8bc71'); rect(7, 4, 1, 5, '#e8bc71');
  } else if (shape === 'apple') {
    poly([[3, 5], [6, 3], [8, 5], [11, 3], [14, 5], [14, 10], [11, 14], [5, 14], [2, 10]], color);
    rect(7, 1, 2, 3, '#8c603c'); rect(9, 1, 3, 1, '#90bc60'); rect(4, 6, 2, 3, '#ffe7a6');
  } else if (shape === 'trophy') {
    poly([[8, 1], [14, 5], [12, 10], [8, 15], [4, 10], [2, 5]], color);
    rect(6, 5, 4, 4, '#fff2d1');
  } else if (shape === 'string') {
    poly([[3, 3], [11, 2], [14, 5], [10, 9], [5, 9], [4, 12], [12, 12], [13, 14], [3, 14], [1, 10], [4, 7], [11, 6], [10, 4], [3, 5]], color);
  } else if (shape === 'wheat') {
    rect(7, 3, 2, 12, '#bfa256');
    for (let y = 2; y < 11; y += 3) { rect(4, y, 3, 2, color); rect(9, y + 1, 3, 2, color); }
  } else if (shape === 'dust') {
    for (const [x, y] of [[3, 10], [6, 8], [8, 4], [11, 8], [7, 11], [11, 12]]) rect(x, y, 3, 2, color);
  } else {
    poly([[5, 2], [11, 2], [14, 6], [12, 12], [8, 15], [2, 9], [2, 5]], color);
    rect(5, 4, 3, 2, '#ffffff'); rect(4, 7, 1, 3, '#d8e4df');
  }
  spriteCache.set(id, cv);
  return cv;
}

const atlasCache: Partial<Record<TexturePack, Atlas>> = {};

export function buildAtlas(pack: TexturePack): Atlas {
  const cached = atlasCache[pack];
  if (cached) return cached;
  const { size: S, smooth } = PACKS[pack];
  const canvas = document.createElement('canvas');
  canvas.width = S * ATLAS_COLS;
  canvas.height = S * ATLAS_ROWS;
  const ctx = canvas.getContext('2d')!;
  const tiles: HTMLCanvasElement[] = [];
  const colors: RGB[] = [];
  TILES.forEach((name, i) => {
    const c = makeCtx(S, 1337 + i * 7919, smooth);
    const classic = natureTile(name, S) ?? classicTile(name, S);
    if (classic) c.img.data.set(classic.data);
    else {
      const draw = DRAW[name];
      if (draw) draw(c);
      else adventureTile(name, c);
    }
    const tc = document.createElement('canvas');
    tc.width = S;
    tc.height = S;
    tc.getContext('2d')!.putImageData(c.img, 0, 0);
    tiles.push(tc);
    ctx.putImageData(c.img, (i % ATLAS_COLS) * S, Math.floor(i / ATLAS_COLS) * S);
    let r = 0, g = 0, b = 0, n = 0;
    for (let p = 0; p < c.img.data.length; p += 4) {
      if (c.img.data[p + 3] > 100) {
        r += c.img.data[p];
        g += c.img.data[p + 1];
        b += c.img.data[p + 2];
        n++;
      }
    }
    colors.push(n ? [r / n, g / n, b / n] : [200, 200, 200]);
  });
  const atlas = { canvas, tiles, colors, size: S };
  atlasCache[pack] = atlas;
  return atlas;
}

export function animateAtlas(pack: TexturePack, time: number, target?: HTMLCanvasElement) {
  const atlas = buildAtlas(pack);
  const context = (target ?? atlas.canvas).getContext('2d')!;
  for (const name of ['water', 'lava'] as const) {
    const tile = TILES.indexOf(name);
    const image = classicTile(name, atlas.size, time);
    if (image) context.putImageData(image, tile % ATLAS_COLS * atlas.size, Math.floor(tile / ATLAS_COLS) * atlas.size);
  }
}

const iconCache: Partial<Record<TexturePack, string[]>> = {};

export function getIcons(pack: TexturePack): string[] {
  const cached = iconCache[pack];
  if (cached) return cached;
  const atlas = buildAtlas(pack);
  const S = atlas.size;
  const out: string[] = [''];
  for (let id = 1; id < BLOCKS.length; id++) {
    const def = BLOCKS[id];
    if (!def) { out.push(''); continue; }
    if (def.kind) { out.push(itemSprite(id).toDataURL()); continue; }
    if (FLAT_ICONS.has(id)) {
      const fc = document.createElement('canvas');
      fc.width = 64;
      fc.height = 64;
      const fctx = fc.getContext('2d')!;
      fctx.imageSmoothingEnabled = false;
      fctx.drawImage(atlas.tiles[def.tiles[1]], 6, 6, 52, 52);
      out.push(fc.toDataURL());
      continue;
    }
    const cv = document.createElement('canvas');
    cv.width = 64;
    cv.height = 64;
    const ctx = cv.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    const top = atlas.tiles[def.tiles[0]], side = atlas.tiles[def.tiles[1]];
    const boxes = blockBounds(id);
    const geometry = boxes.length ? boxes : [[0, 0, 0, 1, 1, 1]];
    const project = (x: number, y: number, z: number) => [32 + (x - z) * 28, 4 + (x + z) * 14 + (1 - y) * 30];
    const face = (texture: HTMLCanvasElement, origin: number[], a: number[], b: number[], shade: number) => {
      ctx.setTransform(a[0] / S, a[1] / S, b[0] / S, b[1] / S, origin[0], origin[1]); ctx.drawImage(texture, 0, 0);
      if (shade) { ctx.globalCompositeOperation = 'source-atop'; ctx.fillStyle = `rgba(0,0,0,${shade})`; ctx.fillRect(0, 0, S, S); ctx.globalCompositeOperation = 'source-over'; }
    };
    for (const [x0, y0, z0, x1, rawY1, z1] of geometry) {
      const y1 = Math.min(1, rawY1), w = x1 - x0, h = y1 - y0, d = z1 - z0;
      face(top, project(x0, y1, z0), [28 * w, 14 * w], [-28 * d, 14 * d], 0);
      face(id === B.CHEST ? atlas.tiles[TILES.indexOf('chest_front')] : side, project(x0, y1, z1), [28 * w, 14 * w], [0, 30 * h], 0.18);
      face(side, project(x1, y1, z1), [28 * d, -14 * d], [0, 30 * h], 0.36);
    }
    out.push(cv.toDataURL());
  }
  iconCache[pack] = out;
  return out;
}
