import * as THREE from 'three';
import { World, Chunk, CS, CH } from './world';
import { BLOCKS, B, I, isSolid, isPlaceable, RECIPES, STATION_BLOCKS, recipeStation, ARMOR_SLOTS, WOODS, LEAF_IDS, SAPLING_IDS, PLANT_IDS, SOIL_IDS, GRASS_IDS, SLAB_IDS, STAIR_IDS, DOUBLE_SLABS, maxStack, type EquipmentSlot, type Station, type WoodKind } from './blocks';
import { buildAtlas, animateAtlas, ATLAS_COLS } from './textures';
import { buildChunkGeometry } from './mesher';
import type { Settings, WorldMeta, WorldSave, Slot, Dimension, Adventure, Equipment, SavedMob } from './settings';
import { sfx, configureAudio, setAudioListener, setAudioFocus, subscribeCaptions, tickMusic } from './sound';
import { craftInventory, cloneInventory, consume, insertItem, itemCount, ingredientCount, makeSlot, normalizeSlot, organizeSlots, transferStack, clickStack, sameStack } from './inventory';
import { BOSS_MAX_HP, newAdventure, emptyEquipment, DIMENSION_NAMES } from './adventure';
import { CombatSystem } from './combat';
import { DropSystem } from './drops';
import { PortalSystem } from './portals';
import { blockBounds, clearLine, intersects, overlapsWorld, type Bounds } from './collision';
import { freshHunger, normalizeHunger, exhaust, feed, starvationFloor } from './hunger';
import { craftGrid, fillRecipeGrid, findGridRecipe, allowedRecipe, type CraftCell } from './crafting';
import { BIOME_BY_ID, treeBlocks, type BiomeId } from './biomes';
import { setMusicScene } from './music';
import { FirstPersonView } from './firstPerson';

THREE.ColorManagement.enabled = false;

export interface HudState {
  health: number;
  inventory: (Slot | null)[];
  selected: number;
  fps: number;
  flying: boolean;
  loading: number;
  loaded: boolean;
  dead: boolean;
  underwater: boolean;
  pos: [number, number, number];
  breakProgress: number;
  target: string;
  targetId: number;
  chunks: number;
  drawCalls: number;
  tris: number;
  hurt: number;
  timeOfDay: number;
  equipment: Equipment;
  armor: number;
  adventure: Adventure;
  dimension: Dimension;
  notice: string;
  combatTarget: { name: string; health: number; maxHealth: number; intent?: string } | null;
  bossPhase: string;
  attackReady: number;
  reserveCount: number;
  portalCharge: number;
  droppedCount: number;
  resolution: number;
  subtitle: string;
  deathPoint?: WorldSave['deathPoint'];
  air: number;
  hunger: number;
  saturation: number;
  eating: number;
  biome: string;
  biomeId: string;
  chest: (Slot | null)[] | null;
  waypoint?: WorldSave['waypoint'];
  cursor: Slot | null;
  personalCraft: (Slot | null)[];
}

export interface EngineCallbacks {
  onHud: (h: HudState) => void;
  onAutosave?: (data: WorldSave) => void;
  onDeath?: () => void;
  onPointerUnlock?: () => void;
  onKey?: (k: 'inventory' | 'pause' | 'journal') => void;
  onOpenCrafting?: () => void;
  onOpenChest?: () => void;
}

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
}
interface Tnt {
  x: number;
  y: number;
  z: number;
  t: number;
  mesh: THREE.Mesh;
}
interface Hit {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  id: number;
  hitY?: number;
}

interface Placement { x: number; y: number; z: number; id: number; state: number; valid: boolean }

const HW = 0.3;
const PH = 1.8;
const EYE = 1.62;
const GRAVITY = 28;
const JUMP_V = 8.6;

export const DEFAULT_CREATIVE_HOTBAR = [B.GRASS, B.DIRT, B.STONE, B.COBBLE, B.PLANKS, B.LOG, B.GLASS, B.BRICK, B.TNT];

export class Engine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  world: World;
  settings: Settings;
  meta: WorldMeta;
  cb: EngineCallbacks;

  matOpaque: THREE.MeshBasicMaterial;
  matWater: THREE.MeshBasicMaterial;
  texture: THREE.CanvasTexture;
  atlasColors: [number, number, number][] = [];

  pos = new THREE.Vector3(8.5, 80, 8.5);
  vel = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  onGround = false;
  flying = false;
  health = 20;
  air = 20;
  hunger = freshHunger();
  private eating: { index: number; id: number; progress: number } | null = null;
  private regeneration = 0;
  private hungerTimer = 0;
  private starvationTimer = 0;
  private eatingSound = 0;
  private generatorVersion = 2;
  private realmStates: NonNullable<WorldSave['states']> = {};
  private chests: Record<string, (Slot | null)[]> = {};
  private openChestKey: string | null = null;
  private saplings: NonNullable<WorldSave['saplings']> = [];
  private waypoint: WorldSave['waypoint'];
  private biomeId: BiomeId = 'plains';
  private biomeTimer = 0;
  private saplingTimer = 0;
  private useCooldown = 0;
  dead = false;
  fallStart = 0;
  spawned = false;
  hasSavedPos = false;
  inventory: (Slot | null)[] = new Array(36).fill(null);
  selected = 0;
  cursor: Slot | null = null;
  personalCraft: (Slot | null)[] = Array(4).fill(null);
  time = 0.28;
  dimension: Dimension = 'overworld';
  adventure: Adventure = newAdventure();
  equipment: Equipment = emptyEquipment();
  combat: CombatSystem;
  drops: DropSystem;
  portals: PortalSystem;
  craftingStation: Station = 'hand';
  craftError = '';
  attackCooldown = 0;
  attackDuration = 0.55;
  private realms: NonNullable<WorldSave['realms']> = {};
  private mobRealms: Partial<Record<Dimension, SavedMob[]>> = {};
  private returnPoint: [number, number, number] | null = null;
  private stationTarget: Hit | null = null;
  private crops: NonNullable<WorldSave['crops']> = [];
  private reserve: Slot[] = [];
  private notice = '';
  private noticeTimer = 0;
  private damageCooldown = 0;
  private lastDamage = 0;
  private liquidTimer = 0;
  private zoomed = false;
  private effectiveResolution = 0.75;
  private adaptiveTimer = 0;
  private frameAverage = 1 / 60;
  private ambientTimer = 0;
  private subtitle = '';
  private subtitleTimer = 0;
  private deathPoint: WorldSave['deathPoint'];
  private environmentalQueue = new Set<string>();
  private environmentTimer = 0;
  private contextLost = false;
  private textureTimer = 0;

  input = { moveX: 0, moveY: 0, lookX: 0, lookY: 0, jump: false, down: false, breaking: false, place: false, sprint: false, blocking: false, useHeld: false };
  bypassTable = false;
  keys = new Set<string>();
  paused = false;
  private lastJumpPress = 0;

  private offsets: [number, number, number][] = [];
  private offsetsR = -1;
  private raf = 0;
  private last = 0;
  private fpsFrames = 0;
  private fpsTime = 0;
  private fps = 0;
  private hudTime = 0;
  private unloadTime = 0;
  private autosaveTime = 0;
  private target: Hit | null = null;
  private breakKey = '';
  private breakProgress = 0;
  private breakCooldown = 0;
  private digSoundT = 0;
  private hurtCounter = 0;
  private regenT = 0;
  private stepDist = 0;
  private bobPhase = 0;
  private bobAmt = 0;
  private shake = 0;
  private swing = 0;
  private underwater = false;
  private wasInWater = false;

  private selection: THREE.LineSegments;
  private placementOutline: THREE.LineSegments;
  private crack: THREE.Mesh;
  private sun: THREE.Mesh;
  private moon: THREE.Mesh;
  private stars: THREE.Points;
  private clouds: THREE.Mesh;
  private cloudDrift = 0;
  private firstPerson: FirstPersonView;
  private particles: Particle[] = [];
  private particleGeo = new THREE.BoxGeometry(0.14, 0.14, 0.14);
  private particleMats = new Map<number, THREE.MeshBasicMaterial>();
  private tnts: Tnt[] = [];
  private primedRealms: NonNullable<WorldSave['primedTnt']> = {};
  private tntMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false });
  private skyColor = new THREE.Color();
  private isTouch: boolean;
  private disposers: (() => void)[] = [];

  constructor(canvas: HTMLCanvasElement, settings: Settings, meta: WorldMeta, save: WorldSave | null, cb: EngineCallbacks, isTouch: boolean) {
    this.settings = settings;
    this.meta = meta;
    this.cb = cb;
    this.isTouch = isTouch;
    configureAudio(settings);
    this.effectiveResolution = settings.resolution;

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.antialias, powerPreference: settings.preset === 'rapido' ? 'low-power' : 'high-performance', alpha: false });
    this.renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
    this.applyResolution();

    this.camera = new THREE.PerspectiveCamera(settings.fov, window.innerWidth / window.innerHeight, 0.08, 1000);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);
    this.scene.fog = new THREE.Fog(0x88aaff, 40, 80);

    const atlas = buildAtlas(settings.texturePack);
    this.atlasColors = atlas.colors;
    this.texture = this.makeTexture(this.worldAtlasCanvas());
    this.matOpaque = new THREE.MeshBasicMaterial({ map: this.texture, vertexColors: true, alphaTest: 0.5 });
    this.matWater = new THREE.MeshBasicMaterial({ map: this.texture, vertexColors: true, transparent: true, depthWrite: false, side: THREE.DoubleSide });

    this.dimension = save?.dimension ?? 'overworld';
    this.generatorVersion = save?.generatorVersion ?? meta.generatorVersion ?? (save ? 1 : 2);
    this.realmStates = save?.states ?? {};
    this.realms = { overworld: save?.mods ?? {}, ...save?.realms };
    this.world = new World(meta.seed, meta.type, this.realms[this.dimension], this.dimension, this.generatorVersion, this.realmStates[this.dimension]);
    this.adventure = { ...newAdventure(), ...save?.adventure };
    this.adventure.bossHealth = Math.max(0, Math.min(BOSS_MAX_HP, this.adventure.bossHealth));
    this.adventure.crystals = [...new Set(this.adventure.crystals.filter((id) => id >= 0 && id < 4))];
    this.returnPoint = save?.returnPoint ?? null;
    this.deathPoint = save?.deathPoint;
    this.crops = save?.crops ?? [];
    this.saplings = save?.saplings ?? [];
    this.waypoint = save?.waypoint;
    if (save?.chests) for (const [key, slots] of Object.entries(save.chests)) {
      if (/^(overworld|nether|end):[-\d]+,\d+,[-\d]+$/.test(key) && Array.isArray(slots)) this.chests[key] = Array.from({ length: 27 }, (_, index) => normalizeSlot(slots[index]));
    }
    this.adventure.biomes = Array.isArray(save?.adventure?.biomes) ? [...new Set(save.adventure.biomes.filter((id) => BIOME_BY_ID[id as BiomeId]?.id === id))] : [];
    this.reserve = (save?.reserve ?? []).map(normalizeSlot).filter((s): s is Slot => !!s);
    ARMOR_SLOTS.forEach((key) => {
      const slot = normalizeSlot(save?.equipment?.[key]);
      this.equipment[key] = slot && BLOCKS[slot.id]?.equip === key ? slot : null;
    });

    // player state
    if (save?.player) {
      const p = save.player;
      this.pos.set(p.x, p.y, p.z);
      this.yaw = p.yaw;
      this.pitch = p.pitch;
      this.health = p.health;
      this.air = Math.max(0, Math.min(20, p.air ?? 20));
      this.hunger = normalizeHunger(p.hunger);
      this.regeneration = Math.max(0, Math.min(8, p.regeneration ?? 0));
      this.flying = p.flying && meta.mode === 'creative';
      this.hasSavedPos = !save?.needsSpawn;
    } else {
      const [sx, sz] = this.world.findSpawn();
      this.pos.set(sx, CH, sz);
    }
    if (save?.inventory) this.inventory = Array.from({ length: 36 }, (_, i) => normalizeSlot(save.inventory?.[i]));
    else if (meta.mode === 'creative') DEFAULT_CREATIVE_HOTBAR.forEach((id, i) => (this.inventory[i] = { id, count: 1 }));
    else this.inventory[8] = makeSlot(I.APPLE, 3);
    this.cursor = normalizeSlot(save?.cursor);
    this.personalCraft = Array.from({ length: 4 }, (_, i) => normalizeSlot(save?.personalCraft?.[i]));
    this.settleInventory();
    this.inventory.forEach((slot) => { if (slot && !this.adventure.collected.includes(slot.id)) this.adventure.collected.push(slot.id); });
    this.selected = Math.max(0, Math.min(8, save?.selected ?? 0));
    this.time = save?.time ?? 0.28;
    this.fallStart = this.pos.y;
    this.dead = this.health <= 0;

    // selection outline
    const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004));
    this.selection = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.7 }));
    this.selection.visible = false;
    this.scene.add(this.selection);
    this.placementOutline = new THREE.LineSegments(edges.clone(), new THREE.LineBasicMaterial({ color: 0xc8eea2, transparent: true, opacity: 0.8 }));
    this.placementOutline.visible = false; this.scene.add(this.placementOutline);

    this.crack = new THREE.Mesh(
      new THREE.BoxGeometry(1.006, 1.006, 1.006),
      new THREE.MeshBasicMaterial({ map: this.makeCrackTexture(), transparent: true, depthWrite: false, opacity: 0, fog: false }),
    );
    this.crack.visible = false;
    this.scene.add(this.crack);

    // sky
    this.sun = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshBasicMaterial({ map: this.makeSunTexture(false), transparent: true, fog: false, depthWrite: false }));
    this.moon = new THREE.Mesh(new THREE.PlaneGeometry(28, 28), new THREE.MeshBasicMaterial({ map: this.makeSunTexture(true), transparent: true, fog: false, depthWrite: false }));
    this.sun.renderOrder = -10;
    this.moon.renderOrder = -10;
    this.scene.add(this.sun, this.moon);

    const starPos: number[] = [];
    for (let i = 0; i < 700; i++) {
      const u = Math.random() * Math.PI * 2;
      const v = Math.acos(Math.random() * 1.6 - 0.6);
      starPos.push(Math.sin(v) * Math.cos(u) * 400, Math.cos(v) * 400, Math.sin(v) * Math.sin(u) * 400);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.Float32BufferAttribute(starPos, 3));
    this.stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, transparent: true, fog: false, depthWrite: false }));
    this.stars.renderOrder = -11;
    this.scene.add(this.stars);

    this.clouds = this.makeClouds();
    this.scene.add(this.clouds);

    this.firstPerson = new FirstPersonView(this.camera, settings);
    this.updateHand();

    this.mobRealms = save?.mobs ?? {};
    this.combat = new CombatSystem(this, this.mobRealms[this.dimension]);
    this.drops = new DropSystem(this, save?.drops);
    this.portals = new PortalSystem(this, save?.portals);
    this.primedRealms = save?.primedTnt ?? {};
    this.restorePrimedTnt();
    subscribeCaptions((text) => { this.subtitle = text; this.subtitleTimer = 3; });

    this.applySettings(settings, null);

    const onResize = () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.applyResolution();
    };
    window.addEventListener('resize', onResize);
    this.disposers.push(() => window.removeEventListener('resize', onResize));
    const onLost = (event: Event) => { event.preventDefault(); this.contextLost = true; this.setPaused(true); this.notify('Renderização interrompida. Aguarde ou reabra o mundo.'); this.cb.onPointerUnlock?.(); this.cb.onAutosave?.(this.serialize()); };
    const onRestored = () => { this.contextLost = false; this.texture.needsUpdate = true; this.applyResolution(); };
    canvas.addEventListener('webglcontextlost', onLost);
    canvas.addEventListener('webglcontextrestored', onRestored);
    this.disposers.push(() => { canvas.removeEventListener('webglcontextlost', onLost); canvas.removeEventListener('webglcontextrestored', onRestored); subscribeCaptions(null); });
    this.setupDesktop(canvas);
  }

  // ---------- setup helpers ----------
  private worldAtlasCanvas() {
    const atlas = buildAtlas(this.settings.texturePack);
    if (this.settings.fancyLeaves) return atlas.canvas;
    const canvas = document.createElement('canvas'); canvas.width = atlas.canvas.width; canvas.height = atlas.canvas.height;
    const context = canvas.getContext('2d')!; context.drawImage(atlas.canvas, 0, 0);
    for (const id of LEAF_IDS) {
      const tile = BLOCKS[id].tiles[1], image = atlas.tiles[tile].getContext('2d')!.getImageData(0, 0, atlas.size, atlas.size);
      const color = atlas.colors[tile];
      for (let i = 0; i < image.data.length; i += 4) if (image.data[i + 3] < 128) {
        image.data[i] = color[0] * 0.78; image.data[i + 1] = color[1] * 0.78; image.data[i + 2] = color[2] * 0.78; image.data[i + 3] = 255;
      }
      context.putImageData(image, tile % ATLAS_COLS * atlas.size, Math.floor(tile / ATLAS_COLS) * atlas.size);
    }
    return canvas;
  }

  private makeTexture(canvas: HTMLCanvasElement) {
    const t = new THREE.CanvasTexture(canvas);
    t.magFilter = THREE.NearestFilter;
    t.minFilter = this.settings.mipmaps ? THREE.NearestMipmapNearestFilter : THREE.NearestFilter;
    t.generateMipmaps = this.settings.mipmaps;
    t.anisotropy = Math.min(this.settings.anisotropy, this.renderer.capabilities.getMaxAnisotropy());
    t.colorSpace = THREE.NoColorSpace;
    return t;
  }

  private makeCrackTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const ctx = c.getContext('2d')!;
    ctx.strokeStyle = 'rgba(0,0,0,0.9)';
    ctx.lineWidth = 2;
    let seed = 7;
    const r = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let k = 0; k < 7; k++) {
      ctx.beginPath();
      let x = 16, y = 16;
      ctx.moveTo(x, y);
      for (let s = 0; s < 5; s++) {
        x += (r() - 0.5) * 14;
        y += (r() - 0.5) * 14;
        ctx.lineTo(Math.round(x), Math.round(y));
      }
      ctx.stroke();
    }
    const t = new THREE.CanvasTexture(c);
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    return t;
  }

  private makeSunTexture(moon: boolean) {
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const ctx = c.getContext('2d')!;
    if (moon) {
      ctx.fillStyle = '#dfe4ee';
      ctx.fillRect(6, 6, 20, 20);
      ctx.fillStyle = '#b8bfcc';
      ctx.fillRect(10, 10, 5, 5);
      ctx.fillRect(18, 17, 4, 4);
      ctx.fillRect(12, 20, 3, 3);
    } else {
      ctx.fillStyle = 'rgba(255,240,150,0.35)';
      ctx.fillRect(2, 2, 28, 28);
      ctx.fillStyle = '#fff6a0';
      ctx.fillRect(7, 7, 18, 18);
      ctx.fillStyle = '#ffffe8';
      ctx.fillRect(10, 10, 12, 12);
    }
    const t = new THREE.CanvasTexture(c);
    t.magFilter = THREE.NearestFilter;
    return t;
  }

  private makeClouds() {
    const N = 128;
    const c = document.createElement('canvas');
    c.width = c.height = N;
    const ctx = c.getContext('2d')!;
    const img = ctx.createImageData(N, N);
    const grid = new Float32Array(16 * 16).map(() => Math.random());
    const g = (x: number, y: number) => grid[((y + 16) % 16) * 16 + ((x + 16) % 16)];
    for (let y = 0; y < N; y++)
      for (let x = 0; x < N; x++) {
        const fx = (x / N) * 16, fy = (y / N) * 16;
        const x0 = Math.floor(fx), y0 = Math.floor(fy);
        const tx = fx - x0, ty = fy - y0;
        const v = (g(x0, y0) * (1 - tx) + g(x0 + 1, y0) * tx) * (1 - ty) + (g(x0, y0 + 1) * (1 - tx) + g(x0 + 1, y0 + 1) * tx) * ty;
        const on = v + Math.random() * 0.12 > 0.62;
        const i = (y * N + x) * 4;
        img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
        img.data[i + 3] = on ? 220 : 0;
      }
    ctx.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(c);
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    const SIZE = 1536;
    const geo = new THREE.PlaneGeometry(SIZE, SIZE, 16, 16);
    const p = geo.attributes.position;
    const cols: number[] = [];
    for (let i = 0; i < p.count; i++) {
      const d = Math.sqrt(p.getX(i) ** 2 + p.getY(i) ** 2) / (SIZE / 2);
      const a = Math.max(0, Math.min(1, (1 - d) / 0.45));
      cols.push(1, 1, 1, a);
    }
    geo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 4));
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: t, transparent: true, vertexColors: true, fog: false, depthWrite: false, side: THREE.DoubleSide }));
    m.rotation.x = -Math.PI / 2;
    m.position.y = CH + 10;
    m.renderOrder = 5;
    return m;
  }

  private updateHand() {
    this.firstPerson?.setState(this.inventory[this.selected], this.equipment);
  }

  private applyResolution() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.renderer.setPixelRatio(Math.max(0.25, dpr * this.effectiveResolution));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
  }

  private setupDesktop(canvas: HTMLCanvasElement) {
    let dragging = false;
    let mouseX = 0, mouseY = 0;
    const onClick = () => {
      if (!this.paused && document.pointerLockElement !== canvas) this.lockPointer();
    };
    const onMove = (e: MouseEvent) => {
      if (this.paused) return;
      const locked = document.pointerLockElement === canvas;
      if (!locked && !dragging) return;
      const dx = locked ? e.movementX : e.clientX - mouseX, dy = locked ? e.movementY : e.clientY - mouseY;
      mouseX = e.clientX; mouseY = e.clientY;
      this.input.lookX += dx * 0.0022 * this.settings.sensitivity;
      this.input.lookY += dy * 0.0022 * this.settings.sensitivity * (this.settings.invertY ? -1 : 1);
    };
    const onDown = (e: MouseEvent) => {
      if (this.paused) return;
      if (document.pointerLockElement !== canvas) {
        if (e.target !== canvas || this.isTouch) return;
        if (e.button === 0) { dragging = true; mouseX = e.clientX; mouseY = e.clientY; }
        if (e.button === 2) this.input.place = true;
        return;
      }
      if (e.button === 0) this.input.breaking = true;
      if (e.button === 2) {
        this.input.place = true;
        this.input.useHeld = true;
        const held = this.inventory[this.selected];
        this.input.blocking = !!this.equipment.offhand && !(held && (BLOCKS[held.id]?.food || [I.BOW, I.CROSSBOW, I.TRIDENT].includes(held.id as 128 | 129 | 130)));
      }
      if (e.button === 1 && this.target && this.meta.mode === 'creative') this.pickBlock(this.target.id);
    };
    const onUp = (e: MouseEvent) => {
      dragging = false;
      if (e.button === 0) this.input.breaking = false;
      if (e.button === 2) { this.input.blocking = false; this.input.useHeld = false; }
    };
    const onWheel = (e: WheelEvent) => {
      if (this.paused) return;
      this.selectSlot((this.selected + (e.deltaY > 0 ? 1 : 8)) % 9);
    };
    const onLock = () => {
      if (document.pointerLockElement !== canvas) {
        this.input.breaking = false;
        this.keys.clear();
        this.cb.onPointerUnlock?.();
      }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      const focused = e.target as HTMLElement;
      if (e.code === 'Escape' && !document.pointerLockElement && !e.repeat) { this.cb.onKey?.('pause'); return; }
      if (focused?.tagName === 'INPUT' || focused?.tagName === 'TEXTAREA' || focused?.tagName === 'SELECT' || focused?.isContentEditable) return;
      if (e.code === 'KeyE') {
        if (e.repeat) return;
        e.preventDefault();
        if (!this.paused && this.tryOpenCrafting()) return;
        this.cb.onKey?.('inventory');
        return;
      }
      if (e.code === 'KeyJ' && !e.repeat) { this.cb.onKey?.('journal'); return; }
      if (this.paused) return;
      if (this.dead || !this.spawned) return;
      if (e.code === 'Space') e.preventDefault();
      if (e.code === 'KeyQ' && !e.repeat) { this.dropSlot(this.selected, e.ctrlKey); e.preventDefault(); return; }
      if (e.code === 'KeyG' && !e.repeat) { this.drops.collectNearby(true); return; }
      if (e.code === 'KeyZ') this.input.breaking = true;
      if (e.code === 'KeyV' && !e.repeat) { this.input.place = true; this.input.useHeld = true; }
      if (e.code === 'KeyC' || e.code === 'KeyF') {
        this.tryOpenCrafting();
        return;
      }
      if (e.code === 'Space' && !e.repeat) this.jumpPressed();
      if (e.code.startsWith('Digit')) {
        const n = parseInt(e.code.slice(5));
        if (n >= 1 && n <= 9) this.selectSlot(n - 1);
      }
      this.keys.add(e.code);
    };
    const onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.code); if (e.code === 'KeyZ') this.input.breaking = false; if (e.code === 'KeyV') this.input.useHeld = false; };
    const onBlur = () => {
      dragging = false; this.keys.clear(); this.input.breaking = this.input.blocking = false;
      this.input.moveX = this.input.moveY = 0;
      this.setPaused(true); this.cb.onPointerUnlock?.();
    };
    const noCtx = (e: Event) => e.preventDefault();
    canvas.addEventListener('click', onClick);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('mouseup', onUp);
    canvas.addEventListener('wheel', onWheel, { passive: true });
    document.addEventListener('pointerlockchange', onLock);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    canvas.addEventListener('contextmenu', noCtx);
    this.disposers.push(() => {
      canvas.removeEventListener('click', onClick);
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('mouseup', onUp);
      canvas.removeEventListener('wheel', onWheel);
      document.removeEventListener('pointerlockchange', onLock);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      canvas.removeEventListener('contextmenu', noCtx);
      if (document.pointerLockElement) document.exitPointerLock?.();
    });
  }

  // ---------- public API ----------
  start() {
    this.last = performance.now() / 1000;
    let nextFrame = this.last;
    const loop = (t: number) => {
      this.raf = requestAnimationFrame(loop);
      const now = t / 1000;
      const elapsed = now - this.last;
      const limit = this.paused && this.spawned ? 15 : this.settings.fpsLimit;
      if (limit > 0 && now + 0.0005 < nextFrame) return;
      this.last = now;
      nextFrame = limit > 0 ? Math.max(nextFrame + 1 / limit, now) : now;
      this.frame(Math.min(elapsed, 0.05), elapsed);
    };
    this.raf = requestAnimationFrame(loop);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.disposers.forEach((d) => d());
    this.world.chunks.forEach((c) => this.disposeChunkMeshes(c));
    this.combat.dispose();
    this.drops.dispose(); this.portals.dispose();
    this.firstPerson.dispose();
    const disposed = new Set<THREE.Material>();
    this.scene.traverse((object) => {
      const mesh = object as THREE.Mesh;
      mesh.geometry?.dispose();
      if (mesh.material) for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
        if (!disposed.has(mat)) { (mat as THREE.MeshBasicMaterial).map?.dispose(); mat.dispose(); disposed.add(mat); }
      }
    });
    this.particleGeo.dispose();
    this.particleMats.forEach((mat) => mat.dispose());
    this.texture.dispose();
    this.renderer.dispose();
  }

  setPaused(p: boolean) {
    if (this.contextLost || this.dead || this.adventure.victory && !this.adventure.victorySeen) p = true;
    if (this.paused && !p) { this.adaptiveTimer = 0; this.frameAverage = 1 / (this.settings.fpsLimit || this.settings.targetFps); }
    this.paused = p;
    if (!p) { this.openChestKey = null; this.settleInventory(); }
    if (p) {
      this.eating = null;
      this.input.breaking = false;
      this.input.jump = false;
      this.input.down = false;
      this.input.place = false;
      this.input.useHeld = false;
      this.input.blocking = false;
      this.input.lookX = this.input.lookY = 0;
      this.input.moveX = this.input.moveY = 0;
      this.input.sprint = false;
      this.keys.clear();
    }
  }

  lockPointer() {
    if (!this.isTouch) {
      try {
        this.renderer.domElement.requestPointerLock?.()?.catch(() => this.notify('Sem captura: arraste para olhar, Z ataca, V usa e Q solta itens.'));
      } catch { this.notify('Arraste para olhar. Z ataca; V usa; Q solta itens.'); }
    }
  }

  setSettings(s: Settings) {
    const old = this.settings;
    this.settings = s;
    this.applySettings(s, old);
  }

  private applySettings(s: Settings, old: Settings | null) {
    configureAudio(s);
    this.camera.fov = this.zoomed ? 28 : s.fov;
    this.camera.updateProjectionMatrix();
    if (!old || old.resolution !== s.resolution || old.dynamicResolution !== s.dynamicResolution) { this.effectiveResolution = s.resolution; this.applyResolution(); }
    this.clouds.visible = s.clouds;
    this.firstPerson.setSettings(s); this.updateHand();
    if (old && (old.texturePack !== s.texturePack || old.mipmaps !== s.mipmaps || old.anisotropy !== s.anisotropy || old.fancyLeaves !== s.fancyLeaves)) {
      const atlas = buildAtlas(s.texturePack);
      this.atlasColors = atlas.colors;
      const old = this.texture;
      this.texture = this.makeTexture(this.worldAtlasCanvas());
      this.matOpaque.map = this.texture;
      this.matWater.map = this.texture;
      this.matOpaque.needsUpdate = this.matWater.needsUpdate = true;
      old.dispose();
      this.particleMats.forEach((m) => m.dispose());
      this.particleMats.clear();
      this.particles.forEach((particle) => this.scene.remove(particle.mesh)); this.particles = [];
      this.drops?.refreshTextures();
    }
    if (old && (old.ao !== s.ao || old.smoothLight !== s.smoothLight || old.fancyLeaves !== s.fancyLeaves)) {
      this.world.chunks.forEach((c) => (c.dirty = true));
    }
  }

  selectSlot(i: number) {
    if (!Number.isInteger(i) || i < 0 || i > 8) return;
    if (this.selected !== i) sfx.select();
    if (this.selected !== i) this.eating = null;
    this.zoomed = false; this.camera.fov = this.settings.fov; this.camera.updateProjectionMatrix();
    this.selected = i;
    this.updateHand();
    this.emitHud();
  }

  setSlot(i: number, slot: Slot | null) {
    if (i < 0 || i >= 36) return;
    this.inventory[i] = normalizeSlot(slot);
    this.updateHand();
    this.emitHud();
  }

  swapSlots(a: number, b: number) {
    if (a < 0 || b < 0 || a >= 36 || b >= 36 || a === b) return;
    const t = this.inventory[a];
    const destination = this.inventory[b];
    if (t && destination && sameStack(t, destination) && maxStack(t.id) > 1 && destination.count < maxStack(t.id)) {
      const n = Math.min(maxStack(t.id) - destination.count, t.count); destination.count += n; t.count -= n;
      if (!t.count) this.inventory[a] = null;
      this.updateHand(); this.emitHud(); sfx.select(); return;
    }
    this.inventory[a] = this.inventory[b];
    this.inventory[b] = t;
    this.updateHand();
    this.emitHud();
  }

  splitStack(index: number) {
    const slot = this.inventory[index], empty = this.inventory.findIndex((s) => !s);
    if (!slot || slot.count < 2 || empty < 0) return false;
    const count = Math.floor(slot.count / 2); slot.count -= count;
    this.inventory[empty] = { ...slot, count }; this.emitHud(); sfx.select(); return true;
  }

  inventoryClick(area: 'bag' | 'craft', index: number, right = false) {
    if (this.dead || !this.paused) return;
    const slots = area === 'bag' ? this.inventory : this.personalCraft;
    if (!Number.isInteger(index) || index < 0 || index >= slots.length) return;
    const result = clickStack(slots[index], this.cursor, right);
    slots[index] = result.target; this.cursor = result.carried;
    this.updateHand(); this.emitHud(); sfx.select();
  }

  equipmentClick(key: EquipmentSlot) {
    if (this.dead || !this.paused || !ARMOR_SLOTS.includes(key)) return false;
    if (this.cursor && BLOCKS[this.cursor.id]?.equip !== key) { this.notify('Esta peça não cabe neste espaço.'); return false; }
    const slot = this.equipment[key]; this.equipment[key] = this.cursor; this.cursor = slot;
    this.updateHand(); this.emitHud(); sfx.equip(); return true;
  }

  collectMatching(index: number) {
    if (!Number.isInteger(index) || index < 0 || index >= 36) return;
    const wanted = this.cursor ?? this.inventory[index];
    if (!wanted || maxStack(wanted.id) <= 1) return;
    if (!this.cursor) { this.cursor = { ...wanted }; this.inventory[index] = null; }
    for (let i = 0; i < this.inventory.length && this.cursor!.count < maxStack(wanted.id); i++) {
      const item = this.inventory[i]; if (!item || !sameStack(item, wanted)) continue;
      const count = Math.min(item.count, maxStack(wanted.id) - this.cursor!.count);
      this.cursor!.count += count; item.count -= count; if (!item.count) this.inventory[i] = null;
    }
    this.updateHand(); this.emitHud(); sfx.select();
  }

  settleInventory() {
    if (!this.cursor && !this.personalCraft.some(Boolean)) return;
    for (const item of [this.cursor, ...this.personalCraft]) {
      if (!item) continue;
      const remaining = insertItem(this.inventory, item.id, item.count, item);
      if (remaining) this.reserve.push({ ...item, count: remaining });
    }
    this.cursor = null; this.personalCraft = Array(4).fill(null); this.updateHand();
  }

  returnCarried() {
    if (!this.cursor) return;
    const remaining = insertItem(this.inventory, this.cursor.id, this.cursor.count, this.cursor);
    if (remaining) this.reserve.push({ ...this.cursor, count: remaining });
    this.cursor = null; this.updateHand(); this.emitHud();
  }

  dropCarried(all = false) {
    if (!this.cursor || this.dead || !this.spawned) return false;
    const amount = all ? this.cursor.count : 1;
    const origin = this.pos.clone().add(new THREE.Vector3(0, 1.25, 0));
    const velocity = this.camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(3.5); velocity.y += 1;
    if (!this.drops.spawn({ ...this.cursor, count: amount }, origin, velocity, 1.7)) { this.notify('Muitos itens no chão.'); return false; }
    this.cursor.count -= amount; if (!this.cursor.count) this.cursor = null;
    this.emitHud(); sfx.drop(); return true;
  }

  eatCarried() {
    if (!this.cursor || !BLOCKS[this.cursor.id]?.food || this.dead) return false;
    const previous = this.inventory[this.selected];
    this.inventory[this.selected] = this.cursor; this.cursor = previous;
    const success = this.beginEating(this.selected);
    if (!success) { const food = this.inventory[this.selected]; this.inventory[this.selected] = this.cursor; this.cursor = food; }
    this.updateHand(); this.emitHud(); return success;
  }

  personalRecipeIndex() { return findGridRecipe(this.personalCraft.map((slot) => slot?.id ?? null), 2, 'hand'); }

  takePersonalCraft(toInventory = false, repeat = false) {
    if (this.dead || !this.paused) return false;
    let made = 0;
    for (let iteration = 0; iteration < (repeat ? 64 : 1); iteration++) {
      const index = this.personalRecipeIndex(); if (index < 0) break;
      const recipe = RECIPES[index], output = makeSlot(recipe.out, recipe.count);
      const next = cloneInventory(this.inventory);
      if (toInventory) { if (insertItem(next, recipe.out, recipe.count)) break; }
      else if (this.cursor && (!sameStack(this.cursor, output) || this.cursor.count + recipe.count > maxStack(recipe.out))) break;
      else if (recipe.count > maxStack(recipe.out)) break;
      this.personalCraft = this.personalCraft.map((slot) => !slot || slot.count <= 1 ? null : { ...slot, count: slot.count - 1 });
      if (toInventory) this.inventory = next;
      else this.cursor = this.cursor ? { ...this.cursor, count: this.cursor.count + recipe.count } : output;
      this.recordItem(recipe.out, true); made++;
    }
    if (made) { this.updateHand(); this.emitHud(); sfx.craft(); }
    else this.craftError = 'Libere espaço ou complete os ingredientes.';
    return made > 0;
  }

  fillPersonalRecipe(index: number) {
    const recipe = RECIPES[index];
    if (!recipe || !allowedRecipe(recipe, 'hand', 2)) return false;
    const bag = cloneInventory(this.inventory);
    for (const item of this.personalCraft) if (item && insertItem(bag, item.id, item.count, item)) { this.craftError = 'Libere espaço antes de trocar a receita.'; return false; }
    const grid = fillRecipeGrid(recipe, 2, bag);
    const ingredients: (Slot | null)[] = Array(4).fill(null);
    for (let i = 0; i < 4; i++) {
      const id = grid[i]; if (id === null) continue;
      const source = bag.findIndex((item) => item?.id === id && item.count > 0);
      if (source < 0) {
        if (this.meta.mode !== 'creative') { this.craftError = 'Você ainda não tem todos os ingredientes.'; return false; }
        ingredients[i] = makeSlot(id); continue;
      }
      ingredients[i] = { ...bag[source]!, count: 1 }; bag[source]!.count--; if (!bag[source]!.count) bag[source] = null;
    }
    this.inventory = bag; this.personalCraft = ingredients; this.updateHand(); this.emitHud(); sfx.select(); return true;
  }

  receiveDrop(slot: Slot) {
    const left = insertItem(this.inventory, slot.id, slot.count, slot);
    if (left < slot.count) { this.recordItem(slot.id); this.updateHand(); }
    return left;
  }

  dropLoot(id: number, count: number, position: THREE.Vector3, template?: Slot) {
    if (!BLOCKS[id] || count <= 0) return;
    const slot = template ? { ...template, count } : makeSlot(id, count);
    if (!this.drops.spawn(slot, position, new THREE.Vector3((Math.random() - 0.5) * 2, 2.7, (Math.random() - 0.5) * 2))) {
      this.reserve.push(slot); this.notify('Limite de itens no chão: excedente guardado na Reserva.');
    }
  }

  dropSlot(index = this.selected, all = false) {
    if (this.dead || !this.spawned) return false;
    const slot = this.inventory[index];
    if (!slot) return false;
    const count = all ? slot.count : 1;
    const direction = this.camera.getWorldDirection(new THREE.Vector3());
    const origin = this.pos.clone().add(new THREE.Vector3(0, 1.3, 0));
    if (!this.drops.spawn({ ...slot, count }, origin, direction.multiplyScalar(4).add(new THREE.Vector3(0, 1, 0)), 1.7)) { this.notify('Muitos itens no chão. Recolha alguns antes de soltar mais.'); return false; }
    slot.count -= count; if (!slot.count) this.inventory[index] = null;
    this.updateHand(); this.emitHud(); sfx.drop(); return true;
  }

  pickBlock(id: number) {
    const existing = this.inventory.slice(0, 9).findIndex((s) => s?.id === id);
    if (existing >= 0) this.selectSlot(existing);
    else this.setSlot(this.selected, { id, count: 1 });
  }

  countItem(id: number) {
    return itemCount(this.inventory, id);
  }

  countIngredient(id: number) { return ingredientCount(this.inventory, id); }

  craftManual(grid: CraftCell[], size: 2 | 3, station: Station) {
    if (!this.canUseStation(station) || (size === 3 && station !== 'bench') || (size === 2 && station !== 'hand')) { this.craftError = 'Abra a estação de criação correta.'; return false; }
    const result = craftGrid(this.inventory, grid, size, station, this.meta.mode === 'creative');
    if (!result.ok) { this.craftError = result.reason; return false; }
    this.inventory = result.inventory; this.recordItem(RECIPES[result.recipeIndex].out, true);
    this.updateHand(); this.emitHud(); sfx.craft(); return true;
  }

  sortBackpack() {
    this.settleInventory();
    this.inventory = [...this.inventory.slice(0, 9), ...organizeSlots(this.inventory.slice(9))];
    this.emitHud(); sfx.select();
  }

  quickMove(index: number) {
    const slot = this.inventory[index]; if (!slot) return;
    const source = cloneInventory(this.inventory);
    const start = index < 9 ? 9 : 0, end = index < 9 ? 36 : 9;
    const target = source.slice(start, end);
    const moved = transferStack(source, target, index);
    if (!moved) { this.notify('Nenhum espaço disponível no destino.'); return; }
    target.forEach((item, i) => { source[start + i] = item; });
    this.inventory = source; this.updateHand(); this.emitHud(); sfx.select();
  }

  canCraft(ri: number, station: Station = 'hand') {
    const r = RECIPES[ri];
    if (!r || !this.canUseStation(station)) return false;
    const needed = recipeStation(r);
    if (needed !== station && !(needed === 'hand' && station === 'bench')) return false;
    return craftInventory(this.inventory, r, this.meta.mode === 'creative').ok;
  }

  craft(ri: number, station: Station = 'hand') {
    const r = RECIPES[ri];
    if (!r || !this.canUseStation(station) || (recipeStation(r) !== station && !(recipeStation(r) === 'hand' && station === 'bench'))) {
      this.craftError = 'Use a bancada correta.';
      return false;
    }
    const result = craftInventory(this.inventory, r, this.meta.mode === 'creative');
    if (!result.ok) { this.craftError = result.reason; return false; }
    this.inventory = result.inventory;
    this.recordItem(r.out, true);
    if (station === 'furnace') sfx.smelt(); else sfx.craft();
    this.updateHand();
    this.emitHud();
    return true;
  }

  addItem(id: number, n: number) {
    if (!BLOCKS[id] || n <= 0) return;
    const left = insertItem(this.inventory, id, n);
    if (left) {
      this.reserve.push(makeSlot(id, left));
      this.notify('Inventário cheio. Recolha os itens na Reserva do inventário.');
    }
    this.recordItem(id);
    this.updateHand();
  }

  private recordItem(id: number, crafted = false) {
    if (!this.adventure.collected.includes(id)) this.adventure.collected.push(id);
    if (crafted && !this.adventure.crafted.includes(id)) {
      this.adventure.crafted.push(id);
      this.adventure.xp += 1;
    }
  }

  collectReserve() {
    this.reserve = this.reserve.flatMap((slot) => {
      const remaining = insertItem(this.inventory, slot.id, slot.count, slot);
      return remaining ? [{ ...slot, count: remaining }] : [];
    });
    this.updateHand(); this.emitHud();
  }

  notify(text: string) { this.notice = text; this.noticeTimer = 3.5; }

  canUseStation(station: Station) {
    if (station === 'hand') return true;
    const t = this.stationTarget;
    return !!t && STATION_BLOCKS[this.world.getBlock(t.x, t.y, t.z)] === station
      && this.pos.distanceTo(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5)) < 8;
  }

  equipItem(index: number) {
    const slot = this.inventory[index];
    const key = slot && BLOCKS[slot.id]?.equip;
    if (!slot || !key) return false;
    this.inventory[index] = this.equipment[key];
    this.equipment[key] = slot;
    this.updateHand(); this.emitHud(); sfx.equip();
    return true;
  }

  useInventoryItem(index: number) {
    const slot = this.inventory[index];
    if (!slot) return false;
    if (BLOCKS[slot.id].equip) return this.equipItem(index);
    return this.beginEating(index);
  }

  canEat(index: number) {
    const slot = this.inventory[index], item = slot && BLOCKS[slot.id];
    return !!item?.food && (this.hunger.food < 20 || !this.settings.hungerEnabled && this.health < 20 || !!item.regeneration && this.health < 20 || this.meta.mode === 'creative');
  }

  private beginEating(index: number) {
    if (this.dead || this.eating || !this.canEat(index)) { if (!this.eating) this.notify('Você está bem alimentado.'); return false; }
    if (index >= 9) { const previous = this.inventory[this.selected]; this.inventory[this.selected] = this.inventory[index]; this.inventory[index] = previous; index = this.selected; this.updateHand(); }
    else this.selectSlot(index);
    const slot = this.inventory[index]!;
    this.eating = { index, id: slot.id, progress: 0 }; this.eatingSound = 0;
    this.input.breaking = false; this.input.blocking = false;
    this.emitHud(); return true;
  }

  private spendEnergy(amount: number) {
    if (this.meta.mode === 'survival' && this.settings.hungerEnabled && this.settings.difficulty !== 'peaceful') {
      const before = this.hunger.food;
      exhaust(this.hunger, amount);
      if (before > 6 && this.hunger.food <= 6) this.notify('A fome está baixa. Coma para voltar a correr.');
    }
  }

  private updateSurvival(dt: number) {
    if (this.eating) {
      const slot = this.inventory[this.eating.index];
      if (!slot || slot.id !== this.eating.id || slot.count <= 0) this.eating = null;
      else {
        this.eating.progress += dt / 1.35; this.eatingSound -= dt;
        if (this.eatingSound <= 0) { sfx.eat(); this.eatingSound = 0.55; }
        if (this.eating.progress >= 1) {
          const item = BLOCKS[slot.id];
          feed(this.hunger, item.food ?? 0, item.saturation ?? 0);
          if (!this.settings.hungerEnabled) this.health = Math.min(20, this.health + (item.food ?? 0));
          this.regeneration = Math.max(this.regeneration, item.regeneration ?? 0);
          if (this.meta.mode !== 'creative') { slot.count--; if (!slot.count) this.inventory[this.eating.index] = null; if (item.returns) this.addItem(item.returns, 1); }
          this.eating = null; this.updateHand(); this.emitHud(); sfx.pop();
        }
      }
    }
    if (this.meta.mode !== 'survival') return;
    this.hungerTimer += dt;
    if (this.hungerTimer >= 1) {
      this.hungerTimer = 0;
      if (this.regeneration > 0) { this.health = Math.min(20, this.health + 1); this.regeneration--; }
      if (!this.settings.hungerEnabled || this.settings.difficulty === 'peaceful') { this.hunger.food = Math.min(20, this.hunger.food + 1); this.hunger.saturation = Math.min(this.hunger.food, Math.max(5, this.hunger.saturation)); }
    }
    const fed = !this.settings.hungerEnabled || this.settings.difficulty === 'peaceful' || this.hunger.food >= 18;
    if (this.settings.naturalRegeneration && fed && this.health < 20 && this.adventure.elapsed - this.lastDamage > 3) {
      this.regenT += dt;
      if (this.regenT >= 4) { this.regenT = 0; this.health = Math.min(20, this.health + 1); this.spendEnergy(4); }
    } else this.regenT = 0;
    if (this.settings.hungerEnabled && this.hunger.food <= 0) {
      this.starvationTimer += dt;
      if (this.starvationTimer >= 4) { this.starvationTimer = 0; if (this.health > starvationFloor(this.settings.difficulty)) this.damage(1, undefined, 'starve'); }
    } else this.starvationTimer = 0;
  }

  private chestKey(x: number, y: number, z: number) { return `${this.dimension}:${x},${y},${z}`; }
  private chestAccessible() {
    if (!this.openChestKey || !this.openChestKey.startsWith(`${this.dimension}:`)) return false;
    const [x, y, z] = this.openChestKey.split(':')[1].split(',').map(Number);
    return this.world.getBlock(x, y, z) === B.CHEST && this.pos.distanceTo(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5)) < 7;
  }
  transferChest(fromChest: boolean, index: number, one = false) {
    if (!this.chestAccessible() || this.dead) return false;
    const chest = this.chests[this.openChestKey!] ??= Array(27).fill(null);
    const moved = transferStack(fromChest ? chest : this.inventory, fromChest ? this.inventory : chest, index, one ? 1 : Infinity);
    if (!moved) this.notify('O destino não tem espaço para este item.');
    this.updateHand(); this.emitHud(); if (moved) sfx.select(); return moved > 0;
  }
  transferAllChest(toChest: boolean) {
    if (!this.chestAccessible()) return;
    const chest = this.chests[this.openChestKey!] ??= Array(27).fill(null);
    const source = toChest ? this.inventory : chest;
    for (let i = toChest ? 9 : 0; i < source.length; i++) transferStack(source, toChest ? chest : this.inventory, i);
    this.updateHand(); this.emitHud(); sfx.select();
  }
  private spillChest(x: number, y: number, z: number) {
    const key = this.chestKey(x, y, z), slots = this.chests[key];
    if (slots) { for (const slot of slots) if (slot) this.dropLoot(slot.id, slot.count, new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), slot); delete this.chests[key]; }
  }

  unequipItem(key: EquipmentSlot) {
    const slot = this.equipment[key];
    if (!slot) return;
    const next = cloneInventory(this.inventory);
    if (insertItem(next, slot.id, 1, slot)) { this.notify('Libere um espaço no inventário.'); return; }
    this.inventory = next; this.equipment[key] = null;
    this.updateHand(); this.emitHud();
  }

  armorPoints() {
    return Math.min(20, ARMOR_SLOTS.reduce((total, key) => {
      const slot = this.equipment[key];
      return total + (slot && key !== 'offhand' ? (BLOCKS[slot.id].protection ?? 0) + (slot.enchant ?? 0) : 0);
    }, 0));
  }

  enchantItem(index: number) {
    const slot = this.inventory[index];
    if (!slot || !BLOCKS[slot.id].durability || !this.canUseStation('enchanting')) return false;
    if ((slot.enchant ?? 0) >= 3) { this.craftError = 'Encantamento máximo: III.'; return false; }
    if (this.meta.mode !== 'creative' && (this.adventure.xp < 5 || !consume(this.inventory, [[I.LAPIS, 3], [I.AMETHYST, 1]]))) {
      this.craftError = 'Precisa de 5 XP, 3 lápis-lazúli e 1 ametista.'; return false;
    }
    if (this.meta.mode !== 'creative') this.adventure.xp -= 5;
    slot.enchant = (slot.enchant ?? 0) + 1;
    slot.durability = BLOCKS[slot.id].durability;
    this.emitHud(); sfx.enchant(); return true;
  }

  private wearHeld(amount = 1) {
    if (this.meta.mode === 'creative') return;
    const slot = this.inventory[this.selected];
    if (!slot || !BLOCKS[slot.id].durability) return;
    slot.durability = (slot.durability ?? BLOCKS[slot.id].durability!) - amount;
    if (slot.durability <= 0) { sfx.toolBreak(); this.notify(`${BLOCKS[slot.id].name} quebrou.`); this.inventory[this.selected] = null; this.updateHand(); }
  }

  jumpPressed() {
    const now = performance.now();
    if (this.meta.mode === 'creative' && now - this.lastJumpPress < 300) {
      this.flying = !this.flying;
      this.vel.y = 0;
      this.lastJumpPress = 0;
      this.emitHud();
      return;
    }
    this.lastJumpPress = now;
  }

  toggleFly() {
    if (this.meta.mode !== 'creative') return;
    this.flying = !this.flying;
    this.vel.y = 0;
    this.emitHud();
  }

  tryOpenCrafting() {
    if (this.paused || this.dead || !this.spawned) return false;
    const target = this.raycast(this.meta.mode === 'creative' ? 7 : 5);
    if (target?.id === B.CHEST) {
      if (isSolid(this.world.getBlock(target.x, target.y + 1, target.z))) { this.notify('O baú precisa de espaço livre acima da tampa.'); return true; }
      this.openChestKey = this.chestKey(target.x, target.y, target.z);
      this.chests[this.openChestKey] ??= Array(27).fill(null);
      this.setPaused(true); this.emitHud(); sfx.open(); this.cb.onOpenChest?.(); return true;
    }
    if (target && STATION_BLOCKS[target.id]) {
      this.craftingStation = STATION_BLOCKS[target.id]!;
      this.stationTarget = target;
      this.swing = 1;
      this.setPaused(true);
      sfx.open();
      this.cb.onOpenCrafting?.();
      return true;
    }
    if (target && (target.id === B.NETHER_GATE || target.id === B.END_GATE)) {
      this.portals.expandLegacy(target.x, target.y, target.z, target.id === B.END_GATE);
      return true;
    }
    return false;
  }

  respawn() {
    this.combat.recoverThrownItems();
    if (this.dimension !== 'overworld') this.enterDimension('overworld');
    const [sx, sz] = this.world.findSpawn();
    this.pos.set(sx, CH - 1, sz);
    this.vel.set(0, 0, 0);
    this.health = 20;
    this.air = 20;
    this.hunger = freshHunger(); this.eating = null; this.regeneration = 0;
    this.dead = false;
    this.spawned = false;
    this.hasSavedPos = false;
    this.damageCooldown = 3;
    this.emitHud();
  }

  enterDimension(dimension: Dimension) {
    if (dimension === this.dimension) return;
    this.combat.recoverThrownItems();
    if (this.dimension === 'overworld') this.returnPoint = [this.pos.x, this.pos.y, this.pos.z];
    this.realms[this.dimension] = this.world.serializeMods();
    this.realmStates[this.dimension] = this.world.serializeStates();
    this.mobRealms[this.dimension] = this.combat.serialize();
    this.primedRealms[this.dimension] = this.tnts.map(({ x, y, z, t }) => ({ x, y, z, remaining: t }));
    this.world.chunks.forEach((chunk) => this.disposeChunkMeshes(chunk));
    this.world.chunks.clear();
    this.combat.reset();
    this.drops.hideAll();
    this.environmentalQueue.clear();
    this.particles.forEach((p) => this.scene.remove(p.mesh)); this.particles = [];
    this.tnts.forEach((t) => { this.scene.remove(t.mesh); t.mesh.geometry.dispose(); }); this.tnts = [];
    this.dimension = dimension;
    this.world = new World(this.meta.seed, this.meta.type, this.realms[dimension], dimension, this.generatorVersion, this.realmStates[dimension]);
    this.combat.restore(this.mobRealms[dimension]);
    this.restorePrimedTnt();
    if (dimension === 'overworld' && this.returnPoint) { this.pos.set(...this.returnPoint); this.hasSavedPos = true; }
    else { const [x, z] = this.world.findSpawn(); this.pos.set(x, CH - 1, z); this.hasSavedPos = false; }
    if (dimension === 'nether') this.adventure.netherVisited = true;
    if (dimension === 'end') this.adventure.endVisited = true;
    this.vel.set(0, 0, 0); this.target = null; this.stationTarget = null;
    this.openChestKey = null; this.eating = null; this.biomeTimer = 1;
    this.input.breaking = false; this.input.place = false; this.input.blocking = false;
    this.input.useHeld = false;
    this.input.moveX = this.input.moveY = 0;
    this.input.lookX = this.input.lookY = 0;
    this.zoomed = false; this.camera.fov = this.settings.fov;
    this.flying = false; this.spawned = false; this.yaw = 0; this.pitch = 0;
    this.selection.visible = this.crack.visible = false;
    this.placementOutline.visible = false;
    this.damageCooldown = 3;
    this.notify(`Você chegou: ${DIMENSION_NAMES[dimension]}.`);
    this.portals.cooldown = 5; this.portals.charge = 0; this.portals.refresh();
    this.emitHud();
  }

  acknowledgeVictory() {
    this.adventure.victorySeen = true;
    this.emitHud(); this.cb.onAutosave?.(this.serialize());
  }

  serialize(): WorldSave {
    this.realms[this.dimension] = this.world.serializeMods();
    this.realmStates[this.dimension] = this.world.serializeStates();
    this.mobRealms[this.dimension] = this.combat.serialize();
    this.primedRealms[this.dimension] = this.tnts.map(({ x, y, z, t }) => ({ x, y, z, remaining: t }));
    const { overworld, ...otherRealms } = this.realms;
    const safeY = !this.spawned && !this.hasSavedPos ? Math.max(1, this.world.heightAt(this.pos.x, this.pos.z) + 1) : this.pos.y;
    return {
      version: 4,
      mods: overworld ?? {},
      player: { x: this.pos.x, y: safeY, z: this.pos.z, yaw: this.yaw, pitch: this.pitch, health: this.health, flying: this.flying, air: this.air, hunger: { ...this.hunger }, regeneration: this.regeneration },
      inventory: this.inventory,
      selected: this.selected,
      time: this.time,
      dimension: this.dimension,
      realms: otherRealms,
      adventure: this.adventure,
      equipment: this.equipment,
      returnPoint: this.returnPoint ?? undefined,
      crops: this.crops,
      reserve: this.reserve,
      drops: [...this.drops.serialize(), ...this.combat.serializeFlyingItems()],
      portals: this.portals.records.map((p) => ({ ...p })),
      deathPoint: this.deathPoint,
      needsSpawn: !this.spawned && !this.hasSavedPos,
      generatorVersion: this.generatorVersion,
      states: this.realmStates,
      chests: this.chests,
      saplings: this.saplings,
      waypoint: this.waypoint,
      cursor: this.cursor ? { ...this.cursor } : null,
      personalCraft: cloneInventory(this.personalCraft),
      mobs: this.mobRealms,
      primedTnt: this.primedRealms,
    };
  }

  // ---------- world / chunks ----------
  private computeOffsets() {
    const R = this.settings.renderDistance;
    if (R === this.offsetsR) return;
    this.offsetsR = R;
    const list: [number, number, number][] = [];
    for (let dz = -R - 1; dz <= R + 1; dz++) for (let dx = -R - 1; dx <= R + 1; dx++) list.push([dx, dz, dx * dx + dz * dz]);
    list.sort((a, b) => a[2] - b[2]);
    this.offsets = list;
  }

  private disposeChunkMeshes(c: Chunk) {
    if (c.opaque) {
      this.scene.remove(c.opaque);
      c.opaque.geometry.dispose();
      c.opaque = null;
    }
    if (c.water) {
      this.scene.remove(c.water);
      c.water.geometry.dispose();
      c.water = null;
    }
    c.meshed = false;
  }

  private meshChunk(c: Chunk) {
    const { opaque, water } = buildChunkGeometry(this.world, c, this.settings);
    this.disposeChunkMeshes(c);
    if (opaque) {
      const m = new THREE.Mesh(opaque, this.matOpaque);
      m.position.set(c.cx * CS, 0, c.cz * CS);
      m.matrixAutoUpdate = false;
      m.updateMatrix();
      this.scene.add(m);
      c.opaque = m;
    }
    if (water) {
      const m = new THREE.Mesh(water, this.matWater);
      m.position.set(c.cx * CS, 0, c.cz * CS);
      m.matrixAutoUpdate = false;
      m.updateMatrix();
      m.renderOrder = 2;
      this.scene.add(m);
      c.water = m;
    }
    c.dirty = false;
    c.meshed = true;
  }

  private neighborsReady(cx: number, cz: number) {
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (!this.world.getChunk(cx + dx, cz + dz)) return false;
    return true;
  }

  private updateChunks(budgetMs: number) {
    this.computeOffsets();
    const R = this.settings.renderDistance;
    const r2 = (R + 0.5) * (R + 0.5);
    const pcx = Math.floor(this.pos.x / CS), pcz = Math.floor(this.pos.z / CS);
    const deadline = performance.now() + budgetMs;
    let ops = 0;
    for (let i = 0; i < this.offsets.length; i++) {
      const [dx, dz, d2] = this.offsets[i];
      const cx = pcx + dx, cz = pcz + dz;
      const c = this.world.getChunk(cx, cz);
      if (!c) {
        if (ops > 0 && performance.now() > deadline) break;
        this.world.generate(cx, cz);
        ops++;
        continue;
      }
      if (d2 <= r2 && (c.dirty || !c.meshed) && this.neighborsReady(cx, cz)) {
        if (ops > 0 && performance.now() > deadline) break;
        this.meshChunk(c);
        ops++;
      }
    }
  }

  private unloadFar() {
    const R = this.settings.renderDistance;
    const r2 = (R + 1.5) * (R + 1.5);
    const pcx = Math.floor(this.pos.x / CS), pcz = Math.floor(this.pos.z / CS);
    const remove: string[] = [];
    this.world.chunks.forEach((c, k) => {
      const dx = c.cx - pcx, dz = c.cz - pcz;
      if (Math.abs(dx) > R + 3 || Math.abs(dz) > R + 3) {
        this.disposeChunkMeshes(c);
        remove.push(k);
      } else if (c.meshed && dx * dx + dz * dz > r2) {
        this.disposeChunkMeshes(c);
      }
    });
    remove.forEach((k) => this.world.chunks.delete(k));
  }

  // ---------- physics ----------
  private solidAt(x: number, y: number, z: number) {
    const id = this.world.getBlock(x, y, z);
    return id === -1 || isSolid(id);
  }

  private collidesAt(px: number, py: number, pz: number) {
    return overlapsWorld(this.world, [px - HW, py, pz - HW, px + HW, py + PH, pz + HW]);
  }

  private moveAxis(axis: 0 | 1 | 2, amount: number): boolean {
    if (amount === 0) return false;
    const p = this.pos;
    if (axis === 0) p.x += amount;
    else if (axis === 1) p.y += amount;
    else p.z += amount;
    const x0 = Math.floor(p.x - HW), x1 = Math.floor(p.x + HW - 1e-7);
    const y0 = Math.floor(p.y) - 1, y1 = Math.floor(p.y + PH - 1e-7);
    const z0 = Math.floor(p.z - HW), z1 = Math.floor(p.z + HW - 1e-7);
    let hit = false;
    let bound = amount > 0 ? Infinity : -Infinity;
    const body: Bounds = [p.x - HW, p.y, p.z - HW, p.x + HW, p.y + PH, p.z + HW];
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++)
        for (let x = x0; x <= x1; x++) {
          for (const box of blockBounds(this.world.getBlock(x, y, z), this.world.getState(x, y, z))) {
            if (!intersects(body, box, x, y, z)) continue;
            hit = true;
            const offset = axis === 0 ? x : axis === 1 ? y : z;
            const edge = offset + box[amount > 0 ? axis : axis + 3];
            bound = amount > 0 ? Math.min(bound, edge) : Math.max(bound, edge);
          }
        }
    if (!hit) return false;
    if (axis === 0) p.x = amount > 0 ? bound - HW - 1e-4 : bound + HW + 1e-4;
    else if (axis === 1) p.y = amount > 0 ? bound - PH - 1e-4 : bound;
    else p.z = amount > 0 ? bound - HW - 1e-4 : bound + HW + 1e-4;
    return true;
  }

  private physics(dt: number) {
    const inp = this.input;
    const k = this.keys;
    let fwd = inp.moveY, str = inp.moveX;
    if (k.has('KeyW') || k.has('ArrowUp')) fwd += 1;
    if (k.has('KeyS') || k.has('ArrowDown')) fwd -= 1;
    if (k.has('KeyA') || k.has('ArrowLeft')) str -= 1;
    if (k.has('KeyD') || k.has('ArrowRight')) str += 1;
    const jump = inp.jump || k.has('Space');
    const down = inp.down || k.has('ShiftLeft') || k.has('ShiftRight');
    const canSprint = this.meta.mode === 'creative' || !this.settings.hungerEnabled || this.hunger.food > 6;
    const sprint = canSprint && !this.eating && (inp.sprint || k.has('ControlLeft') || (Math.hypot(inp.moveX, inp.moveY) > 0.95 && inp.moveY > 0.6));

    const len = Math.hypot(fwd, str);
    if (len > 1) {
      fwd /= len;
      str /= len;
    }
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const wx = -sin * fwd + cos * str;
    const wz = -cos * fwd - sin * str;

    const feet = this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y + 0.3), Math.floor(this.pos.z));
    const inWater = feet === B.WATER || this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y + 1), Math.floor(this.pos.z)) === B.WATER;
    if (inWater && !this.wasInWater && this.vel.y < -4) sfx.splash();
    this.wasInWater = inWater;

    let speed = this.flying ? (sprint ? 21 : 11) : sprint ? 5.7 : 4.3;
    if (down && !this.flying) speed *= 0.35;
    if (this.eating) speed *= 0.45;
    if (this.equipment.offhand && (this.input.blocking || k.has('KeyR'))) speed *= 0.55;
    if (inWater && !this.flying) speed *= 0.55;
    const accel = this.flying ? 10 : this.onGround ? 14 : inWater ? 6 : 3.5;
    const a = Math.min(1, dt * accel);
    this.vel.x += (wx * speed - this.vel.x) * a;
    this.vel.z += (wz * speed - this.vel.z) * a;

    if (this.flying) {
      const vy = (jump ? 1 : 0) - (down ? 1 : 0);
      this.vel.y += (vy * 9 - this.vel.y) * Math.min(1, dt * 10);
    } else if (inWater) {
      this.vel.y -= 9 * dt;
      this.vel.y *= Math.pow(0.15, dt);
      if (jump) this.vel.y = Math.min(this.vel.y + 28 * dt, 3.6);
      this.vel.y = Math.max(this.vel.y, -4);
    } else {
      this.vel.y -= GRAVITY * dt;
      if (this.vel.y < -55) this.vel.y = -55;
      if (jump && this.onGround) {
        sfx.jump();
        this.spendEnergy(sprint ? 0.2 : 0.05);
        this.vel.y = JUMP_V;
        this.onGround = false;
      }
    }

    const maxMove = Math.max(Math.abs(this.vel.x), Math.abs(this.vel.y), Math.abs(this.vel.z)) * dt;
    const steps = Math.max(1, Math.ceil(maxMove / 0.35));
    const sdt = dt / steps;
    const wasGround = this.onGround;
    this.onGround = false;
    let hitH = false;
    const ox = this.pos.x, oz = this.pos.z;
    for (let s = 0; s < steps; s++) {
      const vy = this.vel.y * sdt;
      if (this.moveAxis(1, vy)) {
        if (vy < 0) {
          this.onGround = true;
          if (this.flying) {
            this.flying = false;
            this.emitHud();
          }
        }
        this.vel.y = 0;
      }
      for (const axis of [0, 2] as const) {
        const movement = (axis === 0 ? this.vel.x : this.vel.z) * sdt;
        const start = this.pos.clone();
        if (down && wasGround && !this.flying) {
          const test = start.clone(); test.setComponent(axis, test.getComponent(axis) + movement);
          if (!this.collidesAt(test.x, test.y - 0.2, test.z)) continue;
        }
        if (this.moveAxis(axis, movement)) {
          const test = start.clone(); test.setComponent(axis, test.getComponent(axis) + movement);
          if ((wasGround || this.onGround) && !this.flying && !down && !this.collidesAt(test.x, test.y + 0.51, test.z)) {
            this.pos.copy(test); this.pos.y += 0.51; this.moveAxis(1, -0.51);
          } else { hitH = true; if (axis === 0) this.vel.x = 0; else this.vel.z = 0; }
        }
      }
    }

    // auto jump
    if (hitH && (this.onGround || wasGround) && this.settings.autoJump && !this.flying && len > 0.2) {
      const tx = this.pos.x + wx * 0.45, tz = this.pos.z + wz * 0.45;
      if (!this.collidesAt(tx, this.pos.y + 1.05, tz) && this.collidesAt(tx, this.pos.y + 0.05, tz)) this.vel.y = JUMP_V;
    }

    // footsteps / bob
    const moved = Math.hypot(this.pos.x - ox, this.pos.z - oz);
    this.spendEnergy(moved * (sprint ? 0.12 : inWater ? 0.04 : 0.015));
    if (this.onGround) {
      this.stepDist += moved;
      if (this.stepDist > 1.8) {
        this.stepDist = 0;
        sfx.step(this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y - 0.1), Math.floor(this.pos.z)));
        if (!down) this.combat.hear(this.pos, sprint ? 12 : 5);
      }
      this.bobPhase += moved * 2.2;
      this.bobAmt += (Math.min(1, moved / dt / 4.3) - this.bobAmt) * Math.min(1, dt * 8);
    } else this.bobAmt *= Math.pow(0.02, dt);

    // fall damage
    if (this.flying || inWater || this.meta.mode === 'creative') this.fallStart = this.pos.y;
    else if (this.onGround) {
      const dist = this.fallStart - this.pos.y;
        if (dist > 3.5) this.damage(Math.floor(dist - 3), undefined, 'fall');
      this.fallStart = this.pos.y;
    } else this.fallStart = Math.max(this.fallStart, this.pos.y);

    if (this.pos.y < -20 || (this.dimension === 'end' && this.pos.y < 12)) {
      if (this.meta.mode === 'creative') {
        this.pos.y = CH;
        this.vel.y = 0;
        this.flying = true;
      } else this.damage(100, undefined, 'void');
    }
  }

  damage(n: number, source?: THREE.Vector3, kind: 'combat' | 'fall' | 'void' | 'lava' | 'drown' | 'starve' = 'combat') {
    if (this.meta.mode === 'creative' || this.dead || n <= 0 || (this.damageCooldown > 0 && kind !== 'void')) return;
    if (kind === 'combat') {
      n *= this.settings.difficulty === 'hard' ? 1.4 : this.settings.difficulty === 'easy' ? 0.65 : 1;
      const shield = this.equipment.offhand;
      const blocking = this.input.blocking || this.keys.has('KeyR');
      const front = source ? source.clone().sub(this.pos).normalize().dot(this.camera.getWorldDirection(new THREE.Vector3())) > -0.15 : true;
      if (shield && blocking && front) {
        shield.durability = (shield.durability ?? BLOCKS[shield.id].durability!) - Math.ceil(n);
        if (shield.durability <= 0) { this.equipment.offhand = null; this.notify('Seu escudo quebrou.'); }
        n = Math.max(1, Math.ceil(n * 0.15));
        sfx.block();
      }
      n = Math.max(1, Math.ceil(n * (1 - this.armorPoints() * 0.04)));
      for (const key of ARMOR_SLOTS.slice(0, 4)) {
        const slot = this.equipment[key];
        if (!slot) continue;
        slot.durability = (slot.durability ?? BLOCKS[slot.id].durability!) - 1;
        if (slot.durability <= 0) { this.notify(`${BLOCKS[slot.id].name} quebrou.`); this.equipment[key] = null; }
      }
    }
    this.damageCooldown = 0.6;
    this.lastDamage = this.adventure.elapsed;
    this.regenT = 0;
    this.health = Math.max(0, this.health - n);
    this.eating = null;
    this.hurtCounter++;
    this.shake = Math.max(this.shake, 0.25);
    sfx.hurt();
    if (this.health <= 0) {
      this.dead = true;
      this.adventure.deaths++;
      this.deathPoint = { position: this.pos.toArray() as [number, number, number], dimension: this.dimension };
      sfx.death();
      if (!this.settings.keepInventory) {
        for (const slot of [...this.inventory, ...Object.values(this.equipment), this.cursor, ...this.personalCraft]) if (slot) this.dropLoot(slot.id, slot.count, this.pos.clone().add(new THREE.Vector3(0, 0.6, 0)), slot);
        this.inventory.fill(null); this.equipment = emptyEquipment();
        this.cursor = null; this.personalCraft.fill(null);
        this.adventure.xp = Math.floor(this.adventure.xp / 2);
        this.updateHand();
      }
      this.setPaused(true);
      this.cb.onDeath?.();
      this.cb.onAutosave?.(this.serialize());
    }
    this.emitHud();
  }

  // ---------- interaction ----------
  private raycast(maxD: number): Hit | null {
    const o = this.camera.getWorldPosition(new THREE.Vector3());
    const d = this.camera.getWorldDirection(new THREE.Vector3());
    let x = Math.floor(o.x), y = Math.floor(o.y), z = Math.floor(o.z);
    const sx = Math.sign(d.x), sy = Math.sign(d.y), sz = Math.sign(d.z);
    const tdx = sx !== 0 ? Math.abs(1 / d.x) : Infinity;
    const tdy = sy !== 0 ? Math.abs(1 / d.y) : Infinity;
    const tdz = sz !== 0 ? Math.abs(1 / d.z) : Infinity;
    let tmx = sx > 0 ? (x + 1 - o.x) * tdx : sx < 0 ? (o.x - x) * tdx : Infinity;
    let tmy = sy > 0 ? (y + 1 - o.y) * tdy : sy < 0 ? (o.y - y) * tdy : Infinity;
    let tmz = sz > 0 ? (z + 1 - o.z) * tdz : sz < 0 ? (o.z - z) * tdz : Infinity;
    let nx = 0, ny = 0, nz = 0, t = 0;
    while (t <= maxD) {
      const id = this.world.getBlock(x, y, z);
      if (id === -1) return null;
      if (id !== 0 && id !== B.WATER && id !== B.LAVA && id !== B.NETHER_PORTAL_X && id !== B.NETHER_PORTAL_Z && id !== B.END_SURFACE) {
        const bounds = blockBounds(id, this.world.getState(x, y, z));
        if (!bounds.length) return { x, y, z, nx, ny, nz, id };
        const ray = new THREE.Ray(o, d);
        let closest: { point: THREE.Vector3; bounds: Bounds; distance: number } | null = null;
        for (const box of bounds) {
          const point = ray.intersectBox(new THREE.Box3(new THREE.Vector3(x + box[0], y + box[1], z + box[2]), new THREE.Vector3(x + box[3], y + box[4], z + box[5])), new THREE.Vector3());
          if (point && point.distanceTo(o) <= maxD && (!closest || point.distanceTo(o) < closest.distance)) closest = { point, bounds: box, distance: point.distanceTo(o) };
        }
        if (closest) {
          const p = closest.point, b = closest.bounds;
          const distances = [Math.abs(p.x - x - b[0]), Math.abs(p.x - x - b[3]), Math.abs(p.y - y - b[1]), Math.abs(p.y - y - b[4]), Math.abs(p.z - z - b[2]), Math.abs(p.z - z - b[5])];
          const face = distances.indexOf(Math.min(...distances));
          return { x, y, z, id, hitY: p.y - y, nx: face < 2 ? face === 0 ? -1 : 1 : 0, ny: face >= 2 && face < 4 ? face === 2 ? -1 : 1 : 0, nz: face >= 4 ? face === 4 ? -1 : 1 : 0 };
        }
      }
      if (tmx < tmy && tmx < tmz) {
        x += sx; t = tmx; tmx += tdx; nx = -sx; ny = 0; nz = 0;
      } else if (tmy < tmz) {
        y += sy; t = tmy; tmy += tdy; nx = 0; ny = -sy; nz = 0;
      } else {
        z += sz; t = tmz; tmz += tdz; nx = 0; ny = 0; nz = -sz;
      }
    }
    return null;
  }

  private spawnParticles(x: number, y: number, z: number, id: number, n: number, power = 3) {
    if (!this.settings.particles) return;
    n = Math.max(1, Math.round(n * this.settings.particleDensity));
    const tile = BLOCKS[id].tiles[1];
    let mat = this.particleMats.get(tile);
    if (!mat) {
      const c = this.atlasColors[tile];
      mat = new THREE.MeshBasicMaterial({ color: new THREE.Color(c[0] / 255, c[1] / 255, c[2] / 255) });
      this.particleMats.set(tile, mat);
    }
    for (let i = 0; i < n && this.particles.length < Math.floor(180 * this.settings.particleDensity); i++) {
      const m = new THREE.Mesh(this.particleGeo, mat);
      m.position.set(x + Math.random(), y + Math.random(), z + Math.random());
      const s = 0.5 + Math.random() * 0.8;
      m.scale.setScalar(s);
      this.scene.add(m);
      this.particles.push({
        mesh: m,
        vel: new THREE.Vector3((Math.random() - 0.5) * power, Math.random() * power + 1, (Math.random() - 0.5) * power),
        life: 0.6 + Math.random() * 0.6,
      });
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      p.vel.y -= 22 * dt;
      const np = p.mesh.position.clone().addScaledVector(p.vel, dt);
      if (this.solidAt(Math.floor(np.x), Math.floor(np.y), Math.floor(np.z))) {
        p.vel.multiplyScalar(0.2);
        p.vel.y = 0;
      } else p.mesh.position.copy(np);
      p.mesh.rotation.x += dt * 5;
    }
  }

  private breakBlock(h: Hit) {
    const { x, y, z, id } = h;
    if (this.meta.mode !== 'creative' && (id === B.BEDROCK || BLOCKS[id].hardness < 0)) return;
    if (id === B.CHEST) this.spillChest(x, y, z);
    this.clearPlantTimers(x, y, z);
    this.world.setBlock(x, y, z, 0);
    this.queueEnvironment(x, y, z);
    const near = [this.world.getBlock(x + 1, y, z), this.world.getBlock(x - 1, y, z), this.world.getBlock(x, y, z + 1), this.world.getBlock(x, y, z - 1), this.world.getBlock(x, y + 1, z)];
    if (near.includes(B.WATER)) this.world.setBlock(x, y, z, B.WATER);
    this.spawnParticles(x, y, z, id, 10);
    sfx.brk(id);
    this.combat.hear(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), 12);
    this.swing = 1;
    if (this.meta.mode === 'survival') {
      const def = BLOCKS[id];
      let drop = def.drop === undefined ? id : def.drop;
      if (LEAF_IDS.has(id) && this.inventory[this.selected] && BLOCKS[this.inventory[this.selected]!.id].tool === 'hoe') drop = id;
      if (drop) {
        this.dropLoot(drop, def.dropCount ?? 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      }
      if (LEAF_IDS.has(id)) {
        const wood = WOODS.find((w) => w.leaves === id)!;
        if ((wood.key === 'oak' || wood.key === 'dark') && Math.random() < 0.13) this.dropLoot(I.APPLE, 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
        if (Math.random() < 0.18) this.dropLoot(wood.sapling, 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
        if (Math.random() < 0.08) this.dropLoot(I.STICK, 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      }
      if (id === B.TALLGRASS) this.dropLoot(I.SEEDS, 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      if (id === B.GRAVEL && Math.random() < 0.2) this.dropLoot(I.FLINT, 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      if (id === B.RIPE_CROPS) this.dropLoot(I.SEEDS, 2, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      if (id === B.END_FRAME_EYE) this.dropLoot(I.EYE, 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      this.adventure.mined++;
      this.spendEnergy(0.06);
      if ((def.drop ?? 0) >= 100) this.adventure.xp++;
      this.wearHeld();
      this.emitHud();
    }
  }

  private placeBlock() {
    if (this.eating) return;
    if (this.target?.id === B.BERRY_BUSH && !this.input.down && !this.keys.has('ShiftLeft')) {
      const { x, y, z } = this.target;
      this.world.setBlock(x, y, z, B.BERRY_EMPTY);
      this.dropLoot(I.BERRIES, 3, new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5));
      this.crops = this.crops.filter((crop) => crop.dimension !== this.dimension || crop.x !== x || crop.y !== y || crop.z !== z);
      this.crops.push({ x, y, z, dimension: this.dimension, remaining: 45, plant: B.BERRY_EMPTY, result: B.BERRY_BUSH });
      sfx.place(B.LEAVES); return;
    }
    if (this.useHeldItem()) return;
    const t = this.target;
    if (!t) return;
    this.swing = 1;
    if (STATION_BLOCKS[t.id] || t.id === B.CHEST || t.id === B.NETHER_GATE || t.id === B.END_GATE) {
      const sneak = this.input.down || this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
      if (!sneak && !this.bypassTable) {
        this.tryOpenCrafting();
        return;
      }
    }
    this.bypassTable = false;
    const slot = this.inventory[this.selected];
    if (!slot || !isPlaceable(slot.id)) return;
    const placement = this.getPlacement(t, slot.id);
    if (!placement.valid) { this.notify('Não é possível construir aqui. Verifique o espaço e o apoio.'); return; }
    const { x: px, y: py, z: pz, id, state } = placement;
    this.clearPlantTimers(px, py, pz);
    this.world.setBlock(px, py, pz, id, state);
    if (SAPLING_IDS.has(id)) this.saplings.push({ x: px, y: py, z: pz, block: id, dimension: this.dimension, remaining: 60 });
    if (id === B.BERRY_EMPTY) this.crops.push({ x: px, y: py, z: pz, dimension: this.dimension, remaining: 45, plant: B.BERRY_EMPTY, result: B.BERRY_BUSH });
    this.queueEnvironment(px, py, pz);
    sfx.place(slot.id);
    this.combat.hear(new THREE.Vector3(px + 0.5, py + 0.5, pz + 0.5), 7);
    if (this.meta.mode === 'survival') {
      slot.count--;
      if (slot.count <= 0) this.inventory[this.selected] = null;
      this.updateHand();
      this.emitHud();
    }
  }

  private getPlacement(target: Hit, heldId: number): Placement {
    const replaceable = PLANT_IDS.has(target.id) && target.id !== B.CROPS && target.id !== B.RIPE_CROPS;
    let x = target.x + target.nx, y = target.y + target.ny, z = target.z + target.nz;
    let id = heldId, state = 0;
    if (id === B.BERRY_BUSH) id = B.BERRY_EMPTY;
    if (replaceable) { x = target.x; y = target.y; z = target.z; }
    const upper = target.ny < 0 || target.ny === 0 && (target.hitY ?? 0.25) > 0.5;
    if (SLAB_IDS.has(id)) {
      state = upper ? 4 : 0;
      if (target.id === id && (target.ny === 1 && !(this.world.getState(target.x, target.y, target.z) & 4) || target.ny === -1 && !!(this.world.getState(target.x, target.y, target.z) & 4))) {
        x = target.x; y = target.y; z = target.z; id = DOUBLE_SLABS[id]; state = 0;
      }
    }
    if (STAIR_IDS.has(id)) state = ((Math.round(this.yaw / (Math.PI / 2)) + 2) % 4 + 4) % 4 | (upper ? 4 : 0);
    if (id === B.CHEST) state = ((Math.round(this.yaw / (Math.PI / 2)) % 4) + 4) % 4;
    const existing = this.world.getBlock(x, y, z);
    if (SLAB_IDS.has(heldId) && existing === heldId && (this.world.getState(x, y, z) & 4) !== state) { id = DOUBLE_SLABS[heldId]; state = 0; }
    const merging = id === DOUBLE_SLABS[heldId] && existing === heldId;
    const body: Bounds = [this.pos.x - HW, this.pos.y, this.pos.z - HW, this.pos.x + HW, this.pos.y + PH, this.pos.z + HW];
    let valid = y > 0 && y < CH && (existing === 0 || existing === B.WATER || PLANT_IDS.has(existing) || merging)
      && !blockBounds(id, state).some((box) => intersects(body, box, x, y, z)) && !this.combat.blocksPlacement(x, y, z, id, state);
    const below = this.world.getBlock(x, y - 1, z);
    if (SAPLING_IDS.has(id) || id === B.BERRY_BUSH || id === B.BERRY_EMPTY || id === B.MUSHROOM_RED || id === B.MUSHROOM_BROWN || id === B.CHERRY_FLOWER) valid &&= SOIL_IDS.has(below);
    if (id === B.TORCH) valid &&= isSolid(below);
    if (id === B.CROPS || id === B.RIPE_CROPS) valid &&= below === B.FARMLAND;
    if (id === B.SUGAR_CANE) valid &&= below === B.SUGAR_CANE || SOIL_IDS.has(below) || below === B.SAND || below === B.RED_SAND;
    if (id === B.LILY) valid &&= below === B.WATER;
    return { x, y, z, id, state, valid };
  }

  private useHeldItem() {
    const slot = this.inventory[this.selected];
    if (!slot) return false;
    const def = BLOCKS[slot.id];
    const target = this.target;
    const station = target && (STATION_BLOCKS[target.id] || target.id === B.CHEST || target.id === B.NETHER_GATE || target.id === B.END_GATE);
    if (station && !this.bypassTable) return false;
    this.bypassTable = false;
    if (slot.id === I.FLINT_STEEL) {
      if (target?.id === B.TNT) { this.ignite(target.x, target.y, target.z, 2.5); this.wearHeld(); sfx.ignite(); return true; }
      if (target) {
        let lit = this.portals.ignite(target.x + target.nx, target.y + target.ny, target.z + target.nz);
        if (!lit && target.id === B.OBSIDIAN) for (const [dx, dy, dz] of [[0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
          if (this.portals.ignite(target.x + dx, target.y + dy, target.z + dz)) { lit = true; break; }
        }
        if (lit) this.wearHeld();
      }
      return true;
    }
    if (slot.id === I.EYE && target?.id === B.END_FRAME) {
      this.world.setBlock(target.x, target.y, target.z, B.END_FRAME_EYE);
      if (this.meta.mode !== 'creative') consume(this.inventory, [[I.EYE, 1]]);
      sfx.eye(); this.updateHand();
      if (!this.portals.activateEnd(target.x, target.y, target.z)) this.notify('Olho inserido. Complete os 12 espaços do anel 5 x 5, sem cantos.');
      return true;
    }
    if (def.food) { this.beginEating(this.selected); return true; }
    if (def.equip) { this.equipItem(this.selected); return true; }
    if ([I.BOW, I.CROSSBOW, I.TRIDENT].includes(slot.id as 128 | 129 | 130)) { this.performAttack(); return true; }
    if (def.tool === 'hoe' && target && SOIL_IDS.has(target.id)) {
      if (this.world.getBlock(target.x, target.y + 1, target.z) !== 0) { this.notify('Remova o bloco acima da terra.'); return true; }
      this.world.setBlock(target.x, target.y, target.z, B.FARMLAND);
      this.wearHeld(); this.swing = 1; sfx.place(); return true;
    }
    if (def.tool === 'shovel' && target && GRASS_IDS.has(target.id) && this.world.getBlock(target.x, target.y + 1, target.z) === 0) {
      this.world.setBlock(target.x, target.y, target.z, B.PATH); this.wearHeld(); sfx.place(B.DIRT); return true;
    }
    if (slot.id === I.BONE_MEAL && target) {
      const wood = WOODS.find((w) => w.sapling === target.id);
      let grown = false;
      if (wood) grown = this.tryGrowTree(wood.key, target.x, target.y, target.z);
      else if (target.id === B.CROPS || target.id === B.BERRY_EMPTY) { this.world.setBlock(target.x, target.y, target.z, target.id === B.CROPS ? B.RIPE_CROPS : B.BERRY_BUSH); grown = true; }
      if (grown) { if (this.meta.mode !== 'creative') consume(this.inventory, [[I.BONE_MEAL, 1]]); this.updateHand(); sfx.pop(); }
      else this.notify('Use em mudas com espaço livre, trigo ou arbustos crescendo.');
      return true;
    }
    if (slot.id === I.SEEDS) {
      if (target?.id !== B.FARMLAND || this.world.getBlock(target.x, target.y + 1, target.z) !== 0) { this.notify('Use uma enxada e plante na terra arada.'); return true; }
      this.clearPlantTimers(target.x, target.y + 1, target.z);
      this.world.setBlock(target.x, target.y + 1, target.z, B.CROPS);
      this.crops.push({ x: target.x, y: target.y + 1, z: target.z, dimension: this.dimension, remaining: 30, plant: B.CROPS, result: B.RIPE_CROPS });
      if (this.meta.mode !== 'creative') consume(this.inventory, [[I.SEEDS, 1]]);
      this.updateHand(); sfx.place(); return true;
    }
    if (slot.id === I.COMPASS) {
      if (this.waypoint && this.dimension === 'overworld') { this.notify(`${this.waypoint.name}: X ${this.waypoint.x}, Z ${this.waypoint.z}. Distância: ${Math.round(Math.hypot(this.pos.x - this.waypoint.x, this.pos.z - this.waypoint.z))} blocos.`); return true; }
      const [x, z] = this.world.findSpawn(); this.notify(`Ponto de chegada: X ${Math.floor(x)}, Z ${Math.floor(z)}. Você: X ${Math.floor(this.pos.x)}, Z ${Math.floor(this.pos.z)}.`); return true;
    }
    if (slot.id === I.SPYGLASS) {
      this.zoomed = !this.zoomed; this.camera.fov = this.zoomed ? 28 : this.settings.fov; this.camera.updateProjectionMatrix(); return true;
    }
    if (slot.id === I.EYE) { this.notify('Coloque 12 molduras em um anel 5 x 5 sem cantos; use um olho em cada moldura.'); return true; }
    return false;
  }

  private performAttack() {
    if (this.eating) return true;
    const slot = this.inventory[this.selected];
    const def = slot ? BLOCKS[slot.id] : null;
    const isWeapon = def?.kind === 'weapon';
    if (this.equipment.offhand && (this.input.blocking || this.keys.has('KeyR'))) return true;
    if (this.attackCooldown > 0) return isWeapon || !!this.combat.getTarget();
    const damage = (def?.damage ?? 1) + (slot?.enchant ?? 0) * 1.5;
    let usedEquipment = false;
    const ranged = slot && [I.BOW, I.CROSSBOW, I.TRIDENT].includes(slot.id as 128 | 129 | 130);
    if (ranged && slot) {
      if (!this.combat.canShoot()) { this.notify('Aguarde os projéteis anteriores.'); return true; }
      if (slot.id !== I.TRIDENT && this.meta.mode !== 'creative' && !consume(this.inventory, [[I.ARROW, 1]])) {
        this.notify('Sem flechas. Crie 8 com 1 graveto + 1 sílex.'); this.attackCooldown = 0.8; return true;
      }
      let thrown: Slot | undefined;
      if (slot.id === I.TRIDENT && this.meta.mode !== 'creative') {
        const remaining = (slot.durability ?? BLOCKS[I.TRIDENT].durability!) - 1;
        if (remaining > 0) thrown = { ...slot, count: 1, durability: remaining };
        else sfx.toolBreak();
        this.inventory[this.selected] = null; this.updateHand();
      }
      this.combat.shootPlayer(damage, slot.id === I.TRIDENT, thrown);
      usedEquipment = true;
    } else {
      const smash = slot?.id === I.MACE ? Math.max(0, -this.vel.y) * 0.7 : 0;
      const hit = this.combat.melee(damage + smash, 4.5);
      if (!hit && !isWeapon) return false;
      usedEquipment = hit;
      if (hit) sfx.brk();
    }
    this.attackDuration = def?.tool === 'axe' || slot?.id === I.MACE ? 1 : slot?.id === I.CROSSBOW ? 1.05 : 0.55;
    this.attackCooldown = this.attackDuration;
    this.swing = 1;
    if (usedEquipment) this.spendEnergy(0.1);
    sfx.swing();
    if (usedEquipment && slot?.id !== I.TRIDENT) this.wearHeld();
    return true;
  }

  private ignite(x: number, y: number, z: number, t: number, sound = true) {
    if (this.tnts.some((n) => n.x === x && n.y === y && n.z === z)) return;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.02, 1.02, 1.02), this.tntMat);
    mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
    this.scene.add(mesh);
    this.tnts.push({ x, y, z, t, mesh });
    if (sound) sfx.fuse();
  }

  private restorePrimedTnt() {
    const records = this.primedRealms[this.dimension];
    if (!Array.isArray(records)) return;
    for (const record of records.slice(0, 128)) {
      if (!record || ![record.x, record.y, record.z].every(Number.isInteger) || record.y < 0 || record.y >= CH || !Number.isFinite(record.remaining)) continue;
      this.ignite(record.x, record.y, record.z, Math.max(0.05, Math.min(4, record.remaining)), false);
    }
  }

  explode(cx: number, cy: number, cz: number, mob = false) {
    const R = 3.4;
    if (!mob) this.world.setBlock(cx, cy, cz, 0);
    const center = new THREE.Vector3(cx + 0.5, cy + 0.5, cz + 0.5);
    const exposure = clearLine(this.world, center, this.pos.clone().add(new THREE.Vector3(0, 1.5, 0))) ? 1 : clearLine(this.world, center, this.pos.clone().add(new THREE.Vector3(0, 0.5, 0))) ? 0.5 : 0;
    this.combat.hear(center, 30);
    this.combat.blast(center, 7);
    if (!mob || this.settings.mobGriefing) {
    for (let dy = -4; dy <= 4; dy++)
      for (let dz = -4; dz <= 4; dz++)
        for (let dx = -4; dx <= 4; dx++) {
          const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (d > R + Math.random() * 0.8) continue;
          const x = cx + dx, y = cy + dy, z = cz + dz;
          const id = this.world.getBlock(x, y, z);
          if (id <= 0 || BLOCKS[id]?.hardness < 0 || id === B.WATER || id === B.OBSIDIAN || id === B.NETHER_GATE || id === B.END_GATE || id === B.ANCIENT_DEBRIS || id === B.END_FRAME || id === B.END_FRAME_EYE) continue;
          if (id === B.TNT) {
            this.ignite(x, y, z, 0.3 + Math.random() * 0.5);
            continue;
          }
          this.world.setBlock(x, y, z, 0);
          if (id === B.CHEST) this.spillChest(x, y, z);
          this.queueEnvironment(x, y, z);
          if (Math.random() < 0.08) this.spawnParticles(x, y, z, id, 2, 8);
          if (this.meta.mode === 'survival' && Math.random() < 0.15) {
            const def = BLOCKS[id];
            const drop = def.drop === undefined ? id : def.drop;
            if (drop && (def.minTier ?? 0) < 3) this.dropLoot(drop, def.dropCount ?? 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
          }
        }
    }
    if (this.settings.particles) {
      this.spawnParticles(cx - 1, cy, cz - 1, B.COBBLE, 14, 12);
      this.spawnParticles(cx, cy, cz, B.WOOL_WHITE, 14, 10);
    }
    sfx.boom(new THREE.Vector3(cx, cy, cz));
    const pc = new THREE.Vector3(this.pos.x, this.pos.y + 0.9, this.pos.z);
    const dist = pc.distanceTo(new THREE.Vector3(cx + 0.5, cy + 0.5, cz + 0.5));
    this.shake = Math.max(this.shake, Math.max(0, 1.2 - dist * 0.08));
    if (dist < 8 && exposure > 0) {
      const dir = pc.clone().sub(new THREE.Vector3(cx + 0.5, cy + 0.5, cz + 0.5)).normalize();
      this.vel.addScaledVector(dir, (8 - dist) * 2.2 * exposure);
      this.vel.y += (8 - dist) * 0.8 * exposure;
      this.damage(Math.round((8 - dist) * 2.5 * exposure), center);
    }
    this.emitHud();
  }

  private updateTnt(dt: number) {
    for (let i = this.tnts.length - 1; i >= 0; i--) {
      if (this.dead || this.paused) break;
      const t = this.tnts[i];
      const block = this.world.getBlock(t.x, t.y, t.z);
      if (block === -1) { t.mesh.visible = false; continue; }
      t.t -= dt;
      t.mesh.visible = Math.floor(t.t * 6) % 2 === 0;
      if (block !== B.TNT) {
        this.scene.remove(t.mesh);
        t.mesh.geometry.dispose();
        this.tnts.splice(i, 1);
        continue;
      }
      if (t.t <= 0) {
        this.scene.remove(t.mesh);
        t.mesh.geometry.dispose();
        this.tnts.splice(i, 1);
        this.explode(t.x, t.y, t.z);
      }
    }
  }

  private interact(dt: number) {
    const reach = this.meta.mode === 'creative' ? 7 : 5;
    this.target = this.raycast(reach);
    const t = this.target;
    if (t) {
      this.selection.visible = true;
      const boxes = blockBounds(t.id, this.world.getState(t.x, t.y, t.z));
      const minY = boxes.length ? Math.min(...boxes.map((b) => b[1])) : 0;
      const maxY = boxes.length ? Math.max(...boxes.map((b) => b[4])) : t.id === B.TORCH ? 0.625 : 1;
      const width = t.id === B.TORCH ? 0.15 : 1;
      this.selection.scale.set(width, maxY - minY, width);
      this.selection.position.set(t.x + 0.5, t.y + (maxY + minY) / 2, t.z + 0.5);
    } else this.selection.visible = false;
    this.placementOutline.visible = false;
    const heldId = this.inventory[this.selected]?.id ?? 0;
    if (t && this.settings.placementPreview && isPlaceable(heldId) && !this.eating && !STATION_BLOCKS[t.id] && t.id !== B.CHEST) {
      const placement = this.getPlacement(t, heldId), bounds = blockBounds(placement.id, placement.state);
      const bottom = bounds.length ? Math.min(...bounds.map((b) => b[1])) : 0;
      const top = bounds.length ? Math.max(...bounds.map((b) => b[4])) : 1;
      this.placementOutline.position.set(placement.x + 0.5, placement.y + (bottom + top) / 2, placement.z + 0.5);
      this.placementOutline.scale.set(1.004, top - bottom, 1.004);
      (this.placementOutline.material as THREE.LineBasicMaterial).color.set(placement.valid ? 0xb4df7d : 0xdc8374);
      this.placementOutline.visible = true;
    }

    this.breakCooldown -= dt;
    const attacked = this.input.breaking && this.performAttack();
    if (this.input.breaking && t && !attacked) {
      const held = this.inventory[this.selected];
      const tool = held ? BLOCKS[held.id] : null;
      const key = t.x + ',' + t.y + ',' + t.z + ':' + (held?.id ?? 0);
      if (key !== this.breakKey) {
        this.breakKey = key;
        this.breakProgress = 0;
      }
      const def = BLOCKS[t.id];
      if (this.meta.mode === 'creative') {
        if (this.breakCooldown <= 0) {
          this.breakBlock(t);
          this.breakCooldown = 0.22;
        }
      } else if (def.hardness >= 0) {
        if (def.minTier && (tool?.tool !== 'pickaxe' || (tool.tier ?? 0) < def.minTier)) {
          const required = ['', 'madeira', 'pedra ou cobre', 'ferro', 'diamante', 'netherita'][def.minTier];
          this.notify(`Precisa de picareta de ${required} ou melhor.`);
          this.breakProgress = 0;
          this.crack.visible = false;
          if (this.input.place) { this.input.place = false; this.placeBlock(); }
          return;
        }
        const speed = tool?.tool && tool.tool === def.preferredTool ? (tool.speed ?? 1) + (held?.enchant ?? 0) * 2 : 1;
        this.breakProgress += dt * speed / (def.hardness * 0.9 + 0.15);
        this.swing = Math.max(this.swing, 0.6);
        this.digSoundT -= dt;
        if (this.digSoundT <= 0) {
          sfx.dig(t.id);
          this.digSoundT = 0.25;
          if (this.settings.particles) this.spawnParticles(t.x, t.y, t.z, t.id, 1, 2);
        }
        if (this.breakProgress >= 1) {
          this.breakBlock(t);
          this.breakProgress = 0;
          this.breakKey = '';
        }
      }
    } else {
      this.breakProgress = 0;
      this.breakKey = '';
    }
    if (this.breakProgress > 0 && t) {
      this.crack.visible = true;
      this.crack.position.copy(this.selection.position);
      (this.crack.material as THREE.MeshBasicMaterial).opacity = 0.2 + this.breakProgress * 0.8;
      this.crack.scale.copy(this.selection.scale).multiplyScalar(1.003);
    } else this.crack.visible = false;

    this.useCooldown -= dt;
    const continuousBuild = this.input.useHeld && this.useCooldown <= 0 && isPlaceable(heldId) && !!t && !STATION_BLOCKS[t.id] && t.id !== B.CHEST;
    if (this.input.place || continuousBuild) {
      this.input.place = false;
      this.useCooldown = 0.24;
      this.placeBlock();
    }
  }

  // ---------- sky ----------
  private updateSky(dt: number) {
    if (this.settings.dayCycle && !this.paused && this.spawned) this.time = (this.time + dt / 720) % 1;
    const a = this.time * Math.PI * 2;
    const sunY = Math.sin(a);
    const day = THREE.MathUtils.smoothstep(sunY, -0.18, 0.28);
    const bright = (0.12 + this.settings.brightness * 0.24) + (0.88 - this.settings.brightness * 0.24) * day;
    const sunset = Math.max(0, 1 - Math.abs(sunY) * 3.5) * (Math.cos(a) > -2 ? 1 : 0);
    const sky = this.skyColor.setRGB(0.03 + 0.45 * day, 0.04 + 0.62 * day, 0.1 + 0.9 * day);
    sky.lerp(new THREE.Color(1, 0.55, 0.32), sunset * 0.45);

    const R = this.settings.renderDistance;
    const fog = this.scene.fog as THREE.Fog;
    if (this.underwater) {
      fog.color.setRGB(0.08 * bright, 0.2 * bright, 0.55 * bright);
      fog.near = 0.5;
      fog.far = 14;
      this.scene.background = fog.color;
    } else {
      fog.color.copy(sky);
      fog.near = R * CS * 0.5;
      fog.far = R * CS * 0.95;
      this.scene.background = sky;
    }
    this.camera.far = Math.max(600, R * CS * 1.5);
    this.camera.updateProjectionMatrix();

    this.matOpaque.color.setScalar(bright);
    this.matWater.color.setScalar(bright);
    this.firstPerson.setLight(Math.max(0.58, bright));
    (this.clouds.material as THREE.MeshBasicMaterial).color.setRGB(0.25 + 0.75 * day, 0.25 + 0.75 * day, 0.3 + 0.7 * day);

    const cp = this.camera.position;
    this.sun.position.set(cp.x + Math.cos(a) * 320, cp.y + sunY * 320, cp.z + 60);
    this.sun.lookAt(cp);
    this.moon.position.set(cp.x - Math.cos(a) * 320, cp.y - sunY * 320, cp.z - 60);
    this.moon.lookAt(cp);
    this.stars.position.copy(cp);
    (this.stars.material as THREE.PointsMaterial).opacity = Math.max(0, 1 - day * 1.6);
    this.stars.visible = day < 0.65;

    if (this.clouds.visible) {
      this.cloudDrift += dt * 1.2;
      this.clouds.position.x = cp.x;
      this.clouds.position.z = cp.z;
      const map = (this.clouds.material as THREE.MeshBasicMaterial).map!;
      map.offset.set((cp.x + this.cloudDrift) / 1536, -cp.z / 1536);
    }
    const overworld = this.dimension === 'overworld';
    this.sun.visible = this.moon.visible = overworld;
    this.clouds.visible = overworld && this.settings.clouds;
    if (!overworld) {
      this.stars.visible = this.dimension === 'end';
      (this.stars.material as THREE.PointsMaterial).opacity = 0.8;
      fog.color.set(this.dimension === 'nether' ? 0x51252e : 0x191321);
      fog.near = this.dimension === 'nether' ? 15 : 40;
      fog.far = this.dimension === 'nether' ? this.settings.renderDistance * CS * 0.95 : Math.max(70, this.settings.renderDistance * CS);
      this.scene.background = fog.color;
      this.matOpaque.color.setScalar(this.dimension === 'nether' ? 0.85 : 0.8);
      this.firstPerson.setLight(0.93);
    }
  }

  // ---------- frame ----------
  private frame(dt: number, elapsed: number) {
    const now = performance.now();
    setAudioFocus(!document.hidden && document.hasFocus());
    if (document.hidden || this.contextLost) return;
    setAudioListener(this.pos, this.yaw);
    tickMusic(Math.min(elapsed, 0.25));
    this.subtitleTimer = Math.max(0, this.subtitleTimer - dt);
    if (!this.subtitleTimer) this.subtitle = '';
    this.fpsFrames++;
    this.fpsTime += elapsed;
    if (this.fpsTime >= 0.5) {
      this.fps = Math.round(this.fpsFrames / this.fpsTime);
      this.fpsFrames = 0;
      this.fpsTime = 0;
    }

    this.frameAverage += (Math.min(elapsed, 0.15) - this.frameAverage) * 0.04;
    this.adaptiveTimer += dt;
    if (this.adaptiveTimer > 3 && this.spawned && !this.paused && this.settings.dynamicResolution) {
      this.adaptiveTimer = 0;
      const target = Math.min(this.settings.targetFps, this.settings.fpsLimit || 60);
      const fps = 1 / this.frameAverage;
      const next = fps < target * 0.78 ? Math.max(0.35, this.effectiveResolution - 0.08) : fps > target * 0.96 ? Math.min(this.settings.resolution, this.effectiveResolution + 0.035) : this.effectiveResolution;
      if (Math.abs(next - this.effectiveResolution) > 0.01) { this.effectiveResolution = next; this.applyResolution(); }
    }
    const budget = this.spawned ? Math.min(this.settings.chunkBudget, this.frameAverage > 1 / 35 ? 3 : 12) : 15;
    this.updateChunks(budget);
    if (now - this.unloadTime > 2000) {
      this.unloadTime = now;
      this.unloadFar();
    }

    if (!this.spawned) {
      this.trySpawn();
    } else if (!this.paused && !this.dead) {
      this.adventure.elapsed += dt;
      this.damageCooldown = Math.max(0, this.damageCooldown - dt);
      this.attackCooldown = Math.max(0, this.attackCooldown - dt);
      this.noticeTimer = Math.max(0, this.noticeTimer - dt);
      if (!this.noticeTimer) this.notice = '';
      this.yaw -= this.input.lookX;
      this.pitch -= this.input.lookY;
      this.pitch = Math.max(-1.56, Math.min(1.56, this.pitch));
      this.physics(dt);
      this.camera.position.copy(this.pos).add(new THREE.Vector3(0, EYE, 0));
      this.camera.rotation.set(this.pitch, this.yaw, 0);
      this.camera.updateMatrixWorld();
      if (!this.dead) this.interact(dt);
      if (this.spawned && !this.paused) {
        this.combat.update(dt);
      }
      if (this.spawned && !this.paused && !this.dead) {
        this.updateTnt(dt);
      }
      if (this.spawned && !this.paused && !this.dead) {
        this.updateCrops(dt);
        this.updateSurvival(dt);
      }
      if (this.spawned && !this.paused && !this.dead) {
        this.updateTrees(dt);
        this.updateBiome(dt);
        this.updateEnvironment(dt);
        this.drops.update(dt);
        this.portals.update(dt);
        this.textureTimer += dt;
        if (this.textureTimer >= 0.2 && this.settings.animatedTextures) {
          this.textureTimer = 0; animateAtlas(this.settings.texturePack, this.adventure.elapsed, this.texture.image as HTMLCanvasElement); this.texture.needsUpdate = true;
        }
        this.ambientTimer += dt;
        if (this.ambientTimer > 18) { this.ambientTimer = 0; sfx.ambient(this.dimension); }
      }
      this.liquidTimer += dt;
      const submerged = this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y + EYE), Math.floor(this.pos.z)) === B.WATER;
      this.air = this.meta.mode === 'creative' ? 20 : Math.max(0, Math.min(20, this.air + dt * (submerged ? -1.3 : 5)));
      if (this.liquidTimer >= 1) {
        this.liquidTimer = 0;
        if (this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y), Math.floor(this.pos.z)) === B.LAVA) this.damage(4, undefined, 'lava');
        if (submerged && this.air === 0) this.damage(2, undefined, 'drown');
        if (this.wasInWater && Math.hypot(this.vel.x, this.vel.z) > 0.5) sfx.swim();
      }
    }
    this.input.lookX = 0;
    this.input.lookY = 0;
    if (!this.paused) this.updateParticles(dt);

    // camera
    const bob = this.settings.viewBob ? this.bobAmt : 0;
    const by = Math.abs(Math.sin(this.bobPhase)) * 0.07 * bob;
    const bx = Math.cos(this.bobPhase) * 0.04 * bob;
    this.shake = Math.max(0, this.shake - dt * 1.5);
    const sh = this.settings.screenEffects ? this.shake * 0.25 : 0;
    this.camera.position.set(
      this.pos.x + Math.cos(this.yaw) * bx + (Math.random() - 0.5) * sh,
      this.pos.y + EYE + by + (Math.random() - 0.5) * sh,
      this.pos.z - Math.sin(this.yaw) * bx + (Math.random() - 0.5) * sh,
    );
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    this.underwater = this.world.getBlock(Math.floor(this.camera.position.x), Math.floor(this.camera.position.y), Math.floor(this.camera.position.z)) === B.WATER;

    this.swing = Math.max(0, this.swing - dt * 4);
    this.updateHand();
    this.firstPerson.update(dt, { time: this.adventure.elapsed, swing: this.swing, mining: this.input.breaking && this.breakProgress > 0,
      eating: this.eating?.progress ?? 0, bob, phase: this.bobPhase, yaw: this.yaw, pitch: this.pitch,
      blocking: this.input.blocking || this.keys.has('KeyR'), visible: this.spawned && this.settings.showHand && !this.dead, paused: this.paused });

    this.updateSky(dt);
    this.renderer.render(this.scene, this.camera);
    const calls = this.renderer.info.render.calls, triangles = this.renderer.info.render.triangles;
    if (this.firstPerson.render(this.renderer)) { this.renderer.info.render.calls += calls; this.renderer.info.render.triangles += triangles; }

    if ((!this.paused || !this.spawned) && now - this.hudTime > (this.settings.preset === 'rapido' ? 160 : 100)) {
      this.hudTime = now;
      this.emitHud();
    }
    if (this.spawned && now - this.autosaveTime > this.settings.autosaveSeconds * 1000) {
      this.autosaveTime = now;
      this.cb.onAutosave?.(this.serialize());
    }
  }

  private loadProgress() {
    const pcx = Math.floor(this.pos.x / CS), pcz = Math.floor(this.pos.z / CS);
    const R = Math.min(2, this.settings.renderDistance);
    const r2 = (R + 0.5) * (R + 0.5);
    let total = 0, done = 0;
    for (let dz = -R; dz <= R; dz++)
      for (let dx = -R; dx <= R; dx++) {
        if (dx * dx + dz * dz > r2) continue;
        total++;
        if (this.world.getChunk(pcx + dx, pcz + dz)?.meshed) done++;
      }
    return done / total;
  }

  private trySpawn() {
    if (this.loadProgress() < 1) return;
    if (!this.hasSavedPos) {
      const x = Math.floor(this.pos.x), z = Math.floor(this.pos.z);
      let y = CH - 1;
      while (y > 0 && !isSolid(this.world.getBlock(x, y, z))) y--;
      this.pos.y = y + 1;
    }
    // Old flat worlds had a shallow floor; relocate safely after the terrain upgrade.
    while (this.pos.y < CH - 2 && this.collidesAt(this.pos.x, this.pos.y, this.pos.z)) this.pos.y = Math.floor(this.pos.y) + 1;
    this.fallStart = this.pos.y;
    this.vel.set(0, 0, 0);
    this.spawned = true;
    this.updateBiome(1);
    this.autosaveTime = performance.now();
    this.emitHud();
  }

  private updateCrops(dt: number) {
    this.crops = this.crops.filter((crop) => {
      if (crop.dimension === this.dimension && this.world.getBlock(crop.x, crop.y, crop.z) !== -1) crop.remaining -= dt;
      if (crop.dimension !== this.dimension || crop.remaining > 0) return true;
      const block = this.world.getBlock(crop.x, crop.y, crop.z);
      if (block === -1) return true;
      if (block === (crop.plant ?? B.CROPS)) this.world.setBlock(crop.x, crop.y, crop.z, crop.result ?? B.RIPE_CROPS);
      return false;
    });
  }

  private clearPlantTimers(x: number, y: number, z: number) {
    const keep = (plant: { x: number; y: number; z: number; dimension: Dimension }) => plant.dimension !== this.dimension || plant.x !== x || plant.y !== y || plant.z !== z;
    this.saplings = this.saplings.filter(keep);
    this.crops = this.crops.filter(keep);
  }

  private tryGrowTree(kind: WoodKind, x: number, y: number, z: number) {
    const body: Bounds = [this.pos.x - HW, this.pos.y, this.pos.z - HW, this.pos.x + HW, this.pos.y + PH, this.pos.z + HW];
    const shape = treeBlocks(kind, x, y - 1, z, this.meta.seed);
    if (shape.some(([px, py, pz]) => intersects(body, [0, 0, 0, 1, 1, 1], px, py, pz))) return false;
    return this.world.growTree(kind, x, y, z);
  }

  private updateTrees(dt: number) {
    this.saplingTimer += dt;
    if (this.saplingTimer < 1) return;
    const elapsed = this.saplingTimer; this.saplingTimer = 0;
    this.saplings = this.saplings.filter((sapling) => {
      if (sapling.dimension !== this.dimension) return true;
      const block = this.world.getBlock(sapling.x, sapling.y, sapling.z);
      if (block === -1) return true;
      if (block !== sapling.block) return false;
      sapling.remaining -= elapsed;
      if (sapling.remaining > 0) return true;
      const wood = WOODS.find((w) => w.sapling === block);
      if (wood && this.tryGrowTree(wood.key, sapling.x, sapling.y, sapling.z)) return false;
      sapling.remaining = 10; return true;
    });
  }

  private updateBiome(dt: number) {
    this.biomeTimer += dt;
    if (this.biomeTimer < 0.8) return;
    this.biomeTimer = 0;
    if (this.dimension === 'overworld') {
      this.biomeId = this.world.biomeAt(this.pos.x, this.pos.z);
      const discoveries = this.adventure.biomes ??= [];
      if (!discoveries.includes(this.biomeId)) {
        discoveries.push(this.biomeId);
        if (discoveries.length > 1) { this.notify(`Novo bioma: ${BIOME_BY_ID[this.biomeId].name}. Veja seu atlas na Jornada.`); this.adventure.xp += 3; }
      }
    }
    const cave = this.dimension === 'overworld' && this.pos.y < this.world.heightAt(this.pos.x, this.pos.z) - 8;
    setMusicScene(cave ? 'cave' : this.dimension, this.biomeId, Math.sin(this.time * Math.PI * 2) < 0);
  }

  locateBiome(id: BiomeId) {
    if (this.dimension !== 'overworld') { this.notify('Procure biomas na superfície.'); return false; }
    if (!BIOME_BY_ID[id]) return false;
    let found: { x: number; z: number } | null = null;
    for (let radius = 0; radius <= 1536 && !found; radius += 48) {
      const samples = Math.max(1, Math.ceil(radius / 12));
      for (let i = 0; i < samples; i++) {
        const angle = i / samples * Math.PI * 2;
        const x = Math.round(this.pos.x + Math.cos(angle) * radius), z = Math.round(this.pos.z + Math.sin(angle) * radius);
        if (this.world.biomeAt(x, z) === id) { found = { x, z }; break; }
      }
    }
    if (!found) { this.notify('Não encontrado nesta região. Explore mais longe ou crie um mundo Terras Vivas.'); return false; }
    this.waypoint = { ...found, name: BIOME_BY_ID[id].name }; this.emitHud();
    this.notify(`Destino marcado: ${this.waypoint.name}. Não há teletransporte; siga as coordenadas.`);
    return true;
  }

  clearWaypoint() { this.waypoint = undefined; this.emitHud(); }

  private queueEnvironment(x: number, y: number, z: number) {
    for (let dy = 0; dy <= 2; dy++) if (y + dy < CH) this.environmentalQueue.add(`${x},${y + dy},${z}`);
  }

  private updateEnvironment(dt: number) {
    this.environmentTimer += dt;
    if (this.environmentTimer < 0.08) return;
    this.environmentTimer = 0;
    const keys = [...this.environmentalQueue].slice(0, 40);
    for (const key of keys) {
      this.environmentalQueue.delete(key);
      const [x, y, z] = key.split(',').map(Number);
      const id = this.world.getBlock(x, y, z), below = this.world.getBlock(x, y - 1, z);
      if (id <= 0 || below === -1) continue;
      if ((id === B.SAND || id === B.RED_SAND || id === B.GRAVEL) && (below === 0 || below === B.WATER)) {
        this.world.setBlock(x, y, z, 0); this.world.setBlock(x, y - 1, z, id);
        this.queueEnvironment(x, y - 1, z); this.queueEnvironment(x, y + 1, z);
      }
      if ((PLANT_IDS.has(id) || id === B.TORCH)
        && (!(id === B.SUGAR_CANE && below === B.SUGAR_CANE) && !isSolid(below) || (id === B.CROPS || id === B.RIPE_CROPS) && below !== B.FARMLAND)) {
        this.world.setBlock(x, y, z, 0);
        this.clearPlantTimers(x, y, z);
        const def = BLOCKS[id], drop = def.drop ?? id;
        if (drop) this.dropLoot(drop, def.dropCount ?? 1, new THREE.Vector3(x + 0.5, y + 0.4, z + 0.5));
      }
    }
  }

  emitHud() {
    const info = this.renderer.info.render;
    this.cb.onHud({
      health: this.health,
      inventory: this.inventory.map((s) => (s ? { ...s } : null)),
      selected: this.selected,
      fps: this.fps,
      flying: this.flying,
      loading: this.spawned ? 1 : this.loadProgress(),
      loaded: this.spawned,
      dead: this.dead,
      underwater: this.underwater,
      pos: [this.pos.x, this.pos.y, this.pos.z],
      breakProgress: this.breakProgress,
      target: this.target ? BLOCKS[this.target.id].name : '',
      targetId: this.target ? this.target.id : 0,
      chunks: this.world.chunks.size,
      drawCalls: info.calls,
      tris: info.triangles,
      hurt: this.hurtCounter,
      timeOfDay: this.time,
      equipment: Object.fromEntries(ARMOR_SLOTS.map((key) => [key, this.equipment[key] ? { ...this.equipment[key] } : null])) as Equipment,
      armor: this.armorPoints(),
      adventure: { ...this.adventure, collected: [...this.adventure.collected], crafted: [...this.adventure.crafted], crystals: [...this.adventure.crystals] },
      dimension: this.dimension,
      notice: this.notice,
      combatTarget: this.spawned ? this.combat.getTarget() : null,
      bossPhase: this.combat.phase,
      attackReady: Math.max(0, 1 - this.attackCooldown / this.attackDuration),
      reserveCount: this.reserve.reduce((n, slot) => n + slot.count, 0),
      portalCharge: this.portals.charge,
      droppedCount: this.drops.count,
      resolution: this.effectiveResolution,
      subtitle: this.subtitle,
      deathPoint: this.deathPoint,
      air: this.air,
      hunger: this.hunger.food,
      saturation: this.hunger.saturation,
      eating: this.eating?.progress ?? 0,
      biome: this.dimension === 'overworld' ? BIOME_BY_ID[this.biomeId].name : DIMENSION_NAMES[this.dimension],
      biomeId: this.biomeId,
      chest: this.openChestKey && this.chestAccessible() ? cloneInventory(this.chests[this.openChestKey] ?? Array(27).fill(null)) : null,
      waypoint: this.waypoint,
      cursor: this.cursor ? { ...this.cursor } : null,
      personalCraft: cloneInventory(this.personalCraft),
    });
  }
}
