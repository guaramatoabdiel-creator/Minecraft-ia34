import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { B, I, maxStack, toolId } from '../src/game/blocks.ts';
import { clickStack, sameStack, makeSlot, insertItem, transferStack } from '../src/game/inventory.ts';
import { chooseBehavior, inVisionCone, interceptSeconds, type Senses } from '../src/game/mobBrain.ts';
import { standingHeight, canTraverse, findPath } from '../src/game/navigation.ts';
import { clearLine, firstBlockIntersection } from '../src/game/collision.ts';
import { detailedItemPixels } from '../src/game/itemArt.ts';
import { Engine } from '../src/game/engine.ts';
import { CombatSystem } from '../src/game/combat.ts';
import { newAdventure } from '../src/game/adventure.ts';
import { defaultSettings, type Slot } from '../src/game/settings.ts';
import { parseWorldBackup } from '../src/game/backups.ts';
import { setSoundEnabled } from '../src/game/sound.ts';

setSoundEnabled(false);

function field() {
  const cells = new Map<string, number>();
  return {
    revision: 0,
    getState: () => 0,
    getBlock(x: number, y: number, z: number) { return cells.get(`${x},${y},${z}`) ?? (y <= 0 ? B.STONE : B.AIR); },
    set(x: number, y: number, z: number, id: number) { cells.set(`${x},${y},${z}`, id); this.revision++; },
    heightAt: () => 0,
  };
}

test('right click picks up half an odd stack, then places one at a time', () => {
  const first = clickStack(makeSlot(B.STONE, 9), null, true);
  assert.equal(first.target?.count, 4); assert.equal(first.carried?.count, 5);
  const second = clickStack(null, first.carried, true);
  assert.equal(second.target?.count, 1); assert.equal(second.carried?.count, 4);
  const third = clickStack(makeSlot(B.STONE, 63), second.carried);
  assert.equal(third.target?.count, 64); assert.equal(third.carried?.count, 3);
});

test('cursor swaps preserve enchantments and never stack soups or tools', () => {
  const tool = { ...makeSlot(toolId('iron', 'sword')), durability: 47, enchant: 2 };
  const result = clickStack(makeSlot(B.DIRT, 12), tool);
  assert.deepEqual(result.target, tool); assert.equal(result.carried?.count, 12);
  assert.equal(maxStack(I.STEW), 1);
  const soups = clickStack(makeSlot(I.STEW), makeSlot(I.STEW), true);
  assert.equal(soups.target?.count, 1); assert.equal(soups.carried?.count, 1);
  assert.equal(sameStack(tool, { ...tool, enchant: 3 }), false);
  const bag: (Slot | null)[] = [makeSlot(B.STONE, 3), null];
  assert.equal(transferStack(bag, bag, 0), 0);
  assert.equal(bag[0]?.count, 3);
});

test('actual personal crafting inputs are consumed exactly once; closing a full bag preserves the cursor', () => {
  const engine = Object.create(Engine.prototype) as Engine;
  Object.assign(engine, {
    inventory: Array(36).fill(null), cursor: null, personalCraft: [makeSlot(B.PLANKS, 2), makeSlot(B.BIRCH_PLANKS, 2), makeSlot(B.CHERRY_PLANKS, 2), makeSlot(B.SPRUCE_PLANKS, 2)],
    reserve: [], paused: true, dead: false, selected: 0, adventure: newAdventure(), meta: { mode: 'survival' }, emitHud: () => {},
  });
  assert.equal(engine.takePersonalCraft(), true);
  assert.equal(engine.cursor?.id, B.CRAFTING); assert.equal(engine.cursor?.count, 1);
  assert.ok(engine.personalCraft.every((slot) => slot?.count === 1));
  assert.equal(engine.takePersonalCraft(), true); assert.equal(engine.cursor?.count, 2);
  assert.ok(engine.personalCraft.every((slot) => slot === null));
  assert.equal(engine.takePersonalCraft(), false);
  engine.inventory = Array.from({ length: 36 }, () => makeSlot(B.STONE, 64));
  engine.settleInventory();
  assert.equal(engine.cursor, null);
  assert.equal((engine as unknown as { reserve: Slot[] }).reserve[0].count, 2);
});

test('a creature cannot see through a thin fence even between coarse sampling points', () => {
  const world = field(); world.set(0, 1, 0, B.FENCE);
  const from = { x: -0.4, y: 1.7, z: 0.51 }, to = { x: 1.4, y: 1.7, z: 0.51 };
  assert.equal(clearLine(world, from, to, 2), false);
  const t = firstBlockIntersection(world, from, to);
  assert.ok(t !== null && t >= 0 && t <= 1);
  world.set(0, 1, 0, B.AIR);
  assert.equal(clearLine(world, from, to), true);
});

test('navigation respects wide bodies, ceiling clearance, hazards and a safe drop limit', () => {
  const world = field();
  for (let z = -2; z <= 2; z++) for (let y = 1; y <= 3; y++) { world.set(0, y, z, B.STONE); world.set(2, y, z, B.STONE); }
  assert.equal(standingHeight(world, 1.5, 0.5, 1, 1.8, 1, 0.28), 1);
  assert.equal(standingHeight(world, 1.5, 0.5, 1, 0.88, 1, 0.52), null);
  const cliff = field();
  for (let y = -5; y <= 1; y++) cliff.set(1, y, 0, B.AIR);
  assert.equal(standingHeight(cliff, 1.5, 0.5, 1, 1.8, 1, 0.28, 2), null);
  const ceiling = field(); ceiling.set(1, 1, 0, B.STONE); ceiling.set(0, 3, 0, B.STONE);
  assert.equal(canTraverse(ceiling, { x: 0.5, y: 1, z: 0.5 }, { x: 1.5, y: 2, z: 0.5 }), false);
  const lava = field(); lava.set(1, 1, 0, B.LAVA);
  assert.equal(standingHeight(lava, 1.5, 0.5, 1), null);
});

test('A star does not cut a diagonal corner between two solid columns', () => {
  const world = field();
  for (let y = 1; y <= 3; y++) { world.set(1, y, 0, B.STONE); world.set(0, y, 1, B.STONE); }
  const path = findPath(world, { x: 0.5, y: 1, z: 0.5 }, { x: 2.5, y: 1, z: 2.5 }, 1.8, 250);
  assert.ok(path.length > 0);
  assert.ok(!(path[0].x === 1.5 && path[0].z === 1.5));
});

test('state decisions use memory after losing sight and prioritize safety over attacking', () => {
  const senses: Senses = { passive: false, seesPlayer: true, distance: 10, anger: 6, memory: 6, afraid: 0, tempted: false, exposed: false, ranged: false, creeper: false, heard: false, stuck: false };
  assert.equal(chooseBehavior(senses), 'chase');
  assert.equal(chooseBehavior({ ...senses, seesPlayer: false }), 'search');
  assert.equal(chooseBehavior({ ...senses, seesPlayer: false, memory: 0 }), 'wander');
  assert.equal(chooseBehavior({ ...senses, exposed: true }), 'shelter');
  assert.equal(chooseBehavior({ ...senses, ranged: true, distance: 3 }), 'retreat');
  assert.equal(chooseBehavior({ ...senses, ranged: true }), 'aim');
  assert.equal(chooseBehavior({ ...senses, passive: true, tempted: true }), 'follow');
  assert.equal(chooseBehavior({ ...senses, passive: true, tempted: true, afraid: 2 }), 'flee');
  assert.equal(chooseBehavior({ ...senses, anger: 0, heard: true }), 'investigate');
  assert.equal(inVisionCone(0, 1, 0, -10, 10, false), false);
  assert.equal(inVisionCone(0, 1, 0, -10, 10, true), true);
  assert.equal(interceptSeconds(200, 15), 0.65);
});

test('creatures persist health and position without persisting transient meshes', () => {
  const host = { scene: new THREE.Scene(), world: field(), dimension: 'overworld', pos: new THREE.Vector3(), settings: defaultSettings(), adventure: newAdventure() } as unknown as Engine;
  const combat = new CombatSystem(host, [{ kind: 'zombie', position: [4.5, 1, 3.5], health: 7, yaw: 1.2, age: 8 }]);
  const saved = combat.serialize();
  assert.equal(saved.length, 1); assert.equal(saved[0].health, 7); assert.deepEqual(saved[0].position, [4.5, 1, 3.5]);
  assert.equal('group' in saved[0], false);
  combat.dispose();
});

test('backups preserve in-flight inventory transactions and mob state', () => {
  const exported = { format: 'mineblock-world', meta: { name: 'Teste', seed: 5, type: 'normal', mode: 'survival' }, save: { version: 4, mods: {}, cursor: makeSlot(I.DIAMOND, 4), personalCraft: [makeSlot(B.PLANKS, 3), null, null, null], mobs: { overworld: [{ kind: 'skeleton', position: [1, 2, 3], health: 9, yaw: 0, age: 2 }] } } };
  const imported = parseWorldBackup(JSON.stringify(exported));
  assert.equal(imported.save.cursor?.count, 4); assert.equal(imported.save.personalCraft?.[0]?.count, 3); assert.equal(imported.save.mobs?.overworld?.[0].health, 9);
});

test('the original item art has clean pixel alpha and different tool silhouettes', () => {
  const sword = detailedItemPixels(toolId('diamond', 'sword'))!;
  const pickaxe = detailedItemPixels(toolId('diamond', 'pickaxe'))!;
  assert.equal(sword.length, 16 * 16 * 4);
  assert.notDeepEqual(sword, pickaxe);
  for (let i = 3; i < sword.length; i += 4) assert.ok(sword[i] === 0 || sword[i] === 255);
  const bag: (Slot | null)[] = [makeSlot(B.STONE, 60), null];
  assert.equal(insertItem(bag, B.STONE, 8), 0); assert.equal(bag[0]?.count, 64); assert.equal(bag[1]?.count, 4);
});