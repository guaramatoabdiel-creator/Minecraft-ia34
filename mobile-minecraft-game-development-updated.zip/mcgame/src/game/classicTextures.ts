import { hash3, hashString } from './noise';

type RGB = [number, number, number];
const colors: Record<string, RGB> = {
  grass_top: [105, 158, 65], grass_side: [125, 87, 58], dirt: [125, 87, 58], stone: [126, 126, 123],
  deepslate: [66, 67, 72], cobble: [120, 120, 114], mossy: [115, 119, 100],
  sand: [221, 211, 163], sandstone: [208, 193, 141], gravel: [134, 125, 119],
  planks: [173, 138, 81], log_side: [104, 82, 47], log_top: [171, 135, 80],
  birch_side: [218, 218, 201], birch_top: [201, 183, 134],
  leaves: [64, 123, 36], birch_leaves: [98, 143, 63], snow: [233, 241, 241], snow_side: [125, 87, 58],
  water: [48, 92, 193], lava: [232, 91, 20], obsidian: [30, 23, 46], bedrock: [77, 78, 77],
  netherrack: [112, 46, 47], ancient_debris: [106, 77, 66], end_stone: [216, 217, 159],
  furnace: [115, 116, 111], stone_bricks: [126, 126, 121], brick: [154, 76, 59],
  crafting_top: [160, 117, 65], crafting_side: [160, 117, 65],
  end_frame_top: [125, 156, 125], end_frame_eye: [125, 156, 125], end_frame_side: [93, 122, 99],
  end_surface: [13, 29, 30], portal: [121, 54, 178], glass: [190, 219, 225],
};
const ores: Record<string, RGB> = { coal: [39, 40, 39], iron: [210, 164, 138], copper: [205, 130, 77], gold: [242, 211, 71], diamond: [91, 219, 210], redstone: [195, 40, 41], lapis: [46, 85, 184], emerald: [50, 195, 94], quartz_ore: [237, 219, 198], nether_gold: [237, 192, 56] };

// Original 16-pixel motifs stay crisp at every pack resolution.
export function classicTile(name: string, size: number, time = 0): ImageData | null {
  const oreName = name.replace('deep_', '');
  const ore = ores[oreName];
  const baseName = ore ? name.startsWith('deep_') ? 'deepslate' : name === 'quartz_ore' || name === 'nether_gold' ? 'netherrack' : 'stone' : name;
  const base = colors[baseName];
  if (!base) return null;
  const image = new ImageData(size, size);
  const seed = hashString(name);
  const noise = (x: number, y: number, extra = 0) => hash3(x, y, extra, seed);
  const offset = Math.floor(time * 3);
  const orePoints = [[2, 3], [10, 2], [6, 7], [12, 10], [3, 12]];
  for (let py = 0; py < size; py++) for (let px = 0; px < size; px++) {
    const x = Math.floor(px / size * 16), y = Math.floor(py / size * 16);
    const coarse = noise(Math.floor(x / 3), Math.floor(y / 2));
    const fine = noise(x, y);
    let rgb = [...base] as RGB;
    let shade = (coarse - 0.5) * 0.16 + (fine - 0.5) * 0.13;
    let alpha = 255;
    if (baseName === 'stone' || baseName === 'deepslate') {
      shade = (coarse - 0.5) * 0.18 + (fine - 0.5) * 0.11;
      if (baseName === 'deepslate' && y % 4 === 3) shade -= 0.17;
      if (noise(Math.floor((x + y) / 4), Math.floor(y / 3)) < 0.2 && y % 3 === 0) shade -= 0.10;
    }
    if (baseName === 'dirt' || baseName === 'grass_side' || baseName === 'snow_side') {
      if (fine > 0.81) rgb = [151, 112, 75];
      else if (fine < 0.14) rgb = [94, 67, 48];
      if (fine > 0.94) rgb = [136, 132, 119];
      const fringe = [3, 4, 3, 2, 3, 5, 4, 3, 4, 5, 3, 3, 2, 3, 4, 3][x];
      if (baseName !== 'dirt' && y <= fringe) { rgb = baseName === 'snow_side' ? colors.snow : colors.grass_top; shade -= y === fringe ? 0.12 : 0; }
    }
    if (baseName === 'grass_top') {
      shade = (coarse - 0.5) * 0.22 + (fine - 0.5) * 0.21;
      if ((x + y * 3) % 13 === 0) rgb = [124, 170, 70];
    }
    if (baseName === 'planks' || baseName.startsWith('crafting')) {
      const row = Math.floor(y / 4), seam = [5, 11, 3, 12][row];
      shade = (noise(Math.floor(x / 5), y) - 0.5) * 0.16;
      if (y % 4 === 3 || x === seam) shade -= 0.24;
      else if (y % 4 === 0) shade += 0.07;
      if (baseName === 'crafting_top') {
        if (x < 2 || x > 13 || y < 2 || y > 13) rgb = [94, 65, 34];
        else if (x === 5 || x === 10 || y === 5 || y === 10) rgb = [72, 47, 27];
        else rgb = [180, 140, 87];
      }
      if (baseName === 'crafting_side') {
        if (y < 3 || x < 2 || x > 13) rgb = [91, 60, 33];
        if (y > 5 && y < 14 && (x === 4 || x === 11)) rgb = [72, 51, 29];
        if (y === 5 && (x > 2 && x < 7 || x > 9 && x < 13)) rgb = [169, 162, 136];
      }
    }
    if (baseName === 'log_side') {
      shade = (noise(Math.floor(x / 2), Math.floor(y / 7)) - 0.5) * 0.34;
      if (x % 4 === 0) shade -= 0.18;
      if (x % 4 === 1 && y % 9 < 6) shade += 0.12;
    }
    if (baseName === 'log_top' || baseName === 'birch_top') {
      const distance = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
      if (distance > 6.2) rgb = baseName === 'birch_top' ? colors.birch_side : colors.log_side;
      else if (Math.floor(distance) % 2 === 0) shade -= 0.17;
    }
    if (baseName === 'birch_side') {
      if ((y === 3 || y === 4) && x > 1 && x < 7 || y === 11 && x > 8 || y === 14 && x < 4) rgb = [64, 62, 51];
      shade *= 0.3;
    }
    if (baseName.includes('leaves')) {
      const leaf = (x % 4) + (y % 4);
      shade = fine * 0.28 - 0.09 + (leaf < 3 ? 0.15 : -0.1);
      if (fine < 0.12 || leaf === 0) alpha = 0;
    }
    if (baseName === 'cobble' || baseName === 'mossy') {
      const row = Math.floor(y / 4), lx = (x + row % 2 * 3) % 6, ly = y % 4;
      const seam = ly === 3 || lx === 0;
      shade = seam ? -0.35 : ly === 0 ? 0.13 : lx === 5 ? -0.12 : (fine - 0.5) * 0.15;
      if (baseName === 'mossy' && noise(Math.floor(x / 2), Math.floor(y / 3)) > 0.5) rgb = [79, 115, 55];
    }
    if (baseName === 'stone_bricks' || baseName === 'brick' || baseName === 'sandstone') {
      const rowHeight = baseName === 'stone_bricks' ? 8 : 4;
      const lx = (x + Math.floor(y / rowHeight) % 2 * 4) % 8, ly = y % rowHeight;
      if (ly === rowHeight - 1 || lx === 0) { rgb = baseName === 'brick' ? [172, 163, 143] : rgb; shade -= baseName === 'brick' ? 0 : 0.3; }
      else if (ly === 0) shade += 0.1;
    }
    if (baseName === 'obsidian') {
      shade = fine * 0.15;
      if (coarse > 0.7 && (y + x) % 3 !== 0) rgb = [58, 40, 81];
      if (fine > 0.95) rgb = [76, 51, 99];
    }
    if (baseName === 'bedrock') shade = (fine - 0.5) * 0.7;
    if (baseName === 'gravel') { shade = (fine - 0.5) * 0.45; if (coarse < 0.3) rgb = [94, 93, 92]; }
    if (baseName === 'netherrack') { if (coarse > 0.65) rgb = [149, 65, 60]; else if (fine < 0.22) rgb = [71, 36, 39]; }
    if (baseName === 'end_stone') { shade = fine < 0.13 ? -0.16 : (coarse - 0.5) * 0.1; }
    if (baseName === 'ancient_debris') {
      const lx = (x + Math.floor(y / 5) % 2 * 4) % 8, ly = y % 5;
      if (ly === 0 || lx === 0) rgb = [63, 45, 41];
      else if (ly === 1 || lx === 1) rgb = [158, 120, 95];
      else if (ly === 3 && lx > 2 && lx < 6) rgb = [126, 91, 74];
    }
    if (baseName === 'furnace') {
      if ((y > 2 && y < 6 || y > 9 && y < 14) && x > 2 && x < 13) rgb = y === 12 && x > 4 && x < 11 ? [180, 83, 31] : [39, 39, 38];
      if (x === 0 || y === 0) shade += 0.13;
      if (x === 15 || y === 15) shade -= 0.3;
    }
    if (baseName === 'water' || baseName === 'lava') {
      const wave = Math.sin((x + offset) * 0.72 + Math.sin(y * 0.5 + time)) + Math.cos((y + offset) * 0.6);
      shade = wave * (baseName === 'water' ? 0.07 : 0.16);
      if (baseName === 'water') { alpha = 178; if (wave > 1.3) rgb = [68, 124, 220]; }
      else if (wave > 0.6) rgb = [255, 164, 31];
    }
    if (baseName === 'glass') {
      shade = 0; alpha = 16;
      if (x === 0 || y === 0 || x === 15 || y === 15) { alpha = 205; rgb = [184, 215, 218]; }
      else if ((x - y === 3 || x - y === 6) && x < 13 && y < 8) { alpha = 135; rgb = [224, 244, 247]; }
    }
    if (baseName.startsWith('end_frame')) {
      if (baseName === 'end_frame_side') {
        if (y > 10) rgb = [206, 207, 149];
        if (x % 4 === 0 && y < 9) rgb = [53, 89, 67];
      } else {
        if (x < 2 || x > 13 || y < 2 || y > 13) rgb = [55, 90, 63];
        if (x >= 4 && x <= 11 && y >= 4 && y <= 11) rgb = [31, 54, 41];
        if (baseName === 'end_frame_eye' && x >= 5 && x <= 10 && y >= 5 && y <= 10) rgb = x === 7 || x === 8 ? [24, 45, 38] : [125, 208, 126];
      }
    }
    if (baseName === 'portal') shade = Math.sin(x * 0.6 + y * 0.5) * 0.3;
    if (baseName === 'end_surface' && fine > 0.965) rgb = [86, 185, 163];
    if (ore) {
      for (let i = 0; i < orePoints.length; i++) {
        const [ox, oy] = orePoints[i];
        const dx = x - ox, dy = y - oy;
        if (dx >= 0 && dx < 3 && dy >= 0 && dy < (i % 2 ? 2 : 3) && !(dx === 2 && dy === 2)) {
          rgb = ore; shade = dy === 0 ? 0.18 : dx === 0 ? -0.22 : -0.04;
          if (oreName === 'copper' && i % 2 === 0) rgb = [74, 142, 105];
        }
      }
    }
    const micro = size > 16 ? (noise(px, py, 9) - 0.5) * 0.025 : 0;
    const index = (py * size + px) * 4;
    for (let c = 0; c < 3; c++) image.data[index + c] = Math.min(255, Math.max(0, rgb[c] * (1 + shade + micro)));
    image.data[index + 3] = alpha;
  }
  return image;
}