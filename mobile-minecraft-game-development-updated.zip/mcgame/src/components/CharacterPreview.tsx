import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ExplorerModel, type Appearance } from '../game/playerModel';
import { ItemModels } from '../game/itemModels';
import type { Equipment, Slot } from '../game/settings';
import type { TexturePack } from '../game/textures';

export default function CharacterPreview({ appearance, equipment, held, pack }: { appearance: Appearance; equipment: Equipment; held: Slot | null; pack: TexturePack }) {
  const container = useRef<HTMLDivElement>(null), canvas = useRef<HTMLCanvasElement>(null);
  const latest = useRef({ equipment, held }); latest.current = { equipment, held };
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const element = container.current!, surface = canvas.current!;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ canvas: surface, alpha: true, antialias: false, powerPreference: 'low-power' }); }
    catch { setFailed(true); return; }
    setFailed(false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)); renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
    const scene = new THREE.Scene(), camera = new THREE.OrthographicCamera(-0.92, 0.92, 1.3, -1.3, 0.1, 20);
    camera.position.set(0, 1.04, 5); camera.lookAt(0, 1.02, 0);
    const avatar = new ExplorerModel(appearance); scene.add(avatar.root); avatar.root.rotation.y = -0.34;
    const models = new ItemModels(pack);
    let item: THREE.Mesh | null = null, shield: THREE.Mesh | null = null, heldKey = '', shieldKey = '';
    let yaw = -0.34, targetYaw = -0.34, targetPitch = 0, drag = false, lastX = 0, lastFrame = 0, request = 0;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const resize = () => {
      const { width, height } = element.getBoundingClientRect(); if (width < 1 || height < 1) return;
      renderer.setSize(width, height, false);
      const aspect = width / height; camera.left = -1.17 * aspect; camera.right = 1.17 * aspect; camera.top = 1.17; camera.bottom = -1.17; camera.updateProjectionMatrix();
    };
    const observer = new ResizeObserver(resize); observer.observe(element); resize();
    const pointerDown = (event: PointerEvent) => { drag = true; lastX = event.clientX; surface.setPointerCapture(event.pointerId); };
    const pointerMove = (event: PointerEvent) => {
      const rect = element.getBoundingClientRect();
      if (drag) { targetYaw += (event.clientX - lastX) * 0.025; lastX = event.clientX; }
      else targetYaw = -0.34 + (event.clientX - rect.left - rect.width / 2) / rect.width * 0.8;
      targetPitch = Math.max(-0.2, Math.min(0.2, (event.clientY - rect.top - rect.height / 2) / rect.height * 0.35));
    };
    const up = () => { drag = false; };
    const lost = (event: Event) => { event.preventDefault(); setFailed(true); };
    const restored = () => setFailed(false);
    surface.addEventListener('pointerdown', pointerDown); surface.addEventListener('pointermove', pointerMove);
    surface.addEventListener('pointerup', up); surface.addEventListener('pointercancel', up);
    surface.addEventListener('webglcontextlost', lost); surface.addEventListener('webglcontextrestored', restored);
    const loop = (time: number) => {
      request = requestAnimationFrame(loop);
      if (document.hidden || time - lastFrame < 40) return; lastFrame = time;
      avatar.setEquipment(latest.current.equipment);
      const slot = latest.current.held;
      const key = `${slot?.id ?? 0}:${slot?.enchant ?? 0}`;
      if (key !== heldKey) {
        heldKey = key; item?.removeFromParent(); item = null;
        if (slot) { item = models.create(slot.id, slot.enchant); item.scale.setScalar(0.48); item.position.set(0, -0.6, 0.1); item.rotation.set(-0.1, 0, -0.2); avatar.rightArm.add(item); }
      }
      const offhand = latest.current.equipment.offhand;
      const nextShield = `${offhand?.id ?? 0}:${offhand?.enchant ?? 0}`;
      if (nextShield !== shieldKey) {
        shieldKey = nextShield; shield?.removeFromParent(); shield = null;
        if (offhand) { shield = models.create(offhand.id, offhand.enchant); shield.scale.setScalar(0.6); shield.position.set(0.08, -0.4, 0.17); shield.rotation.y = -0.4; avatar.leftArm.add(shield); }
      }
      yaw += (targetYaw - yaw) * 0.15; avatar.root.rotation.y = yaw;
      avatar.head.rotation.x += (targetPitch - avatar.head.rotation.x) * 0.12;
      avatar.rightArm.rotation.x = item ? -0.25 : 0.02;
      avatar.rightArm.rotation.z = 0.04 + (reduced ? 0 : Math.sin(time * 0.0018) * 0.025);
      avatar.leftArm.rotation.z = -0.04 - (reduced ? 0 : Math.sin(time * 0.0018) * 0.025);
      renderer.render(scene, camera);
    };
    request = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(request); observer.disconnect();
      surface.removeEventListener('pointerdown', pointerDown); surface.removeEventListener('pointermove', pointerMove); surface.removeEventListener('pointerup', up); surface.removeEventListener('pointercancel', up);
      surface.removeEventListener('webglcontextlost', lost); surface.removeEventListener('webglcontextrestored', restored);
      avatar.dispose(); models.dispose(); renderer.dispose(); renderer.forceContextLoss();
    };
  }, [appearance.style, appearance.skin, pack]);

  return <div ref={container} className="explorer-preview" aria-label="Prévia 3D do seu explorador, com a armadura equipada">
    <canvas ref={canvas} style={{ touchAction: 'none' }} />
    {failed ? <span className="avatar-unavailable">Prévia 3D indisponível</span> : <span className="avatar-turn-hint">Arraste para girar</span>}
  </div>;
}